package org.json.simple;

public interface JSONAware {
  String toJSONString();
}


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/org/json/simple/JSONAware.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */