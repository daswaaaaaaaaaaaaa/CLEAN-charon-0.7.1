package org.spongepowered.asm.mixin.transformer.ext;

public interface IClassGenerator {
  byte[] generate(String paramString);
}


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/org/spongepowered/asm/mixin/transformer/ext/IClassGenerator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */