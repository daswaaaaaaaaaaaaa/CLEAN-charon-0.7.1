package org.spongepowered.asm.mixin.transformer.ext;

import java.io.File;

public interface IDecompiler {
  void decompile(File paramFile);
}


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/org/spongepowered/asm/mixin/transformer/ext/IDecompiler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */