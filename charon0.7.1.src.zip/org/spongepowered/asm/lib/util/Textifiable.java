package org.spongepowered.asm.lib.util;

import java.util.Map;
import org.spongepowered.asm.lib.Label;

public interface Textifiable {
  void textify(StringBuffer paramStringBuffer, Map<Label, String> paramMap);
}


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/org/spongepowered/asm/lib/util/Textifiable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */