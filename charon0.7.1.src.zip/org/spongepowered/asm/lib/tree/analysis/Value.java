package org.spongepowered.asm.lib.tree.analysis;

public interface Value {
  int getSize();
}


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/org/spongepowered/asm/lib/tree/analysis/Value.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */