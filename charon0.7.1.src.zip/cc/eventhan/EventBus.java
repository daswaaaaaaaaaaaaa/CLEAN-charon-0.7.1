/*     */ package cc.eventhan;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface EventBus
/*     */ {
/*     */   void subscribe(Listenable paramListenable);
/*     */   
/*     */   void subscribe(Listener paramListener);
/*     */   
/*     */   void subscribeAll(Listenable... listenables) {
/*  46 */     Arrays.<Listenable>stream(listenables).forEach(this::subscribe);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void subscribeAll(Iterable<Listenable> listenables) {
/*  58 */     listenables.forEach(this::subscribe);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void subscribeAll(Listener... listeners) {
/*  70 */     Arrays.<Listener>stream(listeners).forEach(this::subscribe);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void unsubscribe(Listenable paramListenable);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void unsubscribe(Listener paramListener);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void unsubscribeAll(Listenable... listenables) {
/* 100 */     Arrays.<Listenable>stream(listenables).forEach(this::unsubscribe);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   default void unsubscribeAll(Iterable<Listenable> listenables) {
/* 112 */     listenables.forEach(this::unsubscribe);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void unsubscribeAll(Listener... listeners) {
/* 124 */     Arrays.<Listener>stream(listeners).forEach(this::unsubscribe);
/*     */   }
/*     */   
/*     */   void post(Object paramObject);
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/eventhan/EventBus.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */