/*    */ package cc.eventhan;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum EventState
/*    */ {
/* 11 */   PRE, POST;
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/eventhan/EventState.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */