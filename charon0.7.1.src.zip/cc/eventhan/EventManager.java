/*     */ package cc.eventhan;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import java.util.stream.Collectors;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EventManager
/*     */   implements EventBus
/*     */ {
/*  22 */   private final Map<Listenable, List<Listener>> SUBSCRIPTION_CACHE = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  27 */   private final Map<Class<?>, List<Listener>> SUBSCRIPTION_MAP = new ConcurrentHashMap<>();
/*     */ 
/*     */   
/*     */   public void subscribe(Listenable listenable) {
/*  31 */     List<Listener> listeners = this.SUBSCRIPTION_CACHE.computeIfAbsent(listenable, o -> (List)Arrays.<Field>stream(o.getClass().getDeclaredFields()).filter(EventManager::isValidField).map(()).filter(Objects::nonNull).collect(Collectors.toList()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  38 */     listeners.forEach(this::subscribe);
/*     */   }
/*     */ 
/*     */   
/*     */   public void subscribe(Listener<?> listener) {
/*  43 */     List<Listener> listeners = this.SUBSCRIPTION_MAP.computeIfAbsent(listener.getTarget(), target -> new CopyOnWriteArrayList());
/*     */     
/*  45 */     int index = 0;
/*  46 */     for (; index < listeners.size() && 
/*  47 */       listener.getPriority() <= ((Listener)listeners.get(index)).getPriority(); index++);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  52 */     listeners.add(index, listener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void unsubscribe(Listenable listenable) {
/*  57 */     List<Listener> objectListeners = this.SUBSCRIPTION_CACHE.get(listenable);
/*  58 */     if (objectListeners == null) {
/*     */       return;
/*     */     }
/*  61 */     this.SUBSCRIPTION_MAP.values().forEach(listeners -> listeners.removeIf(objectListeners::contains));
/*     */   }
/*     */ 
/*     */   
/*     */   public void unsubscribe(Listener listener) {
/*  66 */     ((List)this.SUBSCRIPTION_MAP.get(listener.getTarget())).removeIf(l -> l.equals(listener));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void post(Object event) {
/*  72 */     List<Listener> listeners = this.SUBSCRIPTION_MAP.get(event.getClass());
/*  73 */     if (listeners != null) {
/*  74 */       listeners.forEach(listener -> listener.invoke(event));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isValidField(Field field) {
/*  88 */     return (field.isAnnotationPresent((Class)EventHandler.class) && Listener.class.isAssignableFrom(field.getType()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Listener asListener(Listenable listenable, Field field) {
/*     */     try {
/* 103 */       boolean accessible = field.isAccessible();
/* 104 */       field.setAccessible(true);
/* 105 */       Listener listener = (Listener)field.get(listenable);
/* 106 */       field.setAccessible(accessible);
/*     */       
/* 108 */       if (listener == null) {
/* 109 */         return null;
/*     */       }
/* 111 */       return listener;
/* 112 */     } catch (IllegalAccessException e) {
/* 113 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/eventhan/EventManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */