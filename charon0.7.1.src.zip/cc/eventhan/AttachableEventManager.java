/*    */ package cc.eventhan;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AttachableEventManager
/*    */   extends EventManager
/*    */   implements AttachableEventBus
/*    */ {
/* 18 */   private final List<EventBus> attached = new ArrayList<>();
/*    */ 
/*    */   
/*    */   public void subscribe(Listenable listenable) {
/* 22 */     super.subscribe(listenable);
/*    */     
/* 24 */     if (!this.attached.isEmpty()) {
/* 25 */       this.attached.forEach(bus -> bus.subscribe(listenable));
/*    */     }
/*    */   }
/*    */   
/*    */   public void subscribe(Listener listener) {
/* 30 */     super.subscribe(listener);
/*    */     
/* 32 */     if (!this.attached.isEmpty()) {
/* 33 */       this.attached.forEach(bus -> bus.subscribe(listener));
/*    */     }
/*    */   }
/*    */   
/*    */   public void unsubscribe(Listenable listenable) {
/* 38 */     super.unsubscribe(listenable);
/*    */     
/* 40 */     if (!this.attached.isEmpty()) {
/* 41 */       this.attached.forEach(bus -> bus.unsubscribe(listenable));
/*    */     }
/*    */   }
/*    */   
/*    */   public void unsubscribe(Listener listener) {
/* 46 */     super.unsubscribe(listener);
/*    */     
/* 48 */     if (!this.attached.isEmpty()) {
/* 49 */       this.attached.forEach(bus -> bus.unsubscribe(listener));
/*    */     }
/*    */   }
/*    */   
/*    */   public void post(Object event) {
/* 54 */     super.post(event);
/*    */     
/* 56 */     if (!this.attached.isEmpty()) {
/* 57 */       this.attached.forEach(bus -> bus.post(event));
/*    */     }
/*    */   }
/*    */   
/*    */   public void attach(EventBus bus) {
/* 62 */     if (!this.attached.contains(bus)) {
/* 63 */       this.attached.add(bus);
/*    */     }
/*    */   }
/*    */   
/*    */   public void detach(EventBus bus) {
/* 68 */     this.attached.remove(bus);
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/eventhan/AttachableEventManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */