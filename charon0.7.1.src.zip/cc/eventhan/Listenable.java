package cc.eventhan;

public interface Listenable {}


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/eventhan/Listenable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */