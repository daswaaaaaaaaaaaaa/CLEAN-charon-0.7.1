package cc.eventhan;

@FunctionalInterface
public interface EventHook<T> {
  void invoke(T paramT);
}


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/eventhan/EventHook.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */