package cc.eventhan;

public interface ICancellable {
  void cancel();
  
  boolean isCancelled();
}


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/eventhan/ICancellable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */