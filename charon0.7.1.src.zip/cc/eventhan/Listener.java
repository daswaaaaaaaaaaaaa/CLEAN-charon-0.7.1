/*    */ package cc.eventhan;
/*    */ 
/*    */ import java.util.function.Predicate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Listener<T>
/*    */   implements EventHook<T>
/*    */ {
/*    */   private final Class<T> target;
/*    */   private final EventHook<T> hook;
/*    */   private final Predicate<T>[] filters;
/*    */   private final int priority;
/*    */   
/*    */   @SafeVarargs
/*    */   public Listener(EventHook<T> hook, Predicate<T>... filters) {
/* 41 */     this(hook, 0, filters);
/*    */   }
/*    */ 
/*    */   
/*    */   @SafeVarargs
/*    */   public Listener(EventHook<T> hook, int priority, Predicate<T>... filters) {
/* 47 */     this.hook = hook;
/* 48 */     this.priority = priority;
/* 49 */     this.target = TypeResolver.resolveRawArgument(EventHook.class, hook.getClass());
/* 50 */     this.filters = filters;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Class<T> getTarget() {
/* 60 */     return this.target;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getPriority() {
/* 73 */     return this.priority;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void invoke(T event) {
/* 87 */     if (this.filters.length > 0) {
/* 88 */       for (Predicate<T> filter : this.filters) {
/* 89 */         if (!filter.test(event)) {
/*    */           return;
/*    */         }
/*    */       } 
/*    */     }
/* 94 */     this.hook.invoke(event);
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/eventhan/Listener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */