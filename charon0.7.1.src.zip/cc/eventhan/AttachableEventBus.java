package cc.eventhan;

public interface AttachableEventBus extends EventBus {
  void attach(EventBus paramEventBus);
  
  void detach(EventBus paramEventBus);
}


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/eventhan/AttachableEventBus.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */