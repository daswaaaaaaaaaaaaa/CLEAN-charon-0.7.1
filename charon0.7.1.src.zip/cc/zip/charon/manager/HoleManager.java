/*    */ package cc.zip.charon.manager;
/*    */ 
/*    */ import cc.zip.charon.features.Feature;
/*    */ import cc.zip.charon.util.BlockUtil;
/*    */ import cc.zip.charon.util.EntityUtil;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Comparator;
/*    */ import java.util.List;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.init.Blocks;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.util.math.Vec3i;
/*    */ 
/*    */ public class HoleManager extends Feature {
/* 16 */   private static final BlockPos[] surroundOffset = BlockUtil.toBlockPos(EntityUtil.getOffsets(0, true));
/* 17 */   private final List<BlockPos> midSafety = new ArrayList<>();
/* 18 */   private List<BlockPos> holes = new ArrayList<>();
/*    */   
/*    */   public void update() {
/* 21 */     if (!fullNullCheck()) {
/* 22 */       this.holes = calcHoles();
/*    */     }
/*    */   }
/*    */   
/*    */   public List<BlockPos> getHoles() {
/* 27 */     return this.holes;
/*    */   }
/*    */   
/*    */   public List<BlockPos> getMidSafety() {
/* 31 */     return this.midSafety;
/*    */   }
/*    */   
/*    */   public List<BlockPos> getSortedHoles() {
/* 35 */     this.holes.sort(Comparator.comparingDouble(hole -> mc.field_71439_g.func_174818_b(hole)));
/* 36 */     return getHoles();
/*    */   }
/*    */   
/*    */   public List<BlockPos> calcHoles() {
/* 40 */     ArrayList<BlockPos> safeSpots = new ArrayList<>();
/* 41 */     this.midSafety.clear();
/* 42 */     List<BlockPos> positions = BlockUtil.getSphere(EntityUtil.getPlayerPos((EntityPlayer)mc.field_71439_g), 6.0F, 6, false, true, 0);
/* 43 */     for (BlockPos pos : positions) {
/* 44 */       if (!mc.field_71441_e.func_180495_p(pos).func_177230_c().equals(Blocks.field_150350_a) || !mc.field_71441_e.func_180495_p(pos.func_177982_a(0, 1, 0)).func_177230_c().equals(Blocks.field_150350_a) || !mc.field_71441_e.func_180495_p(pos.func_177982_a(0, 2, 0)).func_177230_c().equals(Blocks.field_150350_a))
/*    */         continue; 
/* 46 */       boolean isSafe = true;
/* 47 */       boolean midSafe = true;
/* 48 */       for (BlockPos offset : surroundOffset) {
/* 49 */         Block block = mc.field_71441_e.func_180495_p(pos.func_177971_a((Vec3i)offset)).func_177230_c();
/* 50 */         if (BlockUtil.isBlockUnSolid(block)) {
/* 51 */           midSafe = false;
/*    */         }
/* 53 */         if (block != Blocks.field_150357_h && block != Blocks.field_150343_Z && block != Blocks.field_150477_bB && block != Blocks.field_150467_bQ)
/*    */         {
/* 55 */           isSafe = false; } 
/*    */       } 
/* 57 */       if (isSafe) {
/* 58 */         safeSpots.add(pos);
/*    */       }
/* 60 */       if (!midSafe)
/* 61 */         continue;  this.midSafety.add(pos);
/*    */     } 
/* 63 */     return safeSpots;
/*    */   }
/*    */   
/*    */   public boolean isSafe(BlockPos pos) {
/* 67 */     boolean isSafe = true; BlockPos[] arrayOfBlockPos; int i; byte b;
/* 68 */     for (arrayOfBlockPos = surroundOffset, i = arrayOfBlockPos.length, b = 0; b < i; ) { BlockPos offset = arrayOfBlockPos[b];
/* 69 */       Block block = mc.field_71441_e.func_180495_p(pos.func_177971_a((Vec3i)offset)).func_177230_c();
/* 70 */       if (block == Blocks.field_150357_h) { b++; continue; }
/* 71 */        isSafe = false; }
/*    */ 
/*    */     
/* 74 */     return isSafe;
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/manager/HoleManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */