/*    */ package cc.zip.charon.manager;
/*    */ 
/*    */ import cc.zip.charon.features.gui.components.Component;
/*    */ import cc.zip.charon.features.modules.client.ClickGui;
/*    */ import cc.zip.charon.util.ColorUtil;
/*    */ import java.awt.Color;
/*    */ 
/*    */ public class ColorManager
/*    */ {
/* 10 */   private float red = 1.0F;
/* 11 */   private float green = 1.0F;
/* 12 */   private float blue = 1.0F;
/* 13 */   private float alpha = 1.0F;
/* 14 */   private Color color = new Color(this.red, this.green, this.blue, this.alpha);
/*    */   
/*    */   public Color getColor() {
/* 17 */     return this.color;
/*    */   }
/*    */   
/*    */   public void setColor(Color color) {
/* 21 */     this.color = color;
/*    */   }
/*    */   
/*    */   public int getColorAsInt() {
/* 25 */     return ColorUtil.toRGBA(this.color);
/*    */   }
/*    */   
/*    */   public int getColorAsIntFullAlpha() {
/* 29 */     return ColorUtil.toRGBA(new Color(this.color.getRed(), this.color.getGreen(), this.color.getBlue(), 255));
/*    */   }
/*    */   
/*    */   public int getColorWithAlpha(int alpha) {
/* 33 */     if (((Boolean)(ClickGui.getInstance()).rainbow.getValue()).booleanValue()) {
/* 34 */       return ColorUtil.rainbow(Component.counter1[0] * ((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB();
/*    */     }
/* 36 */     return ColorUtil.toRGBA(new Color(this.red, this.green, this.blue, alpha / 255.0F));
/*    */   }
/*    */   
/*    */   public void setColor(float red, float green, float blue, float alpha) {
/* 40 */     this.red = red;
/* 41 */     this.green = green;
/* 42 */     this.blue = blue;
/* 43 */     this.alpha = alpha;
/* 44 */     updateColor();
/*    */   }
/*    */   
/*    */   public void updateColor() {
/* 48 */     setColor(new Color(this.red, this.green, this.blue, this.alpha));
/*    */   }
/*    */   
/*    */   public void setColor(int red, int green, int blue, int alpha) {
/* 52 */     this.red = red / 255.0F;
/* 53 */     this.green = green / 255.0F;
/* 54 */     this.blue = blue / 255.0F;
/* 55 */     this.alpha = alpha / 255.0F;
/* 56 */     updateColor();
/*    */   }
/*    */   
/*    */   public void setRed(float red) {
/* 60 */     this.red = red;
/* 61 */     updateColor();
/*    */   }
/*    */   
/*    */   public void setGreen(float green) {
/* 65 */     this.green = green;
/* 66 */     updateColor();
/*    */   }
/*    */   
/*    */   public void setBlue(float blue) {
/* 70 */     this.blue = blue;
/* 71 */     updateColor();
/*    */   }
/*    */   
/*    */   public void setAlpha(float alpha) {
/* 75 */     this.alpha = alpha;
/* 76 */     updateColor();
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/manager/ColorManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */