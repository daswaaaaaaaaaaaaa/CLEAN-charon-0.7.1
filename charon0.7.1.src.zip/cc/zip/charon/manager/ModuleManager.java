/*     */ package cc.zip.charon.manager;
/*     */ import cc.zip.charon.event.events.Render2DEvent;
/*     */ import cc.zip.charon.event.events.Render3DEvent;
/*     */ import cc.zip.charon.features.Feature;
/*     */ import cc.zip.charon.features.modules.Module;
/*     */ import cc.zip.charon.features.modules.client.ClickGui;
/*     */ import cc.zip.charon.features.modules.client.HUD;
/*     */ import cc.zip.charon.features.modules.combat.AutoCrystalDied;
/*     */ import cc.zip.charon.features.modules.combat.AutoMinecart;
/*     */ import cc.zip.charon.features.modules.combat.BedAura;
/*     */ import cc.zip.charon.features.modules.misc.AutoGG;
/*     */ import cc.zip.charon.features.modules.misc.ChatModifier;
/*     */ import cc.zip.charon.features.modules.misc.MCF;
/*     */ import cc.zip.charon.features.modules.misc.Modificator;
/*     */ import cc.zip.charon.features.modules.misc.NoHandShake;
/*     */ import cc.zip.charon.features.modules.misc.Tracker;
/*     */ import cc.zip.charon.features.modules.movement.Step;
/*     */ import cc.zip.charon.features.modules.movement.Velocity;
/*     */ import cc.zip.charon.features.modules.player.MCP;
/*     */ import cc.zip.charon.features.modules.player.MultiTask;
/*     */ import cc.zip.charon.features.modules.render.ArrowESP;
/*     */ import cc.zip.charon.features.modules.render.BlockHighlight;
/*     */ import cc.zip.charon.features.modules.render.CrossHairs;
/*     */ import cc.zip.charon.features.modules.render.Skeleton;
/*     */ import cc.zip.charon.features.modules.render.WorldTime;
/*     */ import cc.zip.charon.util.Util;
/*     */ import com.mojang.realmsclient.gui.ChatFormatting;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.stream.Collectors;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ 
/*     */ public class ModuleManager extends Feature {
/*  36 */   public ArrayList<Module> modules = new ArrayList<>();
/*  37 */   public List<Module> sortedModules = new ArrayList<>();
/*  38 */   public List<String> sortedModulesABC = new ArrayList<>();
/*     */   public Animation animationThread;
/*     */   
/*     */   public void init() {
/*  42 */     this.modules.add(new AutoCrystalDied());
/*  43 */     this.modules.add(new FeetXP());
/*  44 */     this.modules.add(new CharonRPC());
/*  45 */     this.modules.add(new CrossHairs());
/*  46 */     this.modules.add(new AutoRatSuppi());
/*  47 */     this.modules.add(new WorldTime());
/*  48 */     this.modules.add(new ElytraFly());
/*  49 */     this.modules.add(new Velocity());
/*  50 */     this.modules.add(new BedAura());
/*  51 */     this.modules.add(new CustomView());
/*  52 */     this.modules.add(new ClickGui());
/*  53 */     this.modules.add(new FontMod());
/*  54 */     this.modules.add(new ExtraTab());
/*  55 */     this.modules.add(new HUD());
/*  56 */     this.modules.add(new BlockHighlight());
/*  57 */     this.modules.add(new HoleESP());
/*  58 */     this.modules.add(new Skeleton());
/*  59 */     this.modules.add(new Wireframe());
/*  60 */     this.modules.add(new Replenish());
/*  61 */     this.modules.add(new SmallShield());
/*  62 */     this.modules.add(new HandChams());
/*  63 */     this.modules.add(new Trajectories());
/*  64 */     this.modules.add(new FakePlayer());
/*  65 */     this.modules.add(new TpsSync());
/*  66 */     this.modules.add(new MultiTask());
/*  67 */     this.modules.add(new MCP());
/*  68 */     this.modules.add(new LiquidInteract());
/*  69 */     this.modules.add(new Speedmine());
/*  70 */     this.modules.add(new ReverseStep());
/*  71 */     this.modules.add(new NoVoid());
/*  72 */     this.modules.add(new NoHandShake());
/*  73 */     this.modules.add(new BuildHeight());
/*  74 */     this.modules.add(new ChatModifier());
/*  75 */     this.modules.add(new MCF());
/*  76 */     this.modules.add(new Modificator());
/*  77 */     this.modules.add(new AutoGG());
/*  78 */     this.modules.add(new ToolTips());
/*  79 */     this.modules.add(new Tracker());
/*  80 */     this.modules.add(new PopCounter());
/*  81 */     this.modules.add(new Offhand());
/*  82 */     this.modules.add(new Surround());
/*  83 */     this.modules.add(new AutoTrap());
/*  84 */     this.modules.add(new AutoWeb());
/*  85 */     this.modules.add(new AutoCrystal());
/*  86 */     this.modules.add(new Killaura());
/*  87 */     this.modules.add(new Criticals());
/*  88 */     this.modules.add(new HoleFiller());
/*  89 */     this.modules.add(new AutoArmor());
/*  90 */     this.modules.add(new Speed());
/*  91 */     this.modules.add(new Step());
/*  92 */     this.modules.add(new Scaffold());
/*  93 */     this.modules.add(new TestPhase());
/*  94 */     this.modules.add(new FastPlace());
/*  95 */     this.modules.add(new ESP());
/*  96 */     this.modules.add(new Selftrap());
/*  97 */     this.modules.add(new NoHitBox());
/*  98 */     this.modules.add(new AutoMinecart());
/*  99 */     this.modules.add(new SelfFill());
/* 100 */     this.modules.add(new ArrowESP());
/*     */   }
/*     */   
/*     */   public Module getModuleByName(String name) {
/* 104 */     for (Module module : this.modules) {
/* 105 */       if (!module.getName().equalsIgnoreCase(name))
/* 106 */         continue;  return module;
/*     */     } 
/* 108 */     return null;
/*     */   }
/*     */   
/*     */   public <T extends Module> T getModuleByClass(Class<T> clazz) {
/* 112 */     for (Module module : this.modules) {
/* 113 */       if (!clazz.isInstance(module))
/* 114 */         continue;  return (T)module;
/*     */     } 
/* 116 */     return null;
/*     */   }
/*     */   
/*     */   public void enableModule(Class<Module> clazz) {
/* 120 */     Module module = getModuleByClass(clazz);
/* 121 */     if (module != null) {
/* 122 */       module.enable();
/*     */     }
/*     */   }
/*     */   
/*     */   public void disableModule(Class<Module> clazz) {
/* 127 */     Module module = getModuleByClass(clazz);
/* 128 */     if (module != null) {
/* 129 */       module.disable();
/*     */     }
/*     */   }
/*     */   
/*     */   public void enableModule(String name) {
/* 134 */     Module module = getModuleByName(name);
/* 135 */     if (module != null) {
/* 136 */       module.enable();
/*     */     }
/*     */   }
/*     */   
/*     */   public void disableModule(String name) {
/* 141 */     Module module = getModuleByName(name);
/* 142 */     if (module != null) {
/* 143 */       module.disable();
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isModuleEnabled(String name) {
/* 148 */     Module module = getModuleByName(name);
/* 149 */     return (module != null && module.isOn());
/*     */   }
/*     */   
/*     */   public boolean isModuleEnabled(Class<Module> clazz) {
/* 153 */     Module module = getModuleByClass(clazz);
/* 154 */     return (module != null && module.isOn());
/*     */   }
/*     */   
/*     */   public Module getModuleByDisplayName(String displayName) {
/* 158 */     for (Module module : this.modules) {
/* 159 */       if (!module.getDisplayName().equalsIgnoreCase(displayName))
/* 160 */         continue;  return module;
/*     */     } 
/* 162 */     return null;
/*     */   }
/*     */   
/*     */   public ArrayList<Module> getEnabledModules() {
/* 166 */     ArrayList<Module> enabledModules = new ArrayList<>();
/* 167 */     for (Module module : this.modules) {
/* 168 */       if (!module.isEnabled())
/* 169 */         continue;  enabledModules.add(module);
/*     */     } 
/* 171 */     return enabledModules;
/*     */   }
/*     */   
/*     */   public ArrayList<String> getEnabledModulesName() {
/* 175 */     ArrayList<String> enabledModules = new ArrayList<>();
/* 176 */     for (Module module : this.modules) {
/* 177 */       if (!module.isEnabled() || !module.isDrawn())
/* 178 */         continue;  enabledModules.add(module.getFullArrayString());
/*     */     } 
/* 180 */     return enabledModules;
/*     */   }
/*     */   
/*     */   public ArrayList<Module> getModulesByCategory(Module.Category category) {
/* 184 */     ArrayList<Module> modulesCategory = new ArrayList<>();
/* 185 */     this.modules.forEach(module -> {
/*     */           if (module.getCategory() == category) {
/*     */             modulesCategory.add(module);
/*     */           }
/*     */         });
/* 190 */     return modulesCategory;
/*     */   }
/*     */   
/*     */   public List<Module.Category> getCategories() {
/* 194 */     return Arrays.asList(Module.Category.values());
/*     */   }
/*     */   
/*     */   public void onLoad() {
/* 198 */     this.modules.stream().filter(Module::listening).forEach(MinecraftForge.EVENT_BUS::register);
/* 199 */     this.modules.forEach(Module::onLoad);
/*     */   }
/*     */   
/*     */   public void onUpdate() {
/* 203 */     this.modules.stream().filter(Feature::isEnabled).forEach(Module::onUpdate);
/*     */   }
/*     */   
/*     */   public void onTick() {
/* 207 */     this.modules.stream().filter(Feature::isEnabled).forEach(Module::onTick);
/*     */   }
/*     */   
/*     */   public void onRender2D(Render2DEvent event) {
/* 211 */     this.modules.stream().filter(Feature::isEnabled).forEach(module -> module.onRender2D(event));
/*     */   }
/*     */   
/*     */   public void onRender3D(Render3DEvent event) {
/* 215 */     this.modules.stream().filter(Feature::isEnabled).forEach(module -> module.onRender3D(event));
/*     */   }
/*     */   
/*     */   public void sortModules(boolean reverse) {
/* 219 */     this.sortedModules = (List<Module>)getEnabledModules().stream().filter(Module::isDrawn).sorted(Comparator.comparing(module -> Integer.valueOf(this.renderer.getStringWidth(module.getFullArrayString()) * (reverse ? -1 : 1)))).collect(Collectors.toList());
/*     */   }
/*     */   
/*     */   public void sortModulesABC() {
/* 223 */     this.sortedModulesABC = new ArrayList<>(getEnabledModulesName());
/* 224 */     this.sortedModulesABC.sort(String.CASE_INSENSITIVE_ORDER);
/*     */   }
/*     */   
/*     */   public void onLogout() {
/* 228 */     this.modules.forEach(Module::onLogout);
/*     */   }
/*     */   
/*     */   public void onLogin() {
/* 232 */     this.modules.forEach(Module::onLogin);
/*     */   }
/*     */   
/*     */   public void onUnload() {
/* 236 */     this.modules.forEach(MinecraftForge.EVENT_BUS::unregister);
/* 237 */     this.modules.forEach(Module::onUnload);
/*     */   }
/*     */   
/*     */   public void onUnloadPost() {
/* 241 */     for (Module module : this.modules) {
/* 242 */       module.enabled.setValue(Boolean.valueOf(false));
/*     */     }
/*     */   }
/*     */   
/*     */   public void onKeyPressed(int eventKey) {
/* 247 */     if (eventKey == 0 || !Keyboard.getEventKeyState() || mc.field_71462_r instanceof cc.zip.charon.features.gui.Gui) {
/*     */       return;
/*     */     }
/* 250 */     this.modules.forEach(module -> {
/*     */           if (module.getBind().getKey() == eventKey)
/*     */             module.toggle(); 
/*     */         });
/*     */   }
/*     */   
/*     */   private class Animation
/*     */     extends Thread
/*     */   {
/*     */     public Module module;
/*     */     public float offset;
/*     */     public float vOffset;
/*     */     ScheduledExecutorService service;
/*     */     
/*     */     public Animation() {
/* 265 */       super("Animation");
/* 266 */       this.service = Executors.newSingleThreadScheduledExecutor();
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/* 271 */       if ((HUD.getInstance()).renderingMode.getValue() == HUD.RenderingMode.Length) {
/* 272 */         for (Module module : ModuleManager.this.sortedModules) {
/* 273 */           String text = module.getDisplayName() + ChatFormatting.GRAY + ((module.getDisplayInfo() != null) ? (" [" + ChatFormatting.WHITE + module.getDisplayInfo() + ChatFormatting.GRAY + "]") : "");
/* 274 */           module.offset = ModuleManager.this.renderer.getStringWidth(text) / ((Integer)(HUD.getInstance()).animationHorizontalTime.getValue()).floatValue();
/* 275 */           module.vOffset = ModuleManager.this.renderer.getFontHeight() / ((Integer)(HUD.getInstance()).animationVerticalTime.getValue()).floatValue();
/* 276 */           if (module.isEnabled() && ((Integer)(HUD.getInstance()).animationHorizontalTime.getValue()).intValue() != 1) {
/* 277 */             if (module.arrayListOffset <= module.offset || Util.mc.field_71441_e == null)
/* 278 */               continue;  module.arrayListOffset -= module.offset;
/* 279 */             module.sliding = true;
/*     */             continue;
/*     */           } 
/* 282 */           if (!module.isDisabled() || ((Integer)(HUD.getInstance()).animationHorizontalTime.getValue()).intValue() == 1)
/* 283 */             continue;  if (module.arrayListOffset < ModuleManager.this.renderer.getStringWidth(text) && Util.mc.field_71441_e != null) {
/* 284 */             module.arrayListOffset += module.offset;
/* 285 */             module.sliding = true;
/*     */             continue;
/*     */           } 
/* 288 */           module.sliding = false;
/*     */         } 
/*     */       } else {
/* 291 */         for (String e : ModuleManager.this.sortedModulesABC) {
/* 292 */           Module module = Charon.moduleManager.getModuleByName(e);
/* 293 */           String text = module.getDisplayName() + ChatFormatting.GRAY + ((module.getDisplayInfo() != null) ? (" [" + ChatFormatting.WHITE + module.getDisplayInfo() + ChatFormatting.GRAY + "]") : "");
/* 294 */           module.offset = ModuleManager.this.renderer.getStringWidth(text) / ((Integer)(HUD.getInstance()).animationHorizontalTime.getValue()).floatValue();
/* 295 */           module.vOffset = ModuleManager.this.renderer.getFontHeight() / ((Integer)(HUD.getInstance()).animationVerticalTime.getValue()).floatValue();
/* 296 */           if (module.isEnabled() && ((Integer)(HUD.getInstance()).animationHorizontalTime.getValue()).intValue() != 1) {
/* 297 */             if (module.arrayListOffset <= module.offset || Util.mc.field_71441_e == null)
/* 298 */               continue;  module.arrayListOffset -= module.offset;
/* 299 */             module.sliding = true;
/*     */             continue;
/*     */           } 
/* 302 */           if (!module.isDisabled() || ((Integer)(HUD.getInstance()).animationHorizontalTime.getValue()).intValue() == 1)
/* 303 */             continue;  if (module.arrayListOffset < ModuleManager.this.renderer.getStringWidth(text) && Util.mc.field_71441_e != null) {
/* 304 */             module.arrayListOffset += module.offset;
/* 305 */             module.sliding = true;
/*     */             continue;
/*     */           } 
/* 308 */           module.sliding = false;
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void start() {
/* 315 */       System.out.println("Starting animation thread.");
/* 316 */       this.service.scheduleAtFixedRate(this, 0L, 1L, TimeUnit.MILLISECONDS);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/manager/ModuleManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */