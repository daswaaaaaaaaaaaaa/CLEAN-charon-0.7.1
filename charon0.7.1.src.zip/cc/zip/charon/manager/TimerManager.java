/*    */ package cc.zip.charon.manager;
/*    */ 
/*    */ import cc.zip.charon.Charon;
/*    */ import cc.zip.charon.features.Feature;
/*    */ import cc.zip.charon.features.modules.player.TimerSpeed;
/*    */ 
/*    */ public class TimerManager
/*    */   extends Feature
/*    */ {
/* 10 */   private float timer = 1.0F;
/*    */   private TimerSpeed module;
/*    */   
/*    */   public void init() {
/* 14 */     this.module = Charon.moduleManager.<TimerSpeed>getModuleByClass(TimerSpeed.class);
/*    */   }
/*    */   
/*    */   public void unload() {
/* 18 */     this.timer = 1.0F;
/* 19 */     mc.field_71428_T.field_194149_e = 50.0F;
/*    */   }
/*    */   
/*    */   public void update() {
/* 23 */     if (this.module != null && this.module.isEnabled()) {
/* 24 */       this.timer = this.module.speed;
/*    */     }
/* 26 */     mc.field_71428_T.field_194149_e = 50.0F / ((this.timer <= 0.0F) ? 0.1F : this.timer);
/*    */   }
/*    */   
/*    */   public float getTimer() {
/* 30 */     return this.timer;
/*    */   }
/*    */   
/*    */   public void setTimer(float timer) {
/* 34 */     if (timer > 0.0F) {
/* 35 */       this.timer = timer;
/*    */     }
/*    */   }
/*    */   
/*    */   public void reset() {
/* 40 */     this.timer = 1.0F;
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/manager/TimerManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */