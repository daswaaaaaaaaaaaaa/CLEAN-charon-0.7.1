/*    */ package cc.zip.charon.manager;
/*    */ import cc.zip.charon.features.Feature;
/*    */ import cc.zip.charon.features.command.Command;
/*    */ import cc.zip.charon.features.command.commands.FriendCommand;
/*    */ import cc.zip.charon.features.command.commands.ModuleCommand;
/*    */ import cc.zip.charon.features.command.commands.ReloadCommand;
/*    */ import cc.zip.charon.features.command.commands.UnloadCommand;
/*    */ import com.mojang.realmsclient.gui.ChatFormatting;
/*    */ import java.util.ArrayList;
/*    */ import java.util.LinkedList;
/*    */ 
/*    */ public class CommandManager extends Feature {
/* 13 */   private final ArrayList<Command> commands = new ArrayList<>();
/* 14 */   private String clientMessage = "[charon.eu]";
/* 15 */   private String prefix = ".";
/*    */   
/*    */   public CommandManager() {
/* 18 */     super("Command");
/* 19 */     this.commands.add(new ClientInfoCommand());
/* 20 */     this.commands.add(new BindCommand());
/* 21 */     this.commands.add(new ModuleCommand());
/* 22 */     this.commands.add(new PrefixCommand());
/* 23 */     this.commands.add(new ConfigCommand());
/* 24 */     this.commands.add(new FriendCommand());
/* 25 */     this.commands.add(new HelpCommand());
/* 26 */     this.commands.add(new ReloadCommand());
/* 27 */     this.commands.add(new UnloadCommand());
/* 28 */     this.commands.add(new ReloadSoundCommand());
/*    */   }
/*    */   
/*    */   public static String[] removeElement(String[] input, int indexToDelete) {
/* 32 */     LinkedList<String> result = new LinkedList<>();
/* 33 */     for (int i = 0; i < input.length; i++) {
/* 34 */       if (i != indexToDelete)
/* 35 */         result.add(input[i]); 
/*    */     } 
/* 37 */     return result.<String>toArray(input);
/*    */   }
/*    */   
/*    */   private static String strip(String str, String key) {
/* 41 */     if (str.startsWith(key) && str.endsWith(key)) {
/* 42 */       return str.substring(key.length(), str.length() - key.length());
/*    */     }
/* 44 */     return str;
/*    */   }
/*    */   
/*    */   public void executeCommand(String command) {
/* 48 */     String[] parts = command.split(" (?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
/* 49 */     String name = parts[0].substring(1);
/* 50 */     String[] args = removeElement(parts, 0);
/* 51 */     for (int i = 0; i < args.length; i++) {
/* 52 */       if (args[i] != null)
/* 53 */         args[i] = strip(args[i], "\""); 
/*    */     } 
/* 55 */     for (Command c : this.commands) {
/* 56 */       if (!c.getName().equalsIgnoreCase(name))
/* 57 */         continue;  c.execute(parts);
/*    */       return;
/*    */     } 
/* 60 */     Command.sendMessage(ChatFormatting.GRAY + "Command not found, type 'help' for the commands list.");
/*    */   }
/*    */   
/*    */   public Command getCommandByName(String name) {
/* 64 */     for (Command command : this.commands) {
/* 65 */       if (!command.getName().equals(name))
/* 66 */         continue;  return command;
/*    */     } 
/* 68 */     return null;
/*    */   }
/*    */   
/*    */   public ArrayList<Command> getCommands() {
/* 72 */     return this.commands;
/*    */   }
/*    */   
/*    */   public String getClientMessage() {
/* 76 */     return this.clientMessage;
/*    */   }
/*    */   
/*    */   public void setClientMessage(String clientMessage) {
/* 80 */     this.clientMessage = clientMessage;
/*    */   }
/*    */   
/*    */   public String getPrefix() {
/* 84 */     return this.prefix;
/*    */   }
/*    */   
/*    */   public void setPrefix(String prefix) {
/* 88 */     this.prefix = prefix;
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/manager/CommandManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */