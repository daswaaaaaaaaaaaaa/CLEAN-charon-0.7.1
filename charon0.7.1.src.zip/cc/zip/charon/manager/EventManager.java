/*     */ package cc.zip.charon.manager;
/*     */ import cc.zip.charon.Charon;
/*     */ import cc.zip.charon.event.events.ConnectionEvent;
/*     */ import cc.zip.charon.event.events.PacketEvent;
/*     */ import cc.zip.charon.event.events.Render2DEvent;
/*     */ import cc.zip.charon.event.events.Render3DEvent;
/*     */ import cc.zip.charon.event.events.UpdateWalkingPlayerEvent;
/*     */ import cc.zip.charon.features.command.Command;
/*     */ import cc.zip.charon.features.modules.client.HUD;
/*     */ import cc.zip.charon.features.modules.misc.PopCounter;
/*     */ import cc.zip.charon.util.Timer;
/*     */ import com.google.common.base.Strings;
/*     */ import java.util.UUID;
/*     */ import net.minecraft.client.gui.ScaledResolution;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.network.play.server.SPacketEntityStatus;
/*     */ import net.minecraft.network.play.server.SPacketPlayerListItem;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.client.event.ClientChatEvent;
/*     */ import net.minecraftforge.client.event.RenderGameOverlayEvent;
/*     */ import net.minecraftforge.client.event.RenderWorldLastEvent;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import net.minecraftforge.event.entity.living.LivingEvent;
/*     */ import net.minecraftforge.fml.common.eventhandler.Event;
/*     */ import net.minecraftforge.fml.common.eventhandler.EventPriority;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import net.minecraftforge.fml.common.gameevent.TickEvent;
/*     */ import net.minecraftforge.fml.common.network.FMLNetworkEvent;
/*     */ import org.lwjgl.input.Keyboard;
/*     */ 
/*     */ public class EventManager extends Feature {
/*  33 */   private final Timer logoutTimer = new Timer();
/*     */   
/*     */   public void init() {
/*  36 */     MinecraftForge.EVENT_BUS.register(this);
/*     */   }
/*     */   
/*     */   public void onUnload() {
/*  40 */     MinecraftForge.EVENT_BUS.unregister(this);
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onUpdate(LivingEvent.LivingUpdateEvent event) {
/*  45 */     if (!fullNullCheck() && (event.getEntity().func_130014_f_()).field_72995_K && event.getEntityLiving().equals(mc.field_71439_g)) {
/*  46 */       Charon.inventoryManager.update();
/*  47 */       Charon.moduleManager.onUpdate();
/*  48 */       if ((HUD.getInstance()).renderingMode.getValue() == HUD.RenderingMode.Length) {
/*  49 */         Charon.moduleManager.sortModules(true);
/*     */       } else {
/*  51 */         Charon.moduleManager.sortModulesABC();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onClientConnect(FMLNetworkEvent.ClientConnectedToServerEvent event) {
/*  58 */     this.logoutTimer.reset();
/*  59 */     Charon.moduleManager.onLogin();
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onClientDisconnect(FMLNetworkEvent.ClientDisconnectionFromServerEvent event) {
/*  64 */     Charon.moduleManager.onLogout();
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onTick(TickEvent.ClientTickEvent event) {
/*  69 */     if (fullNullCheck())
/*     */       return; 
/*  71 */     Charon.moduleManager.onTick();
/*  72 */     for (EntityPlayer player : mc.field_71441_e.field_73010_i) {
/*  73 */       if (player == null || player.func_110143_aJ() > 0.0F)
/*     */         continue; 
/*  75 */       MinecraftForge.EVENT_BUS.post((Event)new DeathEvent(player));
/*  76 */       PopCounter.getInstance().onDeath(player);
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onUpdateWalkingPlayer(UpdateWalkingPlayerEvent event) {
/*  82 */     if (fullNullCheck())
/*     */       return; 
/*  84 */     if (event.getStage() == 0) {
/*  85 */       Charon.speedManager.updateValues();
/*  86 */       Charon.rotationManager.updateRotations();
/*  87 */       Charon.positionManager.updatePosition();
/*     */     } 
/*  89 */     if (event.getStage() == 1) {
/*  90 */       Charon.rotationManager.restoreRotations();
/*  91 */       Charon.positionManager.restorePosition();
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketReceive(PacketEvent.Receive event) {
/*  97 */     if (event.getStage() != 0)
/*     */       return; 
/*  99 */     Charon.serverManager.onPacketReceived();
/* 100 */     if (event.getPacket() instanceof SPacketEntityStatus) {
/* 101 */       SPacketEntityStatus packet = (SPacketEntityStatus)event.getPacket();
/* 102 */       if (packet.func_149160_c() == 35 && packet.func_149161_a((World)mc.field_71441_e) instanceof EntityPlayer) {
/* 103 */         EntityPlayer player = (EntityPlayer)packet.func_149161_a((World)mc.field_71441_e);
/* 104 */         MinecraftForge.EVENT_BUS.post((Event)new TotemPopEvent(player));
/* 105 */         PopCounter.getInstance().onTotemPop(player);
/*     */       } 
/*     */     } 
/* 108 */     if (event.getPacket() instanceof SPacketPlayerListItem && !fullNullCheck() && this.logoutTimer.passedS(1.0D)) {
/* 109 */       SPacketPlayerListItem packet = (SPacketPlayerListItem)event.getPacket();
/* 110 */       if (!SPacketPlayerListItem.Action.ADD_PLAYER.equals(packet.func_179768_b()) && !SPacketPlayerListItem.Action.REMOVE_PLAYER.equals(packet.func_179768_b()))
/*     */         return; 
/* 112 */       packet.func_179767_a().stream().filter(Objects::nonNull).filter(data -> (!Strings.isNullOrEmpty(data.func_179962_a().getName()) || data.func_179962_a().getId() != null))
/* 113 */         .forEach(data -> {
/*     */             String name;
/*     */             EntityPlayer entity;
/*     */             UUID id = data.func_179962_a().getId();
/*     */             switch (packet.func_179768_b()) {
/*     */               case ADD_PLAYER:
/*     */                 name = data.func_179962_a().getName();
/*     */                 MinecraftForge.EVENT_BUS.post((Event)new ConnectionEvent(0, id, name));
/*     */                 break;
/*     */               case REMOVE_PLAYER:
/*     */                 entity = mc.field_71441_e.func_152378_a(id);
/*     */                 if (entity != null) {
/*     */                   String logoutName = entity.func_70005_c_();
/*     */                   MinecraftForge.EVENT_BUS.post((Event)new ConnectionEvent(1, entity, id, logoutName));
/*     */                   break;
/*     */                 } 
/*     */                 MinecraftForge.EVENT_BUS.post((Event)new ConnectionEvent(2, id, null));
/*     */                 break;
/*     */             } 
/*     */           });
/*     */     } 
/* 134 */     if (event.getPacket() instanceof net.minecraft.network.play.server.SPacketTimeUpdate)
/* 135 */       Charon.serverManager.update(); 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onWorldRender(RenderWorldLastEvent event) {
/* 140 */     if (event.isCanceled())
/*     */       return; 
/* 142 */     mc.field_71424_I.func_76320_a("oyvey");
/* 143 */     GlStateManager.func_179090_x();
/* 144 */     GlStateManager.func_179147_l();
/* 145 */     GlStateManager.func_179118_c();
/* 146 */     GlStateManager.func_179120_a(770, 771, 1, 0);
/* 147 */     GlStateManager.func_179103_j(7425);
/* 148 */     GlStateManager.func_179097_i();
/* 149 */     GlStateManager.func_187441_d(1.0F);
/* 150 */     Render3DEvent render3dEvent = new Render3DEvent(event.getPartialTicks());
/* 151 */     Charon.moduleManager.onRender3D(render3dEvent);
/* 152 */     GlStateManager.func_187441_d(1.0F);
/* 153 */     GlStateManager.func_179103_j(7424);
/* 154 */     GlStateManager.func_179084_k();
/* 155 */     GlStateManager.func_179141_d();
/* 156 */     GlStateManager.func_179098_w();
/* 157 */     GlStateManager.func_179126_j();
/* 158 */     GlStateManager.func_179089_o();
/* 159 */     GlStateManager.func_179089_o();
/* 160 */     GlStateManager.func_179132_a(true);
/* 161 */     GlStateManager.func_179098_w();
/* 162 */     GlStateManager.func_179147_l();
/* 163 */     GlStateManager.func_179126_j();
/* 164 */     mc.field_71424_I.func_76319_b();
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void renderHUD(RenderGameOverlayEvent.Post event) {
/* 169 */     if (event.getType() == RenderGameOverlayEvent.ElementType.HOTBAR)
/* 170 */       Charon.textManager.updateResolution(); 
/*     */   }
/*     */   
/*     */   @SubscribeEvent(priority = EventPriority.LOW)
/*     */   public void onRenderGameOverlayEvent(RenderGameOverlayEvent.Text event) {
/* 175 */     if (event.getType().equals(RenderGameOverlayEvent.ElementType.TEXT)) {
/* 176 */       ScaledResolution resolution = new ScaledResolution(mc);
/* 177 */       Render2DEvent render2DEvent = new Render2DEvent(event.getPartialTicks(), resolution);
/* 178 */       Charon.moduleManager.onRender2D(render2DEvent);
/* 179 */       GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent(priority = EventPriority.NORMAL, receiveCanceled = true)
/*     */   public void onKeyInput(InputEvent.KeyInputEvent event) {
/* 185 */     if (Keyboard.getEventKeyState())
/* 186 */       Charon.moduleManager.onKeyPressed(Keyboard.getEventKey()); 
/*     */   }
/*     */   
/*     */   @SubscribeEvent(priority = EventPriority.HIGHEST)
/*     */   public void onChatSent(ClientChatEvent event) {
/* 191 */     if (event.getMessage().startsWith(Command.getCommandPrefix())) {
/* 192 */       event.setCanceled(true);
/*     */       try {
/* 194 */         mc.field_71456_v.func_146158_b().func_146239_a(event.getMessage());
/* 195 */         if (event.getMessage().length() > 1) {
/* 196 */           Charon.commandManager.executeCommand(event.getMessage().substring(Command.getCommandPrefix().length() - 1));
/*     */         } else {
/* 198 */           Command.sendMessage("Please enter a command.");
/*     */         } 
/* 200 */       } catch (Exception e) {
/* 201 */         e.printStackTrace();
/* 202 */         Command.sendMessage(ChatFormatting.RED + "An error occurred while running this command. Check the log!");
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/manager/EventManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */