/*    */ package cc.zip.charon.manager;
/*    */ 
/*    */ import cc.zip.charon.util.Util;
/*    */ import net.minecraft.network.Packet;
/*    */ import net.minecraft.network.play.client.CPacketHeldItemChange;
/*    */ 
/*    */ public class InventoryManager implements Util {
/*    */   public int currentPlayerItem;
/*  9 */   private int recoverySlot = -1;
/*    */   
/*    */   public void update() {
/* 12 */     if (this.recoverySlot != -1) {
/* 13 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange((this.recoverySlot == 8) ? 7 : (this.recoverySlot + 1)));
/* 14 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange(this.recoverySlot));
/* 15 */       mc.field_71439_g.field_71071_by.field_70461_c = this.recoverySlot;
/* 16 */       int i = mc.field_71439_g.field_71071_by.field_70461_c;
/* 17 */       if (i != this.currentPlayerItem) {
/* 18 */         this.currentPlayerItem = i;
/* 19 */         mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange(this.currentPlayerItem));
/*    */       } 
/* 21 */       this.recoverySlot = -1;
/*    */     } 
/*    */   }
/*    */   
/*    */   public void recoverSilent(int slot) {
/* 26 */     this.recoverySlot = slot;
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/manager/InventoryManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */