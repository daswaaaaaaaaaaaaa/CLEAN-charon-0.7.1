/*     */ package cc.zip.charon.manager;
/*     */ 
/*     */ import cc.zip.charon.Charon;
/*     */ import cc.zip.charon.features.Feature;
/*     */ import cc.zip.charon.features.gui.font.CustomFont;
/*     */ import cc.zip.charon.features.modules.client.FontMod;
/*     */ import cc.zip.charon.util.Timer;
/*     */ import java.awt.Font;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ 
/*     */ public class TextManager
/*     */   extends Feature
/*     */ {
/*  14 */   private final Timer idleTimer = new Timer();
/*     */   public int scaledWidth;
/*     */   public int scaledHeight;
/*     */   public int scaleFactor;
/*  18 */   private CustomFont customFont = new CustomFont(new Font("Verdana", 0, 17), true, false);
/*     */   private boolean idling;
/*     */   
/*     */   public TextManager() {
/*  22 */     updateResolution();
/*     */   }
/*     */   
/*     */   public void init(boolean startup) {
/*  26 */     FontMod cFont = Charon.moduleManager.<FontMod>getModuleByClass(FontMod.class);
/*     */     try {
/*  28 */       setFontRenderer(new Font((String)cFont.fontName.getValue(), ((Integer)cFont.fontStyle.getValue()).intValue(), ((Integer)cFont.fontSize.getValue()).intValue()), ((Boolean)cFont.antiAlias.getValue()).booleanValue(), ((Boolean)cFont.fractionalMetrics.getValue()).booleanValue());
/*  29 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void drawStringWithShadow(String text, float x, float y, int color) {
/*  35 */     drawString(text, x, y, color, true);
/*     */   }
/*     */   
/*     */   public void drawString(String text, float x, float y, int color, boolean shadow) {
/*  39 */     if (Charon.moduleManager.isModuleEnabled(FontMod.getInstance().getName())) {
/*  40 */       if (shadow) {
/*  41 */         this.customFont.drawStringWithShadow(text, x, y, color);
/*     */       } else {
/*  43 */         this.customFont.drawString(text, x, y, color);
/*     */       } 
/*     */       return;
/*     */     } 
/*  47 */     mc.field_71466_p.func_175065_a(text, x, y, color, shadow);
/*     */   }
/*     */   
/*     */   public int getStringWidth(String text) {
/*  51 */     if (Charon.moduleManager.isModuleEnabled(FontMod.getInstance().getName())) {
/*  52 */       return this.customFont.getStringWidth(text);
/*     */     }
/*  54 */     return mc.field_71466_p.func_78256_a(text);
/*     */   }
/*     */   
/*     */   public int getFontHeight() {
/*  58 */     if (Charon.moduleManager.isModuleEnabled(FontMod.getInstance().getName())) {
/*  59 */       String text = "A";
/*  60 */       return this.customFont.getStringHeight(text);
/*     */     } 
/*  62 */     return mc.field_71466_p.field_78288_b;
/*     */   }
/*     */   
/*     */   public void setFontRenderer(Font font, boolean antiAlias, boolean fractionalMetrics) {
/*  66 */     this.customFont = new CustomFont(font, antiAlias, fractionalMetrics);
/*     */   }
/*     */   
/*     */   public Font getCurrentFont() {
/*  70 */     return this.customFont.getFont();
/*     */   }
/*     */   
/*     */   public void updateResolution() {
/*  74 */     this.scaledWidth = mc.field_71443_c;
/*  75 */     this.scaledHeight = mc.field_71440_d;
/*  76 */     this.scaleFactor = 1;
/*  77 */     boolean flag = mc.func_152349_b();
/*  78 */     int i = mc.field_71474_y.field_74335_Z;
/*  79 */     if (i == 0) {
/*  80 */       i = 1000;
/*     */     }
/*  82 */     while (this.scaleFactor < i && this.scaledWidth / (this.scaleFactor + 1) >= 320 && this.scaledHeight / (this.scaleFactor + 1) >= 240) {
/*  83 */       this.scaleFactor++;
/*     */     }
/*  85 */     if (flag && this.scaleFactor % 2 != 0 && this.scaleFactor != 1) {
/*  86 */       this.scaleFactor--;
/*     */     }
/*  88 */     double scaledWidthD = (this.scaledWidth / this.scaleFactor);
/*  89 */     double scaledHeightD = (this.scaledHeight / this.scaleFactor);
/*  90 */     this.scaledWidth = MathHelper.func_76143_f(scaledWidthD);
/*  91 */     this.scaledHeight = MathHelper.func_76143_f(scaledHeightD);
/*     */   }
/*     */   
/*     */   public String getIdleSign() {
/*  95 */     if (this.idleTimer.passedMs(500L)) {
/*  96 */       this.idling = !this.idling;
/*  97 */       this.idleTimer.reset();
/*     */     } 
/*  99 */     if (this.idling) {
/* 100 */       return "_";
/*     */     }
/* 102 */     return "";
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/manager/TextManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */