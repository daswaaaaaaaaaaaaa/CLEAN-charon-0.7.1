/*    */ package cc.zip.charon.event;
/*    */ 
/*    */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Cancelable
/*    */ public class EventMo
/*    */   extends Event
/*    */ {
/*    */   Stage stage;
/*    */   
/*    */   public EventMo() {}
/*    */   
/*    */   public EventMo(Stage stage) {
/* 21 */     this.stage = stage;
/*    */   }
/*    */   
/*    */   public Stage getStage() {
/* 25 */     return this.stage;
/*    */   }
/*    */   
/*    */   public void setStage(Stage stage) {
/* 29 */     this.stage = stage;
/* 30 */     setCanceled(false);
/*    */   }
/*    */   
/*    */   public enum Stage {
/* 34 */     PRE,
/* 35 */     POST;
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/event/EventMo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */