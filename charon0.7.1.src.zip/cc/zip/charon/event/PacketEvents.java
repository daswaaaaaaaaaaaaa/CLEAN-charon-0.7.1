/*    */ package cc.zip.charon.event;
/*    */ 
/*    */ import net.minecraft.network.Packet;
/*    */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Cancelable
/*    */ public class PacketEvents
/*    */   extends EventMo
/*    */ {
/*    */   Packet<?> packet;
/*    */   
/*    */   public PacketEvents(Packet<?> packet, EventMo.Stage stage) {
/* 17 */     super(stage);
/* 18 */     this.packet = packet;
/*    */   }
/*    */   
/*    */   public Packet<?> getPacket() {
/* 22 */     return this.packet;
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/event/PacketEvents.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */