/*    */ package cc.zip.charon.event.events;
/*    */ 
/*    */ import cc.zip.charon.event.EventStage;
/*    */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*    */ 
/*    */ @Cancelable
/*    */ public class ChatEvent extends EventStage {
/*    */   private final String msg;
/*    */   
/*    */   public ChatEvent(String msg) {
/* 11 */     this.msg = msg;
/*    */   }
/*    */   
/*    */   public String getMsg() {
/* 15 */     return this.msg;
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/event/events/ChatEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */