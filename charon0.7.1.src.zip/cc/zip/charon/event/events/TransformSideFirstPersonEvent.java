/*    */ package cc.zip.charon.event.events;
/*    */ 
/*    */ import cc.zip.charon.event.EventStage;
/*    */ import net.minecraft.util.EnumHandSide;
/*    */ 
/*    */ public class TransformSideFirstPersonEvent
/*    */   extends EventStage {
/*    */   private final EnumHandSide enumHandSide;
/*    */   
/*    */   public TransformSideFirstPersonEvent(EnumHandSide enumHandSide) {
/* 11 */     this.enumHandSide = enumHandSide;
/*    */   }
/*    */   
/*    */   public EnumHandSide getEnumHandSide() {
/* 15 */     return this.enumHandSide;
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/event/events/TransformSideFirstPersonEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */