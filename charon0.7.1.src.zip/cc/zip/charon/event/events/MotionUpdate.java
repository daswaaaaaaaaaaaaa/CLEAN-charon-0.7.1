/*    */ package cc.zip.charon.event.events;
/*    */ 
/*    */ import cc.zip.charon.event.EventStage;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MotionUpdate
/*    */   extends EventStage
/*    */ {
/*    */   public int stage;
/*    */   
/*    */   public MotionUpdate(int stage) {
/* 14 */     this.stage = stage;
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/event/events/MotionUpdate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */