/*   */ package cc.zip.charon.event.events;
/*   */ 
/*   */ import cc.zip.charon.event.EventStage;
/*   */ 
/*   */ public class UpdateWalkingPlayerEvent
/*   */   extends EventStage {
/*   */   public UpdateWalkingPlayerEvent(int stage) {
/* 8 */     super(stage);
/*   */   }
/*   */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/event/events/UpdateWalkingPlayerEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */