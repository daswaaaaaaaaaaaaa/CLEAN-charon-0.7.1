/*    */ package cc.zip.charon.event.events;
/*    */ 
/*    */ import cc.zip.charon.event.EventMo;
/*    */ import cc.zip.charon.event.PacketEvents;
/*    */ import net.minecraft.network.Packet;
/*    */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*    */ 
/*    */ 
/*    */ 
/*    */ @Cancelable
/*    */ public class PacketSendEvent
/*    */   extends PacketEvents
/*    */ {
/*    */   public PacketSendEvent(Packet<?> packet, EventMo.Stage stage) {
/* 15 */     super(packet, stage);
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/event/events/PacketSendEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */