/*    */ package cc.zip.charon.event.events;
/*    */ 
/*    */ import cc.zip.charon.event.EventStage;
/*    */ 
/*    */ public class KeyEvent
/*    */   extends EventStage {
/*    */   private final int key;
/*    */   
/*    */   public KeyEvent(int key) {
/* 10 */     this.key = key;
/*    */   }
/*    */   
/*    */   public int getKey() {
/* 14 */     return this.key;
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/event/events/KeyEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */