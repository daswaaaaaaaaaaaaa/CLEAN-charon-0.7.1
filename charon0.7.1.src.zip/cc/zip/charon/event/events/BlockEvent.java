/*    */ package cc.zip.charon.event.events;
/*    */ 
/*    */ import cc.zip.charon.event.EventStage;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*    */ 
/*    */ @Cancelable
/*    */ public class BlockEvent extends EventStage {
/*    */   public BlockPos pos;
/*    */   public EnumFacing facing;
/*    */   
/*    */   public BlockEvent(int stage, BlockPos pos, EnumFacing facing) {
/* 14 */     super(stage);
/* 15 */     this.pos = pos;
/* 16 */     this.facing = facing;
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/event/events/BlockEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */