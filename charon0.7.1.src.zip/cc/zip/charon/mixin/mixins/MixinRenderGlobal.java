/*    */ package cc.zip.charon.mixin.mixins;
/*    */ 
/*    */ import cc.zip.charon.features.modules.movement.Speed;
/*    */ import net.minecraft.client.renderer.ChunkRenderContainer;
/*    */ import net.minecraft.client.renderer.RenderGlobal;
/*    */ import net.minecraft.client.renderer.entity.RenderManager;
/*    */ import net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher;
/*    */ import net.minecraft.util.math.AxisAlignedBB;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Redirect;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({RenderGlobal.class})
/*    */ public abstract class MixinRenderGlobal
/*    */ {
/*    */   @Redirect(method = {"setupTerrain"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/ChunkRenderContainer;initialize(DDD)V"))
/*    */   public void initializeHook(ChunkRenderContainer chunkRenderContainer, double viewEntityXIn, double viewEntityYIn, double viewEntityZIn) {
/* 22 */     double y = viewEntityYIn;
/* 23 */     if (Speed.getInstance().isOn() && ((Boolean)(Speed.getInstance()).noShake.getValue()).booleanValue() && (Speed.getInstance()).modes.getValue() != Speed.Mode.INSTANT && (Speed.getInstance()).antiShake) {
/* 24 */       y = (Speed.getInstance()).startY;
/*    */     }
/* 26 */     chunkRenderContainer.func_178004_a(viewEntityXIn, y, viewEntityZIn);
/*    */   }
/*    */   
/*    */   @Redirect(method = {"renderEntities"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/entity/RenderManager;setRenderPosition(DDD)V"))
/*    */   public void setRenderPositionHook(RenderManager renderManager, double renderPosXIn, double renderPosYIn, double renderPosZIn) {
/* 31 */     double y = renderPosYIn;
/* 32 */     if (Speed.getInstance().isOn() && ((Boolean)(Speed.getInstance()).noShake.getValue()).booleanValue() && (Speed.getInstance()).modes.getValue() != Speed.Mode.INSTANT && (Speed.getInstance()).antiShake) {
/* 33 */       y = (Speed.getInstance()).startY;
/*    */     }
/* 35 */     TileEntityRendererDispatcher.field_147555_c = y;
/* 36 */     renderManager.func_178628_a(renderPosXIn, y, renderPosZIn);
/*    */   }
/*    */   
/*    */   @Redirect(method = {"drawSelectionBox"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/util/math/AxisAlignedBB;offset(DDD)Lnet/minecraft/util/math/AxisAlignedBB;"))
/*    */   public AxisAlignedBB offsetHook(AxisAlignedBB axisAlignedBB, double x, double y, double z) {
/* 41 */     double yIn = y;
/* 42 */     if (Speed.getInstance().isOn() && ((Boolean)(Speed.getInstance()).noShake.getValue()).booleanValue() && (Speed.getInstance()).modes.getValue() != Speed.Mode.INSTANT && (Speed.getInstance()).antiShake) {
/* 43 */       yIn = (Speed.getInstance()).startY;
/*    */     }
/* 45 */     return axisAlignedBB.func_72317_d(x, y, z);
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/mixin/mixins/MixinRenderGlobal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */