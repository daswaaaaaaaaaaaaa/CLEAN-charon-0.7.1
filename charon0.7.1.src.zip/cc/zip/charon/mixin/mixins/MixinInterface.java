/*    */ package cc.zip.charon.mixin.mixins;
/*    */ 
/*    */ import net.minecraft.client.Minecraft;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface MixinInterface
/*    */ {
/* 20 */   public static final Minecraft mc = Minecraft.func_71410_x();
/* 21 */   public static final boolean nullCheck = (mc.field_71439_g == null || mc.field_71441_e == null);
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/mixin/mixins/MixinInterface.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */