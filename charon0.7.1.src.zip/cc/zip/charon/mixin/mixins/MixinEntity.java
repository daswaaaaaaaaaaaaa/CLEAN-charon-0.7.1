/*     */ package cc.zip.charon.mixin.mixins;
/*     */ 
/*     */ import cc.zip.charon.event.events.StepEvent;
/*     */ import cc.zip.charon.features.modules.misc.BetterPortals;
/*     */ import cc.zip.charon.util.none.PushEvents;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.crash.CrashReport;
/*     */ import net.minecraft.crash.CrashReportCategory;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.MoverType;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.SoundEvents;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.ReportedException;
/*     */ import net.minecraft.util.SoundEvent;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import net.minecraftforge.fml.common.eventhandler.Event;
/*     */ import org.spongepowered.asm.mixin.Final;
/*     */ import org.spongepowered.asm.mixin.Mixin;
/*     */ import org.spongepowered.asm.mixin.Overwrite;
/*     */ import org.spongepowered.asm.mixin.Shadow;
/*     */ import org.spongepowered.asm.mixin.injection.At;
/*     */ import org.spongepowered.asm.mixin.injection.Redirect;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Mixin({Entity.class})
/*     */ public abstract class MixinEntity
/*     */ {
/*     */   @Shadow
/*     */   public double field_70165_t;
/*     */   @Shadow
/*     */   public double field_70163_u;
/*     */   @Shadow
/*     */   public double field_70161_v;
/*     */   @Shadow
/*     */   public double field_70159_w;
/*     */   @Shadow
/*     */   public double field_70181_x;
/*     */   @Shadow
/*     */   public double field_70179_y;
/*     */   @Shadow
/*     */   public float field_70177_z;
/*     */   @Shadow
/*     */   public float field_70125_A;
/*     */   @Shadow
/*     */   public boolean field_70122_E;
/*     */   @Shadow
/*     */   public boolean field_70145_X;
/*     */   @Shadow
/*     */   public float field_70141_P;
/*     */   @Shadow
/*     */   public World field_70170_p;
/*     */   @Shadow
/*     */   @Final
/*     */   private double[] field_191505_aI;
/*     */   @Shadow
/*     */   private long field_191506_aJ;
/*     */   @Shadow
/*     */   protected boolean field_70134_J;
/*     */   @Shadow
/*     */   public float field_70138_W;
/*     */   @Shadow
/*     */   public boolean field_70123_F;
/*     */   @Shadow
/*     */   public boolean field_70124_G;
/*     */   @Shadow
/*     */   public boolean field_70132_H;
/*     */   @Shadow
/*     */   public float field_70140_Q;
/*     */   @Shadow
/*     */   public float field_82151_R;
/*     */   @Shadow
/*     */   private int field_190534_ay;
/*     */   @Shadow
/*     */   private int field_70150_b;
/*     */   @Shadow
/*     */   private float field_191959_ay;
/*     */   @Shadow
/*     */   protected Random field_70146_Z;
/*     */   
/*     */   @Shadow
/*     */   public abstract boolean func_70051_ag();
/*     */   
/*     */   @Shadow
/*     */   public abstract boolean func_184218_aH();
/*     */   
/*     */   @Shadow
/*     */   public abstract boolean func_70093_af();
/*     */   
/*     */   @Shadow
/*     */   public abstract void func_174826_a(AxisAlignedBB paramAxisAlignedBB);
/*     */   
/*     */   @Shadow
/*     */   public abstract AxisAlignedBB func_174813_aQ();
/*     */   
/*     */   @Shadow
/*     */   public abstract void func_174829_m();
/*     */   
/*     */   @Shadow
/*     */   protected abstract void func_184231_a(double paramDouble, boolean paramBoolean, IBlockState paramIBlockState, BlockPos paramBlockPos);
/*     */   
/*     */   @Shadow
/*     */   protected abstract boolean func_70041_e_();
/*     */   
/*     */   @Shadow
/*     */   public abstract boolean func_70090_H();
/*     */   
/*     */   @Shadow
/*     */   public abstract boolean func_184207_aI();
/*     */   
/*     */   @Shadow
/*     */   public abstract Entity func_184179_bs();
/*     */   
/*     */   @Shadow
/*     */   public abstract void func_184185_a(SoundEvent paramSoundEvent, float paramFloat1, float paramFloat2);
/*     */   
/*     */   @Shadow
/*     */   protected abstract void func_145775_I();
/*     */   
/*     */   @Shadow
/*     */   public abstract boolean func_70026_G();
/*     */   
/*     */   @Shadow
/*     */   protected abstract void func_180429_a(BlockPos paramBlockPos, Block paramBlock);
/*     */   
/*     */   @Shadow
/*     */   protected abstract SoundEvent func_184184_Z();
/*     */   
/*     */   @Shadow
/*     */   protected abstract float func_191954_d(float paramFloat);
/*     */   
/*     */   @Shadow
/*     */   protected abstract boolean func_191957_ae();
/*     */   
/*     */   @Shadow
/*     */   public abstract void func_85029_a(CrashReportCategory paramCrashReportCategory);
/*     */   
/*     */   @Shadow
/*     */   protected abstract void func_70081_e(int paramInt);
/*     */   
/*     */   @Shadow
/*     */   public abstract void func_70015_d(int paramInt);
/*     */   
/*     */   @Shadow
/*     */   protected abstract int func_190531_bD();
/*     */   
/*     */   @Shadow
/*     */   public abstract boolean func_70027_ad();
/*     */   
/*     */   @Shadow
/*     */   public abstract int func_82145_z();
/*     */   
/*     */   @Overwrite
/*     */   public void func_70091_d(MoverType type, double x, double y, double z) {
/* 167 */     Entity _this = (Entity)this;
/* 168 */     if (this.field_70145_X) {
/* 169 */       func_174826_a(func_174813_aQ().func_72317_d(x, y, z));
/* 170 */       func_174829_m();
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 176 */       if (type == MoverType.PISTON) {
/* 177 */         long i = this.field_70170_p.func_82737_E();
/* 178 */         if (i != this.field_191506_aJ) {
/* 179 */           Arrays.fill(this.field_191505_aI, 0.0D);
/* 180 */           this.field_191506_aJ = i;
/*     */         } 
/* 182 */         if (x != 0.0D) {
/* 183 */           int j = EnumFacing.Axis.X.ordinal();
/* 184 */           double d0 = MathHelper.func_151237_a(x + this.field_191505_aI[j], -0.51D, 0.51D);
/* 185 */           x = d0 - this.field_191505_aI[j];
/* 186 */           this.field_191505_aI[j] = d0;
/* 187 */           if (Math.abs(x) <= 9.999999747378752E-6D) {
/*     */             return;
/*     */           }
/* 190 */         } else if (y != 0.0D) {
/* 191 */           int l4 = EnumFacing.Axis.Y.ordinal();
/* 192 */           double d12 = MathHelper.func_151237_a(y + this.field_191505_aI[l4], -0.51D, 0.51D);
/* 193 */           y = d12 - this.field_191505_aI[l4];
/* 194 */           this.field_191505_aI[l4] = d12;
/* 195 */           if (Math.abs(y) <= 9.999999747378752E-6D) {
/*     */             return;
/*     */           }
/*     */         } else {
/* 199 */           if (z == 0.0D) {
/*     */             return;
/*     */           }
/* 202 */           int i5 = EnumFacing.Axis.Z.ordinal();
/* 203 */           double d13 = MathHelper.func_151237_a(z + this.field_191505_aI[i5], -0.51D, 0.51D);
/* 204 */           z = d13 - this.field_191505_aI[i5];
/* 205 */           this.field_191505_aI[i5] = d13;
/* 206 */           if (Math.abs(z) <= 9.999999747378752E-6D) {
/*     */             return;
/*     */           }
/*     */         } 
/*     */       } 
/* 211 */       this.field_70170_p.field_72984_F.func_76320_a("move");
/* 212 */       double d10 = this.field_70165_t;
/* 213 */       double d11 = this.field_70163_u;
/* 214 */       double d1 = this.field_70161_v;
/* 215 */       if (this.field_70134_J) {
/* 216 */         this.field_70134_J = false;
/* 217 */         x *= 0.25D;
/* 218 */         y *= 0.05000000074505806D;
/* 219 */         z *= 0.25D;
/* 220 */         this.field_70159_w = 0.0D;
/* 221 */         this.field_70181_x = 0.0D;
/* 222 */         this.field_70179_y = 0.0D;
/*     */       } 
/* 224 */       double d2 = x;
/* 225 */       double d3 = y;
/* 226 */       double d4 = z;
/* 227 */       if ((type == MoverType.SELF || type == MoverType.PLAYER) && this.field_70122_E && func_70093_af() && _this instanceof net.minecraft.entity.player.EntityPlayer) {
/* 228 */         double d5 = 0.05D;
/* 229 */         while (x != 0.0D && this.field_70170_p.func_184144_a(_this, func_174813_aQ().func_72317_d(x, -this.field_70138_W, 0.0D)).isEmpty()) {
/* 230 */           x = (x < 0.05D && x >= -0.05D) ? 0.0D : ((x > 0.0D) ? (x -= 0.05D) : (x += 0.05D));
/* 231 */           d2 = x;
/*     */         } 
/* 233 */         while (z != 0.0D && this.field_70170_p.func_184144_a(_this, func_174813_aQ().func_72317_d(0.0D, -this.field_70138_W, z)).isEmpty()) {
/* 234 */           z = (z < 0.05D && z >= -0.05D) ? 0.0D : ((z > 0.0D) ? (z -= 0.05D) : (z += 0.05D));
/* 235 */           d4 = z;
/*     */         } 
/* 237 */         while (x != 0.0D && z != 0.0D && this.field_70170_p.func_184144_a(_this, func_174813_aQ().func_72317_d(x, -this.field_70138_W, z)).isEmpty()) {
/* 238 */           x = (x < 0.05D && x >= -0.05D) ? 0.0D : ((x > 0.0D) ? (x -= 0.05D) : (x += 0.05D));
/* 239 */           d2 = x;
/* 240 */           z = (z < 0.05D && z >= -0.05D) ? 0.0D : ((z > 0.0D) ? (z -= 0.05D) : (z += 0.05D));
/* 241 */           d4 = z;
/*     */         } 
/*     */       } 
/* 244 */       List<AxisAlignedBB> list1 = this.field_70170_p.func_184144_a(_this, func_174813_aQ().func_72321_a(x, y, z));
/* 245 */       AxisAlignedBB axisalignedbb = func_174813_aQ();
/* 246 */       if (y != 0.0D) {
/* 247 */         int l = list1.size();
/* 248 */         for (int k = 0; k < l; k++) {
/* 249 */           y = ((AxisAlignedBB)list1.get(k)).func_72323_b(func_174813_aQ(), y);
/*     */         }
/* 251 */         func_174826_a(func_174813_aQ().func_72317_d(0.0D, y, 0.0D));
/*     */       } 
/* 253 */       if (x != 0.0D) {
/* 254 */         int l5 = list1.size();
/* 255 */         for (int j5 = 0; j5 < l5; j5++) {
/* 256 */           x = ((AxisAlignedBB)list1.get(j5)).func_72316_a(func_174813_aQ(), x);
/*     */         }
/* 258 */         if (x != 0.0D) {
/* 259 */           func_174826_a(func_174813_aQ().func_72317_d(x, 0.0D, 0.0D));
/*     */         }
/*     */       } 
/* 262 */       if (z != 0.0D) {
/* 263 */         int i6 = list1.size();
/* 264 */         for (int k5 = 0; k5 < i6; k5++) {
/* 265 */           z = ((AxisAlignedBB)list1.get(k5)).func_72322_c(func_174813_aQ(), z);
/*     */         }
/* 267 */         if (z != 0.0D) {
/* 268 */           func_174826_a(func_174813_aQ().func_72317_d(0.0D, 0.0D, z));
/*     */         }
/*     */       } 
/* 271 */       boolean flag = (this.field_70122_E || (d3 != y && d3 < 0.0D)), bl = flag;
/* 272 */       if (this.field_70138_W > 0.0F && flag && (d2 != x || d4 != z)) {
/* 273 */         StepEvent preEvent = new StepEvent(0, _this);
/* 274 */         MinecraftForge.EVENT_BUS.post((Event)preEvent);
/* 275 */         double d14 = x;
/* 276 */         double d6 = y;
/* 277 */         double d7 = z;
/* 278 */         AxisAlignedBB axisalignedbb1 = func_174813_aQ();
/* 279 */         func_174826_a(axisalignedbb);
/* 280 */         y = preEvent.getHeight();
/* 281 */         List<AxisAlignedBB> list = this.field_70170_p.func_184144_a(_this, func_174813_aQ().func_72321_a(d2, y, d4));
/* 282 */         AxisAlignedBB axisalignedbb2 = func_174813_aQ();
/* 283 */         AxisAlignedBB axisalignedbb3 = axisalignedbb2.func_72321_a(d2, 0.0D, d4);
/* 284 */         double d8 = y;
/* 285 */         int k1 = list.size();
/* 286 */         for (int j1 = 0; j1 < k1; j1++) {
/* 287 */           d8 = ((AxisAlignedBB)list.get(j1)).func_72323_b(axisalignedbb3, d8);
/*     */         }
/* 289 */         axisalignedbb2 = axisalignedbb2.func_72317_d(0.0D, d8, 0.0D);
/* 290 */         double d18 = d2;
/* 291 */         int i2 = list.size();
/* 292 */         for (int l1 = 0; l1 < i2; l1++) {
/* 293 */           d18 = ((AxisAlignedBB)list.get(l1)).func_72316_a(axisalignedbb2, d18);
/*     */         }
/* 295 */         axisalignedbb2 = axisalignedbb2.func_72317_d(d18, 0.0D, 0.0D);
/* 296 */         double d19 = d4;
/* 297 */         int k2 = list.size();
/* 298 */         for (int j2 = 0; j2 < k2; j2++) {
/* 299 */           d19 = ((AxisAlignedBB)list.get(j2)).func_72322_c(axisalignedbb2, d19);
/*     */         }
/* 301 */         axisalignedbb2 = axisalignedbb2.func_72317_d(0.0D, 0.0D, d19);
/* 302 */         AxisAlignedBB axisalignedbb4 = func_174813_aQ();
/* 303 */         double d20 = y;
/* 304 */         int i3 = list.size();
/* 305 */         for (int l2 = 0; l2 < i3; l2++) {
/* 306 */           d20 = ((AxisAlignedBB)list.get(l2)).func_72323_b(axisalignedbb4, d20);
/*     */         }
/* 308 */         axisalignedbb4 = axisalignedbb4.func_72317_d(0.0D, d20, 0.0D);
/* 309 */         double d21 = d2;
/* 310 */         int k3 = list.size();
/* 311 */         for (int j3 = 0; j3 < k3; j3++) {
/* 312 */           d21 = ((AxisAlignedBB)list.get(j3)).func_72316_a(axisalignedbb4, d21);
/*     */         }
/* 314 */         axisalignedbb4 = axisalignedbb4.func_72317_d(d21, 0.0D, 0.0D);
/* 315 */         double d22 = d4;
/* 316 */         int i4 = list.size();
/* 317 */         for (int l3 = 0; l3 < i4; l3++) {
/* 318 */           d22 = ((AxisAlignedBB)list.get(l3)).func_72322_c(axisalignedbb4, d22);
/*     */         }
/* 320 */         axisalignedbb4 = axisalignedbb4.func_72317_d(0.0D, 0.0D, d22);
/* 321 */         double d23 = d18 * d18 + d19 * d19;
/* 322 */         double d9 = d21 * d21 + d22 * d22;
/* 323 */         if (d23 > d9) {
/* 324 */           x = d18;
/* 325 */           z = d19;
/* 326 */           y = -d8;
/* 327 */           func_174826_a(axisalignedbb2);
/*     */         } else {
/* 329 */           x = d21;
/* 330 */           z = d22;
/* 331 */           y = -d20;
/* 332 */           func_174826_a(axisalignedbb4);
/*     */         } 
/* 334 */         int k4 = list.size();
/* 335 */         for (int j4 = 0; j4 < k4; j4++) {
/* 336 */           y = ((AxisAlignedBB)list.get(j4)).func_72323_b(func_174813_aQ(), y);
/*     */         }
/* 338 */         func_174826_a(func_174813_aQ().func_72317_d(0.0D, y, 0.0D));
/* 339 */         if (d14 * d14 + d7 * d7 >= x * x + z * z) {
/* 340 */           x = d14;
/* 341 */           y = d6;
/* 342 */           z = d7;
/* 343 */           func_174826_a(axisalignedbb1);
/*     */         } else {
/* 345 */           StepEvent postEvent = new StepEvent(1, _this);
/* 346 */           MinecraftForge.EVENT_BUS.post((Event)postEvent);
/*     */         } 
/*     */       } 
/* 349 */       this.field_70170_p.field_72984_F.func_76319_b();
/* 350 */       this.field_70170_p.field_72984_F.func_76320_a("rest");
/* 351 */       func_174829_m();
/* 352 */       this.field_70123_F = (d2 != x || d4 != z);
/* 353 */       this.field_70124_G = (d3 != y);
/* 354 */       this.field_70122_E = (this.field_70124_G && d3 < 0.0D);
/* 355 */       this.field_70132_H = (this.field_70123_F || this.field_70124_G);
/* 356 */       int j6 = MathHelper.func_76128_c(this.field_70165_t);
/* 357 */       int i1 = MathHelper.func_76128_c(this.field_70163_u - 0.20000000298023224D);
/* 358 */       int k6 = MathHelper.func_76128_c(this.field_70161_v);
/* 359 */       BlockPos blockpos = new BlockPos(j6, i1, k6);
/* 360 */       IBlockState iblockstate = this.field_70170_p.func_180495_p(blockpos); BlockPos blockpos1; IBlockState iblockstate1; Block block1;
/* 361 */       if (iblockstate.func_185904_a() == Material.field_151579_a && (block1 = (iblockstate1 = this.field_70170_p.func_180495_p(blockpos1 = blockpos.func_177977_b())).func_177230_c() instanceof net.minecraft.block.BlockFence || block1 instanceof net.minecraft.block.BlockWall || block1 instanceof net.minecraft.block.BlockFenceGate)) {
/* 362 */         iblockstate = iblockstate1;
/* 363 */         blockpos = blockpos1;
/*     */       } 
/* 365 */       func_184231_a(y, this.field_70122_E, iblockstate, blockpos);
/* 366 */       if (d2 != x) {
/* 367 */         this.field_70159_w = 0.0D;
/*     */       }
/* 369 */       if (d4 != z) {
/* 370 */         this.field_70179_y = 0.0D;
/*     */       }
/* 372 */       Block block = iblockstate.func_177230_c();
/* 373 */       if (d3 != y) {
/* 374 */         block.func_176216_a(this.field_70170_p, _this);
/*     */       }
/* 376 */       if (func_70041_e_() && (!this.field_70122_E || !func_70093_af() || !(_this instanceof net.minecraft.entity.player.EntityPlayer)) && !func_184218_aH()) {
/* 377 */         double d15 = this.field_70165_t - d10;
/* 378 */         double d16 = this.field_70163_u - d11;
/* 379 */         double d17 = this.field_70161_v - d1;
/* 380 */         if (block != Blocks.field_150468_ap) {
/* 381 */           d16 = 0.0D;
/*     */         }
/* 383 */         if (block != null && this.field_70122_E) {
/* 384 */           block.func_176199_a(this.field_70170_p, blockpos, _this);
/*     */         }
/* 386 */         this.field_70140_Q = (float)(this.field_70140_Q + MathHelper.func_76133_a(d15 * d15 + d17 * d17) * 0.6D);
/* 387 */         this.field_82151_R = (float)(this.field_82151_R + MathHelper.func_76133_a(d15 * d15 + d16 * d16 + d17 * d17) * 0.6D);
/* 388 */         if (this.field_82151_R > this.field_70150_b && iblockstate.func_185904_a() != Material.field_151579_a) {
/* 389 */           this.field_70150_b = (int)this.field_82151_R + 1;
/* 390 */           if (func_70090_H()) {
/* 391 */             Entity entity = (func_184207_aI() && func_184179_bs() != null) ? func_184179_bs() : _this;
/* 392 */             float f = (entity == _this) ? 0.35F : 0.4F;
/* 393 */             float f1 = MathHelper.func_76133_a(entity.field_70159_w * entity.field_70159_w * 0.20000000298023224D + entity.field_70181_x * entity.field_70181_x + entity.field_70179_y * entity.field_70179_y * 0.20000000298023224D) * f;
/* 394 */             if (f1 > 1.0F) {
/* 395 */               f1 = 1.0F;
/*     */             }
/* 397 */             func_184185_a(func_184184_Z(), f1, 1.0F + (this.field_70146_Z.nextFloat() - this.field_70146_Z.nextFloat()) * 0.4F);
/*     */           } else {
/* 399 */             func_180429_a(blockpos, block);
/*     */           } 
/* 401 */         } else if (this.field_82151_R > this.field_191959_ay && func_191957_ae() && iblockstate.func_185904_a() == Material.field_151579_a) {
/* 402 */           this.field_191959_ay = func_191954_d(this.field_82151_R);
/*     */         } 
/*     */       } 
/*     */       try {
/* 406 */         func_145775_I();
/*     */       }
/* 408 */       catch (Throwable throwable) {
/* 409 */         CrashReport crashreport = CrashReport.func_85055_a(throwable, "Checking entity block collision");
/* 410 */         CrashReportCategory crashreportcategory = crashreport.func_85058_a("Entity being checked for collision");
/* 411 */         func_85029_a(crashreportcategory);
/* 412 */         throw new ReportedException(crashreport);
/*     */       } 
/* 414 */       boolean flag1 = func_70026_G();
/* 415 */       if (this.field_70170_p.func_147470_e(func_174813_aQ().func_186664_h(0.001D))) {
/* 416 */         func_70081_e(1);
/* 417 */         if (!flag1) {
/* 418 */           this.field_190534_ay++;
/* 419 */           if (this.field_190534_ay == 0) {
/* 420 */             func_70015_d(8);
/*     */           }
/*     */         } 
/* 423 */       } else if (this.field_190534_ay <= 0) {
/* 424 */         this.field_190534_ay = -func_190531_bD();
/*     */       } 
/* 426 */       if (flag1 && func_70027_ad()) {
/* 427 */         func_184185_a(SoundEvents.field_187541_bC, 0.7F, 1.6F + (this.field_70146_Z.nextFloat() - this.field_70146_Z.nextFloat()) * 0.4F);
/* 428 */         this.field_190534_ay = -func_190531_bD();
/*     */       } 
/* 430 */       this.field_70170_p.field_72984_F.func_76319_b();
/*     */     } 
/*     */   }
/*     */   
/*     */   @Redirect(method = {"onEntityUpdate"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;getMaxInPortalTime()I"))
/*     */   private int getMaxInPortalTimeHook(Entity entity) {
/* 436 */     int time = func_82145_z();
/* 437 */     if (BetterPortals.getInstance().isOn() && ((Boolean)(BetterPortals.getInstance()).fastPortal.getValue()).booleanValue()) {
/* 438 */       time = ((Integer)(BetterPortals.getInstance()).time.getValue()).intValue();
/*     */     }
/* 440 */     return time;
/*     */   }
/*     */   
/*     */   @Redirect(method = {"applyEntityCollision"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;addVelocity(DDD)V"))
/*     */   public void addVelocityHook(Entity entity, double x, double y, double z) {
/* 445 */     PushEvents event = new PushEvents(entity, x, y, z, true);
/* 446 */     MinecraftForge.EVENT_BUS.post((Event)event);
/* 447 */     if (!event.isCanceled()) {
/* 448 */       entity.field_70159_w += event.x;
/* 449 */       entity.field_70181_x += event.y;
/* 450 */       entity.field_70179_y += event.z;
/* 451 */       entity.field_70160_al = event.airbone;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/mixin/mixins/MixinEntity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */