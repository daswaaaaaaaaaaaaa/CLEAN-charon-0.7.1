/*    */ package cc.zip.charon.mixin.mixins;
/*    */ 
/*    */ import net.minecraft.client.gui.GuiMainMenu;
/*    */ import net.minecraft.client.gui.GuiScreen;
/*    */ import net.minecraft.util.ResourceLocation;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin({GuiMainMenu.class})
/*    */ public class MixinGuiMainMenu extends GuiScreen {
/*    */   @Inject(method = {"drawScreen"}, at = {@At("TAIL")}, cancellable = true)
/*    */   public void drawText(int mouseX, int mouseY, float partialTicks, CallbackInfo callbackInfo) {
/* 15 */     ResourceLocation resourceLocation = new ResourceLocation("util", "charoneu.png");
/* 16 */     this.field_146297_k.func_110434_K().func_110577_a(resourceLocation);
/* 17 */     this; func_146110_a(2, 2, 0.0F, 0.0F, 160, 32, 160.0F, 32.0F);
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/mixin/mixins/MixinGuiMainMenu.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */