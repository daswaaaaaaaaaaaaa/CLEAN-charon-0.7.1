/*    */ package cc.zip.charon.mixin.mixins;
/*    */ 
/*    */ import cc.zip.charon.Charon;
/*    */ import cc.zip.charon.features.modules.player.TpsSync;
/*    */ import com.mojang.authlib.GameProfile;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.entity.SharedMonsterAttributes;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.world.World;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({EntityPlayer.class})
/*    */ public abstract class MixinEntityPlayer
/*    */   extends EntityLivingBase
/*    */ {
/*    */   public MixinEntityPlayer(World worldIn, GameProfile gameProfileIn) {
/* 22 */     super(worldIn);
/*    */   }
/*    */   
/*    */   @Inject(method = {"getCooldownPeriod"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void getCooldownPeriodHook(CallbackInfoReturnable<Float> callbackInfoReturnable) {
/* 27 */     if (TpsSync.getInstance().isOn() && ((Boolean)(TpsSync.getInstance()).attack.getValue()).booleanValue())
/* 28 */       callbackInfoReturnable.setReturnValue(Float.valueOf((float)(1.0D / ((EntityPlayer)EntityPlayer.class.cast(this)).func_110148_a(SharedMonsterAttributes.field_188790_f).func_111125_b() * 20.0D * Charon.serverManager.getTpsFactor()))); 
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/mixin/mixins/MixinEntityPlayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */