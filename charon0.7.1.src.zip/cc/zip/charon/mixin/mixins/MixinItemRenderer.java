/*    */ package cc.zip.charon.mixin.mixins;
/*    */ 
/*    */ import cc.zip.charon.Charon;
/*    */ import cc.zip.charon.event.events.TransformSideFirstPersonEvent;
/*    */ import cc.zip.charon.features.modules.render.CustomView;
/*    */ import cc.zip.charon.features.modules.render.SmallShield;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.entity.AbstractClientPlayer;
/*    */ import net.minecraft.client.renderer.GlStateManager;
/*    */ import net.minecraft.client.renderer.ItemRenderer;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.EnumHand;
/*    */ import net.minecraft.util.EnumHandSide;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.Redirect;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ @Mixin({ItemRenderer.class})
/*    */ public abstract class MixinItemRenderer
/*    */ {
/*    */   private boolean injection = true;
/*    */   
/*    */   @Shadow
/*    */   public abstract void func_187457_a(AbstractClientPlayer paramAbstractClientPlayer, float paramFloat1, float paramFloat2, EnumHand paramEnumHand, float paramFloat3, ItemStack paramItemStack, float paramFloat4);
/*    */   
/*    */   @Inject(method = {"renderItemInFirstPerson(Lnet/minecraft/client/entity/AbstractClientPlayer;FFLnet/minecraft/util/EnumHand;FLnet/minecraft/item/ItemStack;F)V"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void renderItemInFirstPersonHook(AbstractClientPlayer player, float p_187457_2_, float p_187457_3_, EnumHand hand, float p_187457_5_, ItemStack stack, float p_187457_7_, CallbackInfo info) {
/* 32 */     if (this.injection) {
/* 33 */       info.cancel();
/* 34 */       SmallShield offset = SmallShield.getINSTANCE();
/* 35 */       float xOffset = 0.0F;
/* 36 */       float yOffset = 0.0F;
/* 37 */       this.injection = false;
/* 38 */       if (hand == EnumHand.MAIN_HAND) {
/* 39 */         if (offset.isOn() && player.func_184614_ca() != ItemStack.field_190927_a) {
/* 40 */           xOffset = ((Float)offset.mainX.getValue()).floatValue();
/* 41 */           yOffset = ((Float)offset.mainY.getValue()).floatValue();
/*    */         } 
/* 43 */       } else if (!((Boolean)offset.normalOffset.getValue()).booleanValue() && offset.isOn() && player.func_184592_cb() != ItemStack.field_190927_a) {
/* 44 */         xOffset = ((Float)offset.offX.getValue()).floatValue();
/* 45 */         yOffset = ((Float)offset.offY.getValue()).floatValue();
/*    */       } 
/* 47 */       func_187457_a(player, p_187457_2_, p_187457_3_, hand, p_187457_5_ + xOffset, stack, p_187457_7_ + yOffset);
/* 48 */       this.injection = true;
/*    */     } 
/*    */   }
/*    */   
/*    */   @Redirect(method = {"renderArmFirstPerson"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/GlStateManager;translate(FFF)V", ordinal = 0))
/*    */   public void translateHook(float x, float y, float z) {
/* 54 */     SmallShield offset = SmallShield.getINSTANCE();
/* 55 */     boolean shiftPos = ((Minecraft.func_71410_x()).field_71439_g != null && (Minecraft.func_71410_x()).field_71439_g.func_184614_ca() != ItemStack.field_190927_a && offset.isOn());
/* 56 */     GlStateManager.func_179109_b(x + (shiftPos ? ((Float)offset.mainX.getValue()).floatValue() : 0.0F), y + (shiftPos ? ((Float)offset.mainY.getValue()).floatValue() : 0.0F), z);
/*    */   }
/*    */   
/*    */   @Inject(method = {"transformSideFirstPerson"}, at = {@At("HEAD")})
/*    */   public void transformSideFirstPerson(EnumHandSide hand, float p_187459_2_, CallbackInfo callbackInfo) {
/* 61 */     TransformSideFirstPersonEvent event = new TransformSideFirstPersonEvent(hand);
/*    */   }
/*    */   
/*    */   @Inject(method = {"transformEatFirstPerson"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void transformEatFirstPerson(float p_187454_1_, EnumHandSide hand, ItemStack stack, CallbackInfo callbackInfo) {
/* 66 */     TransformSideFirstPersonEvent event = new TransformSideFirstPersonEvent(hand);
/*    */     
/* 68 */     CustomView customView = (CustomView)Charon.moduleManager.getModuleByClass(CustomView.class);
/*    */     
/* 70 */     if (customView.isEnabled() && ((Boolean)customView.cancelEating.getValue()).booleanValue()) {
/* 71 */       callbackInfo.cancel();
/*    */     }
/*    */   }
/*    */   
/*    */   @Inject(method = {"transformFirstPerson"}, at = {@At("HEAD")})
/*    */   public void transformFirstPerson(EnumHandSide hand, float p_187453_2_, CallbackInfo callbackInfo) {
/* 77 */     TransformSideFirstPersonEvent event = new TransformSideFirstPersonEvent(hand);
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/mixin/mixins/MixinItemRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */