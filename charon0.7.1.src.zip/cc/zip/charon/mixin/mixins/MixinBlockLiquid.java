/*    */ package cc.zip.charon.mixin.mixins;
/*    */ 
/*    */ import cc.zip.charon.features.modules.player.LiquidInteract;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.BlockLiquid;
/*    */ import net.minecraft.block.material.Material;
/*    */ import net.minecraft.block.properties.IProperty;
/*    */ import net.minecraft.block.state.IBlockState;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ @Mixin({BlockLiquid.class})
/*    */ public class MixinBlockLiquid
/*    */   extends Block {
/*    */   protected MixinBlockLiquid(Material materialIn) {
/* 18 */     super(materialIn);
/*    */   }
/*    */   
/*    */   @Inject(method = {"canCollideCheck"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void canCollideCheckHook(IBlockState blockState, boolean hitIfLiquid, CallbackInfoReturnable<Boolean> info) {
/* 23 */     info.setReturnValue(Boolean.valueOf(((hitIfLiquid && ((Integer)blockState.func_177229_b((IProperty)BlockLiquid.field_176367_b)).intValue() == 0) || LiquidInteract.getInstance().isOn())));
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/mixin/mixins/MixinBlockLiquid.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */