/*    */ package cc.zip.charon.mixin.mixins;
/*    */ import cc.zip.charon.Charon;
/*    */ import cc.zip.charon.event.events.KeyEvent;
/*    */ import cc.zip.charon.features.modules.player.MultiTask;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.entity.EntityPlayerSP;
/*    */ import net.minecraft.client.multiplayer.PlayerControllerMP;
/*    */ import net.minecraft.crash.CrashReport;
/*    */ import net.minecraftforge.common.MinecraftForge;
/*    */ import net.minecraftforge.fml.common.eventhandler.Event;
/*    */ import org.lwjgl.input.Keyboard;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.Redirect;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin({Minecraft.class})
/*    */ public abstract class MixinMinecraft {
/*    */   @Inject(method = {"shutdownMinecraftApplet"}, at = {@At("HEAD")})
/*    */   private void stopClient(CallbackInfo callbackInfo) {
/* 22 */     unload();
/*    */   }
/*    */   
/*    */   @Redirect(method = {"run"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Minecraft;displayCrashReport(Lnet/minecraft/crash/CrashReport;)V"))
/*    */   public void displayCrashReport(Minecraft minecraft, CrashReport crashReport) {
/* 27 */     unload();
/*    */   }
/*    */ 
/*    */   
/*    */   @Inject(method = {"runTickKeyboard"}, at = {@At(value = "INVOKE", remap = false, target = "Lorg/lwjgl/input/Keyboard;getEventKey()I", ordinal = 0, shift = At.Shift.BEFORE)})
/*    */   private void onKeyboard(CallbackInfo callbackInfo) {
/* 33 */     int i = (Keyboard.getEventKey() == 0) ? (Keyboard.getEventCharacter() + 256) : Keyboard.getEventKey(), n = i;
/* 34 */     if (Keyboard.getEventKeyState()) {
/* 35 */       KeyEvent event = new KeyEvent(i);
/* 36 */       MinecraftForge.EVENT_BUS.post((Event)event);
/*    */     } 
/*    */   }
/*    */   
/*    */   private void unload() {
/* 41 */     Charon.LOGGER.info("Initiated client shutdown.");
/* 42 */     Charon.onUnload();
/* 43 */     Charon.LOGGER.info("Finished client shutdown.");
/*    */   }
/*    */   
/*    */   @Redirect(method = {"sendClickBlockToController"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/entity/EntityPlayerSP;isHandActive()Z"))
/*    */   private boolean isHandActiveWrapper(EntityPlayerSP playerSP) {
/* 48 */     return (!MultiTask.getInstance().isOn() && playerSP.func_184587_cr());
/*    */   }
/*    */   
/*    */   @Redirect(method = {"rightClickMouse"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/multiplayer/PlayerControllerMP;getIsHittingBlock()Z", ordinal = 0))
/*    */   private boolean isHittingBlockHook(PlayerControllerMP playerControllerMP) {
/* 53 */     return (!MultiTask.getInstance().isOn() && playerControllerMP.func_181040_m());
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/mixin/mixins/MixinMinecraft.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */