/*     */ package cc.zip.charon;
/*     */ import cc.zip.charon.manager.ColorManager;
/*     */ import cc.zip.charon.manager.CommandManager;
/*     */ import cc.zip.charon.manager.EventManager;
/*     */ import cc.zip.charon.manager.FileManager;
/*     */ import cc.zip.charon.manager.HoleManager;
/*     */ import cc.zip.charon.manager.InventoryManager;
/*     */ import cc.zip.charon.manager.ModuleManager;
/*     */ import cc.zip.charon.manager.PacketManager;
/*     */ import cc.zip.charon.manager.PositionManager;
/*     */ import cc.zip.charon.manager.PotionManager;
/*     */ import cc.zip.charon.manager.ReloadManager;
/*     */ import cc.zip.charon.manager.ServerManager;
/*     */ import cc.zip.charon.manager.SpeedManager;
/*     */ import cc.zip.charon.manager.TextManager;
/*     */ 
/*     */ @Mod(modid = "charon", name = "charon.eu", version = "0.7")
/*     */ public class Charon {
/*  19 */   public static final Logger LOGGER = LogManager.getLogger("charon.eu");
/*     */   
/*     */   public static final String MODID = "charon";
/*     */   
/*     */   public static final String MODNAME = "charon";
/*     */   public static final String MODVER = "0.7";
/*     */   public static CommandManager commandManager;
/*     */   public static FriendManager friendManager;
/*     */   public static ModuleManager moduleManager;
/*     */   public static PacketManager packetManager;
/*     */   public static ColorManager colorManager;
/*     */   public static HoleManager holeManager;
/*     */   public static InventoryManager inventoryManager;
/*     */   public static PotionManager potionManager;
/*     */   public static RotationManager rotationManager;
/*     */   public static PositionManager positionManager;
/*     */   public static SpeedManager speedManager;
/*     */   public static ReloadManager reloadManager;
/*     */   public static FileManager fileManager;
/*     */   public static ConfigManager configManager;
/*     */   public static ServerManager serverManager;
/*     */   public static EventManager eventManager;
/*     */   public static TextManager textManager;
/*     */   public static TimerManager timerManager;
/*     */   @Instance
/*     */   public static Charon INSTANCE;
/*     */   private static boolean unloaded = false;
/*     */   
/*     */   public static void load() {
/*  48 */     LOGGER.info("\n\nLoading charon");
/*     */ 
/*     */     
/*  51 */     LOGGER.info("\n\nUnloading charon");
/*  52 */     LOGGER.info("\n\nUnloading charon");
/*     */ 
/*     */     
/*  55 */     unloaded = false;
/*  56 */     if (reloadManager != null) {
/*  57 */       reloadManager.unload();
/*  58 */       reloadManager = null;
/*     */     } 
/*  60 */     textManager = new TextManager();
/*  61 */     commandManager = new CommandManager();
/*  62 */     friendManager = new FriendManager();
/*  63 */     moduleManager = new ModuleManager();
/*  64 */     rotationManager = new RotationManager();
/*  65 */     packetManager = new PacketManager();
/*  66 */     eventManager = new EventManager();
/*  67 */     speedManager = new SpeedManager();
/*  68 */     potionManager = new PotionManager();
/*  69 */     inventoryManager = new InventoryManager();
/*  70 */     serverManager = new ServerManager();
/*  71 */     fileManager = new FileManager();
/*  72 */     colorManager = new ColorManager();
/*  73 */     positionManager = new PositionManager();
/*  74 */     configManager = new ConfigManager();
/*  75 */     holeManager = new HoleManager();
/*  76 */     Main.main();
/*  77 */     LOGGER.info("Managers loaded.");
/*  78 */     moduleManager.init();
/*  79 */     LOGGER.info("Modules loaded.");
/*  80 */     configManager.init();
/*  81 */     eventManager.init();
/*  82 */     LOGGER.info("EventManager loaded.");
/*  83 */     textManager.init(true);
/*  84 */     moduleManager.onLoad();
/*  85 */     LOGGER.info("charon successfully loaded!\n");
/*     */   }
/*     */   
/*     */   public static void unload(boolean unload) {
/*  89 */     LOGGER.info("\n\nUnloading suharhack");
/*  90 */     if (unload) {
/*  91 */       reloadManager = new ReloadManager();
/*  92 */       reloadManager.init((commandManager != null) ? commandManager.getPrefix() : ".");
/*     */     } 
/*  94 */     onUnload();
/*  95 */     eventManager = null;
/*  96 */     friendManager = null;
/*  97 */     speedManager = null;
/*  98 */     holeManager = null;
/*  99 */     positionManager = null;
/* 100 */     rotationManager = null;
/* 101 */     configManager = null;
/* 102 */     commandManager = null;
/* 103 */     colorManager = null;
/* 104 */     serverManager = null;
/* 105 */     fileManager = null;
/* 106 */     potionManager = null;
/* 107 */     inventoryManager = null;
/* 108 */     moduleManager = null;
/* 109 */     textManager = null;
/* 110 */     LOGGER.info("charon unloaded!\n");
/*     */   }
/*     */   
/*     */   public static void reload() {
/* 114 */     unload(false);
/* 115 */     load();
/*     */   }
/*     */   
/*     */   public static void onUnload() {
/* 119 */     if (!unloaded) {
/* 120 */       eventManager.onUnload();
/* 121 */       moduleManager.onUnload();
/* 122 */       configManager.saveConfig(configManager.config.replaceFirst("garbage client/", ""));
/* 123 */       moduleManager.onUnloadPost();
/* 124 */       unloaded = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @EventHandler
/*     */   public void init(FMLInitializationEvent event) {
/* 131 */     Display.setTitle("charon");
/* 132 */     load();
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/Charon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */