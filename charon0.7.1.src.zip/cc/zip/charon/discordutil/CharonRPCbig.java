/*    */ package cc.zip.charon.discordutil;
/*    */ 
/*    */ import cc.zip.charon.features.modules.rpc.CharonRPC;
/*    */ import club.minnced.discord.rpc.DiscordEventHandlers;
/*    */ import club.minnced.discord.rpc.DiscordRPC;
/*    */ import club.minnced.discord.rpc.DiscordRichPresence;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CharonRPCbig
/*    */ {
/*    */   private static final DiscordRPC rpc;
/*    */   public static DiscordRichPresence presence;
/*    */   private static Thread thread;
/* 15 */   private static int index = 1; static {
/* 16 */     rpc = DiscordRPC.INSTANCE;
/* 17 */     presence = new DiscordRichPresence();
/*    */   }
/*    */   
/*    */   public static void start() {
/* 21 */     DiscordEventHandlers handlers = new DiscordEventHandlers();
/* 22 */     rpc.Discord_Initialize("818218548588838962", handlers, true, "");
/* 23 */     presence.startTimestamp = System.currentTimeMillis() / 1000L;
/* 24 */     presence.state = (String)CharonRPC.INSTANCE.state.getValue();
/* 25 */     presence.largeImageKey = "charon";
/* 26 */     presence.largeImageText = "charon-beta 0.6.1";
/* 27 */     rpc.Discord_UpdatePresence(presence);
/* 28 */     thread = new Thread(() -> {
/*    */           while (!Thread.currentThread().isInterrupted()) {
/*    */             rpc.Discord_RunCallbacks();
/*    */             if (((Boolean)CharonRPC.INSTANCE.random.getValue()).booleanValue()) {
/*    */               if (index == 4) {
/*    */                 index = 1;
/*    */               }
/*    */               presence.largeImageKey = "charon" + index;
/*    */               index++;
/*    */             } 
/*    */             rpc.Discord_UpdatePresence(presence);
/*    */             try {
/*    */               Thread.sleep(3000L);
/* 41 */             } catch (InterruptedException interruptedException) {}
/*    */           } 
/*    */         }"RPC-Callback-Handler");
/*    */     
/* 45 */     thread.start();
/*    */   }
/*    */   
/*    */   public static void stop() {
/* 49 */     if (thread != null && !thread.isInterrupted()) {
/* 50 */       thread.interrupt();
/*    */     }
/* 52 */     rpc.Discord_Shutdown();
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/discordutil/CharonRPCbig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */