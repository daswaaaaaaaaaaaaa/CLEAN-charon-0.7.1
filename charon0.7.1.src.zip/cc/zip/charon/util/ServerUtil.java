/*     */ package cc.zip.charon.util;
/*     */ 
/*     */ import cc.zip.charon.event.events.PacketEvent;
/*     */ import cc.zip.charon.features.modules.Module;
/*     */ import cc.zip.charon.features.setting.Setting;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketChatMessage;
/*     */ import net.minecraft.network.play.client.CPacketKeepAlive;
/*     */ import net.minecraft.network.play.server.SPacketChat;
/*     */ import net.minecraft.network.play.server.SPacketKeepAlive;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServerUtil
/*     */   extends Module
/*     */ {
/*  22 */   public Setting<String> ip = register(new Setting("PhobosIP", "0.0.0.0.0"));
/*  23 */   public Setting<String> serverIP = register(new Setting("ServerIP", "AnarchyHvH.eu"));
/*  24 */   public Setting<Boolean> noFML = register(new Setting("RemoveFML", Boolean.valueOf(false)));
/*  25 */   public Setting<Boolean> getName = register(new Setting("GetName", Boolean.valueOf(false)));
/*  26 */   public Setting<Boolean> average = register(new Setting("Average", Boolean.valueOf(false)));
/*  27 */   public Setting<Boolean> clear = register(new Setting("ClearPings", Boolean.valueOf(false)));
/*  28 */   public Setting<Boolean> oneWay = register(new Setting("OneWay", Boolean.valueOf(false)));
/*  29 */   public Setting<Integer> delay = register(new Setting("KeepAlives", Integer.valueOf(10), Integer.valueOf(1), Integer.valueOf(50)));
/*     */   private static ServerUtil instance;
/*  31 */   private final AtomicBoolean connected = new AtomicBoolean(false);
/*  32 */   private final Timer pingTimer = new Timer();
/*  33 */   private long currentPing = 0L;
/*  34 */   private long serverPing = 0L;
/*  35 */   private StringBuffer name = null;
/*  36 */   private long averagePing = 0L;
/*  37 */   private final List<Long> pingList = new ArrayList<>();
/*  38 */   private String serverPrefix = "idk";
/*     */   
/*     */   public ServerUtil() {
/*  41 */     super("PingBypass", "Manages Phobos`s internal Server", Module.Category.CLIENT, false, false, true);
/*  42 */     instance = this;
/*     */   }
/*     */   
/*     */   public String getPlayerName() {
/*  46 */     if (this.name == null) {
/*  47 */       return null;
/*     */     }
/*  49 */     return this.name.toString();
/*     */   }
/*     */   
/*     */   public String getServerPrefix() {
/*  53 */     return this.serverPrefix;
/*     */   }
/*     */   
/*     */   public static ServerUtil getInstance() {
/*  57 */     if (instance == null) {
/*  58 */       instance = new ServerUtil();
/*     */     }
/*  60 */     return instance;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onLogout() {
/*  65 */     this.averagePing = 0L;
/*  66 */     this.currentPing = 0L;
/*  67 */     this.serverPing = 0L;
/*  68 */     this.pingList.clear();
/*  69 */     this.connected.set(false);
/*  70 */     this.name = null;
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onReceivePacket(PacketEvent.Receive event) {
/*  75 */     if (event.getPacket() instanceof SPacketChat) {
/*  76 */       SPacketChat packet = (SPacketChat)event.getPacket();
/*  77 */       if (packet.field_148919_a.func_150260_c().startsWith("@Clientprefix"))
/*     */       {
/*  79 */         String prefix = packet.field_148919_a.func_150254_d().replace("@Clientprefix", "");
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onTick() {
/*  86 */     if (mc.func_147114_u() != null && isConnected()) {
/*  87 */       if (((Boolean)this.getName.getValue()).booleanValue()) {
/*  88 */         mc.func_147114_u().func_147297_a((Packet)new CPacketChatMessage("@Servername"));
/*  89 */         this.getName.setValue(Boolean.valueOf(false));
/*     */       } 
/*  91 */       if (this.serverPrefix.equalsIgnoreCase("idk") && mc.field_71441_e != null) {
/*  92 */         mc.func_147114_u().func_147297_a((Packet)new CPacketChatMessage("@Servergetprefix"));
/*     */       }
/*  94 */       if (this.pingTimer.passedMs((((Integer)this.delay.getValue()).intValue() * 1000))) {
/*  95 */         mc.func_147114_u().func_147297_a((Packet)new CPacketKeepAlive(100L));
/*  96 */         this.pingTimer.reset();
/*     */       } 
/*  98 */       if (((Boolean)this.clear.getValue()).booleanValue()) {
/*  99 */         this.pingList.clear();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketReceive(PacketEvent.Receive event) {
/* 107 */     if (event.getPacket() instanceof SPacketChat)
/* 108 */     { SPacketChat packetChat = (SPacketChat)event.getPacket();
/* 109 */       if (packetChat.func_148915_c().func_150254_d().startsWith("@Client")) {
/* 110 */         this.name = new StringBuffer(TextUtil.stripColor(packetChat.func_148915_c().func_150254_d().replace("@Client", "")));
/* 111 */         event.setCanceled(true);
/*     */       }  }
/* 113 */     else { SPacketKeepAlive alive; if (event.getPacket() instanceof SPacketKeepAlive && (alive = (SPacketKeepAlive)event.getPacket()).func_149134_c() > 0L && alive.func_149134_c() < 1000L) {
/* 114 */         this.serverPing = alive.func_149134_c();
/* 115 */         this.currentPing = ((Boolean)this.oneWay.getValue()).booleanValue() ? (this.pingTimer.getPassedTimeMs() / 2L) : this.pingTimer.getPassedTimeMs();
/* 116 */         this.pingList.add(Long.valueOf(this.currentPing));
/* 117 */         this.averagePing = getAveragePing();
/*     */       }  }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDisplayInfo() {
/* 124 */     return this.averagePing + "ms";
/*     */   }
/*     */   
/*     */   private long getAveragePing() {
/* 128 */     if (!((Boolean)this.average.getValue()).booleanValue() || this.pingList.isEmpty()) {
/* 129 */       return this.currentPing;
/*     */     }
/* 131 */     int full = 0;
/* 132 */     for (Iterator<Long> iterator = this.pingList.iterator(); iterator.hasNext(); ) { long i = ((Long)iterator.next()).longValue();
/* 133 */       full = (int)(full + i); }
/*     */     
/* 135 */     return (full / this.pingList.size());
/*     */   }
/*     */   
/*     */   public boolean isConnected() {
/* 139 */     return this.connected.get();
/*     */   }
/*     */   
/*     */   public long getServerPing() {
/* 143 */     return this.serverPing;
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/util/ServerUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */