/*    */ package cc.zip.charon.util;
/*    */ import com.mojang.authlib.GameProfile;
/*    */ import net.minecraft.client.entity.EntityOtherPlayerMP;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.network.Packet;
/*    */ import net.minecraft.network.play.client.CPacketEntityAction;
/*    */ import net.minecraft.network.play.client.CPacketPlayer;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraft.util.EnumHand;
/*    */ import net.minecraft.util.math.AxisAlignedBB;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.util.math.Vec3d;
/*    */ import net.minecraft.util.math.Vec3i;
/*    */ import net.minecraft.world.World;
/*    */ 
/*    */ public class WorldUtil implements MinecraftInstance {
/*    */   public static void placeBlock(BlockPos pos) {
/*    */     EnumFacing[] arrayOfEnumFacing;
/*    */     int i;
/*    */     byte b;
/* 21 */     for (arrayOfEnumFacing = EnumFacing.values(), i = arrayOfEnumFacing.length, b = 0; b < i; ) { EnumFacing enumFacing = arrayOfEnumFacing[b];
/* 22 */       if (MinecraftInstance.mc.field_71441_e.func_180495_p(pos.func_177972_a(enumFacing)).func_177230_c().equals(Blocks.field_150350_a) || isIntercepted(pos)) { b++; continue; }
/* 23 */        Vec3d vec = new Vec3d(pos.func_177958_n() + 0.5D + enumFacing.func_82601_c() * 0.5D, pos.func_177956_o() + 0.5D + enumFacing.func_96559_d() * 0.5D, pos.func_177952_p() + 0.5D + enumFacing.func_82599_e() * 0.5D);
/* 24 */       float[] old = { MinecraftInstance.mc.field_71439_g.field_70177_z, MinecraftInstance.mc.field_71439_g.field_70125_A };
/* 25 */       MinecraftInstance.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Rotation((float)Math.toDegrees(Math.atan2(vec.field_72449_c - MinecraftInstance.mc.field_71439_g.field_70161_v, vec.field_72450_a - MinecraftInstance.mc.field_71439_g.field_70165_t)) - 90.0F, (float)-Math.toDegrees(Math.atan2(vec.field_72448_b - MinecraftInstance.mc.field_71439_g.field_70163_u + MinecraftInstance.mc.field_71439_g.func_70047_e(), Math.sqrt((vec.field_72450_a - MinecraftInstance.mc.field_71439_g.field_70165_t) * (vec.field_72450_a - MinecraftInstance.mc.field_71439_g.field_70165_t) + (vec.field_72449_c - MinecraftInstance.mc.field_71439_g.field_70161_v) * (vec.field_72449_c - MinecraftInstance.mc.field_71439_g.field_70161_v)))), MinecraftInstance.mc.field_71439_g.field_70122_E));
/* 26 */       MinecraftInstance.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)MinecraftInstance.mc.field_71439_g, CPacketEntityAction.Action.START_SNEAKING));
/* 27 */       MinecraftInstance.mc.field_71442_b.func_187099_a(MinecraftInstance.mc.field_71439_g, MinecraftInstance.mc.field_71441_e, pos.func_177972_a(enumFacing), enumFacing.func_176734_d(), new Vec3d((Vec3i)pos), EnumHand.MAIN_HAND);
/* 28 */       MinecraftInstance.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
/* 29 */       MinecraftInstance.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)MinecraftInstance.mc.field_71439_g, CPacketEntityAction.Action.STOP_SNEAKING));
/* 30 */       MinecraftInstance.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Rotation(old[0], old[1], MinecraftInstance.mc.field_71439_g.field_70122_E));
/*    */       return; }
/*    */   
/*    */   }
/*    */   
/*    */   public static void createFakePlayer(@Nullable String name, boolean copyInventory, boolean copyAngles, boolean health, boolean player, int entityID) {
/* 36 */     EntityOtherPlayerMP entity = player ? new EntityOtherPlayerMP((World)mc.field_71441_e, mc.func_110432_I().func_148256_e()) : new EntityOtherPlayerMP((World)mc.field_71441_e, new GameProfile(UUID.fromString("70ee432d-0a96-4137-a2c0-37cc9df67f03"), name));
/* 37 */     entity.func_82149_j((Entity)mc.field_71439_g);
/*    */     
/* 39 */     if (copyInventory) {
/* 40 */       entity.field_71071_by.func_70455_b(mc.field_71439_g.field_71071_by);
/*    */     }
/* 42 */     if (copyAngles) {
/* 43 */       entity.field_70177_z = mc.field_71439_g.field_70177_z;
/* 44 */       entity.field_70759_as = mc.field_71439_g.field_70759_as;
/*    */     } 
/*    */     
/* 47 */     if (health) {
/* 48 */       entity.func_70606_j(mc.field_71439_g.func_110143_aJ() + mc.field_71439_g.func_110139_bj());
/*    */     }
/* 50 */     mc.field_71441_e.func_73027_a(entityID, (Entity)entity);
/*    */   }
/*    */   
/*    */   public static void placeBlock(BlockPos pos, int slot) {
/* 54 */     if (slot == -1) {
/*    */       return;
/*    */     }
/* 57 */     int prev = MinecraftInstance.mc.field_71439_g.field_71071_by.field_70461_c;
/* 58 */     MinecraftInstance.mc.field_71439_g.field_71071_by.field_70461_c = slot;
/* 59 */     placeBlock(pos);
/* 60 */     MinecraftInstance.mc.field_71439_g.field_71071_by.field_70461_c = prev;
/*    */   }
/*    */   
/*    */   public static boolean isIntercepted(BlockPos pos) {
/* 64 */     for (Entity entity : MinecraftInstance.mc.field_71441_e.field_72996_f) {
/* 65 */       if (!(new AxisAlignedBB(pos)).func_72326_a(entity.func_174813_aQ()))
/* 66 */         continue;  return true;
/*    */     } 
/* 68 */     return false;
/*    */   }
/*    */   
/*    */   public static BlockPos GetLocalPlayerPosFloored() {
/* 72 */     return new BlockPos(Math.floor(MinecraftInstance.mc.field_71439_g.field_70165_t), Math.floor(MinecraftInstance.mc.field_71439_g.field_70163_u), Math.floor(MinecraftInstance.mc.field_71439_g.field_70161_v));
/*    */   }
/*    */   
/*    */   public static boolean canBreak(BlockPos pos) {
/* 76 */     return (MinecraftInstance.mc.field_71441_e.func_180495_p(pos).func_177230_c().func_176195_g(MinecraftInstance.mc.field_71441_e.func_180495_p(pos), (World)MinecraftInstance.mc.field_71441_e, pos) != -1.0F);
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/util/WorldUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */