/*    */ package cc.zip.charon.util;
/*    */ 
/*    */ import cc.zip.charon.mixin.mixins.MixinInterface;
/*    */ import net.minecraft.util.text.ITextComponent;
/*    */ import net.minecraft.util.text.TextComponentString;
/*    */ import net.minecraft.util.text.TextFormatting;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MessageUtil
/*    */   implements MixinInterface
/*    */ {
/*    */   public static void sendClientMessage(String message) {
/* 15 */     mc.field_71456_v.func_146158_b().func_146234_a((ITextComponent)new TextComponentString(TextFormatting.DARK_PURPLE + "[Momentum] " + TextFormatting.RESET + message), 69);
/*    */   }
/*    */   
/*    */   public static void sendRawClientMessage(String message) {
/* 19 */     mc.field_71456_v.func_146158_b().func_146234_a((ITextComponent)new TextComponentString(message), 69);
/*    */   }
/*    */   
/*    */   public static void sendPublicMessage(String message) {
/* 23 */     mc.field_71439_g.func_71165_d(message);
/*    */   }
/*    */ 
/*    */   
/*    */   public static void addOutput(String message) {}
/*    */ 
/*    */   
/*    */   public static void usageException(String usage, String specialUsage) {}
/*    */ 
/*    */   
/*    */   public static String toUnicode(String s) {
/* 34 */     return s.toLowerCase()
/* 35 */       .replace("a", "ᴀ")
/* 36 */       .replace("b", "ʙ")
/* 37 */       .replace("c", "ᴄ")
/* 38 */       .replace("d", "ᴅ")
/* 39 */       .replace("e", "ᴇ")
/* 40 */       .replace("f", "ꜰ")
/* 41 */       .replace("g", "ɢ")
/* 42 */       .replace("h", "ʜ")
/* 43 */       .replace("i", "ɪ")
/* 44 */       .replace("j", "ᴊ")
/* 45 */       .replace("k", "ᴋ")
/* 46 */       .replace("l", "ʟ")
/* 47 */       .replace("m", "ᴍ")
/* 48 */       .replace("n", "ɴ")
/* 49 */       .replace("o", "ᴏ")
/* 50 */       .replace("p", "ᴘ")
/* 51 */       .replace("q", "ǫ")
/* 52 */       .replace("r", "ʀ")
/* 53 */       .replace("s", "ꜱ")
/* 54 */       .replace("t", "ᴛ")
/* 55 */       .replace("u", "ᴜ")
/* 56 */       .replace("v", "ᴠ")
/* 57 */       .replace("w", "ᴡ")
/* 58 */       .replace("x", "ˣ")
/* 59 */       .replace("y", "ʏ")
/* 60 */       .replace("z", "ᴢ");
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/util/MessageUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */