/*     */ package cc.zip.charon.util;
/*     */ 
/*     */ import cc.zip.charon.Charon;
/*     */ import com.mojang.realmsclient.gui.ChatFormatting;
/*     */ import java.awt.Color;
/*     */ import java.math.RoundingMode;
/*     */ import java.text.DecimalFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.enchantment.EnchantmentHelper;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.EnumCreatureType;
/*     */ import net.minecraft.entity.monster.EntityEnderman;
/*     */ import net.minecraft.entity.monster.EntityIronGolem;
/*     */ import net.minecraft.entity.monster.EntityPigZombie;
/*     */ import net.minecraft.entity.passive.EntityWolf;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Enchantments;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketEntityAction;
/*     */ import net.minecraft.network.play.client.CPacketUseEntity;
/*     */ import net.minecraft.potion.Potion;
/*     */ import net.minecraft.potion.PotionEffect;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.MovementInput;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EntityUtil
/*     */   implements Util
/*     */ {
/*  46 */   public static final Vec3d[] antiDropOffsetList = new Vec3d[] { new Vec3d(0.0D, -2.0D, 0.0D) };
/*  47 */   public static final Vec3d[] platformOffsetList = new Vec3d[] { new Vec3d(0.0D, -1.0D, 0.0D), new Vec3d(0.0D, -1.0D, -1.0D), new Vec3d(0.0D, -1.0D, 1.0D), new Vec3d(-1.0D, -1.0D, 0.0D), new Vec3d(1.0D, -1.0D, 0.0D) };
/*  48 */   public static final Vec3d[] legOffsetList = new Vec3d[] { new Vec3d(-1.0D, 0.0D, 0.0D), new Vec3d(1.0D, 0.0D, 0.0D), new Vec3d(0.0D, 0.0D, -1.0D), new Vec3d(0.0D, 0.0D, 1.0D) };
/*  49 */   public static final Vec3d[] OffsetList = new Vec3d[] { new Vec3d(1.0D, 1.0D, 0.0D), new Vec3d(-1.0D, 1.0D, 0.0D), new Vec3d(0.0D, 1.0D, 1.0D), new Vec3d(0.0D, 1.0D, -1.0D), new Vec3d(0.0D, 2.0D, 0.0D) };
/*  50 */   public static final Vec3d[] antiStepOffsetList = new Vec3d[] { new Vec3d(-1.0D, 2.0D, 0.0D), new Vec3d(1.0D, 2.0D, 0.0D), new Vec3d(0.0D, 2.0D, 1.0D), new Vec3d(0.0D, 2.0D, -1.0D) };
/*  51 */   public static final Vec3d[] antiScaffoldOffsetList = new Vec3d[] { new Vec3d(0.0D, 3.0D, 0.0D) };
/*     */   
/*     */   public static void attackEntity(Entity entity, boolean packet, boolean swingArm) {
/*  54 */     if (packet) {
/*  55 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketUseEntity(entity));
/*     */     } else {
/*  57 */       mc.field_71442_b.func_78764_a((EntityPlayer)mc.field_71439_g, entity);
/*     */     } 
/*  59 */     if (swingArm) {
/*  60 */       mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
/*     */     }
/*     */   }
/*     */   
/*     */   public static Vec3d interpolateEntity(Entity entity, float time) {
/*  65 */     return new Vec3d(entity.field_70142_S + (entity.field_70165_t - entity.field_70142_S) * time, entity.field_70137_T + (entity.field_70163_u - entity.field_70137_T) * time, entity.field_70136_U + (entity.field_70161_v - entity.field_70136_U) * time);
/*     */   }
/*     */   
/*     */   public static Vec3d getInterpolatedPos(Entity entity, float partialTicks) {
/*  69 */     return (new Vec3d(entity.field_70142_S, entity.field_70137_T, entity.field_70136_U)).func_178787_e(getInterpolatedAmount(entity, partialTicks));
/*     */   }
/*     */   
/*     */   public static Vec3d getInterpolatedRenderPos(Entity entity, float partialTicks) {
/*  73 */     return getInterpolatedPos(entity, partialTicks).func_178786_a((mc.func_175598_ae()).field_78725_b, (mc.func_175598_ae()).field_78726_c, (mc.func_175598_ae()).field_78723_d);
/*     */   }
/*     */   
/*     */   public static Vec3d getInterpolatedRenderPos(Vec3d vec) {
/*  77 */     return (new Vec3d(vec.field_72450_a, vec.field_72448_b, vec.field_72449_c)).func_178786_a((mc.func_175598_ae()).field_78725_b, (mc.func_175598_ae()).field_78726_c, (mc.func_175598_ae()).field_78723_d);
/*     */   }
/*     */   
/*     */   public static Vec3d getInterpolatedAmount(Entity entity, double x, double y, double z) {
/*  81 */     return new Vec3d((entity.field_70165_t - entity.field_70142_S) * x, (entity.field_70163_u - entity.field_70137_T) * y, (entity.field_70161_v - entity.field_70136_U) * z);
/*     */   }
/*     */   
/*     */   public static Vec3d getInterpolatedAmount(Entity entity, Vec3d vec) {
/*  85 */     return getInterpolatedAmount(entity, vec.field_72450_a, vec.field_72448_b, vec.field_72449_c);
/*     */   }
/*     */   
/*     */   public static Vec3d getInterpolatedAmount(Entity entity, float partialTicks) {
/*  89 */     return getInterpolatedAmount(entity, partialTicks, partialTicks, partialTicks);
/*     */   }
/*     */   
/*     */   public static boolean isPassive(Entity entity) {
/*  93 */     if (entity instanceof EntityWolf && ((EntityWolf)entity).func_70919_bu()) {
/*  94 */       return false;
/*     */     }
/*  96 */     if (entity instanceof net.minecraft.entity.EntityAgeable || entity instanceof net.minecraft.entity.passive.EntityAmbientCreature || entity instanceof net.minecraft.entity.passive.EntitySquid) {
/*  97 */       return true;
/*     */     }
/*  99 */     return (entity instanceof EntityIronGolem && ((EntityIronGolem)entity).func_70643_av() == null);
/*     */   }
/*     */   
/*     */   public static boolean isSafe(Entity entity, int height, boolean floor) {
/* 103 */     return (getUnsafeBlocks(entity, height, floor).size() == 0);
/*     */   }
/*     */   
/*     */   public static boolean stopSneaking(boolean isSneaking) {
/* 107 */     if (isSneaking && mc.field_71439_g != null) {
/* 108 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)mc.field_71439_g, CPacketEntityAction.Action.STOP_SNEAKING));
/*     */     }
/* 110 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean isSafe(Entity entity) {
/* 114 */     return isSafe(entity, 0, false);
/*     */   }
/*     */   
/*     */   public static BlockPos getPlayerPos(EntityPlayer player) {
/* 118 */     return new BlockPos(Math.floor(player.field_70165_t), Math.floor(player.field_70163_u), Math.floor(player.field_70161_v));
/*     */   }
/*     */   
/*     */   public static List<Vec3d> getUnsafeBlocks(Entity entity, int height, boolean floor) {
/* 122 */     return getUnsafeBlocksFromVec3d(entity.func_174791_d(), height, floor);
/*     */   }
/*     */   
/*     */   public static boolean isMobAggressive(Entity entity) {
/* 126 */     if (entity instanceof EntityPigZombie) {
/* 127 */       if (((EntityPigZombie)entity).func_184734_db() || ((EntityPigZombie)entity).func_175457_ck()) {
/* 128 */         return true;
/*     */       }
/*     */     } else {
/* 131 */       if (entity instanceof EntityWolf) {
/* 132 */         return (((EntityWolf)entity).func_70919_bu() && !mc.field_71439_g.equals(((EntityWolf)entity).func_70902_q()));
/*     */       }
/* 134 */       if (entity instanceof EntityEnderman) {
/* 135 */         return ((EntityEnderman)entity).func_70823_r();
/*     */       }
/*     */     } 
/* 138 */     return isHostileMob(entity);
/*     */   }
/*     */   
/*     */   public static boolean isNeutralMob(Entity entity) {
/* 142 */     return (entity instanceof EntityPigZombie || entity instanceof EntityWolf || entity instanceof EntityEnderman);
/*     */   }
/*     */   
/*     */   public static boolean isProjectile(Entity entity) {
/* 146 */     return (entity instanceof net.minecraft.entity.projectile.EntityShulkerBullet || entity instanceof net.minecraft.entity.projectile.EntityFireball);
/*     */   }
/*     */   
/*     */   public static boolean isVehicle(Entity entity) {
/* 150 */     return (entity instanceof net.minecraft.entity.item.EntityBoat || entity instanceof net.minecraft.entity.item.EntityMinecart);
/*     */   }
/*     */   
/*     */   public static boolean isFriendlyMob(Entity entity) {
/* 154 */     return ((entity.isCreatureType(EnumCreatureType.CREATURE, false) && !isNeutralMob(entity)) || entity.isCreatureType(EnumCreatureType.AMBIENT, false) || entity instanceof net.minecraft.entity.passive.EntityVillager || entity instanceof EntityIronGolem || (isNeutralMob(entity) && !isMobAggressive(entity)));
/*     */   }
/*     */   
/*     */   public static boolean isHostileMob(Entity entity) {
/* 158 */     return (entity.isCreatureType(EnumCreatureType.MONSTER, false) && !isNeutralMob(entity));
/*     */   }
/*     */   
/*     */   public static List<Vec3d> getUnsafeBlocksFromVec3d(Vec3d pos, int height, boolean floor) {
/* 162 */     ArrayList<Vec3d> vec3ds = new ArrayList<>();
/* 163 */     for (Vec3d vector : getOffsets(height, floor)) {
/* 164 */       BlockPos targetPos = (new BlockPos(pos)).func_177963_a(vector.field_72450_a, vector.field_72448_b, vector.field_72449_c);
/* 165 */       Block block = mc.field_71441_e.func_180495_p(targetPos).func_177230_c();
/* 166 */       if (block instanceof net.minecraft.block.BlockAir || block instanceof net.minecraft.block.BlockLiquid || block instanceof net.minecraft.block.BlockTallGrass || block instanceof net.minecraft.block.BlockFire || block instanceof net.minecraft.block.BlockDeadBush || block instanceof net.minecraft.block.BlockSnow)
/*     */       {
/* 168 */         vec3ds.add(vector); } 
/*     */     } 
/* 170 */     return vec3ds;
/*     */   }
/*     */   
/*     */   public static boolean isInHole(Entity entity) {
/* 174 */     return isBlockValid(new BlockPos(entity.field_70165_t, entity.field_70163_u, entity.field_70161_v));
/*     */   }
/*     */   
/*     */   public static boolean isBlockValid(BlockPos blockPos) {
/* 178 */     return (isBedrockHole(blockPos) || isObbyHole(blockPos) || isBothHole(blockPos));
/*     */   } public static boolean isObbyHole(BlockPos blockPos) { BlockPos[] touchingBlocks;
/*     */     BlockPos[] arrayOfBlockPos1;
/*     */     int i;
/*     */     byte b;
/* 183 */     for (arrayOfBlockPos1 = touchingBlocks = new BlockPos[] { blockPos.func_177978_c(), blockPos.func_177968_d(), blockPos.func_177974_f(), blockPos.func_177976_e(), blockPos.func_177977_b() }, i = arrayOfBlockPos1.length, b = 0; b < i; ) { BlockPos pos = arrayOfBlockPos1[b];
/* 184 */       IBlockState touchingState = mc.field_71441_e.func_180495_p(pos);
/* 185 */       if (touchingState.func_177230_c() != Blocks.field_150350_a && touchingState.func_177230_c() == Blocks.field_150343_Z) { b++; continue; }
/* 186 */        return false; }
/*     */     
/* 188 */     return true; }
/*     */   public static boolean isBedrockHole(BlockPos blockPos) { BlockPos[] touchingBlocks;
/*     */     BlockPos[] arrayOfBlockPos1;
/*     */     int i;
/*     */     byte b;
/* 193 */     for (arrayOfBlockPos1 = touchingBlocks = new BlockPos[] { blockPos.func_177978_c(), blockPos.func_177968_d(), blockPos.func_177974_f(), blockPos.func_177976_e(), blockPos.func_177977_b() }, i = arrayOfBlockPos1.length, b = 0; b < i; ) { BlockPos pos = arrayOfBlockPos1[b];
/* 194 */       IBlockState touchingState = mc.field_71441_e.func_180495_p(pos);
/* 195 */       if (touchingState.func_177230_c() != Blocks.field_150350_a && touchingState.func_177230_c() == Blocks.field_150357_h) { b++; continue; }
/* 196 */        return false; }
/*     */     
/* 198 */     return true; } public static boolean isBothHole(BlockPos blockPos) {
/*     */     BlockPos[] touchingBlocks;
/*     */     BlockPos[] arrayOfBlockPos1;
/*     */     int i;
/*     */     byte b;
/* 203 */     for (arrayOfBlockPos1 = touchingBlocks = new BlockPos[] { blockPos.func_177978_c(), blockPos.func_177968_d(), blockPos.func_177974_f(), blockPos.func_177976_e(), blockPos.func_177977_b() }, i = arrayOfBlockPos1.length, b = 0; b < i; ) { BlockPos pos = arrayOfBlockPos1[b];
/* 204 */       IBlockState touchingState = mc.field_71441_e.func_180495_p(pos);
/* 205 */       if (touchingState.func_177230_c() != Blocks.field_150350_a && (touchingState.func_177230_c() == Blocks.field_150357_h || touchingState.func_177230_c() == Blocks.field_150343_Z)) {
/*     */         b++; continue;
/* 207 */       }  return false; }
/*     */     
/* 209 */     return true;
/*     */   }
/*     */   
/*     */   public static Vec3d[] getUnsafeBlockArray(Entity entity, int height, boolean floor) {
/* 213 */     List<Vec3d> list = getUnsafeBlocks(entity, height, floor);
/* 214 */     Vec3d[] array = new Vec3d[list.size()];
/* 215 */     return list.<Vec3d>toArray(array);
/*     */   }
/*     */   
/*     */   public static Vec3d[] getUnsafeBlockArrayFromVec3d(Vec3d pos, int height, boolean floor) {
/* 219 */     List<Vec3d> list = getUnsafeBlocksFromVec3d(pos, height, floor);
/* 220 */     Vec3d[] array = new Vec3d[list.size()];
/* 221 */     return list.<Vec3d>toArray(array);
/*     */   }
/*     */   
/*     */   public static double getDst(Vec3d vec) {
/* 225 */     return mc.field_71439_g.func_174791_d().func_72438_d(vec);
/*     */   }
/*     */   
/*     */   public static boolean isTrapped(EntityPlayer player, boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop) {
/* 229 */     return (getUntrappedBlocks(player, antiScaffold, antiStep, legs, platform, antiDrop).size() == 0);
/*     */   }
/*     */   
/*     */   public static boolean isTrappedExtended(int extension, EntityPlayer player, boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop, boolean raytrace) {
/* 233 */     return (getUntrappedBlocksExtended(extension, player, antiScaffold, antiStep, legs, platform, antiDrop, raytrace).size() == 0);
/*     */   }
/*     */   
/*     */   public static List<Vec3d> getUntrappedBlocks(EntityPlayer player, boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop) {
/* 237 */     ArrayList<Vec3d> vec3ds = new ArrayList<>();
/* 238 */     if (!antiStep && getUnsafeBlocks((Entity)player, 2, false).size() == 4) {
/* 239 */       vec3ds.addAll(getUnsafeBlocks((Entity)player, 2, false));
/*     */     }
/* 241 */     for (int i = 0; i < (getTrapOffsets(antiScaffold, antiStep, legs, platform, antiDrop)).length; i++) {
/* 242 */       Vec3d vector = getTrapOffsets(antiScaffold, antiStep, legs, platform, antiDrop)[i];
/* 243 */       BlockPos targetPos = (new BlockPos(player.func_174791_d())).func_177963_a(vector.field_72450_a, vector.field_72448_b, vector.field_72449_c);
/* 244 */       Block block = mc.field_71441_e.func_180495_p(targetPos).func_177230_c();
/* 245 */       if (block instanceof net.minecraft.block.BlockAir || block instanceof net.minecraft.block.BlockLiquid || block instanceof net.minecraft.block.BlockTallGrass || block instanceof net.minecraft.block.BlockFire || block instanceof net.minecraft.block.BlockDeadBush || block instanceof net.minecraft.block.BlockSnow)
/*     */       {
/* 247 */         vec3ds.add(vector); } 
/*     */     } 
/* 249 */     return vec3ds;
/*     */   }
/*     */   
/*     */   public static boolean isInWater(Entity entity) {
/* 253 */     if (entity == null) {
/* 254 */       return false;
/*     */     }
/* 256 */     double y = entity.field_70163_u + 0.01D;
/* 257 */     for (int x = MathHelper.func_76128_c(entity.field_70165_t); x < MathHelper.func_76143_f(entity.field_70165_t); x++) {
/* 258 */       for (int z = MathHelper.func_76128_c(entity.field_70161_v); z < MathHelper.func_76143_f(entity.field_70161_v); ) {
/* 259 */         BlockPos pos = new BlockPos(x, (int)y, z);
/* 260 */         if (!(mc.field_71441_e.func_180495_p(pos).func_177230_c() instanceof net.minecraft.block.BlockLiquid)) { z++; continue; }
/* 261 */          return true;
/*     */       } 
/*     */     } 
/* 264 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean isDrivenByPlayer(Entity entityIn) {
/* 268 */     return (mc.field_71439_g != null && entityIn != null && entityIn.equals(mc.field_71439_g.func_184187_bx()));
/*     */   }
/*     */   
/*     */   public static boolean isPlayer(Entity entity) {
/* 272 */     return entity instanceof EntityPlayer;
/*     */   }
/*     */   
/*     */   public static boolean isAboveWater(Entity entity) {
/* 276 */     return isAboveWater(entity, false);
/*     */   }
/*     */   
/*     */   public static boolean isAboveWater(Entity entity, boolean packet) {
/* 280 */     if (entity == null) {
/* 281 */       return false;
/*     */     }
/* 283 */     double y = entity.field_70163_u - (packet ? 0.03D : (isPlayer(entity) ? 0.2D : 0.5D));
/* 284 */     for (int x = MathHelper.func_76128_c(entity.field_70165_t); x < MathHelper.func_76143_f(entity.field_70165_t); x++) {
/* 285 */       for (int z = MathHelper.func_76128_c(entity.field_70161_v); z < MathHelper.func_76143_f(entity.field_70161_v); ) {
/* 286 */         BlockPos pos = new BlockPos(x, MathHelper.func_76128_c(y), z);
/* 287 */         if (!(mc.field_71441_e.func_180495_p(pos).func_177230_c() instanceof net.minecraft.block.BlockLiquid)) { z++; continue; }
/* 288 */          return true;
/*     */       } 
/*     */     } 
/* 291 */     return false;
/*     */   }
/*     */   
/*     */   public static List<Vec3d> getUntrappedBlocksExtended(int extension, EntityPlayer player, boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop, boolean raytrace) {
/* 295 */     ArrayList<Vec3d> placeTargets = new ArrayList<>();
/* 296 */     if (extension == 1) {
/* 297 */       placeTargets.addAll(targets(player.func_174791_d(), antiScaffold, antiStep, legs, platform, antiDrop, raytrace));
/*     */     } else {
/* 299 */       int extend = 1;
/* 300 */       for (Vec3d vec3d : MathUtil.getBlockBlocks((Entity)player)) {
/* 301 */         if (extend > extension)
/* 302 */           break;  placeTargets.addAll(targets(vec3d, antiScaffold, antiStep, legs, platform, antiDrop, raytrace));
/* 303 */         extend++;
/*     */       } 
/*     */     } 
/* 306 */     ArrayList<Vec3d> removeList = new ArrayList<>();
/* 307 */     for (Vec3d vec3d : placeTargets) {
/* 308 */       BlockPos pos = new BlockPos(vec3d);
/* 309 */       if (BlockUtil.isPositionPlaceable(pos, raytrace) != -1)
/* 310 */         continue;  removeList.add(vec3d);
/*     */     } 
/* 312 */     for (Vec3d vec3d : removeList) {
/* 313 */       placeTargets.remove(vec3d);
/*     */     }
/* 315 */     return placeTargets;
/*     */   }
/*     */   
/*     */   public static List<Vec3d> targets(Vec3d vec3d, boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop, boolean raytrace) {
/* 319 */     ArrayList<Vec3d> placeTargets = new ArrayList<>();
/* 320 */     if (antiDrop) {
/* 321 */       Collections.addAll(placeTargets, BlockUtil.convertVec3ds(vec3d, antiDropOffsetList));
/*     */     }
/* 323 */     if (platform) {
/* 324 */       Collections.addAll(placeTargets, BlockUtil.convertVec3ds(vec3d, platformOffsetList));
/*     */     }
/* 326 */     if (legs) {
/* 327 */       Collections.addAll(placeTargets, BlockUtil.convertVec3ds(vec3d, legOffsetList));
/*     */     }
/* 329 */     Collections.addAll(placeTargets, BlockUtil.convertVec3ds(vec3d, OffsetList));
/* 330 */     if (antiStep) {
/* 331 */       Collections.addAll(placeTargets, BlockUtil.convertVec3ds(vec3d, antiStepOffsetList));
/*     */     } else {
/* 333 */       List<Vec3d> vec3ds = getUnsafeBlocksFromVec3d(vec3d, 2, false);
/* 334 */       if (vec3ds.size() == 4)
/*     */       {
/* 336 */         for (Vec3d vector : vec3ds) {
/* 337 */           BlockPos position = (new BlockPos(vec3d)).func_177963_a(vector.field_72450_a, vector.field_72448_b, vector.field_72449_c);
/* 338 */           switch (BlockUtil.isPositionPlaceable(position, raytrace)) {
/*     */             case 0:
/*     */               break;
/*     */             
/*     */             case -1:
/*     */             case 1:
/*     */             case 2:
/*     */               continue;
/*     */             
/*     */             case 3:
/* 348 */               placeTargets.add(vec3d.func_178787_e(vector)); break;
/*     */             default:
/*     */               // Byte code: goto -> 234
/*     */           } 
/* 352 */           if (antiScaffold) {
/* 353 */             Collections.addAll(placeTargets, BlockUtil.convertVec3ds(vec3d, antiScaffoldOffsetList));
/*     */           }
/* 355 */           return placeTargets;
/*     */         } 
/*     */       }
/*     */     } 
/* 359 */     if (antiScaffold) {
/* 360 */       Collections.addAll(placeTargets, BlockUtil.convertVec3ds(vec3d, antiScaffoldOffsetList));
/*     */     }
/* 362 */     return placeTargets;
/*     */   }
/*     */   
/*     */   public static List<Vec3d> getOffsetList(int y, boolean floor) {
/* 366 */     ArrayList<Vec3d> offsets = new ArrayList<>();
/* 367 */     offsets.add(new Vec3d(-1.0D, y, 0.0D));
/* 368 */     offsets.add(new Vec3d(1.0D, y, 0.0D));
/* 369 */     offsets.add(new Vec3d(0.0D, y, -1.0D));
/* 370 */     offsets.add(new Vec3d(0.0D, y, 1.0D));
/* 371 */     if (floor) {
/* 372 */       offsets.add(new Vec3d(0.0D, (y - 1), 0.0D));
/*     */     }
/* 374 */     return offsets;
/*     */   }
/*     */   
/*     */   public static Vec3d[] getOffsets(int y, boolean floor) {
/* 378 */     List<Vec3d> offsets = getOffsetList(y, floor);
/* 379 */     Vec3d[] array = new Vec3d[offsets.size()];
/* 380 */     return offsets.<Vec3d>toArray(array);
/*     */   }
/*     */   
/*     */   public static Vec3d[] getTrapOffsets(boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop) {
/* 384 */     List<Vec3d> offsets = getTrapOffsetsList(antiScaffold, antiStep, legs, platform, antiDrop);
/* 385 */     Vec3d[] array = new Vec3d[offsets.size()];
/* 386 */     return offsets.<Vec3d>toArray(array);
/*     */   }
/*     */   
/*     */   public static List<Vec3d> getTrapOffsetsList(boolean antiScaffold, boolean antiStep, boolean legs, boolean platform, boolean antiDrop) {
/* 390 */     ArrayList<Vec3d> offsets = new ArrayList<>(getOffsetList(1, false));
/* 391 */     offsets.add(new Vec3d(0.0D, 2.0D, 0.0D));
/* 392 */     if (antiScaffold) {
/* 393 */       offsets.add(new Vec3d(0.0D, 3.0D, 0.0D));
/*     */     }
/* 395 */     if (antiStep) {
/* 396 */       offsets.addAll(getOffsetList(2, false));
/*     */     }
/* 398 */     if (legs) {
/* 399 */       offsets.addAll(getOffsetList(0, false));
/*     */     }
/* 401 */     if (platform) {
/* 402 */       offsets.addAll(getOffsetList(-1, false));
/* 403 */       offsets.add(new Vec3d(0.0D, -1.0D, 0.0D));
/*     */     } 
/* 405 */     if (antiDrop) {
/* 406 */       offsets.add(new Vec3d(0.0D, -2.0D, 0.0D));
/*     */     }
/* 408 */     return offsets;
/*     */   }
/*     */   
/*     */   public static Vec3d[] getHeightOffsets(int min, int max) {
/* 412 */     ArrayList<Vec3d> offsets = new ArrayList<>();
/* 413 */     for (int i = min; i <= max; i++) {
/* 414 */       offsets.add(new Vec3d(0.0D, i, 0.0D));
/*     */     }
/* 416 */     Vec3d[] array = new Vec3d[offsets.size()];
/* 417 */     return offsets.<Vec3d>toArray(array);
/*     */   }
/*     */   
/*     */   public static BlockPos getRoundedBlockPos(Entity entity) {
/* 421 */     return new BlockPos(MathUtil.roundVec(entity.func_174791_d(), 0));
/*     */   }
/*     */   
/*     */   public static boolean isLiving(Entity entity) {
/* 425 */     return entity instanceof EntityLivingBase;
/*     */   }
/*     */   
/*     */   public static boolean isAlive(Entity entity) {
/* 429 */     return (isLiving(entity) && !entity.field_70128_L && ((EntityLivingBase)entity).func_110143_aJ() > 0.0F);
/*     */   }
/*     */   
/*     */   public static boolean isDead(Entity entity) {
/* 433 */     return !isAlive(entity);
/*     */   }
/*     */   
/*     */   public static float getHealth(Entity entity) {
/* 437 */     if (isLiving(entity)) {
/* 438 */       EntityLivingBase livingBase = (EntityLivingBase)entity;
/* 439 */       return livingBase.func_110143_aJ() + livingBase.func_110139_bj();
/*     */     } 
/* 441 */     return 0.0F;
/*     */   }
/*     */   
/*     */   public static float getHealth(Entity entity, boolean absorption) {
/* 445 */     if (isLiving(entity)) {
/* 446 */       EntityLivingBase livingBase = (EntityLivingBase)entity;
/* 447 */       return livingBase.func_110143_aJ() + (absorption ? livingBase.func_110139_bj() : 0.0F);
/*     */     } 
/* 449 */     return 0.0F;
/*     */   }
/*     */   
/*     */   public static boolean canEntityFeetBeSeen(Entity entityIn) {
/* 453 */     return (mc.field_71441_e.func_147447_a(new Vec3d(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70165_t + mc.field_71439_g.func_70047_e(), mc.field_71439_g.field_70161_v), new Vec3d(entityIn.field_70165_t, entityIn.field_70163_u, entityIn.field_70161_v), false, true, false) == null);
/*     */   }
/*     */   
/*     */   public static boolean isntValid(Entity entity, double range) {
/* 457 */     return (entity == null || isDead(entity) || entity.equals(mc.field_71439_g) || (entity instanceof EntityPlayer && Charon.friendManager.isFriend(entity.func_70005_c_())) || mc.field_71439_g.func_70068_e(entity) > MathUtil.square(range));
/*     */   }
/*     */   
/*     */   public static boolean isValid(Entity entity, double range) {
/* 461 */     return !isntValid(entity, range);
/*     */   }
/*     */   
/*     */   public static boolean holdingWeapon(EntityPlayer player) {
/* 465 */     return (player.func_184614_ca().func_77973_b() instanceof net.minecraft.item.ItemSword || player.func_184614_ca().func_77973_b() instanceof net.minecraft.item.ItemAxe);
/*     */   }
/*     */   
/*     */   public static double getMaxSpeed() {
/* 469 */     double maxModifier = 0.2873D;
/* 470 */     if (mc.field_71439_g.func_70644_a(Objects.<Potion>requireNonNull(Potion.func_188412_a(1)))) {
/* 471 */       maxModifier *= 1.0D + 0.2D * (((PotionEffect)Objects.<PotionEffect>requireNonNull(mc.field_71439_g.func_70660_b(Objects.<Potion>requireNonNull(Potion.func_188412_a(1))))).func_76458_c() + 1);
/*     */     }
/* 473 */     return maxModifier;
/*     */   }
/*     */   
/*     */   public static void mutliplyEntitySpeed(Entity entity, double multiplier) {
/* 477 */     if (entity != null) {
/* 478 */       entity.field_70159_w *= multiplier;
/* 479 */       entity.field_70179_y *= multiplier;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean isEntityMoving(Entity entity) {
/* 484 */     if (entity == null) {
/* 485 */       return false;
/*     */     }
/* 487 */     if (entity instanceof EntityPlayer) {
/* 488 */       return (mc.field_71474_y.field_74351_w.func_151470_d() || mc.field_71474_y.field_74368_y.func_151470_d() || mc.field_71474_y.field_74370_x.func_151470_d() || mc.field_71474_y.field_74366_z.func_151470_d());
/*     */     }
/* 490 */     return (entity.field_70159_w != 0.0D || entity.field_70181_x != 0.0D || entity.field_70179_y != 0.0D);
/*     */   }
/*     */   
/*     */   public static double getEntitySpeed(Entity entity) {
/* 494 */     if (entity != null) {
/* 495 */       double distTraveledLastTickX = entity.field_70165_t - entity.field_70169_q;
/* 496 */       double distTraveledLastTickZ = entity.field_70161_v - entity.field_70166_s;
/* 497 */       double speed = MathHelper.func_76133_a(distTraveledLastTickX * distTraveledLastTickX + distTraveledLastTickZ * distTraveledLastTickZ);
/* 498 */       return speed * 20.0D;
/*     */     } 
/* 500 */     return 0.0D;
/*     */   }
/*     */   
/*     */   public static boolean is32k(ItemStack stack) {
/* 504 */     return (EnchantmentHelper.func_77506_a(Enchantments.field_185302_k, stack) >= 1000);
/*     */   }
/*     */   
/*     */   public static void moveEntityStrafe(double speed, Entity entity) {
/* 508 */     if (entity != null) {
/* 509 */       MovementInput movementInput = mc.field_71439_g.field_71158_b;
/* 510 */       double forward = movementInput.field_192832_b;
/* 511 */       double strafe = movementInput.field_78902_a;
/* 512 */       float yaw = mc.field_71439_g.field_70177_z;
/* 513 */       if (forward == 0.0D && strafe == 0.0D) {
/* 514 */         entity.field_70159_w = 0.0D;
/* 515 */         entity.field_70179_y = 0.0D;
/*     */       } else {
/* 517 */         if (forward != 0.0D) {
/* 518 */           if (strafe > 0.0D) {
/* 519 */             yaw += ((forward > 0.0D) ? -45 : 45);
/* 520 */           } else if (strafe < 0.0D) {
/* 521 */             yaw += ((forward > 0.0D) ? 45 : -45);
/*     */           } 
/* 523 */           strafe = 0.0D;
/* 524 */           if (forward > 0.0D) {
/* 525 */             forward = 1.0D;
/* 526 */           } else if (forward < 0.0D) {
/* 527 */             forward = -1.0D;
/*     */           } 
/*     */         } 
/* 530 */         entity.field_70159_w = forward * speed * Math.cos(Math.toRadians((yaw + 90.0F))) + strafe * speed * Math.sin(Math.toRadians((yaw + 90.0F)));
/* 531 */         entity.field_70179_y = forward * speed * Math.sin(Math.toRadians((yaw + 90.0F))) - strafe * speed * Math.cos(Math.toRadians((yaw + 90.0F)));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean rayTraceHitCheck(Entity entity, boolean shouldCheck) {
/* 537 */     return (!shouldCheck || mc.field_71439_g.func_70685_l(entity));
/*     */   }
/*     */   
/*     */   public static Color getColor(Entity entity, int red, int green, int blue, int alpha, boolean colorFriends) {
/* 541 */     Color color = new Color(red / 255.0F, green / 255.0F, blue / 255.0F, alpha / 255.0F);
/* 542 */     if (entity instanceof EntityPlayer && colorFriends && Charon.friendManager.isFriend((EntityPlayer)entity)) {
/* 543 */       color = new Color(0.33333334F, 1.0F, 1.0F, alpha / 255.0F);
/*     */     }
/* 545 */     return color;
/*     */   }
/*     */   
/*     */   public static boolean isMoving() {
/* 549 */     return (mc.field_71439_g.field_191988_bg != 0.0D || mc.field_71439_g.field_70702_br != 0.0D);
/*     */   }
/*     */   
/*     */   public static EntityPlayer getClosestEnemy(double distance) {
/* 553 */     EntityPlayer closest = null;
/* 554 */     for (EntityPlayer player : mc.field_71441_e.field_73010_i) {
/* 555 */       if (isntValid((Entity)player, distance))
/* 556 */         continue;  if (closest == null) {
/* 557 */         closest = player;
/*     */         continue;
/*     */       } 
/* 560 */       if (mc.field_71439_g.func_70068_e((Entity)player) >= mc.field_71439_g.func_70068_e((Entity)closest))
/*     */         continue; 
/* 562 */       closest = player;
/*     */     } 
/* 564 */     return closest;
/*     */   }
/*     */   
/*     */   public static boolean checkCollide() {
/* 568 */     if (mc.field_71439_g.func_70093_af()) {
/* 569 */       return false;
/*     */     }
/* 571 */     if (mc.field_71439_g.func_184187_bx() != null && (mc.field_71439_g.func_184187_bx()).field_70143_R >= 3.0F) {
/* 572 */       return false;
/*     */     }
/* 574 */     return (mc.field_71439_g.field_70143_R < 3.0F);
/*     */   }
/*     */   
/*     */   public static BlockPos getPlayerPosWithEntity() {
/* 578 */     return new BlockPos((mc.field_71439_g.func_184187_bx() != null) ? (mc.field_71439_g.func_184187_bx()).field_70165_t : mc.field_71439_g.field_70165_t, (mc.field_71439_g.func_184187_bx() != null) ? (mc.field_71439_g.func_184187_bx()).field_70163_u : mc.field_71439_g.field_70163_u, (mc.field_71439_g.func_184187_bx() != null) ? (mc.field_71439_g.func_184187_bx()).field_70161_v : mc.field_71439_g.field_70161_v);
/*     */   }
/*     */   
/*     */   public static double[] forward(double speed) {
/* 582 */     float forward = mc.field_71439_g.field_71158_b.field_192832_b;
/* 583 */     float side = mc.field_71439_g.field_71158_b.field_78902_a;
/* 584 */     float yaw = mc.field_71439_g.field_70126_B + (mc.field_71439_g.field_70177_z - mc.field_71439_g.field_70126_B) * mc.func_184121_ak();
/* 585 */     if (forward != 0.0F) {
/* 586 */       if (side > 0.0F) {
/* 587 */         yaw += ((forward > 0.0F) ? -45 : 45);
/* 588 */       } else if (side < 0.0F) {
/* 589 */         yaw += ((forward > 0.0F) ? 45 : -45);
/*     */       } 
/* 591 */       side = 0.0F;
/* 592 */       if (forward > 0.0F) {
/* 593 */         forward = 1.0F;
/* 594 */       } else if (forward < 0.0F) {
/* 595 */         forward = -1.0F;
/*     */       } 
/*     */     } 
/* 598 */     double sin = Math.sin(Math.toRadians((yaw + 90.0F)));
/* 599 */     double cos = Math.cos(Math.toRadians((yaw + 90.0F)));
/* 600 */     double posX = forward * speed * cos + side * speed * sin;
/* 601 */     double posZ = forward * speed * sin - side * speed * cos;
/* 602 */     return new double[] { posX, posZ };
/*     */   }
/*     */   
/*     */   public static Map<String, Integer> getTextRadarPlayers() {
/* 606 */     Map<String, Integer> output = new HashMap<>();
/* 607 */     DecimalFormat dfHealth = new DecimalFormat("#.#");
/* 608 */     dfHealth.setRoundingMode(RoundingMode.CEILING);
/* 609 */     DecimalFormat dfDistance = new DecimalFormat("#.#");
/* 610 */     dfDistance.setRoundingMode(RoundingMode.CEILING);
/* 611 */     StringBuilder healthSB = new StringBuilder();
/* 612 */     StringBuilder distanceSB = new StringBuilder();
/* 613 */     for (EntityPlayer player : mc.field_71441_e.field_73010_i) {
/* 614 */       if (player.func_82150_aj() || player.func_70005_c_().equals(mc.field_71439_g.func_70005_c_()))
/* 615 */         continue;  int hpRaw = (int)getHealth((Entity)player);
/* 616 */       String hp = dfHealth.format(hpRaw);
/* 617 */       healthSB.append("Â§");
/* 618 */       if (hpRaw >= 20) {
/* 619 */         healthSB.append("a");
/* 620 */       } else if (hpRaw >= 10) {
/* 621 */         healthSB.append("e");
/* 622 */       } else if (hpRaw >= 5) {
/* 623 */         healthSB.append("6");
/*     */       } else {
/* 625 */         healthSB.append("c");
/*     */       } 
/* 627 */       healthSB.append(hp);
/* 628 */       int distanceInt = (int)mc.field_71439_g.func_70032_d((Entity)player);
/* 629 */       String distance = dfDistance.format(distanceInt);
/* 630 */       distanceSB.append("Â§");
/* 631 */       if (distanceInt >= 25) {
/* 632 */         distanceSB.append("a");
/* 633 */       } else if (distanceInt > 10) {
/* 634 */         distanceSB.append("6");
/*     */       } else {
/* 636 */         distanceSB.append("c");
/*     */       } 
/* 638 */       distanceSB.append(distance);
/* 639 */       output.put(healthSB.toString() + " " + (Charon.friendManager.isFriend(player) ? (String)ChatFormatting.AQUA : (String)ChatFormatting.RED) + player.func_70005_c_() + " " + distanceSB.toString() + " Â§f0", Integer.valueOf((int)mc.field_71439_g.func_70032_d((Entity)player)));
/* 640 */       healthSB.setLength(0);
/* 641 */       distanceSB.setLength(0);
/*     */     } 
/* 643 */     if (!output.isEmpty()) {
/* 644 */       output = MathUtil.sortByValue(output, false);
/*     */     }
/* 646 */     return output;
/*     */   }
/*     */   
/*     */   public static boolean isAboveBlock(Entity entity, BlockPos blockPos) {
/* 650 */     return (entity.field_70163_u >= blockPos.func_177956_o());
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/util/EntityUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */