/*    */ package cc.zip.charon.util;
/*    */ 
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.potion.Potion;
/*    */ 
/*    */ public class MotionUtil
/*    */ {
/*    */   public static boolean isMoving(EntityLivingBase entity) {
/* 10 */     return (entity.field_191988_bg != 0.0F || entity.field_70702_br != 0.0F);
/*    */   }
/*    */   public static boolean isMovings() {
/* 13 */     return ((Minecraft.func_71410_x()).field_71439_g.field_191988_bg != 0.0D || (Minecraft.func_71410_x()).field_71439_g.field_70702_br != 0.0D);
/*    */   }
/*    */   
/*    */   public static void setSpeed(EntityLivingBase entity, double speed) {
/* 17 */     double[] dir = forward(speed);
/* 18 */     entity.field_70159_w = dir[0];
/* 19 */     entity.field_70179_y = dir[1];
/*    */   }
/*    */   
/*    */   public static double getBaseMoveSpeed() {
/* 23 */     double baseSpeed = 0.2873D;
/* 24 */     if ((Minecraft.func_71410_x()).field_71439_g != null && (Minecraft.func_71410_x()).field_71439_g.func_70644_a(Potion.func_188412_a(1))) {
/* 25 */       int amplifier = (Minecraft.func_71410_x()).field_71439_g.func_70660_b(Potion.func_188412_a(1)).func_76458_c();
/* 26 */       baseSpeed *= 1.0D + 0.2D * (amplifier + 1);
/*    */     } 
/* 28 */     return baseSpeed;
/*    */   }
/*    */   
/*    */   public static double[] forward(double speed) {
/* 32 */     float forward = (Minecraft.func_71410_x()).field_71439_g.field_71158_b.field_192832_b;
/* 33 */     float side = (Minecraft.func_71410_x()).field_71439_g.field_71158_b.field_78902_a;
/* 34 */     float yaw = (Minecraft.func_71410_x()).field_71439_g.field_70126_B + ((Minecraft.func_71410_x()).field_71439_g.field_70177_z - (Minecraft.func_71410_x()).field_71439_g.field_70126_B) * Minecraft.func_71410_x().func_184121_ak();
/* 35 */     if (forward != 0.0F) {
/* 36 */       if (side > 0.0F) {
/* 37 */         yaw += ((forward > 0.0F) ? -45 : 45);
/*    */       }
/* 39 */       else if (side < 0.0F) {
/* 40 */         yaw += ((forward > 0.0F) ? 45 : -45);
/*    */       } 
/* 42 */       side = 0.0F;
/* 43 */       if (forward > 0.0F) {
/* 44 */         forward = 1.0F;
/*    */       }
/* 46 */       else if (forward < 0.0F) {
/* 47 */         forward = -1.0F;
/*    */       } 
/*    */     } 
/* 50 */     double sin = Math.sin(Math.toRadians((yaw + 90.0F)));
/* 51 */     double cos = Math.cos(Math.toRadians((yaw + 90.0F)));
/* 52 */     double posX = forward * speed * cos + side * speed * sin;
/* 53 */     double posZ = forward * speed * sin - side * speed * cos;
/* 54 */     return new double[] { posX, posZ };
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/util/MotionUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */