/*     */ package cc.zip.charon.util;
/*     */ import cc.zip.charon.Charon;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.enchantment.EnchantmentHelper;
/*     */ import net.minecraft.init.Enchantments;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.inventory.ClickType;
/*     */ import net.minecraft.inventory.EntityEquipmentSlot;
/*     */ import net.minecraft.inventory.Slot;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemArmor;
/*     */ import net.minecraft.item.ItemBlock;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketHeldItemChange;
/*     */ 
/*     */ public class InventoryUtil implements Util {
/*     */   public static void switchToHotbarSlot(int slot, boolean silent) {
/*  24 */     if (mc.field_71439_g.field_71071_by.field_70461_c == slot || slot < 0) {
/*     */       return;
/*     */     }
/*  27 */     if (silent) {
/*  28 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange(slot));
/*  29 */       mc.field_71442_b.func_78765_e();
/*     */     } else {
/*  31 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange(slot));
/*  32 */       mc.field_71439_g.field_71071_by.field_70461_c = slot;
/*  33 */       mc.field_71442_b.func_78765_e();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void switchToHotbarSlot(Class clazz, boolean silent) {
/*  38 */     int slot = findHotbarBlock(clazz);
/*  39 */     if (slot > -1) {
/*  40 */       switchToHotbarSlot(slot, silent);
/*     */     }
/*     */   }
/*     */   
/*     */   public static boolean isNull(ItemStack stack) {
/*  45 */     return (stack == null || stack.func_77973_b() instanceof net.minecraft.item.ItemAir);
/*     */   }
/*     */   
/*     */   public static int findHotbarBlock(Class clazz) {
/*  49 */     for (int i = 0; i < 9; i++) {
/*     */       
/*  51 */       ItemStack stack = mc.field_71439_g.field_71071_by.func_70301_a(i);
/*  52 */       if (stack != ItemStack.field_190927_a) {
/*  53 */         if (clazz.isInstance(stack.func_77973_b()))
/*  54 */           return i; 
/*     */         Block block;
/*  56 */         if (stack.func_77973_b() instanceof ItemBlock && clazz.isInstance(block = ((ItemBlock)stack.func_77973_b()).func_179223_d()))
/*     */         {
/*  58 */           return i; } 
/*     */       } 
/*  60 */     }  return -1;
/*     */   }
/*     */   
/*     */   public static int findHotbarBlock(Block blockIn) {
/*  64 */     for (int i = 0; i < 9; ) {
/*     */       
/*  66 */       ItemStack stack = mc.field_71439_g.field_71071_by.func_70301_a(i); Block block;
/*  67 */       if (stack == ItemStack.field_190927_a || !(stack.func_77973_b() instanceof ItemBlock) || (block = ((ItemBlock)stack.func_77973_b()).func_179223_d()) != blockIn) {
/*     */         i++; continue;
/*  69 */       }  return i;
/*     */     } 
/*  71 */     return -1;
/*     */   }
/*     */   
/*     */   public static int getItemHotbar(Item input) {
/*  75 */     for (int i = 0; i < 9; ) {
/*  76 */       Item item = mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b();
/*  77 */       if (Item.func_150891_b(item) != Item.func_150891_b(input)) { i++; continue; }
/*  78 */        return i;
/*     */     } 
/*  80 */     return -1;
/*     */   }
/*     */   
/*     */   public static int findStackInventory(Item input) {
/*  84 */     return findStackInventory(input, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public static int findStackInventory(Item input, boolean withHotbar) {
/*  89 */     int i = withHotbar ? 0 : 9, n = i;
/*  90 */     while (i < 36) {
/*  91 */       Item item = mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b();
/*  92 */       if (Item.func_150891_b(input) == Item.func_150891_b(item)) {
/*  93 */         return i + ((i < 9) ? 36 : 0);
/*     */       }
/*  95 */       i++;
/*     */     } 
/*  97 */     return -1;
/*     */   }
/*     */   
/*     */   public static int findItemInventorySlot(Item item, boolean offHand) {
/* 101 */     AtomicInteger slot = new AtomicInteger();
/* 102 */     slot.set(-1);
/* 103 */     for (Map.Entry<Integer, ItemStack> entry : getInventoryAndHotbarSlots().entrySet()) {
/* 104 */       if (((ItemStack)entry.getValue()).func_77973_b() != item || (((Integer)entry.getKey()).intValue() == 45 && !offHand))
/* 105 */         continue;  slot.set(((Integer)entry.getKey()).intValue());
/* 106 */       return slot.get();
/*     */     } 
/* 108 */     return slot.get();
/*     */   }
/*     */   
/*     */   public static List<Integer> findEmptySlots(boolean withXCarry) {
/* 112 */     ArrayList<Integer> outPut = new ArrayList<>();
/* 113 */     for (Map.Entry<Integer, ItemStack> entry : getInventoryAndHotbarSlots().entrySet()) {
/* 114 */       if (!((ItemStack)entry.getValue()).field_190928_g && ((ItemStack)entry.getValue()).func_77973_b() != Items.field_190931_a)
/* 115 */         continue;  outPut.add(entry.getKey());
/*     */     } 
/* 117 */     if (withXCarry)
/* 118 */       for (int i = 1; i < 5; i++) {
/* 119 */         Slot craftingSlot = mc.field_71439_g.field_71069_bz.field_75151_b.get(i);
/* 120 */         ItemStack craftingStack = craftingSlot.func_75211_c();
/* 121 */         if (craftingStack.func_190926_b() || craftingStack.func_77973_b() == Items.field_190931_a) {
/* 122 */           outPut.add(Integer.valueOf(i));
/*     */         }
/*     */       }  
/* 125 */     return outPut;
/*     */   }
/*     */   
/*     */   public static int findInventoryBlock(Class clazz, boolean offHand) {
/* 129 */     AtomicInteger slot = new AtomicInteger();
/* 130 */     slot.set(-1);
/* 131 */     for (Map.Entry<Integer, ItemStack> entry : getInventoryAndHotbarSlots().entrySet()) {
/* 132 */       if (!isBlock(((ItemStack)entry.getValue()).func_77973_b(), clazz) || (((Integer)entry.getKey()).intValue() == 45 && !offHand))
/* 133 */         continue;  slot.set(((Integer)entry.getKey()).intValue());
/* 134 */       return slot.get();
/*     */     } 
/* 136 */     return slot.get();
/*     */   }
/*     */   
/*     */   public static boolean isBlock(Item item, Class clazz) {
/* 140 */     if (item instanceof ItemBlock) {
/* 141 */       Block block = ((ItemBlock)item).func_179223_d();
/* 142 */       return clazz.isInstance(block);
/*     */     } 
/* 144 */     return false;
/*     */   }
/*     */   
/*     */   public static void confirmSlot(int slot) {
/* 148 */     mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketHeldItemChange(slot));
/* 149 */     mc.field_71439_g.field_71071_by.field_70461_c = slot;
/* 150 */     mc.field_71442_b.func_78765_e();
/*     */   }
/*     */   
/*     */   public static Map<Integer, ItemStack> getInventoryAndHotbarSlots() {
/* 154 */     return getInventorySlots(9, 44);
/*     */   }
/*     */   
/*     */   private static Map<Integer, ItemStack> getInventorySlots(int currentI, int last) {
/* 158 */     HashMap<Integer, ItemStack> fullInventorySlots = new HashMap<>();
/* 159 */     for (int current = currentI; current <= last; current++) {
/* 160 */       fullInventorySlots.put(Integer.valueOf(current), mc.field_71439_g.field_71069_bz.func_75138_a().get(current));
/*     */     }
/* 162 */     return fullInventorySlots;
/*     */   }
/*     */   
/*     */   public static boolean[] switchItem(boolean back, int lastHotbarSlot, boolean switchedItem, Switch mode, Class clazz) {
/* 166 */     boolean[] switchedItemSwitched = { switchedItem, false };
/* 167 */     switch (mode) {
/*     */       case NORMAL:
/* 169 */         if (!back && !switchedItem) {
/* 170 */           switchToHotbarSlot(findHotbarBlock(clazz), false);
/* 171 */           switchedItemSwitched[0] = true;
/* 172 */         } else if (back && switchedItem) {
/* 173 */           switchToHotbarSlot(lastHotbarSlot, false);
/* 174 */           switchedItemSwitched[0] = false;
/*     */         } 
/* 176 */         switchedItemSwitched[1] = true;
/*     */         break;
/*     */       
/*     */       case SILENT:
/* 180 */         if (!back && !switchedItem) {
/* 181 */           switchToHotbarSlot(findHotbarBlock(clazz), true);
/* 182 */           switchedItemSwitched[0] = true;
/* 183 */         } else if (back && switchedItem) {
/* 184 */           switchedItemSwitched[0] = false;
/* 185 */           Charon.inventoryManager.recoverSilent(lastHotbarSlot);
/*     */         } 
/* 187 */         switchedItemSwitched[1] = true;
/*     */         break;
/*     */       
/*     */       case NONE:
/* 191 */         switchedItemSwitched[1] = (back || mc.field_71439_g.field_71071_by.field_70461_c == findHotbarBlock(clazz));
/*     */         break;
/*     */     } 
/* 194 */     return switchedItemSwitched;
/*     */   }
/*     */   
/*     */   public static boolean[] switchItemToItem(boolean back, int lastHotbarSlot, boolean switchedItem, Switch mode, Item item) {
/* 198 */     boolean[] switchedItemSwitched = { switchedItem, false };
/* 199 */     switch (mode) {
/*     */       case NORMAL:
/* 201 */         if (!back && !switchedItem) {
/* 202 */           switchToHotbarSlot(getItemHotbar(item), false);
/* 203 */           switchedItemSwitched[0] = true;
/* 204 */         } else if (back && switchedItem) {
/* 205 */           switchToHotbarSlot(lastHotbarSlot, false);
/* 206 */           switchedItemSwitched[0] = false;
/*     */         } 
/* 208 */         switchedItemSwitched[1] = true;
/*     */         break;
/*     */       
/*     */       case SILENT:
/* 212 */         if (!back && !switchedItem) {
/* 213 */           switchToHotbarSlot(getItemHotbar(item), true);
/* 214 */           switchedItemSwitched[0] = true;
/* 215 */         } else if (back && switchedItem) {
/* 216 */           switchedItemSwitched[0] = false;
/* 217 */           Charon.inventoryManager.recoverSilent(lastHotbarSlot);
/*     */         } 
/* 219 */         switchedItemSwitched[1] = true;
/*     */         break;
/*     */       
/*     */       case NONE:
/* 223 */         switchedItemSwitched[1] = (back || mc.field_71439_g.field_71071_by.field_70461_c == getItemHotbar(item));
/*     */         break;
/*     */     } 
/* 226 */     return switchedItemSwitched;
/*     */   }
/*     */   
/*     */   public static boolean holdingItem(Class clazz) {
/* 230 */     boolean result = false;
/* 231 */     ItemStack stack = mc.field_71439_g.func_184614_ca();
/* 232 */     result = isInstanceOf(stack, clazz);
/* 233 */     if (!result) {
/* 234 */       ItemStack offhand = mc.field_71439_g.func_184592_cb();
/* 235 */       result = isInstanceOf(stack, clazz);
/*     */     } 
/* 237 */     return result;
/*     */   }
/*     */   
/*     */   public static boolean isInstanceOf(ItemStack stack, Class clazz) {
/* 241 */     if (stack == null) {
/* 242 */       return false;
/*     */     }
/* 244 */     Item item = stack.func_77973_b();
/* 245 */     if (clazz.isInstance(item)) {
/* 246 */       return true;
/*     */     }
/* 248 */     if (item instanceof ItemBlock) {
/* 249 */       Block block = Block.func_149634_a(item);
/* 250 */       return clazz.isInstance(block);
/*     */     } 
/* 252 */     return false;
/*     */   }
/*     */   
/*     */   public static int getEmptyXCarry() {
/* 256 */     for (int i = 1; i < 5; ) {
/* 257 */       Slot craftingSlot = mc.field_71439_g.field_71069_bz.field_75151_b.get(i);
/* 258 */       ItemStack craftingStack = craftingSlot.func_75211_c();
/* 259 */       if (!craftingStack.func_190926_b() && craftingStack.func_77973_b() != Items.field_190931_a) { i++; continue; }
/* 260 */        return i;
/*     */     } 
/* 262 */     return -1;
/*     */   }
/*     */   
/*     */   public static boolean isSlotEmpty(int i) {
/* 266 */     Slot slot = mc.field_71439_g.field_71069_bz.field_75151_b.get(i);
/* 267 */     ItemStack stack = slot.func_75211_c();
/* 268 */     return stack.func_190926_b();
/*     */   }
/*     */   
/*     */   public static int convertHotbarToInv(int input) {
/* 272 */     return 36 + input;
/*     */   }
/*     */   
/*     */   public static boolean areStacksCompatible(ItemStack stack1, ItemStack stack2) {
/* 276 */     if (!stack1.func_77973_b().equals(stack2.func_77973_b())) {
/* 277 */       return false;
/*     */     }
/* 279 */     if (stack1.func_77973_b() instanceof ItemBlock && stack2.func_77973_b() instanceof ItemBlock) {
/* 280 */       Block block1 = ((ItemBlock)stack1.func_77973_b()).func_179223_d();
/* 281 */       Block block2 = ((ItemBlock)stack2.func_77973_b()).func_179223_d();
/* 282 */       if (!block1.field_149764_J.equals(block2.field_149764_J)) {
/* 283 */         return false;
/*     */       }
/*     */     } 
/* 286 */     if (!stack1.func_82833_r().equals(stack2.func_82833_r())) {
/* 287 */       return false;
/*     */     }
/* 289 */     return (stack1.func_77952_i() == stack2.func_77952_i());
/*     */   }
/*     */   
/*     */   public static EntityEquipmentSlot getEquipmentFromSlot(int slot) {
/* 293 */     if (slot == 5) {
/* 294 */       return EntityEquipmentSlot.HEAD;
/*     */     }
/* 296 */     if (slot == 6) {
/* 297 */       return EntityEquipmentSlot.CHEST;
/*     */     }
/* 299 */     if (slot == 7) {
/* 300 */       return EntityEquipmentSlot.LEGS;
/*     */     }
/* 302 */     return EntityEquipmentSlot.FEET;
/*     */   }
/*     */   
/*     */   public static int findArmorSlot(EntityEquipmentSlot type, boolean binding) {
/* 306 */     int slot = -1;
/* 307 */     float damage = 0.0F;
/* 308 */     for (int i = 9; i < 45; i++) {
/*     */ 
/*     */       
/* 311 */       ItemStack s = (Minecraft.func_71410_x()).field_71439_g.field_71069_bz.func_75139_a(i).func_75211_c(); ItemArmor armor;
/* 312 */       if (s.func_77973_b() != Items.field_190931_a && s.func_77973_b() instanceof ItemArmor && (armor = (ItemArmor)s.func_77973_b()).func_185083_B_() == type) {
/*     */         
/* 314 */         float currentDamage = (armor.field_77879_b + EnchantmentHelper.func_77506_a(Enchantments.field_180310_c, s));
/* 315 */         boolean cursed = (binding && EnchantmentHelper.func_190938_b(s)), bl = cursed;
/* 316 */         if (currentDamage > damage && !cursed)
/* 317 */         { damage = currentDamage;
/* 318 */           slot = i; } 
/*     */       } 
/* 320 */     }  return slot;
/*     */   }
/*     */   
/*     */   public static int findArmorSlot(EntityEquipmentSlot type, boolean binding, boolean withXCarry) {
/* 324 */     int slot = findArmorSlot(type, binding);
/* 325 */     if (slot == -1 && withXCarry) {
/* 326 */       float damage = 0.0F;
/* 327 */       for (int i = 1; i < 5; i++) {
/*     */ 
/*     */         
/* 330 */         Slot craftingSlot = mc.field_71439_g.field_71069_bz.field_75151_b.get(i);
/* 331 */         ItemStack craftingStack = craftingSlot.func_75211_c(); ItemArmor armor;
/* 332 */         if (craftingStack.func_77973_b() != Items.field_190931_a && craftingStack.func_77973_b() instanceof ItemArmor && (armor = (ItemArmor)craftingStack.func_77973_b()).func_185083_B_() == type) {
/*     */           
/* 334 */           float currentDamage = (armor.field_77879_b + EnchantmentHelper.func_77506_a(Enchantments.field_180310_c, craftingStack));
/* 335 */           boolean cursed = (binding && EnchantmentHelper.func_190938_b(craftingStack)), bl = cursed;
/* 336 */           if (currentDamage > damage && !cursed)
/* 337 */           { damage = currentDamage;
/* 338 */             slot = i; } 
/*     */         } 
/*     */       } 
/* 341 */     }  return slot;
/*     */   }
/*     */   
/*     */   public static int findItemInventorySlot(Item item, boolean offHand, boolean withXCarry) {
/* 345 */     int slot = findItemInventorySlot(item, offHand);
/* 346 */     if (slot == -1 && withXCarry)
/* 347 */       for (int i = 1; i < 5; i++) {
/*     */         
/* 349 */         Slot craftingSlot = mc.field_71439_g.field_71069_bz.field_75151_b.get(i);
/* 350 */         ItemStack craftingStack = craftingSlot.func_75211_c(); Item craftingStackItem;
/* 351 */         if (craftingStack.func_77973_b() != Items.field_190931_a && (craftingStackItem = craftingStack.func_77973_b()) == item)
/*     */         {
/* 353 */           slot = i;
/*     */         }
/*     */       }  
/* 356 */     return slot;
/*     */   }
/*     */   
/*     */   public static int findBlockSlotInventory(Class clazz, boolean offHand, boolean withXCarry) {
/* 360 */     int slot = findInventoryBlock(clazz, offHand);
/* 361 */     if (slot == -1 && withXCarry)
/* 362 */       for (int i = 1; i < 5; i++) {
/*     */         
/* 364 */         Slot craftingSlot = mc.field_71439_g.field_71069_bz.field_75151_b.get(i);
/* 365 */         ItemStack craftingStack = craftingSlot.func_75211_c();
/* 366 */         if (craftingStack.func_77973_b() != Items.field_190931_a) {
/* 367 */           Item craftingStackItem = craftingStack.func_77973_b();
/* 368 */           if (clazz.isInstance(craftingStackItem)) {
/* 369 */             slot = i;
/*     */           } else {
/*     */             Block block;
/* 372 */             if (craftingStackItem instanceof ItemBlock && clazz.isInstance(block = ((ItemBlock)craftingStackItem).func_179223_d()))
/*     */             {
/* 374 */               slot = i; } 
/*     */           } 
/*     */         } 
/* 377 */       }   return slot;
/*     */   }
/*     */   
/*     */   public enum Switch {
/* 381 */     NORMAL,
/* 382 */     SILENT,
/* 383 */     NONE;
/*     */   }
/*     */   
/*     */   public static class Task
/*     */   {
/*     */     private final int slot;
/*     */     private final boolean update;
/*     */     private final boolean quickClick;
/*     */     
/*     */     public Task() {
/* 393 */       this.update = true;
/* 394 */       this.slot = -1;
/* 395 */       this.quickClick = false;
/*     */     }
/*     */     
/*     */     public Task(int slot) {
/* 399 */       this.slot = slot;
/* 400 */       this.quickClick = false;
/* 401 */       this.update = false;
/*     */     }
/*     */     
/*     */     public Task(int slot, boolean quickClick) {
/* 405 */       this.slot = slot;
/* 406 */       this.quickClick = quickClick;
/* 407 */       this.update = false;
/*     */     }
/*     */     
/*     */     public void run() {
/* 411 */       if (this.update) {
/* 412 */         Util.mc.field_71442_b.func_78765_e();
/*     */       }
/* 414 */       if (this.slot != -1) {
/* 415 */         Util.mc.field_71442_b.func_187098_a(0, this.slot, 0, this.quickClick ? ClickType.QUICK_MOVE : ClickType.PICKUP, (EntityPlayer)Util.mc.field_71439_g);
/*     */       }
/*     */     }
/*     */     
/*     */     public boolean isSwitching() {
/* 420 */       return !this.update;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/util/InventoryUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */