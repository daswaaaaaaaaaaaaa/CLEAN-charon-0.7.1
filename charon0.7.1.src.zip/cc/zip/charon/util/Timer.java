/*    */ package cc.zip.charon.util;
/*    */ 
/*    */ 
/*    */ public class Timer
/*    */ {
/*  6 */   private long current = System.currentTimeMillis();
/*    */ 
/*    */   
/*  9 */   private long time = -1L;
/*    */   
/*    */   public boolean passedS(double s) {
/* 12 */     return (getMs(System.nanoTime() - this.time) >= (long)(s * 1000.0D));
/*    */   }
/*    */   
/*    */   public boolean passedM(double m) {
/* 16 */     return (getMs(System.nanoTime() - this.time) >= (long)(m * 1000.0D * 60.0D));
/*    */   }
/*    */   
/*    */   public boolean passedDms(double dms) {
/* 20 */     return (getMs(System.nanoTime() - this.time) >= (long)(dms * 10.0D));
/*    */   }
/*    */   
/*    */   public boolean passedDs(double ds) {
/* 24 */     return (getMs(System.nanoTime() - this.time) >= (long)(ds * 100.0D));
/*    */   }
/*    */   
/*    */   public boolean passedMs(long ms) {
/* 28 */     return (getMs(System.nanoTime() - this.time) >= ms);
/*    */   }
/*    */   
/*    */   public boolean passedNS(long ns) {
/* 32 */     return (System.nanoTime() - this.time >= ns);
/*    */   }
/*    */   
/*    */   public void setMs(long ms) {
/* 36 */     this.time = System.nanoTime() - ms * 1000000L;
/*    */   }
/*    */   
/*    */   public long getPassedTimeMs() {
/* 40 */     return getMs(System.nanoTime() - this.time);
/*    */   }
/*    */   
/*    */   public Timer reset() {
/* 44 */     this.time = System.nanoTime();
/* 45 */     return this;
/*    */   }
/*    */   
/*    */   public long getMs(long time) {
/* 49 */     return time / 1000000L;
/*    */   }
/*    */   public boolean hasReached(long delay) {
/* 52 */     return (System.currentTimeMillis() - this.current >= delay);
/*    */   }
/*    */   public boolean hasReached(long delay, boolean reset) {
/* 55 */     if (reset)
/* 56 */       reset(); 
/* 57 */     return (System.currentTimeMillis() - this.current >= delay);
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/util/Timer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */