/*     */ package cc.zip.charon.util;
/*     */ import cc.zip.charon.features.command.Command;
/*     */ import com.google.gson.JsonArray;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonParser;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Scanner;
/*     */ import java.util.UUID;
/*     */ import javax.net.ssl.HttpsURLConnection;
/*     */ import net.minecraft.client.network.NetHandlerPlayClient;
/*     */ import net.minecraft.client.network.NetworkPlayerInfo;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ 
/*     */ public class PlayerUtil implements Util {
/*  25 */   private static final JsonParser PARSER = new JsonParser();
/*     */   
/*     */   public static String getNameFromUUID(UUID uuid) {
/*     */     try {
/*  29 */       lookUpName process = new lookUpName(uuid);
/*  30 */       Thread thread = new Thread(process);
/*  31 */       thread.start();
/*  32 */       thread.join();
/*  33 */       return process.getName();
/*  34 */     } catch (Exception e) {
/*  35 */       return null;
/*     */     } 
/*     */   }
/*     */   public static boolean isMoving(EntityLivingBase entity) {
/*  39 */     return (entity.field_191988_bg != 0.0F || entity.field_70702_br != 0.0F);
/*     */   }
/*     */   public static void setSpeed(EntityLivingBase entity, double speed) {
/*  42 */     double[] dir = forward(speed);
/*  43 */     entity.field_70159_w = dir[0];
/*  44 */     entity.field_70179_y = dir[1];
/*     */   }
/*     */   public static double getBaseMoveSpeed() {
/*  47 */     double baseSpeed = 0.2873D;
/*  48 */     if (mc.field_71439_g != null && mc.field_71439_g.func_70644_a(Potion.func_188412_a(1))) {
/*  49 */       int amplifier = mc.field_71439_g.func_70660_b(Potion.func_188412_a(1)).func_76458_c();
/*  50 */       baseSpeed *= 1.0D + 0.2D * (amplifier + 1);
/*     */     } 
/*  52 */     return baseSpeed;
/*     */   }
/*     */   public static double[] forward(double speed) {
/*  55 */     float forward = mc.field_71439_g.field_71158_b.field_192832_b;
/*  56 */     float side = mc.field_71439_g.field_71158_b.field_78902_a;
/*  57 */     float yaw = mc.field_71439_g.field_70126_B + (mc.field_71439_g.field_70177_z - mc.field_71439_g.field_70126_B) * mc.func_184121_ak();
/*  58 */     if (forward != 0.0F) {
/*  59 */       if (side > 0.0F) {
/*  60 */         yaw += ((forward > 0.0F) ? -45 : 45);
/*     */       }
/*  62 */       else if (side < 0.0F) {
/*  63 */         yaw += ((forward > 0.0F) ? 45 : -45);
/*     */       } 
/*  65 */       side = 0.0F;
/*  66 */       if (forward > 0.0F) {
/*  67 */         forward = 1.0F;
/*     */       }
/*  69 */       else if (forward < 0.0F) {
/*  70 */         forward = -1.0F;
/*     */       } 
/*     */     } 
/*  73 */     double sin = Math.sin(Math.toRadians((yaw + 90.0F)));
/*  74 */     double cos = Math.cos(Math.toRadians((yaw + 90.0F)));
/*  75 */     double posX = forward * speed * cos + side * speed * sin;
/*  76 */     double posZ = forward * speed * sin - side * speed * cos;
/*  77 */     return new double[] { posX, posZ };
/*     */   }
/*     */   
/*     */   public static String getNameFromUUID(String uuid) {
/*     */     try {
/*  82 */       lookUpName process = new lookUpName(uuid);
/*  83 */       Thread thread = new Thread(process);
/*  84 */       thread.start();
/*  85 */       thread.join();
/*  86 */       return process.getName();
/*  87 */     } catch (Exception e) {
/*  88 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static UUID getUUIDFromName(String name) {
/*     */     try {
/*  94 */       lookUpUUID process = new lookUpUUID(name);
/*  95 */       Thread thread = new Thread(process);
/*  96 */       thread.start();
/*  97 */       thread.join();
/*  98 */       return process.getUUID();
/*  99 */     } catch (Exception e) {
/* 100 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String requestIDs(String data) {
/*     */     try {
/* 106 */       String query = "https://api.mojang.com/profiles/minecraft";
/* 107 */       URL url = new URL(query);
/* 108 */       HttpURLConnection conn = (HttpURLConnection)url.openConnection();
/* 109 */       conn.setConnectTimeout(5000);
/* 110 */       conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
/* 111 */       conn.setDoOutput(true);
/* 112 */       conn.setDoInput(true);
/* 113 */       conn.setRequestMethod("POST");
/* 114 */       OutputStream os = conn.getOutputStream();
/* 115 */       os.write(data.getBytes(StandardCharsets.UTF_8));
/* 116 */       os.close();
/* 117 */       InputStream in = new BufferedInputStream(conn.getInputStream());
/* 118 */       String res = convertStreamToString(in);
/* 119 */       in.close();
/* 120 */       conn.disconnect();
/* 121 */       return res;
/* 122 */     } catch (Exception e) {
/* 123 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String convertStreamToString(InputStream is) {
/* 128 */     Scanner s = (new Scanner(is)).useDelimiter("\\A");
/* 129 */     return s.hasNext() ? s.next() : "/";
/*     */   }
/*     */   
/*     */   public static List<String> getHistoryOfNames(UUID id) {
/*     */     try {
/* 134 */       JsonArray array = getResources(new URL("https://api.mojang.com/user/profiles/" + getIdNoHyphens(id) + "/names"), "GET").getAsJsonArray();
/* 135 */       List<String> temp = Lists.newArrayList();
/* 136 */       for (JsonElement e : array) {
/* 137 */         JsonObject node = e.getAsJsonObject();
/* 138 */         String name = node.get("name").getAsString();
/* 139 */         long changedAt = node.has("changedToAt") ? node.get("changedToAt").getAsLong() : 0L;
/* 140 */         temp.add(name + "Г‚В§8" + (new Date(changedAt)).toString());
/*     */       } 
/* 142 */       Collections.sort(temp);
/* 143 */       return temp;
/* 144 */     } catch (Exception ignored) {
/* 145 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String getIdNoHyphens(UUID uuid) {
/* 150 */     return uuid.toString().replaceAll("-", "");
/*     */   }
/*     */   
/*     */   private static JsonElement getResources(URL url, String request) throws Exception {
/* 154 */     return getResources(url, request, null);
/*     */   }
/*     */   
/*     */   private static JsonElement getResources(URL url, String request, JsonElement element) throws Exception {
/* 158 */     HttpsURLConnection connection = null;
/*     */     try {
/* 160 */       connection = (HttpsURLConnection)url.openConnection();
/* 161 */       connection.setDoOutput(true);
/* 162 */       connection.setRequestMethod(request);
/* 163 */       connection.setRequestProperty("Content-Type", "application/json");
/* 164 */       if (element != null) {
/* 165 */         DataOutputStream output = new DataOutputStream(connection.getOutputStream());
/* 166 */         output.writeBytes(AdvancementManager.field_192783_b.toJson(element));
/* 167 */         output.close();
/*     */       } 
/* 169 */       Scanner scanner = new Scanner(connection.getInputStream());
/* 170 */       StringBuilder builder = new StringBuilder();
/* 171 */       while (scanner.hasNextLine()) {
/* 172 */         builder.append(scanner.nextLine());
/* 173 */         builder.append('\n');
/*     */       } 
/* 175 */       scanner.close();
/* 176 */       String json = builder.toString();
/* 177 */       JsonElement data = PARSER.parse(json);
/* 178 */       return data;
/*     */     } finally {
/* 180 */       if (connection != null)
/* 181 */         connection.disconnect(); 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static class lookUpUUID implements Runnable {
/*     */     private final String name;
/*     */     private volatile UUID uuid;
/*     */     
/*     */     public lookUpUUID(String name) {
/* 190 */       this.name = name;
/*     */     }
/*     */     
/*     */     public void run() {
/*     */       NetworkPlayerInfo profile;
/*     */       try {
/* 196 */         ArrayList<NetworkPlayerInfo> infoMap = new ArrayList<>(((NetHandlerPlayClient)Objects.<NetHandlerPlayClient>requireNonNull(Util.mc.func_147114_u())).func_175106_d());
/* 197 */         profile = infoMap.stream().filter(networkPlayerInfo -> networkPlayerInfo.func_178845_a().getName().equalsIgnoreCase(this.name)).findFirst().orElse(null);
/* 198 */         assert profile != null;
/* 199 */         this.uuid = profile.func_178845_a().getId();
/* 200 */       } catch (Exception e) {
/* 201 */         profile = null;
/*     */       } 
/* 203 */       if (profile == null) {
/* 204 */         Command.sendMessage("Player isn't online. Looking up UUID..");
/* 205 */         String s = PlayerUtil.requestIDs("[\"" + this.name + "\"]");
/* 206 */         if (s == null || s.isEmpty()) {
/* 207 */           Command.sendMessage("Couldn't find player ID. Are you connected to the internet? (0)");
/*     */         } else {
/* 209 */           JsonElement element = (new JsonParser()).parse(s);
/* 210 */           if (element.getAsJsonArray().size() == 0) {
/* 211 */             Command.sendMessage("Couldn't find player ID. (1)");
/*     */           } else {
/*     */             try {
/* 214 */               String id = element.getAsJsonArray().get(0).getAsJsonObject().get("id").getAsString();
/* 215 */               this.uuid = UUIDTypeAdapter.fromString(id);
/* 216 */             } catch (Exception e) {
/* 217 */               e.printStackTrace();
/* 218 */               Command.sendMessage("Couldn't find player ID. (2)");
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     public UUID getUUID() {
/* 226 */       return this.uuid;
/*     */     }
/*     */     
/*     */     public String getName() {
/* 230 */       return this.name;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class lookUpName implements Runnable {
/*     */     private final String uuid;
/*     */     private final UUID uuidID;
/*     */     private volatile String name;
/*     */     
/*     */     public lookUpName(String input) {
/* 240 */       this.uuid = input;
/* 241 */       this.uuidID = UUID.fromString(input);
/*     */     }
/*     */     
/*     */     public lookUpName(UUID input) {
/* 245 */       this.uuidID = input;
/* 246 */       this.uuid = input.toString();
/*     */     }
/*     */     
/*     */     public void run() {
/* 250 */       this.name = lookUpName();
/*     */     }
/*     */     
/*     */     public String lookUpName() {
/* 254 */       EntityPlayer player = null;
/* 255 */       if (Util.mc.field_71441_e != null) {
/* 256 */         player = Util.mc.field_71441_e.func_152378_a(this.uuidID);
/*     */       }
/* 258 */       if (player == null) {
/* 259 */         String url = "https://api.mojang.com/user/profiles/" + this.uuid.replace("-", "") + "/names";
/*     */         try {
/* 261 */           String nameJson = IOUtils.toString(new URL(url));
/* 262 */           if (nameJson.contains(",")) {
/* 263 */             List<String> names = Arrays.asList(nameJson.split(","));
/* 264 */             Collections.reverse(names);
/* 265 */             return ((String)names.get(1)).replace("{\"name\":\"", "").replace("\"", "");
/*     */           } 
/* 267 */           return nameJson.replace("[{\"name\":\"", "").replace("\"}]", "");
/*     */         }
/* 269 */         catch (IOException exception) {
/* 270 */           exception.printStackTrace();
/* 271 */           return null;
/*     */         } 
/*     */       } 
/* 274 */       return player.func_70005_c_();
/*     */     }
/*     */     
/*     */     public String getName() {
/* 278 */       return this.name;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/util/PlayerUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */