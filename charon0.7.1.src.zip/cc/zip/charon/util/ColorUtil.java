/*    */ package cc.zip.charon.util;
/*    */ 
/*    */ import cc.zip.charon.features.modules.client.ClickGui;
/*    */ import java.awt.Color;
/*    */ 
/*    */ public class ColorUtil
/*    */ {
/*    */   public static int toARGB(int r, int g, int b, int a) {
/*  9 */     return (new Color(r, g, b, a)).getRGB();
/*    */   }
/*    */   
/*    */   public static int toRGBA(int r, int g, int b) {
/* 13 */     return toRGBA(r, g, b, 255);
/*    */   }
/*    */   
/*    */   public static int toRGBA(int r, int g, int b, int a) {
/* 17 */     return (r << 16) + (g << 8) + b + (a << 24);
/*    */   }
/*    */   
/*    */   public static int toRGBA(float r, float g, float b, float a) {
/* 21 */     return toRGBA((int)(r * 255.0F), (int)(g * 255.0F), (int)(b * 255.0F), (int)(a * 255.0F));
/*    */   }
/*    */   
/*    */   public static Color rainbow(int delay) {
/* 25 */     double rainbowState = Math.ceil((System.currentTimeMillis() + delay) / 20.0D);
/* 26 */     return Color.getHSBColor((float)((rainbowState %= 360.0D) / 360.0D), ((Float)(ClickGui.getInstance()).rainbowSaturation.getValue()).floatValue() / 255.0F, ((Float)(ClickGui.getInstance()).rainbowBrightness.getValue()).floatValue() / 255.0F);
/*    */   }
/*    */   
/*    */   public static int toRGBA(float[] colors) {
/* 30 */     if (colors.length != 4) {
/* 31 */       throw new IllegalArgumentException("colors[] must have a length of 4!");
/*    */     }
/* 33 */     return toRGBA(colors[0], colors[1], colors[2], colors[3]);
/*    */   }
/*    */   
/*    */   public static int toRGBA(double[] colors) {
/* 37 */     if (colors.length != 4) {
/* 38 */       throw new IllegalArgumentException("colors[] must have a length of 4!");
/*    */     }
/* 40 */     return toRGBA((float)colors[0], (float)colors[1], (float)colors[2], (float)colors[3]);
/*    */   }
/*    */   
/*    */   public static int toRGBA(Color color) {
/* 44 */     return toRGBA(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/util/ColorUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */