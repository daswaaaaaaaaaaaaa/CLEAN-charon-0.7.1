/*   */ package cc.zip.charon.util;
/*   */ 
/*   */ import net.minecraft.client.Minecraft;
/*   */ 
/*   */ public interface Util
/*   */ {
/* 7 */   public static final Minecraft mc = Minecraft.func_71410_x();
/*   */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/util/Util.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */