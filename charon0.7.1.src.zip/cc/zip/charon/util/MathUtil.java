/*     */ package cc.zip.charon.util;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Map;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ 
/*     */ public class MathUtil implements Util {
/*  15 */   private static final Random random = new Random();
/*     */   
/*     */   public static int getRandom(int min, int max) {
/*  18 */     return min + random.nextInt(max - min + 1);
/*     */   }
/*     */   
/*     */   public static double getRandom(double min, double max) {
/*  22 */     return MathHelper.func_151237_a(min + random.nextDouble() * max, min, max);
/*     */   }
/*     */   
/*     */   public static float getRandom(float min, float max) {
/*  26 */     return MathHelper.func_76131_a(min + random.nextFloat() * max, min, max);
/*     */   }
/*     */   
/*     */   public static float[] calcAngleNoY(Vec3d from, Vec3d to) {
/*  30 */     double difX = to.field_72450_a - from.field_72450_a;
/*  31 */     double difZ = to.field_72449_c - from.field_72449_c;
/*  32 */     return new float[] { (float)MathHelper.func_76138_g(Math.toDegrees(Math.atan2(difZ, difX)) - 90.0D) };
/*     */   }
/*     */   
/*     */   public static int clamp(int num, int min, int max) {
/*  36 */     return (num < min) ? min : Math.min(num, max);
/*     */   }
/*     */   
/*     */   public static float clamp(float num, float min, float max) {
/*  40 */     return (num < min) ? min : Math.min(num, max);
/*     */   }
/*     */   
/*     */   public static double clamp(double num, double min, double max) {
/*  44 */     return (num < min) ? min : Math.min(num, max);
/*     */   }
/*     */   
/*     */   public static float sin(float value) {
/*  48 */     return MathHelper.func_76126_a(value);
/*     */   }
/*     */   
/*     */   public static float cos(float value) {
/*  52 */     return MathHelper.func_76134_b(value);
/*     */   }
/*     */   
/*     */   public static float wrapDegrees(float value) {
/*  56 */     return MathHelper.func_76142_g(value);
/*     */   }
/*     */   
/*     */   public static double wrapDegrees(double value) {
/*  60 */     return MathHelper.func_76138_g(value);
/*     */   }
/*     */   
/*     */   public static Vec3d roundVec(Vec3d vec3d, int places) {
/*  64 */     return new Vec3d(round(vec3d.field_72450_a, places), round(vec3d.field_72448_b, places), round(vec3d.field_72449_c, places));
/*     */   }
/*     */   
/*     */   public static double square(double input) {
/*  68 */     return input * input;
/*     */   }
/*     */   
/*     */   public static double round(double value, int places) {
/*  72 */     if (places < 0) {
/*  73 */       throw new IllegalArgumentException();
/*     */     }
/*  75 */     BigDecimal bd = BigDecimal.valueOf(value);
/*  76 */     bd = bd.setScale(places, RoundingMode.FLOOR);
/*  77 */     return bd.doubleValue();
/*     */   }
/*     */   
/*     */   public static float wrap(float valI) {
/*  81 */     float val = valI % 360.0F;
/*  82 */     if (val >= 180.0F) {
/*  83 */       val -= 360.0F;
/*     */     }
/*  85 */     if (val < -180.0F) {
/*  86 */       val += 360.0F;
/*     */     }
/*  88 */     return val;
/*     */   }
/*     */   
/*     */   public static Vec3d direction(float yaw) {
/*  92 */     return new Vec3d(Math.cos(degToRad((yaw + 90.0F))), 0.0D, Math.sin(degToRad((yaw + 90.0F))));
/*     */   }
/*     */   
/*     */   public static float round(float value, int places) {
/*  96 */     if (places < 0) {
/*  97 */       throw new IllegalArgumentException();
/*     */     }
/*  99 */     BigDecimal bd = BigDecimal.valueOf(value);
/* 100 */     bd = bd.setScale(places, RoundingMode.FLOOR);
/* 101 */     return bd.floatValue();
/*     */   }
/*     */   
/*     */   public static <K, V extends Comparable<? super V>> Map<K, V> sortByValue(Map<K, V> map, boolean descending) {
/* 105 */     LinkedList<Map.Entry<K, V>> list = new LinkedList<>(map.entrySet());
/* 106 */     if (descending) {
/* 107 */       list.sort((Comparator)Map.Entry.comparingByValue(Comparator.reverseOrder()));
/*     */     } else {
/* 109 */       list.sort((Comparator)Map.Entry.comparingByValue());
/*     */     } 
/* 111 */     LinkedHashMap<Object, Object> result = new LinkedHashMap<>();
/* 112 */     for (Map.Entry<K, V> entry : list) {
/* 113 */       result.put(entry.getKey(), entry.getValue());
/*     */     }
/* 115 */     return (Map)result;
/*     */   }
/*     */   
/*     */   public static String getTimeOfDay() {
/* 119 */     Calendar c = Calendar.getInstance();
/* 120 */     int timeOfDay = c.get(11);
/* 121 */     if (timeOfDay < 12) {
/* 122 */       return "Good Morning ";
/*     */     }
/* 124 */     if (timeOfDay < 16) {
/* 125 */       return "Good Afternoon ";
/*     */     }
/* 127 */     if (timeOfDay < 21) {
/* 128 */       return "Good Evening ";
/*     */     }
/* 130 */     return "Good Night ";
/*     */   }
/*     */   
/*     */   public static double radToDeg(double rad) {
/* 134 */     return rad * 57.295780181884766D;
/*     */   }
/*     */   
/*     */   public static double degToRad(double deg) {
/* 138 */     return deg * 0.01745329238474369D;
/*     */   }
/*     */   
/*     */   public static double getIncremental(double val, double inc) {
/* 142 */     double one = 1.0D / inc;
/* 143 */     return Math.round(val * one) / one;
/*     */   }
/*     */   
/*     */   public static double[] directionSpeed(double speed) {
/* 147 */     float forward = mc.field_71439_g.field_71158_b.field_192832_b;
/* 148 */     float side = mc.field_71439_g.field_71158_b.field_78902_a;
/* 149 */     float yaw = mc.field_71439_g.field_70126_B + (mc.field_71439_g.field_70177_z - mc.field_71439_g.field_70126_B) * mc.func_184121_ak();
/* 150 */     if (forward != 0.0F) {
/* 151 */       if (side > 0.0F) {
/* 152 */         yaw += ((forward > 0.0F) ? -45 : 45);
/* 153 */       } else if (side < 0.0F) {
/* 154 */         yaw += ((forward > 0.0F) ? 45 : -45);
/*     */       } 
/* 156 */       side = 0.0F;
/* 157 */       if (forward > 0.0F) {
/* 158 */         forward = 1.0F;
/* 159 */       } else if (forward < 0.0F) {
/* 160 */         forward = -1.0F;
/*     */       } 
/*     */     } 
/* 163 */     double sin = Math.sin(Math.toRadians((yaw + 90.0F)));
/* 164 */     double cos = Math.cos(Math.toRadians((yaw + 90.0F)));
/* 165 */     double posX = forward * speed * cos + side * speed * sin;
/* 166 */     double posZ = forward * speed * sin - side * speed * cos;
/* 167 */     return new double[] { posX, posZ };
/*     */   }
/*     */   
/*     */   public static List<Vec3d> getBlockBlocks(Entity entity) {
/* 171 */     ArrayList<Vec3d> vec3ds = new ArrayList<>();
/* 172 */     AxisAlignedBB bb = entity.func_174813_aQ();
/* 173 */     double y = entity.field_70163_u;
/* 174 */     double minX = round(bb.field_72340_a, 0);
/* 175 */     double minZ = round(bb.field_72339_c, 0);
/* 176 */     double maxX = round(bb.field_72336_d, 0);
/* 177 */     double maxZ = round(bb.field_72334_f, 0);
/* 178 */     if (minX != maxX) {
/* 179 */       vec3ds.add(new Vec3d(minX, y, minZ));
/* 180 */       vec3ds.add(new Vec3d(maxX, y, minZ));
/* 181 */       if (minZ != maxZ) {
/* 182 */         vec3ds.add(new Vec3d(minX, y, maxZ));
/* 183 */         vec3ds.add(new Vec3d(maxX, y, maxZ));
/* 184 */         return vec3ds;
/*     */       } 
/* 186 */     } else if (minZ != maxZ) {
/* 187 */       vec3ds.add(new Vec3d(minX, y, minZ));
/* 188 */       vec3ds.add(new Vec3d(minX, y, maxZ));
/* 189 */       return vec3ds;
/*     */     } 
/* 191 */     vec3ds.add(entity.func_174791_d());
/* 192 */     return vec3ds;
/*     */   }
/*     */   
/*     */   public static boolean areVec3dsAligned(Vec3d vec3d1, Vec3d vec3d2) {
/* 196 */     return areVec3dsAlignedRetarded(vec3d1, vec3d2);
/*     */   }
/*     */   
/*     */   public static boolean areVec3dsAlignedRetarded(Vec3d vec3d1, Vec3d vec3d2) {
/* 200 */     BlockPos pos1 = new BlockPos(vec3d1);
/* 201 */     BlockPos pos2 = new BlockPos(vec3d2.field_72450_a, vec3d1.field_72448_b, vec3d2.field_72449_c);
/* 202 */     return pos1.equals(pos2);
/*     */   }
/*     */   
/*     */   public static float[] calcAngle(Vec3d from, Vec3d to) {
/* 206 */     double difX = to.field_72450_a - from.field_72450_a;
/* 207 */     double difY = (to.field_72448_b - from.field_72448_b) * -1.0D;
/* 208 */     double difZ = to.field_72449_c - from.field_72449_c;
/* 209 */     double dist = MathHelper.func_76133_a(difX * difX + difZ * difZ);
/* 210 */     return new float[] { (float)MathHelper.func_76138_g(Math.toDegrees(Math.atan2(difZ, difX)) - 90.0D), (float)MathHelper.func_76138_g(Math.toDegrees(Math.atan2(difY, dist))) };
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/util/MathUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */