/*     */ package cc.zip.charon.util;
/*     */ import net.minecraft.enchantment.EnchantmentHelper;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.SharedMonsterAttributes;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.init.MobEffects;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.util.CombatRules;
/*     */ import net.minecraft.util.DamageSource;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.world.Explosion;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ public class DamageUtil implements Util {
/*     */   public static int getRoundedDamage(ItemStack stack) {
/*  21 */     return (int)getDamageInPercent(stack);
/*     */   }
/*     */   
/*     */   public static float getDamageInPercent(ItemStack stack) {
/*  25 */     return (getItemDamage(stack) / stack.func_77958_k()) * 100.0F;
/*     */   }
/*     */   
/*     */   public static boolean isArmorLow(EntityPlayer player, int durability) {
/*  29 */     for (ItemStack piece : player.field_71071_by.field_70460_b) {
/*  30 */       if (piece == null) {
/*  31 */         return true;
/*     */       }
/*  33 */       if (getItemDamage(piece) >= durability)
/*  34 */         continue;  return true;
/*     */     } 
/*  36 */     return false;
/*     */   }
/*     */   
/*     */   public static int getItemDamage(ItemStack stack) {
/*  40 */     return stack.func_77958_k() - stack.func_77952_i();
/*     */   }
/*     */   
/*     */   public static boolean canTakeDamage(boolean suicide) {
/*  44 */     return (!mc.field_71439_g.field_71075_bZ.field_75098_d && !suicide);
/*     */   }
/*     */   
/*     */   public static float calculateDamage(double posX, double posY, double posZ, Entity entity) {
/*  48 */     float doubleExplosionSize = 12.0F;
/*  49 */     double distancedsize = entity.func_70011_f(posX, posY, posZ) / doubleExplosionSize;
/*  50 */     Vec3d vec3d = new Vec3d(posX, posY, posZ);
/*  51 */     double blockDensity = 0.0D;
/*     */     try {
/*  53 */       blockDensity = entity.field_70170_p.func_72842_a(vec3d, entity.func_174813_aQ());
/*  54 */     } catch (Exception exception) {}
/*     */ 
/*     */     
/*  57 */     double v = (1.0D - distancedsize) * blockDensity;
/*  58 */     float damage = (int)((v * v + v) / 2.0D * 7.0D * doubleExplosionSize + 1.0D);
/*  59 */     double finald = 1.0D;
/*  60 */     if (entity instanceof EntityLivingBase) {
/*  61 */       finald = getBlastReduction((EntityLivingBase)entity, getDamageMultiplied(damage), new Explosion((World)mc.field_71441_e, null, posX, posY, posZ, 6.0F, false, true));
/*     */     }
/*  63 */     return (float)finald;
/*     */   }
/*     */   
/*     */   public static float getBlastReduction(EntityLivingBase entity, float damageI, Explosion explosion) {
/*  67 */     float damage = damageI;
/*  68 */     if (entity instanceof EntityPlayer) {
/*  69 */       EntityPlayer ep = (EntityPlayer)entity;
/*  70 */       DamageSource ds = DamageSource.func_94539_a(explosion);
/*  71 */       damage = CombatRules.func_189427_a(damage, ep.func_70658_aO(), (float)ep.func_110148_a(SharedMonsterAttributes.field_189429_h).func_111126_e());
/*  72 */       int k = 0;
/*     */       try {
/*  74 */         k = EnchantmentHelper.func_77508_a(ep.func_184193_aE(), ds);
/*  75 */       } catch (Exception exception) {}
/*     */ 
/*     */       
/*  78 */       float f = MathHelper.func_76131_a(k, 0.0F, 20.0F);
/*  79 */       damage *= 1.0F - f / 25.0F;
/*  80 */       if (entity.func_70644_a(MobEffects.field_76429_m)) {
/*  81 */         damage -= damage / 4.0F;
/*     */       }
/*  83 */       damage = Math.max(damage, 0.0F);
/*  84 */       return damage;
/*     */     } 
/*  86 */     damage = CombatRules.func_189427_a(damage, entity.func_70658_aO(), (float)entity.func_110148_a(SharedMonsterAttributes.field_189429_h).func_111126_e());
/*  87 */     return damage;
/*     */   }
/*     */   
/*     */   public static float getDamageMultiplied(float damage) {
/*  91 */     int diff = mc.field_71441_e.func_175659_aa().func_151525_a();
/*  92 */     return damage * ((diff == 0) ? 0.0F : ((diff == 2) ? 1.0F : ((diff == 1) ? 0.5F : 1.5F)));
/*     */   }
/*     */   
/*     */   public static float calculateDamage(BlockPos pos, Entity entity) {
/*  96 */     return calculateDamage(pos.func_177958_n() + 0.5D, (pos.func_177956_o() + 1), pos.func_177952_p() + 0.5D, entity);
/*     */   }
/*     */   
/*     */   public static int getCooldownByWeapon(EntityPlayer player) {
/* 100 */     Item item = player.func_184614_ca().func_77973_b();
/* 101 */     if (item instanceof net.minecraft.item.ItemSword) {
/* 102 */       return 600;
/*     */     }
/* 104 */     if (item instanceof net.minecraft.item.ItemPickaxe) {
/* 105 */       return 850;
/*     */     }
/* 107 */     if (item == Items.field_151036_c) {
/* 108 */       return 1100;
/*     */     }
/* 110 */     if (item == Items.field_151018_J) {
/* 111 */       return 500;
/*     */     }
/* 113 */     if (item == Items.field_151019_K) {
/* 114 */       return 350;
/*     */     }
/* 116 */     if (item == Items.field_151053_p || item == Items.field_151049_t) {
/* 117 */       return 1250;
/*     */     }
/* 119 */     if (item instanceof net.minecraft.item.ItemSpade || item == Items.field_151006_E || item == Items.field_151056_x || item == Items.field_151017_I || item == Items.field_151013_M) {
/* 120 */       return 1000;
/*     */     }
/* 122 */     return 250;
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/util/DamageUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */