/*     */ package cc.zip.charon.util;
/*     */ import cc.zip.charon.features.modules.client.ClickGui;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ 
/*     */ public class RotationUtil implements Util {
/*     */   public static Vec3d getEyesPos() {
/*  14 */     return new Vec3d(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + mc.field_71439_g.func_70047_e(), mc.field_71439_g.field_70161_v);
/*     */   }
/*     */   
/*     */   public static double[] calculateLookAt(double px, double py, double pz, EntityPlayer me) {
/*  18 */     double dirx = me.field_70165_t - px;
/*  19 */     double diry = me.field_70163_u - py;
/*  20 */     double dirz = me.field_70161_v - pz;
/*  21 */     double len = Math.sqrt(dirx * dirx + diry * diry + dirz * dirz);
/*  22 */     double pitch = Math.asin(diry /= len);
/*  23 */     double yaw = Math.atan2(dirz /= len, dirx /= len);
/*  24 */     pitch = pitch * 180.0D / Math.PI;
/*  25 */     yaw = yaw * 180.0D / Math.PI;
/*  26 */     return new double[] { yaw += 90.0D, pitch };
/*     */   }
/*     */   
/*     */   public static float[] getLegitRotations(Vec3d vec) {
/*  30 */     Vec3d eyesPos = getEyesPos();
/*  31 */     double diffX = vec.field_72450_a - eyesPos.field_72450_a;
/*  32 */     double diffY = vec.field_72448_b - eyesPos.field_72448_b;
/*  33 */     double diffZ = vec.field_72449_c - eyesPos.field_72449_c;
/*  34 */     double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
/*  35 */     float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0F;
/*  36 */     float pitch = (float)-Math.toDegrees(Math.atan2(diffY, diffXZ));
/*  37 */     return new float[] { mc.field_71439_g.field_70177_z + MathHelper.func_76142_g(yaw - mc.field_71439_g.field_70177_z), mc.field_71439_g.field_70125_A + MathHelper.func_76142_g(pitch - mc.field_71439_g.field_70125_A) };
/*     */   }
/*     */   
/*     */   public static void faceYawAndPitch(float yaw, float pitch) {
/*  41 */     mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Rotation(yaw, pitch, mc.field_71439_g.field_70122_E));
/*     */   }
/*     */   public static boolean isInFov(BlockPos pos) {
/*  44 */     return (pos != null && (mc.field_71439_g.func_174818_b(pos) < 4.0D || yawDist(pos) < (getHalvedfov() + 2.0F)));
/*     */   }
/*     */   
/*     */   public static boolean isInFov(Entity entity) {
/*  48 */     return (entity != null && (mc.field_71439_g.func_70068_e(entity) < 4.0D || yawDist(entity) < (getHalvedfov() + 2.0F)));
/*     */   }
/*     */   public static double yawDist(BlockPos pos) {
/*  51 */     if (pos != null) {
/*  52 */       Vec3d difference = (new Vec3d((Vec3i)pos)).func_178788_d(mc.field_71439_g.func_174824_e(mc.func_184121_ak()));
/*  53 */       double d = Math.abs(mc.field_71439_g.field_70177_z - Math.toDegrees(Math.atan2(difference.field_72449_c, difference.field_72450_a)) - 90.0D) % 360.0D;
/*  54 */       return (d > 180.0D) ? (360.0D - d) : d;
/*     */     } 
/*  56 */     return 0.0D;
/*     */   }
/*     */   public static double yawDist(Entity e) {
/*  59 */     if (e != null) {
/*  60 */       Vec3d difference = e.func_174791_d().func_72441_c(0.0D, (e.func_70047_e() / 2.0F), 0.0D).func_178788_d(mc.field_71439_g.func_174824_e(mc.func_184121_ak()));
/*  61 */       double d = Math.abs(mc.field_71439_g.field_70177_z - Math.toDegrees(Math.atan2(difference.field_72449_c, difference.field_72450_a)) - 90.0D) % 360.0D;
/*  62 */       return (d > 180.0D) ? (360.0D - d) : d;
/*     */     } 
/*  64 */     return 0.0D;
/*     */   }
/*     */   public static float getHalvedfov() {
/*  67 */     return getFov() / 2.0F;
/*     */   }
/*     */   public static boolean isInFov(Vec3d vec3d, Vec3d other) {
/*  70 */     if ((mc.field_71439_g.field_70125_A > 30.0F) ? (other.field_72448_b > mc.field_71439_g.field_70163_u) : (mc.field_71439_g.field_70125_A < -30.0F && other.field_72448_b < mc.field_71439_g.field_70163_u)) {
/*  71 */       return true;
/*     */     }
/*  73 */     float angle = MathUtil.calcAngleNoY(vec3d, other)[0] - transformYaw();
/*  74 */     if (angle < -270.0F) {
/*  75 */       return true;
/*     */     }
/*  77 */     float fov = (((Boolean)(ClickGui.getInstance()).customFov.getValue()).booleanValue() ? ((Float)(ClickGui.getInstance()).fov.getValue()).floatValue() : mc.field_71474_y.field_74334_X) / 2.0F;
/*  78 */     return (angle < fov + 10.0F && angle > -fov - 10.0F);
/*     */   }
/*     */   public static float getFov() {
/*  81 */     return ((Boolean)(ClickGui.getInstance()).customFov.getValue()).booleanValue() ? ((Float)(ClickGui.getInstance()).fov.getValue()).floatValue() : mc.field_71474_y.field_74334_X;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void faceVector(Vec3d vec, boolean normalizeAngle) {
/*  86 */     float[] rotations = getLegitRotations(vec);
/*  87 */     mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Rotation(rotations[0], normalizeAngle ? MathHelper.func_180184_b((int)rotations[1], 360) : rotations[1], mc.field_71439_g.field_70122_E));
/*     */   }
/*     */   public static float transformYaw() {
/*  90 */     float yaw = mc.field_71439_g.field_70177_z % 360.0F;
/*  91 */     if (mc.field_71439_g.field_70177_z > 0.0F) {
/*  92 */       if (yaw > 180.0F) {
/*  93 */         yaw = -180.0F + yaw - 180.0F;
/*     */       }
/*  95 */     } else if (yaw < -180.0F) {
/*  96 */       yaw = 180.0F + yaw + 180.0F;
/*     */     } 
/*  98 */     if (yaw < 0.0F) {
/*  99 */       return 180.0F + yaw;
/*     */     }
/* 101 */     return -180.0F + yaw;
/*     */   }
/*     */   
/*     */   public static void faceEntity(Entity entity) {
/* 105 */     float[] angle = MathUtil.calcAngle(mc.field_71439_g.func_174824_e(mc.func_184121_ak()), entity.func_174824_e(mc.func_184121_ak()));
/* 106 */     faceYawAndPitch(angle[0], angle[1]);
/*     */   }
/*     */   
/*     */   public static float[] getAngle(Entity entity) {
/* 110 */     return MathUtil.calcAngle(mc.field_71439_g.func_174824_e(mc.func_184121_ak()), entity.func_174824_e(mc.func_184121_ak()));
/*     */   }
/*     */   
/*     */   public static int getDirection4D() {
/* 114 */     return MathHelper.func_76128_c((mc.field_71439_g.field_70177_z * 4.0F / 360.0F) + 0.5D) & 0x3;
/*     */   }
/*     */   
/*     */   public static String getDirection4D(boolean northRed) {
/* 118 */     int dirnumber = getDirection4D();
/* 119 */     if (dirnumber == 0) {
/* 120 */       return "South (+Z)";
/*     */     }
/* 122 */     if (dirnumber == 1) {
/* 123 */       return "West (-X)";
/*     */     }
/* 125 */     if (dirnumber == 2) {
/* 126 */       return (northRed ? "Â§c" : "") + "North (-Z)";
/*     */     }
/* 128 */     if (dirnumber == 3) {
/* 129 */       return "East (+X)";
/*     */     }
/* 131 */     return "Loading...";
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/util/RotationUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */