/*      */ package cc.zip.charon.util;
/*      */ import cc.zip.charon.Charon;
/*      */ import java.awt.Color;
/*      */ import java.nio.FloatBuffer;
/*      */ import java.nio.IntBuffer;
/*      */ import java.util.HashMap;
/*      */ import java.util.Objects;
/*      */ import net.minecraft.block.material.Material;
/*      */ import net.minecraft.block.state.IBlockState;
/*      */ import net.minecraft.client.gui.ScaledResolution;
/*      */ import net.minecraft.client.model.ModelBiped;
/*      */ import net.minecraft.client.renderer.BufferBuilder;
/*      */ import net.minecraft.client.renderer.GlStateManager;
/*      */ import net.minecraft.client.renderer.OpenGlHelper;
/*      */ import net.minecraft.client.renderer.RenderGlobal;
/*      */ import net.minecraft.client.renderer.RenderItem;
/*      */ import net.minecraft.client.renderer.Tessellator;
/*      */ import net.minecraft.client.renderer.culling.Frustum;
/*      */ import net.minecraft.client.renderer.culling.ICamera;
/*      */ import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
/*      */ import net.minecraft.client.shader.Framebuffer;
/*      */ import net.minecraft.entity.Entity;
/*      */ import net.minecraft.entity.player.EntityPlayer;
/*      */ import net.minecraft.util.EnumFacing;
/*      */ import net.minecraft.util.math.AxisAlignedBB;
/*      */ import net.minecraft.util.math.BlockPos;
/*      */ import net.minecraft.util.math.Vec3d;
/*      */ import net.minecraft.world.World;
/*      */ import org.lwjgl.BufferUtils;
/*      */ import org.lwjgl.opengl.EXTFramebufferObject;
/*      */ import org.lwjgl.opengl.GL11;
/*      */ import org.lwjgl.util.glu.GLU;
/*      */ import org.lwjgl.util.glu.Sphere;
/*      */ 
/*      */ public class RenderUtil implements Util {
/*   36 */   private static final Frustum frustrum = new Frustum();
/*   37 */   private static final FloatBuffer screenCoords = BufferUtils.createFloatBuffer(3);
/*   38 */   private static final IntBuffer viewport = BufferUtils.createIntBuffer(16);
/*   39 */   private static final FloatBuffer modelView = BufferUtils.createFloatBuffer(16);
/*   40 */   private static final FloatBuffer projection = BufferUtils.createFloatBuffer(16);
/*   41 */   public static RenderItem itemRender = (mc.func_175597_ag()).field_178112_h;
/*   42 */   public static ICamera camera = (ICamera)new Frustum();
/*   43 */   private static boolean depth = GL11.glIsEnabled(2896);
/*   44 */   private static boolean texture = GL11.glIsEnabled(3042);
/*   45 */   private static boolean clean = GL11.glIsEnabled(3553);
/*   46 */   private static boolean bind = GL11.glIsEnabled(2929);
/*   47 */   private static boolean override = GL11.glIsEnabled(2848);
/*      */   
/*      */   static {
/*   50 */     itemRender = mc.func_175599_af();
/*   51 */     camera = (ICamera)new Frustum();
/*   52 */     depth = GL11.glIsEnabled(2896);
/*   53 */     texture = GL11.glIsEnabled(3042);
/*   54 */     clean = GL11.glIsEnabled(3553);
/*   55 */     bind = GL11.glIsEnabled(2929);
/*   56 */     override = GL11.glIsEnabled(2848);
/*      */   }
/*      */   
/*      */   public static void drawRectangleCorrectly(int x, int y, int w, int h, int color) {
/*   60 */     GL11.glLineWidth(1.0F);
/*   61 */     Gui.func_73734_a(x, y, x + w, y + h, color);
/*      */   }
/*      */   public static void drawTriangle(float x, float y, float size, float theta, int color) {
/*   64 */     GL11.glTranslated(x, y, 0.0D);
/*   65 */     GL11.glRotatef(180.0F + theta, 0.0F, 0.0F, 1.0F);
/*   66 */     float alpha = (color >> 24 & 0xFF) / 255.0F;
/*   67 */     float red = (color >> 16 & 0xFF) / 255.0F;
/*   68 */     float green = (color >> 8 & 0xFF) / 255.0F;
/*   69 */     float blue = (color & 0xFF) / 255.0F;
/*   70 */     GL11.glColor4f(red, green, blue, alpha);
/*   71 */     GL11.glEnable(3042);
/*   72 */     GL11.glDisable(3553);
/*   73 */     GL11.glEnable(2848);
/*   74 */     GL11.glBlendFunc(770, 771);
/*   75 */     GL11.glLineWidth(1.0F);
/*   76 */     GL11.glBegin(6);
/*   77 */     GL11.glVertex2d(0.0D, (1.0F * size));
/*   78 */     GL11.glVertex2d((1.0F * size / 2.0F), -(1.0F * size));
/*   79 */     GL11.glVertex2d(-(1.0F * size / 2.0F), -(1.0F * size));
/*   80 */     GL11.glEnd();
/*   81 */     GL11.glDisable(2848);
/*   82 */     GL11.glEnable(3553);
/*   83 */     GL11.glDisable(3042);
/*   84 */     GL11.glRotatef(-180.0F - theta, 0.0F, 0.0F, 1.0F);
/*   85 */     GL11.glTranslated(-x, -y, 0.0D);
/*      */   }
/*      */   
/*      */   public static AxisAlignedBB interpolateAxis(AxisAlignedBB bb) {
/*   89 */     return new AxisAlignedBB(bb.field_72340_a - (mc.func_175598_ae()).field_78730_l, bb.field_72338_b - (mc.func_175598_ae()).field_78731_m, bb.field_72339_c - (mc.func_175598_ae()).field_78728_n, bb.field_72336_d - (mc.func_175598_ae()).field_78730_l, bb.field_72337_e - (mc.func_175598_ae()).field_78731_m, bb.field_72334_f - (mc.func_175598_ae()).field_78728_n);
/*      */   }
/*      */   
/*      */   public static boolean isInViewFrustrum(Entity entity) {
/*   93 */     return (isInViewFrustrum(entity.func_174813_aQ()) || entity.field_70158_ak);
/*      */   }
/*      */   
/*      */   public static boolean isInViewFrustrum(AxisAlignedBB bb) {
/*   97 */     Entity current = Minecraft.func_71410_x().func_175606_aa();
/*   98 */     frustrum.func_78547_a(current.field_70165_t, current.field_70163_u, current.field_70161_v);
/*   99 */     return frustrum.func_78546_a(bb);
/*      */   }
/*      */   
/*      */   public static Vec3d to2D(double x, double y, double z) {
/*  103 */     GL11.glGetFloat(2982, modelView);
/*  104 */     GL11.glGetFloat(2983, projection);
/*  105 */     GL11.glGetInteger(2978, viewport);
/*  106 */     boolean result = GLU.gluProject((float)x, (float)y, (float)z, modelView, projection, viewport, screenCoords);
/*  107 */     if (result) {
/*  108 */       return new Vec3d(screenCoords.get(0), (Display.getHeight() - screenCoords.get(1)), screenCoords.get(2));
/*      */     }
/*  110 */     return null;
/*      */   }
/*      */   
/*      */   public static void drawTracerPointer(float x, float y, float size, float widthDiv, float heightDiv, boolean outline, float outlineWidth, int color) {
/*  114 */     boolean blend = GL11.glIsEnabled(3042);
/*  115 */     float alpha = (color >> 24 & 0xFF) / 255.0F;
/*  116 */     GL11.glEnable(3042);
/*  117 */     GL11.glDisable(3553);
/*  118 */     GL11.glBlendFunc(770, 771);
/*  119 */     GL11.glEnable(2848);
/*  120 */     GL11.glPushMatrix();
/*  121 */     hexColor(color);
/*  122 */     GL11.glBegin(7);
/*  123 */     GL11.glVertex2d(x, y);
/*  124 */     GL11.glVertex2d((x - size / widthDiv), (y + size));
/*  125 */     GL11.glVertex2d(x, (y + size / heightDiv));
/*  126 */     GL11.glVertex2d((x + size / widthDiv), (y + size));
/*  127 */     GL11.glVertex2d(x, y);
/*  128 */     GL11.glEnd();
/*  129 */     if (outline) {
/*  130 */       GL11.glLineWidth(outlineWidth);
/*  131 */       GL11.glColor4f(0.0F, 0.0F, 0.0F, alpha);
/*  132 */       GL11.glBegin(2);
/*  133 */       GL11.glVertex2d(x, y);
/*  134 */       GL11.glVertex2d((x - size / widthDiv), (y + size));
/*  135 */       GL11.glVertex2d(x, (y + size / heightDiv));
/*  136 */       GL11.glVertex2d((x + size / widthDiv), (y + size));
/*  137 */       GL11.glVertex2d(x, y);
/*  138 */       GL11.glEnd();
/*      */     } 
/*  140 */     GL11.glPopMatrix();
/*  141 */     GL11.glEnable(3553);
/*  142 */     if (!blend) {
/*  143 */       GL11.glDisable(3042);
/*      */     }
/*  145 */     GL11.glDisable(2848);
/*      */   }
/*      */   
/*      */   public static void hexColor(int hexColor) {
/*  149 */     float red = (hexColor >> 16 & 0xFF) / 255.0F;
/*  150 */     float green = (hexColor >> 8 & 0xFF) / 255.0F;
/*  151 */     float blue = (hexColor & 0xFF) / 255.0F;
/*  152 */     float alpha = (hexColor >> 24 & 0xFF) / 255.0F;
/*  153 */     GL11.glColor4f(red, green, blue, alpha);
/*      */   }
/*      */   public static void drawCrosshairs(double separation, double bend, double width, double thickness, boolean dynamic, int color) {
/*  156 */     int screenWidth = (new ScaledResolution(mc)).func_78326_a();
/*  157 */     int screenHeight = (new ScaledResolution(mc)).func_78328_b();
/*  158 */     separation += (MotionUtil.isMovings() && dynamic) ? 1.0D : 0.0D;
/*  159 */     drawLine((float)((screenWidth / 2) - separation), (float)((screenHeight / 2) - bend / 2.0D), (float)((screenWidth / 2) - separation - width), (float)((screenHeight / 2) - bend / 2.0D), (int)thickness, color);
/*  160 */     drawLine((float)((screenWidth / 2) + separation), (float)((screenHeight / 2) - bend / 2.0D), (float)((screenWidth / 2) + separation + width), (float)((screenHeight / 2) + bend / 2.0D), (int)thickness, color);
/*  161 */     drawLine((float)((screenWidth / 2) - bend / 2.0D), (float)((screenHeight / 2) - separation), (float)((screenWidth / 2) - bend / 2.0D), (float)((screenHeight / 2) - separation - width), (int)thickness, color);
/*  162 */     drawLine((float)((screenWidth / 2) - bend / 2.0D), (float)((screenHeight / 2) + separation), (float)((screenWidth / 2) + bend / 2.0D), (float)((screenHeight / 2) + separation + width), (int)thickness, color);
/*      */   }
/*      */   
/*      */   public static void drawTexturedRect(int x, int y, int textureX, int textureY, int width, int height, int zLevel) {
/*  166 */     Tessellator tessellator = Tessellator.func_178181_a();
/*  167 */     BufferBuilder BufferBuilder2 = tessellator.func_178180_c();
/*  168 */     BufferBuilder2.func_181668_a(7, DefaultVertexFormats.field_181707_g);
/*  169 */     BufferBuilder2.func_181662_b((x + 0), (y + height), zLevel).func_187315_a(((textureX + 0) * 0.00390625F), ((textureY + height) * 0.00390625F)).func_181675_d();
/*  170 */     BufferBuilder2.func_181662_b((x + width), (y + height), zLevel).func_187315_a(((textureX + width) * 0.00390625F), ((textureY + height) * 0.00390625F)).func_181675_d();
/*  171 */     BufferBuilder2.func_181662_b((x + width), (y + 0), zLevel).func_187315_a(((textureX + width) * 0.00390625F), ((textureY + 0) * 0.00390625F)).func_181675_d();
/*  172 */     BufferBuilder2.func_181662_b((x + 0), (y + 0), zLevel).func_187315_a(((textureX + 0) * 0.00390625F), ((textureY + 0) * 0.00390625F)).func_181675_d();
/*  173 */     tessellator.func_78381_a();
/*      */   }
/*      */   
/*      */   public static void blockESP(BlockPos b, Color c, double length, double length2) {
/*  177 */     blockEsp(b, c, length, length2);
/*      */   }
/*      */   
/*      */   public static void drawBoxESP(BlockPos pos, Color color, boolean secondC, Color secondColor, float lineWidth, boolean outline, boolean box, int boxAlpha, boolean air) {
/*  181 */     if (box) {
/*  182 */       drawBox(pos, new Color(color.getRed(), color.getGreen(), color.getBlue(), boxAlpha));
/*      */     }
/*  184 */     if (outline) {
/*  185 */       drawBlockOutline(pos, secondC ? secondColor : color, lineWidth, air);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void glScissor(float x, float y, float x1, float y1, ScaledResolution sr) {
/*  190 */     GL11.glScissor((int)(x * sr.func_78325_e()), (int)(mc.field_71440_d - y1 * sr.func_78325_e()), (int)((x1 - x) * sr.func_78325_e()), (int)((y1 - y) * sr.func_78325_e()));
/*      */   }
/*      */   
/*      */   public static void drawLine(float x, float y, float x1, float y1, float thickness, int hex) {
/*  194 */     float red = (hex >> 16 & 0xFF) / 255.0F;
/*  195 */     float green = (hex >> 8 & 0xFF) / 255.0F;
/*  196 */     float blue = (hex & 0xFF) / 255.0F;
/*  197 */     float alpha = (hex >> 24 & 0xFF) / 255.0F;
/*  198 */     GlStateManager.func_179094_E();
/*  199 */     GlStateManager.func_179090_x();
/*  200 */     GlStateManager.func_179147_l();
/*  201 */     GlStateManager.func_179118_c();
/*  202 */     GlStateManager.func_179120_a(770, 771, 1, 0);
/*  203 */     GlStateManager.func_179103_j(7425);
/*  204 */     GL11.glLineWidth(thickness);
/*  205 */     GL11.glEnable(2848);
/*  206 */     GL11.glHint(3154, 4354);
/*  207 */     Tessellator tessellator = Tessellator.func_178181_a();
/*  208 */     BufferBuilder bufferbuilder = tessellator.func_178180_c();
/*  209 */     bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
/*  210 */     bufferbuilder.func_181662_b(x, y, 0.0D).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  211 */     bufferbuilder.func_181662_b(x1, y1, 0.0D).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  212 */     tessellator.func_78381_a();
/*  213 */     GlStateManager.func_179103_j(7424);
/*  214 */     GL11.glDisable(2848);
/*  215 */     GlStateManager.func_179084_k();
/*  216 */     GlStateManager.func_179141_d();
/*  217 */     GlStateManager.func_179098_w();
/*  218 */     GlStateManager.func_179121_F();
/*      */   }
/*      */   
/*      */   public static void drawBox(BlockPos pos, Color color) {
/*  222 */     AxisAlignedBB bb = new AxisAlignedBB(pos.func_177958_n() - (mc.func_175598_ae()).field_78730_l, pos.func_177956_o() - (mc.func_175598_ae()).field_78731_m, pos.func_177952_p() - (mc.func_175598_ae()).field_78728_n, (pos.func_177958_n() + 1) - (mc.func_175598_ae()).field_78730_l, (pos.func_177956_o() + 1) - (mc.func_175598_ae()).field_78731_m, (pos.func_177952_p() + 1) - (mc.func_175598_ae()).field_78728_n);
/*  223 */     camera.func_78547_a(((Entity)Objects.requireNonNull((T)mc.func_175606_aa())).field_70165_t, (mc.func_175606_aa()).field_70163_u, (mc.func_175606_aa()).field_70161_v);
/*  224 */     if (camera.func_78546_a(new AxisAlignedBB(bb.field_72340_a + (mc.func_175598_ae()).field_78730_l, bb.field_72338_b + (mc.func_175598_ae()).field_78731_m, bb.field_72339_c + (mc.func_175598_ae()).field_78728_n, bb.field_72336_d + (mc.func_175598_ae()).field_78730_l, bb.field_72337_e + (mc.func_175598_ae()).field_78731_m, bb.field_72334_f + (mc.func_175598_ae()).field_78728_n))) {
/*  225 */       GlStateManager.func_179094_E();
/*  226 */       GlStateManager.func_179147_l();
/*  227 */       GlStateManager.func_179097_i();
/*  228 */       GlStateManager.func_179120_a(770, 771, 0, 1);
/*  229 */       GlStateManager.func_179090_x();
/*  230 */       GlStateManager.func_179132_a(false);
/*  231 */       GL11.glEnable(2848);
/*  232 */       GL11.glHint(3154, 4354);
/*  233 */       RenderGlobal.func_189696_b(bb, color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F);
/*  234 */       GL11.glDisable(2848);
/*  235 */       GlStateManager.func_179132_a(true);
/*  236 */       GlStateManager.func_179126_j();
/*  237 */       GlStateManager.func_179098_w();
/*  238 */       GlStateManager.func_179084_k();
/*  239 */       GlStateManager.func_179121_F();
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void drawBlockOutline(BlockPos pos, Color color, float linewidth, boolean air) {
/*  244 */     IBlockState iblockstate = mc.field_71441_e.func_180495_p(pos);
/*  245 */     if ((air || iblockstate.func_185904_a() != Material.field_151579_a) && mc.field_71441_e.func_175723_af().func_177746_a(pos)) {
/*  246 */       assert mc.field_175622_Z != null;
/*  247 */       Vec3d interp = EntityUtil.interpolateEntity(mc.field_175622_Z, mc.func_184121_ak());
/*  248 */       drawBlockOutline(iblockstate.func_185918_c((World)mc.field_71441_e, pos).func_186662_g(0.0020000000949949026D).func_72317_d(-interp.field_72450_a, -interp.field_72448_b, -interp.field_72449_c), color, linewidth);
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void drawBlockOutline(AxisAlignedBB bb, Color color, float linewidth) {
/*  253 */     float red = color.getRed() / 255.0F;
/*  254 */     float green = color.getGreen() / 255.0F;
/*  255 */     float blue = color.getBlue() / 255.0F;
/*  256 */     float alpha = color.getAlpha() / 255.0F;
/*  257 */     GlStateManager.func_179094_E();
/*  258 */     GlStateManager.func_179147_l();
/*  259 */     GlStateManager.func_179097_i();
/*  260 */     GlStateManager.func_179120_a(770, 771, 0, 1);
/*  261 */     GlStateManager.func_179090_x();
/*  262 */     GlStateManager.func_179132_a(false);
/*  263 */     GL11.glEnable(2848);
/*  264 */     GL11.glHint(3154, 4354);
/*  265 */     GL11.glLineWidth(linewidth);
/*  266 */     Tessellator tessellator = Tessellator.func_178181_a();
/*  267 */     BufferBuilder bufferbuilder = tessellator.func_178180_c();
/*  268 */     bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
/*  269 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  270 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  271 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  272 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  273 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  274 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  275 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  276 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  277 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  278 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  279 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  280 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  281 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  282 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  283 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  284 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  285 */     tessellator.func_78381_a();
/*  286 */     GL11.glDisable(2848);
/*  287 */     GlStateManager.func_179132_a(true);
/*  288 */     GlStateManager.func_179126_j();
/*  289 */     GlStateManager.func_179098_w();
/*  290 */     GlStateManager.func_179084_k();
/*  291 */     GlStateManager.func_179121_F();
/*      */   }
/*      */   
/*      */   public static void drawBoxESP(BlockPos pos, Color color, float lineWidth, boolean outline, boolean box, int boxAlpha) {
/*  295 */     AxisAlignedBB bb = new AxisAlignedBB(pos.func_177958_n() - (mc.func_175598_ae()).field_78730_l, pos.func_177956_o() - (mc.func_175598_ae()).field_78731_m, pos.func_177952_p() - (mc.func_175598_ae()).field_78728_n, (pos.func_177958_n() + 1) - (mc.func_175598_ae()).field_78730_l, (pos.func_177956_o() + 1) - (mc.func_175598_ae()).field_78731_m, (pos.func_177952_p() + 1) - (mc.func_175598_ae()).field_78728_n);
/*  296 */     camera.func_78547_a(((Entity)Objects.requireNonNull((T)mc.func_175606_aa())).field_70165_t, (mc.func_175606_aa()).field_70163_u, (mc.func_175606_aa()).field_70161_v);
/*  297 */     if (camera.func_78546_a(new AxisAlignedBB(bb.field_72340_a + (mc.func_175598_ae()).field_78730_l, bb.field_72338_b + (mc.func_175598_ae()).field_78731_m, bb.field_72339_c + (mc.func_175598_ae()).field_78728_n, bb.field_72336_d + (mc.func_175598_ae()).field_78730_l, bb.field_72337_e + (mc.func_175598_ae()).field_78731_m, bb.field_72334_f + (mc.func_175598_ae()).field_78728_n))) {
/*  298 */       GlStateManager.func_179094_E();
/*  299 */       GlStateManager.func_179147_l();
/*  300 */       GlStateManager.func_179097_i();
/*  301 */       GlStateManager.func_179120_a(770, 771, 0, 1);
/*  302 */       GlStateManager.func_179090_x();
/*  303 */       GlStateManager.func_179132_a(false);
/*  304 */       GL11.glEnable(2848);
/*  305 */       GL11.glHint(3154, 4354);
/*  306 */       GL11.glLineWidth(lineWidth);
/*  307 */       double dist = mc.field_71439_g.func_70011_f((pos.func_177958_n() + 0.5F), (pos.func_177956_o() + 0.5F), (pos.func_177952_p() + 0.5F)) * 0.75D;
/*  308 */       if (box) {
/*  309 */         RenderGlobal.func_189696_b(bb, color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, boxAlpha / 255.0F);
/*      */       }
/*  311 */       if (outline) {
/*  312 */         RenderGlobal.func_189694_a(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c, bb.field_72336_d, bb.field_72337_e, bb.field_72334_f, color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F);
/*      */       }
/*  314 */       GL11.glDisable(2848);
/*  315 */       GlStateManager.func_179132_a(true);
/*  316 */       GlStateManager.func_179126_j();
/*  317 */       GlStateManager.func_179098_w();
/*  318 */       GlStateManager.func_179084_k();
/*  319 */       GlStateManager.func_179121_F();
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void drawText(BlockPos pos, String text) {
/*  324 */     GlStateManager.func_179094_E();
/*  325 */     glBillboardDistanceScaled(pos.func_177958_n() + 0.5F, pos.func_177956_o() + 0.5F, pos.func_177952_p() + 0.5F, (EntityPlayer)mc.field_71439_g, 1.0F);
/*  326 */     GlStateManager.func_179097_i();
/*  327 */     GlStateManager.func_179137_b(-(Charon.textManager.getStringWidth(text) / 2.0D), 0.0D, 0.0D);
/*  328 */     Charon.textManager.drawStringWithShadow(text, 0.0F, 0.0F, -5592406);
/*  329 */     GlStateManager.func_179121_F();
/*      */   }
/*      */   
/*      */   public static void drawOutlinedBlockESP(BlockPos pos, Color color, float linewidth) {
/*  333 */     IBlockState iblockstate = mc.field_71441_e.func_180495_p(pos);
/*  334 */     Vec3d interp = EntityUtil.interpolateEntity((Entity)mc.field_71439_g, mc.func_184121_ak());
/*  335 */     drawBoundingBox(iblockstate.func_185918_c((World)mc.field_71441_e, pos).func_186662_g(0.0020000000949949026D).func_72317_d(-interp.field_72450_a, -interp.field_72448_b, -interp.field_72449_c), linewidth, ColorUtil.toRGBA(color));
/*      */   }
/*      */   
/*      */   public static void blockEsp(BlockPos blockPos, Color c, double length, double length2) {
/*  339 */     double x = blockPos.func_177958_n() - mc.field_175616_W.field_78725_b;
/*  340 */     double y = blockPos.func_177956_o() - mc.field_175616_W.field_78726_c;
/*  341 */     double z = blockPos.func_177952_p() - mc.field_175616_W.field_78723_d;
/*  342 */     GL11.glPushMatrix();
/*  343 */     GL11.glBlendFunc(770, 771);
/*  344 */     GL11.glEnable(3042);
/*  345 */     GL11.glLineWidth(2.0F);
/*  346 */     GL11.glDisable(3553);
/*  347 */     GL11.glDisable(2929);
/*  348 */     GL11.glDepthMask(false);
/*  349 */     GL11.glColor4d((c.getRed() / 255.0F), (c.getGreen() / 255.0F), (c.getBlue() / 255.0F), 0.25D);
/*  350 */     drawColorBox(new AxisAlignedBB(x, y, z, x + length2, y + 1.0D, z + length), 0.0F, 0.0F, 0.0F, 0.0F);
/*  351 */     GL11.glColor4d(0.0D, 0.0D, 0.0D, 0.5D);
/*  352 */     drawSelectionBoundingBox(new AxisAlignedBB(x, y, z, x + length2, y + 1.0D, z + length));
/*  353 */     GL11.glLineWidth(2.0F);
/*  354 */     GL11.glEnable(3553);
/*  355 */     GL11.glEnable(2929);
/*  356 */     GL11.glDepthMask(true);
/*  357 */     GL11.glDisable(3042);
/*  358 */     GL11.glPopMatrix();
/*  359 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*      */   }
/*      */   
/*      */   public static void drawRect(float x, float y, float w, float h, int color) {
/*  363 */     float alpha = (color >> 24 & 0xFF) / 255.0F;
/*  364 */     float red = (color >> 16 & 0xFF) / 255.0F;
/*  365 */     float green = (color >> 8 & 0xFF) / 255.0F;
/*  366 */     float blue = (color & 0xFF) / 255.0F;
/*  367 */     Tessellator tessellator = Tessellator.func_178181_a();
/*  368 */     BufferBuilder bufferbuilder = tessellator.func_178180_c();
/*  369 */     GlStateManager.func_179147_l();
/*  370 */     GlStateManager.func_179090_x();
/*  371 */     GlStateManager.func_179120_a(770, 771, 1, 0);
/*  372 */     bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181706_f);
/*  373 */     bufferbuilder.func_181662_b(x, h, 0.0D).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  374 */     bufferbuilder.func_181662_b(w, h, 0.0D).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  375 */     bufferbuilder.func_181662_b(w, y, 0.0D).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  376 */     bufferbuilder.func_181662_b(x, y, 0.0D).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  377 */     tessellator.func_78381_a();
/*  378 */     GlStateManager.func_179098_w();
/*  379 */     GlStateManager.func_179084_k();
/*      */   }
/*      */   
/*      */   public static void drawColorBox(AxisAlignedBB axisalignedbb, float red, float green, float blue, float alpha) {
/*  383 */     Tessellator ts = Tessellator.func_178181_a();
/*  384 */     BufferBuilder vb = ts.func_178180_c();
/*  385 */     vb.func_181668_a(7, DefaultVertexFormats.field_181707_g);
/*  386 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  387 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  388 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  389 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  390 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  391 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  392 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  393 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  394 */     ts.func_78381_a();
/*  395 */     vb.func_181668_a(7, DefaultVertexFormats.field_181707_g);
/*  396 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  397 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  398 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  399 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  400 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  401 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  402 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  403 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  404 */     ts.func_78381_a();
/*  405 */     vb.func_181668_a(7, DefaultVertexFormats.field_181707_g);
/*  406 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  407 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  408 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  409 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  410 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  411 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  412 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  413 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  414 */     ts.func_78381_a();
/*  415 */     vb.func_181668_a(7, DefaultVertexFormats.field_181707_g);
/*  416 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  417 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  418 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  419 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  420 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  421 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  422 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  423 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  424 */     ts.func_78381_a();
/*  425 */     vb.func_181668_a(7, DefaultVertexFormats.field_181707_g);
/*  426 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  427 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  428 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  429 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  430 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  431 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  432 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  433 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  434 */     ts.func_78381_a();
/*  435 */     vb.func_181668_a(7, DefaultVertexFormats.field_181707_g);
/*  436 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  437 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  438 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  439 */     vb.func_181662_b(axisalignedbb.field_72340_a, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  440 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  441 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  442 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72337_e, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  443 */     vb.func_181662_b(axisalignedbb.field_72336_d, axisalignedbb.field_72338_b, axisalignedbb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  444 */     ts.func_78381_a();
/*      */   }
/*      */   
/*      */   public static void drawSelectionBoundingBox(AxisAlignedBB boundingBox) {
/*  448 */     Tessellator tessellator = Tessellator.func_178181_a();
/*  449 */     BufferBuilder vertexbuffer = tessellator.func_178180_c();
/*  450 */     vertexbuffer.func_181668_a(3, DefaultVertexFormats.field_181705_e);
/*  451 */     vertexbuffer.func_181662_b(boundingBox.field_72340_a, boundingBox.field_72338_b, boundingBox.field_72339_c).func_181675_d();
/*  452 */     vertexbuffer.func_181662_b(boundingBox.field_72336_d, boundingBox.field_72338_b, boundingBox.field_72339_c).func_181675_d();
/*  453 */     vertexbuffer.func_181662_b(boundingBox.field_72336_d, boundingBox.field_72338_b, boundingBox.field_72334_f).func_181675_d();
/*  454 */     vertexbuffer.func_181662_b(boundingBox.field_72340_a, boundingBox.field_72338_b, boundingBox.field_72334_f).func_181675_d();
/*  455 */     vertexbuffer.func_181662_b(boundingBox.field_72340_a, boundingBox.field_72338_b, boundingBox.field_72339_c).func_181675_d();
/*  456 */     tessellator.func_78381_a();
/*  457 */     vertexbuffer.func_181668_a(3, DefaultVertexFormats.field_181705_e);
/*  458 */     vertexbuffer.func_181662_b(boundingBox.field_72340_a, boundingBox.field_72337_e, boundingBox.field_72339_c).func_181675_d();
/*  459 */     vertexbuffer.func_181662_b(boundingBox.field_72336_d, boundingBox.field_72337_e, boundingBox.field_72339_c).func_181675_d();
/*  460 */     vertexbuffer.func_181662_b(boundingBox.field_72336_d, boundingBox.field_72337_e, boundingBox.field_72334_f).func_181675_d();
/*  461 */     vertexbuffer.func_181662_b(boundingBox.field_72340_a, boundingBox.field_72337_e, boundingBox.field_72334_f).func_181675_d();
/*  462 */     vertexbuffer.func_181662_b(boundingBox.field_72340_a, boundingBox.field_72337_e, boundingBox.field_72339_c).func_181675_d();
/*  463 */     tessellator.func_78381_a();
/*  464 */     vertexbuffer.func_181668_a(1, DefaultVertexFormats.field_181705_e);
/*  465 */     vertexbuffer.func_181662_b(boundingBox.field_72340_a, boundingBox.field_72338_b, boundingBox.field_72339_c).func_181675_d();
/*  466 */     vertexbuffer.func_181662_b(boundingBox.field_72340_a, boundingBox.field_72337_e, boundingBox.field_72339_c).func_181675_d();
/*  467 */     vertexbuffer.func_181662_b(boundingBox.field_72336_d, boundingBox.field_72338_b, boundingBox.field_72339_c).func_181675_d();
/*  468 */     vertexbuffer.func_181662_b(boundingBox.field_72336_d, boundingBox.field_72337_e, boundingBox.field_72339_c).func_181675_d();
/*  469 */     vertexbuffer.func_181662_b(boundingBox.field_72336_d, boundingBox.field_72338_b, boundingBox.field_72334_f).func_181675_d();
/*  470 */     vertexbuffer.func_181662_b(boundingBox.field_72336_d, boundingBox.field_72337_e, boundingBox.field_72334_f).func_181675_d();
/*  471 */     vertexbuffer.func_181662_b(boundingBox.field_72340_a, boundingBox.field_72338_b, boundingBox.field_72334_f).func_181675_d();
/*  472 */     vertexbuffer.func_181662_b(boundingBox.field_72340_a, boundingBox.field_72337_e, boundingBox.field_72334_f).func_181675_d();
/*  473 */     tessellator.func_78381_a();
/*      */   }
/*      */   
/*      */   public static void glrendermethod() {
/*  477 */     GL11.glEnable(3042);
/*  478 */     GL11.glBlendFunc(770, 771);
/*  479 */     GL11.glEnable(2848);
/*  480 */     GL11.glLineWidth(2.0F);
/*  481 */     GL11.glDisable(3553);
/*  482 */     GL11.glEnable(2884);
/*  483 */     GL11.glDisable(2929);
/*  484 */     double viewerPosX = (mc.func_175598_ae()).field_78730_l;
/*  485 */     double viewerPosY = (mc.func_175598_ae()).field_78731_m;
/*  486 */     double viewerPosZ = (mc.func_175598_ae()).field_78728_n;
/*  487 */     GL11.glPushMatrix();
/*  488 */     GL11.glTranslated(-viewerPosX, -viewerPosY, -viewerPosZ);
/*      */   }
/*      */   
/*      */   public static void glStart(float n, float n2, float n3, float n4) {
/*  492 */     glrendermethod();
/*  493 */     GL11.glColor4f(n, n2, n3, n4);
/*      */   }
/*      */   
/*      */   public static void glEnd() {
/*  497 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*  498 */     GL11.glPopMatrix();
/*  499 */     GL11.glEnable(2929);
/*  500 */     GL11.glEnable(3553);
/*  501 */     GL11.glDisable(3042);
/*  502 */     GL11.glDisable(2848);
/*      */   }
/*      */   
/*      */   public static AxisAlignedBB getBoundingBox(BlockPos blockPos) {
/*  506 */     return mc.field_71441_e.func_180495_p(blockPos).func_185900_c((IBlockAccess)mc.field_71441_e, blockPos).func_186670_a(blockPos);
/*      */   }
/*      */   
/*      */   public static void drawOutlinedBox(AxisAlignedBB axisAlignedBB) {
/*  510 */     GL11.glBegin(1);
/*  511 */     GL11.glVertex3d(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c);
/*  512 */     GL11.glVertex3d(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c);
/*  513 */     GL11.glVertex3d(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c);
/*  514 */     GL11.glVertex3d(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f);
/*  515 */     GL11.glVertex3d(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f);
/*  516 */     GL11.glVertex3d(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f);
/*  517 */     GL11.glVertex3d(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f);
/*  518 */     GL11.glVertex3d(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c);
/*  519 */     GL11.glVertex3d(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c);
/*  520 */     GL11.glVertex3d(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c);
/*  521 */     GL11.glVertex3d(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72339_c);
/*  522 */     GL11.glVertex3d(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c);
/*  523 */     GL11.glVertex3d(axisAlignedBB.field_72336_d, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f);
/*  524 */     GL11.glVertex3d(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f);
/*  525 */     GL11.glVertex3d(axisAlignedBB.field_72340_a, axisAlignedBB.field_72338_b, axisAlignedBB.field_72334_f);
/*  526 */     GL11.glVertex3d(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f);
/*  527 */     GL11.glVertex3d(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c);
/*  528 */     GL11.glVertex3d(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c);
/*  529 */     GL11.glVertex3d(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c);
/*  530 */     GL11.glVertex3d(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f);
/*  531 */     GL11.glVertex3d(axisAlignedBB.field_72336_d, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f);
/*  532 */     GL11.glVertex3d(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f);
/*  533 */     GL11.glVertex3d(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72334_f);
/*  534 */     GL11.glVertex3d(axisAlignedBB.field_72340_a, axisAlignedBB.field_72337_e, axisAlignedBB.field_72339_c);
/*  535 */     GL11.glEnd();
/*      */   }
/*      */   
/*      */   public static void drawFilledBoxESPN(BlockPos pos, Color color) {
/*  539 */     AxisAlignedBB bb = new AxisAlignedBB(pos.func_177958_n() - (mc.func_175598_ae()).field_78730_l, pos.func_177956_o() - (mc.func_175598_ae()).field_78731_m, pos.func_177952_p() - (mc.func_175598_ae()).field_78728_n, (pos.func_177958_n() + 1) - (mc.func_175598_ae()).field_78730_l, (pos.func_177956_o() + 1) - (mc.func_175598_ae()).field_78731_m, (pos.func_177952_p() + 1) - (mc.func_175598_ae()).field_78728_n);
/*  540 */     int rgba = ColorUtil.toRGBA(color);
/*  541 */     drawFilledBox(bb, rgba);
/*      */   }
/*      */   
/*      */   public static void drawFilledBox(AxisAlignedBB bb, int color) {
/*  545 */     GlStateManager.func_179094_E();
/*  546 */     GlStateManager.func_179147_l();
/*  547 */     GlStateManager.func_179097_i();
/*  548 */     GlStateManager.func_179120_a(770, 771, 0, 1);
/*  549 */     GlStateManager.func_179090_x();
/*  550 */     GlStateManager.func_179132_a(false);
/*  551 */     float alpha = (color >> 24 & 0xFF) / 255.0F;
/*  552 */     float red = (color >> 16 & 0xFF) / 255.0F;
/*  553 */     float green = (color >> 8 & 0xFF) / 255.0F;
/*  554 */     float blue = (color & 0xFF) / 255.0F;
/*  555 */     Tessellator tessellator = Tessellator.func_178181_a();
/*  556 */     BufferBuilder bufferbuilder = tessellator.func_178180_c();
/*  557 */     bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181706_f);
/*  558 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  559 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  560 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  561 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  562 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  563 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  564 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  565 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  566 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  567 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  568 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  569 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  570 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  571 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  572 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  573 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  574 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  575 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  576 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  577 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  578 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  579 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  580 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  581 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  582 */     tessellator.func_78381_a();
/*  583 */     GlStateManager.func_179132_a(true);
/*  584 */     GlStateManager.func_179126_j();
/*  585 */     GlStateManager.func_179098_w();
/*  586 */     GlStateManager.func_179084_k();
/*  587 */     GlStateManager.func_179121_F();
/*      */   }
/*      */   
/*      */   public static void drawBoundingBox(AxisAlignedBB bb, float width, int color) {
/*  591 */     GlStateManager.func_179094_E();
/*  592 */     GlStateManager.func_179147_l();
/*  593 */     GlStateManager.func_179097_i();
/*  594 */     GlStateManager.func_179120_a(770, 771, 0, 1);
/*  595 */     GlStateManager.func_179090_x();
/*  596 */     GlStateManager.func_179132_a(false);
/*  597 */     GL11.glEnable(2848);
/*  598 */     GL11.glHint(3154, 4354);
/*  599 */     GL11.glLineWidth(width);
/*  600 */     float alpha = (color >> 24 & 0xFF) / 255.0F;
/*  601 */     float red = (color >> 16 & 0xFF) / 255.0F;
/*  602 */     float green = (color >> 8 & 0xFF) / 255.0F;
/*  603 */     float blue = (color & 0xFF) / 255.0F;
/*  604 */     Tessellator tessellator = Tessellator.func_178181_a();
/*  605 */     BufferBuilder bufferbuilder = tessellator.func_178180_c();
/*  606 */     bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
/*  607 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  608 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  609 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  610 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  611 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  612 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  613 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  614 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  615 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  616 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  617 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  618 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  619 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  620 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  621 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  622 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  623 */     tessellator.func_78381_a();
/*  624 */     GL11.glDisable(2848);
/*  625 */     GlStateManager.func_179132_a(true);
/*  626 */     GlStateManager.func_179126_j();
/*  627 */     GlStateManager.func_179098_w();
/*  628 */     GlStateManager.func_179084_k();
/*  629 */     GlStateManager.func_179121_F();
/*      */   }
/*      */   
/*      */   public static void glBillboard(float x, float y, float z) {
/*  633 */     float scale = 0.02666667F;
/*  634 */     GlStateManager.func_179137_b(x - (mc.func_175598_ae()).field_78725_b, y - (mc.func_175598_ae()).field_78726_c, z - (mc.func_175598_ae()).field_78723_d);
/*  635 */     GlStateManager.func_187432_a(0.0F, 1.0F, 0.0F);
/*  636 */     GlStateManager.func_179114_b(-mc.field_71439_g.field_70177_z, 0.0F, 1.0F, 0.0F);
/*  637 */     GlStateManager.func_179114_b(mc.field_71439_g.field_70125_A, (mc.field_71474_y.field_74320_O == 2) ? -1.0F : 1.0F, 0.0F, 0.0F);
/*  638 */     GlStateManager.func_179152_a(-scale, -scale, scale);
/*      */   }
/*      */   
/*      */   public static void glBillboardDistanceScaled(float x, float y, float z, EntityPlayer player, float scale) {
/*  642 */     glBillboard(x, y, z);
/*  643 */     int distance = (int)player.func_70011_f(x, y, z);
/*  644 */     float scaleDistance = distance / 2.0F / (2.0F + 2.0F - scale);
/*  645 */     if (scaleDistance < 1.0F) {
/*  646 */       scaleDistance = 1.0F;
/*      */     }
/*  648 */     GlStateManager.func_179152_a(scaleDistance, scaleDistance, scaleDistance);
/*      */   }
/*      */   
/*      */   public static void drawColoredBoundingBox(AxisAlignedBB bb, float width, float red, float green, float blue, float alpha) {
/*  652 */     GlStateManager.func_179094_E();
/*  653 */     GlStateManager.func_179147_l();
/*  654 */     GlStateManager.func_179097_i();
/*  655 */     GlStateManager.func_179120_a(770, 771, 0, 1);
/*  656 */     GlStateManager.func_179090_x();
/*  657 */     GlStateManager.func_179132_a(false);
/*  658 */     GL11.glEnable(2848);
/*  659 */     GL11.glHint(3154, 4354);
/*  660 */     GL11.glLineWidth(width);
/*  661 */     Tessellator tessellator = Tessellator.func_178181_a();
/*  662 */     BufferBuilder bufferbuilder = tessellator.func_178180_c();
/*  663 */     bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
/*  664 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, 0.0F).func_181675_d();
/*  665 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  666 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  667 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  668 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  669 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  670 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  671 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  672 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  673 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  674 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  675 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, 0.0F).func_181675_d();
/*  676 */     bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  677 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, 0.0F).func_181675_d();
/*  678 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  679 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, 0.0F).func_181675_d();
/*  680 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/*  681 */     bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, 0.0F).func_181675_d();
/*  682 */     tessellator.func_78381_a();
/*  683 */     GL11.glDisable(2848);
/*  684 */     GlStateManager.func_179132_a(true);
/*  685 */     GlStateManager.func_179126_j();
/*  686 */     GlStateManager.func_179098_w();
/*  687 */     GlStateManager.func_179084_k();
/*  688 */     GlStateManager.func_179121_F();
/*      */   }
/*      */   
/*      */   public static void drawSphere(double x, double y, double z, float size, int slices, int stacks) {
/*  692 */     Sphere s = new Sphere();
/*  693 */     GL11.glPushMatrix();
/*  694 */     GL11.glBlendFunc(770, 771);
/*  695 */     GL11.glEnable(3042);
/*  696 */     GL11.glLineWidth(1.2F);
/*  697 */     GL11.glDisable(3553);
/*  698 */     GL11.glDisable(2929);
/*  699 */     GL11.glDepthMask(false);
/*  700 */     s.setDrawStyle(100013);
/*  701 */     GL11.glTranslated(x - mc.field_175616_W.field_78725_b, y - mc.field_175616_W.field_78726_c, z - mc.field_175616_W.field_78723_d);
/*  702 */     s.draw(size, slices, stacks);
/*  703 */     GL11.glLineWidth(2.0F);
/*  704 */     GL11.glEnable(3553);
/*  705 */     GL11.glEnable(2929);
/*  706 */     GL11.glDepthMask(true);
/*  707 */     GL11.glDisable(3042);
/*  708 */     GL11.glPopMatrix();
/*      */   }
/*      */   
/*      */   public static void GLPre(float lineWidth) {
/*  712 */     depth = GL11.glIsEnabled(2896);
/*  713 */     texture = GL11.glIsEnabled(3042);
/*  714 */     clean = GL11.glIsEnabled(3553);
/*  715 */     bind = GL11.glIsEnabled(2929);
/*  716 */     override = GL11.glIsEnabled(2848);
/*  717 */     GLPre(depth, texture, clean, bind, override, lineWidth);
/*      */   }
/*      */   
/*      */   public static void GlPost() {
/*  721 */     GLPost(depth, texture, clean, bind, override);
/*      */   }
/*      */   
/*      */   private static void GLPre(boolean depth, boolean texture, boolean clean, boolean bind, boolean override, float lineWidth) {
/*  725 */     if (depth) {
/*  726 */       GL11.glDisable(2896);
/*      */     }
/*  728 */     if (!texture) {
/*  729 */       GL11.glEnable(3042);
/*      */     }
/*  731 */     GL11.glLineWidth(lineWidth);
/*  732 */     if (clean) {
/*  733 */       GL11.glDisable(3553);
/*      */     }
/*  735 */     if (bind) {
/*  736 */       GL11.glDisable(2929);
/*      */     }
/*  738 */     if (!override) {
/*  739 */       GL11.glEnable(2848);
/*      */     }
/*  741 */     GlStateManager.func_187401_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
/*  742 */     GL11.glHint(3154, 4354);
/*  743 */     GlStateManager.func_179132_a(false);
/*      */   }
/*      */   
/*      */   public static float[][] getBipedRotations(ModelBiped biped) {
/*  747 */     float[][] rotations = new float[5][];
/*  748 */     float[] headRotation = { biped.field_78116_c.field_78795_f, biped.field_78116_c.field_78796_g, biped.field_78116_c.field_78808_h };
/*  749 */     rotations[0] = headRotation;
/*  750 */     float[] rightArmRotation = { biped.field_178723_h.field_78795_f, biped.field_178723_h.field_78796_g, biped.field_178723_h.field_78808_h };
/*  751 */     rotations[1] = rightArmRotation;
/*  752 */     float[] leftArmRotation = { biped.field_178724_i.field_78795_f, biped.field_178724_i.field_78796_g, biped.field_178724_i.field_78808_h };
/*  753 */     rotations[2] = leftArmRotation;
/*  754 */     float[] rightLegRotation = { biped.field_178721_j.field_78795_f, biped.field_178721_j.field_78796_g, biped.field_178721_j.field_78808_h };
/*  755 */     rotations[3] = rightLegRotation;
/*  756 */     float[] leftLegRotation = { biped.field_178722_k.field_78795_f, biped.field_178722_k.field_78796_g, biped.field_178722_k.field_78808_h };
/*  757 */     rotations[4] = leftLegRotation;
/*  758 */     return rotations;
/*      */   }
/*      */   
/*      */   private static void GLPost(boolean depth, boolean texture, boolean clean, boolean bind, boolean override) {
/*  762 */     GlStateManager.func_179132_a(true);
/*  763 */     if (!override) {
/*  764 */       GL11.glDisable(2848);
/*      */     }
/*  766 */     if (bind) {
/*  767 */       GL11.glEnable(2929);
/*      */     }
/*  769 */     if (clean) {
/*  770 */       GL11.glEnable(3553);
/*      */     }
/*  772 */     if (!texture) {
/*  773 */       GL11.glDisable(3042);
/*      */     }
/*  775 */     if (depth) {
/*  776 */       GL11.glEnable(2896);
/*      */     }
/*      */   }
/*      */   
/*      */   public static void drawArc(float cx, float cy, float r, float start_angle, float end_angle, int num_segments) {
/*  781 */     GL11.glBegin(4);
/*  782 */     int i = (int)(num_segments / 360.0F / start_angle) + 1;
/*  783 */     while (i <= num_segments / 360.0F / end_angle) {
/*  784 */       double previousangle = 6.283185307179586D * (i - 1) / num_segments;
/*  785 */       double angle = 6.283185307179586D * i / num_segments;
/*  786 */       GL11.glVertex2d(cx, cy);
/*  787 */       GL11.glVertex2d(cx + Math.cos(angle) * r, cy + Math.sin(angle) * r);
/*  788 */       GL11.glVertex2d(cx + Math.cos(previousangle) * r, cy + Math.sin(previousangle) * r);
/*  789 */       i++;
/*      */     } 
/*  791 */     glEnd();
/*      */   }
/*      */   
/*      */   public static void drawArcOutline(float cx, float cy, float r, float start_angle, float end_angle, int num_segments) {
/*  795 */     GL11.glBegin(2);
/*  796 */     int i = (int)(num_segments / 360.0F / start_angle) + 1;
/*  797 */     while (i <= num_segments / 360.0F / end_angle) {
/*  798 */       double angle = 6.283185307179586D * i / num_segments;
/*  799 */       GL11.glVertex2d(cx + Math.cos(angle) * r, cy + Math.sin(angle) * r);
/*  800 */       i++;
/*      */     } 
/*  802 */     glEnd();
/*      */   }
/*      */   
/*      */   public static void drawCircleOutline(float x, float y, float radius) {
/*  806 */     drawCircleOutline(x, y, radius, 0, 360, 40);
/*      */   }
/*      */   
/*      */   public static void drawCircleOutline(float x, float y, float radius, int start, int end, int segments) {
/*  810 */     drawArcOutline(x, y, radius, start, end, segments);
/*      */   }
/*      */   
/*      */   public static void drawCircle(float x, float y, float radius) {
/*  814 */     drawCircle(x, y, radius, 0, 360, 64);
/*      */   }
/*      */   
/*      */   public static void drawCircle(float x, float y, float radius, int start, int end, int segments) {
/*  818 */     drawArc(x, y, radius, start, end, segments);
/*      */   }
/*      */   
/*      */   public static void drawOutlinedRoundedRectangle(int x, int y, int width, int height, float radius, float dR, float dG, float dB, float dA, float outlineWidth) {
/*  822 */     drawRoundedRectangle(x, y, width, height, radius);
/*  823 */     GL11.glColor4f(dR, dG, dB, dA);
/*  824 */     drawRoundedRectangle(x + outlineWidth, y + outlineWidth, width - outlineWidth * 2.0F, height - outlineWidth * 2.0F, radius);
/*      */   }
/*      */   
/*      */   public static void drawRectangle(float x, float y, float width, float height) {
/*  828 */     GL11.glEnable(3042);
/*  829 */     GL11.glBlendFunc(770, 771);
/*  830 */     GL11.glBegin(2);
/*  831 */     GL11.glVertex2d(width, 0.0D);
/*  832 */     GL11.glVertex2d(0.0D, 0.0D);
/*  833 */     GL11.glVertex2d(0.0D, height);
/*  834 */     GL11.glVertex2d(width, height);
/*  835 */     glEnd();
/*      */   }
/*      */   
/*      */   public static void drawRectangleXY(float x, float y, float width, float height) {
/*  839 */     GL11.glEnable(3042);
/*  840 */     GL11.glBlendFunc(770, 771);
/*  841 */     GL11.glBegin(2);
/*  842 */     GL11.glVertex2d((x + width), y);
/*  843 */     GL11.glVertex2d(x, y);
/*  844 */     GL11.glVertex2d(x, (y + height));
/*  845 */     GL11.glVertex2d((x + width), (y + height));
/*  846 */     glEnd();
/*      */   }
/*      */   
/*      */   public static void drawFilledRectangle(float x, float y, float width, float height) {
/*  850 */     GL11.glEnable(3042);
/*  851 */     GL11.glBlendFunc(770, 771);
/*  852 */     GL11.glBegin(7);
/*  853 */     GL11.glVertex2d((x + width), y);
/*  854 */     GL11.glVertex2d(x, y);
/*  855 */     GL11.glVertex2d(x, (y + height));
/*  856 */     GL11.glVertex2d((x + width), (y + height));
/*  857 */     glEnd();
/*      */   }
/*      */   
/*      */   public static void drawRoundedRectangle(float x, float y, float width, float height, float radius) {
/*  861 */     GL11.glEnable(3042);
/*  862 */     drawArc(x + width - radius, y + height - radius, radius, 0.0F, 90.0F, 16);
/*  863 */     drawArc(x + radius, y + height - radius, radius, 90.0F, 180.0F, 16);
/*  864 */     drawArc(x + radius, y + radius, radius, 180.0F, 270.0F, 16);
/*  865 */     drawArc(x + width - radius, y + radius, radius, 270.0F, 360.0F, 16);
/*  866 */     GL11.glBegin(4);
/*  867 */     GL11.glVertex2d((x + width - radius), y);
/*  868 */     GL11.glVertex2d((x + radius), y);
/*  869 */     GL11.glVertex2d((x + width - radius), (y + radius));
/*  870 */     GL11.glVertex2d((x + width - radius), (y + radius));
/*  871 */     GL11.glVertex2d((x + radius), y);
/*  872 */     GL11.glVertex2d((x + radius), (y + radius));
/*  873 */     GL11.glVertex2d((x + width), (y + radius));
/*  874 */     GL11.glVertex2d(x, (y + radius));
/*  875 */     GL11.glVertex2d(x, (y + height - radius));
/*  876 */     GL11.glVertex2d((x + width), (y + radius));
/*  877 */     GL11.glVertex2d(x, (y + height - radius));
/*  878 */     GL11.glVertex2d((x + width), (y + height - radius));
/*  879 */     GL11.glVertex2d((x + width - radius), (y + height - radius));
/*  880 */     GL11.glVertex2d((x + radius), (y + height - radius));
/*  881 */     GL11.glVertex2d((x + width - radius), (y + height));
/*  882 */     GL11.glVertex2d((x + width - radius), (y + height));
/*  883 */     GL11.glVertex2d((x + radius), (y + height - radius));
/*  884 */     GL11.glVertex2d((x + radius), (y + height));
/*  885 */     glEnd();
/*      */   }
/*      */   
/*      */   public static void renderOne(float lineWidth) {
/*  889 */     checkSetupFBO();
/*  890 */     GL11.glPushAttrib(1048575);
/*  891 */     GL11.glDisable(3008);
/*  892 */     GL11.glDisable(3553);
/*  893 */     GL11.glDisable(2896);
/*  894 */     GL11.glEnable(3042);
/*  895 */     GL11.glBlendFunc(770, 771);
/*  896 */     GL11.glLineWidth(lineWidth);
/*  897 */     GL11.glEnable(2848);
/*  898 */     GL11.glEnable(2960);
/*  899 */     GL11.glClear(1024);
/*  900 */     GL11.glClearStencil(15);
/*  901 */     GL11.glStencilFunc(512, 1, 15);
/*  902 */     GL11.glStencilOp(7681, 7681, 7681);
/*  903 */     GL11.glPolygonMode(1032, 6913);
/*      */   }
/*      */   
/*      */   public static void renderTwo() {
/*  907 */     GL11.glStencilFunc(512, 0, 15);
/*  908 */     GL11.glStencilOp(7681, 7681, 7681);
/*  909 */     GL11.glPolygonMode(1032, 6914);
/*      */   }
/*      */   
/*      */   public static void renderThree() {
/*  913 */     GL11.glStencilFunc(514, 1, 15);
/*  914 */     GL11.glStencilOp(7680, 7680, 7680);
/*  915 */     GL11.glPolygonMode(1032, 6913);
/*      */   }
/*      */   
/*      */   public static void renderFour(Color color) {
/*  919 */     setColor(color);
/*  920 */     GL11.glDepthMask(false);
/*  921 */     GL11.glDisable(2929);
/*  922 */     GL11.glEnable(10754);
/*  923 */     GL11.glPolygonOffset(1.0F, -2000000.0F);
/*  924 */     OpenGlHelper.func_77475_a(OpenGlHelper.field_77476_b, 240.0F, 240.0F);
/*      */   }
/*      */   
/*      */   public static void renderFive() {
/*  928 */     GL11.glPolygonOffset(1.0F, 2000000.0F);
/*  929 */     GL11.glDisable(10754);
/*  930 */     GL11.glEnable(2929);
/*  931 */     GL11.glDepthMask(true);
/*  932 */     GL11.glDisable(2960);
/*  933 */     GL11.glDisable(2848);
/*  934 */     GL11.glHint(3154, 4352);
/*  935 */     GL11.glEnable(3042);
/*  936 */     GL11.glEnable(2896);
/*  937 */     GL11.glEnable(3553);
/*  938 */     GL11.glEnable(3008);
/*  939 */     GL11.glPopAttrib();
/*      */   }
/*      */   
/*      */   public static void setColor(Color color) {
/*  943 */     GL11.glColor4d(color.getRed() / 255.0D, color.getGreen() / 255.0D, color.getBlue() / 255.0D, color.getAlpha() / 255.0D);
/*      */   }
/*      */   
/*      */   public static void checkSetupFBO() {
/*  947 */     Framebuffer fbo = mc.field_147124_at;
/*  948 */     if (fbo != null && fbo.field_147624_h > -1) {
/*  949 */       setupFBO(fbo);
/*  950 */       fbo.field_147624_h = -1;
/*      */     } 
/*      */   }
/*      */   
/*      */   private static void setupFBO(Framebuffer fbo) {
/*  955 */     EXTFramebufferObject.glDeleteRenderbuffersEXT(fbo.field_147624_h);
/*  956 */     int stencilDepthBufferID = EXTFramebufferObject.glGenRenderbuffersEXT();
/*  957 */     EXTFramebufferObject.glBindRenderbufferEXT(36161, stencilDepthBufferID);
/*  958 */     EXTFramebufferObject.glRenderbufferStorageEXT(36161, 34041, mc.field_71443_c, mc.field_71440_d);
/*  959 */     EXTFramebufferObject.glFramebufferRenderbufferEXT(36160, 36128, 36161, stencilDepthBufferID);
/*  960 */     EXTFramebufferObject.glFramebufferRenderbufferEXT(36160, 36096, 36161, stencilDepthBufferID);
/*      */   }
/*      */   
/*      */   public static final class GeometryMasks {
/*  964 */     public static final HashMap FACEMAP = new HashMap<>();
/*      */     
/*      */     static {
/*  967 */       FACEMAP.put(EnumFacing.DOWN, Integer.valueOf(1));
/*  968 */       FACEMAP.put(EnumFacing.WEST, Integer.valueOf(16));
/*  969 */       FACEMAP.put(EnumFacing.NORTH, Integer.valueOf(4));
/*  970 */       FACEMAP.put(EnumFacing.SOUTH, Integer.valueOf(8));
/*  971 */       FACEMAP.put(EnumFacing.EAST, Integer.valueOf(32));
/*  972 */       FACEMAP.put(EnumFacing.UP, Integer.valueOf(2));
/*      */     }
/*      */     
/*      */     public static final class Quad {
/*      */       public static final int DOWN = 1;
/*      */       public static final int UP = 2;
/*      */       public static final int NORTH = 4;
/*      */       public static final int SOUTH = 8;
/*      */       public static final int WEST = 16;
/*      */       public static final int EAST = 32;
/*      */       public static final int ALL = 63;
/*      */     }
/*      */     
/*      */     public static final class Line {
/*      */       public static final int DOWN_WEST = 17;
/*      */       public static final int UP_WEST = 18;
/*      */       public static final int DOWN_EAST = 33;
/*      */       public static final int UP_EAST = 34;
/*      */       public static final int DOWN_NORTH = 5;
/*      */       public static final int UP_NORTH = 6;
/*      */       public static final int DOWN_SOUTH = 9;
/*      */       public static final int UP_SOUTH = 10;
/*      */       public static final int NORTH_WEST = 20;
/*      */       public static final int NORTH_EAST = 36;
/*      */       public static final int SOUTH_WEST = 24;
/*      */       public static final int SOUTH_EAST = 40;
/*      */       public static final int ALL = 63;
/*      */     }
/*      */   }
/*      */   
/*      */   public static class RenderTesselator
/*      */     extends Tessellator {
/* 1004 */     public static RenderTesselator INSTANCE = new RenderTesselator();
/*      */     
/*      */     public RenderTesselator() {
/* 1007 */       super(2097152);
/*      */     }
/*      */     
/*      */     public static void prepare(int mode) {
/* 1011 */       prepareGL();
/* 1012 */       begin(mode);
/*      */     }
/*      */     
/*      */     public static void prepareGL() {
/* 1016 */       GL11.glBlendFunc(770, 771);
/* 1017 */       GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
/* 1018 */       GlStateManager.func_187441_d(1.5F);
/* 1019 */       GlStateManager.func_179090_x();
/* 1020 */       GlStateManager.func_179132_a(false);
/* 1021 */       GlStateManager.func_179147_l();
/* 1022 */       GlStateManager.func_179097_i();
/* 1023 */       GlStateManager.func_179140_f();
/* 1024 */       GlStateManager.func_179129_p();
/* 1025 */       GlStateManager.func_179141_d();
/* 1026 */       GlStateManager.func_179124_c(1.0F, 1.0F, 1.0F);
/*      */     }
/*      */     
/*      */     public static void begin(int mode) {
/* 1030 */       INSTANCE.func_178180_c().func_181668_a(mode, DefaultVertexFormats.field_181706_f);
/*      */     }
/*      */     
/*      */     public static void release() {
/* 1034 */       render();
/* 1035 */       releaseGL();
/*      */     }
/*      */     
/*      */     public static void render() {
/* 1039 */       INSTANCE.func_78381_a();
/*      */     }
/*      */     
/*      */     public static void releaseGL() {
/* 1043 */       GlStateManager.func_179089_o();
/* 1044 */       GlStateManager.func_179132_a(true);
/* 1045 */       GlStateManager.func_179098_w();
/* 1046 */       GlStateManager.func_179147_l();
/* 1047 */       GlStateManager.func_179126_j();
/*      */     }
/*      */     
/*      */     public static void drawBox(BlockPos blockPos, int argb, int sides) {
/* 1051 */       int a = argb >>> 24 & 0xFF;
/* 1052 */       int r = argb >>> 16 & 0xFF;
/* 1053 */       int g = argb >>> 8 & 0xFF;
/* 1054 */       int b = argb & 0xFF;
/* 1055 */       drawBox(blockPos, r, g, b, a, sides);
/*      */     }
/*      */     
/*      */     public static void drawBox(float x, float y, float z, int argb, int sides) {
/* 1059 */       int a = argb >>> 24 & 0xFF;
/* 1060 */       int r = argb >>> 16 & 0xFF;
/* 1061 */       int g = argb >>> 8 & 0xFF;
/* 1062 */       int b = argb & 0xFF;
/* 1063 */       drawBox(INSTANCE.func_178180_c(), x, y, z, 1.0F, 1.0F, 1.0F, r, g, b, a, sides);
/*      */     }
/*      */     
/*      */     public static void drawBox(BlockPos blockPos, int r, int g, int b, int a, int sides) {
/* 1067 */       drawBox(INSTANCE.func_178180_c(), blockPos.func_177958_n(), blockPos.func_177956_o(), blockPos.func_177952_p(), 1.0F, 1.0F, 1.0F, r, g, b, a, sides);
/*      */     }
/*      */     
/*      */     public static BufferBuilder getBufferBuilder() {
/* 1071 */       return INSTANCE.func_178180_c();
/*      */     }
/*      */     
/*      */     public static void drawBox(BufferBuilder buffer, float x, float y, float z, float w, float h, float d, int r, int g, int b, int a, int sides) {
/* 1075 */       if ((sides & 0x1) != 0) {
/* 1076 */         buffer.func_181662_b((x + w), y, z).func_181669_b(r, g, b, a).func_181675_d();
/* 1077 */         buffer.func_181662_b((x + w), y, (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/* 1078 */         buffer.func_181662_b(x, y, (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/* 1079 */         buffer.func_181662_b(x, y, z).func_181669_b(r, g, b, a).func_181675_d();
/*      */       } 
/* 1081 */       if ((sides & 0x2) != 0) {
/* 1082 */         buffer.func_181662_b((x + w), (y + h), z).func_181669_b(r, g, b, a).func_181675_d();
/* 1083 */         buffer.func_181662_b(x, (y + h), z).func_181669_b(r, g, b, a).func_181675_d();
/* 1084 */         buffer.func_181662_b(x, (y + h), (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/* 1085 */         buffer.func_181662_b((x + w), (y + h), (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/*      */       } 
/* 1087 */       if ((sides & 0x4) != 0) {
/* 1088 */         buffer.func_181662_b((x + w), y, z).func_181669_b(r, g, b, a).func_181675_d();
/* 1089 */         buffer.func_181662_b(x, y, z).func_181669_b(r, g, b, a).func_181675_d();
/* 1090 */         buffer.func_181662_b(x, (y + h), z).func_181669_b(r, g, b, a).func_181675_d();
/* 1091 */         buffer.func_181662_b((x + w), (y + h), z).func_181669_b(r, g, b, a).func_181675_d();
/*      */       } 
/* 1093 */       if ((sides & 0x8) != 0) {
/* 1094 */         buffer.func_181662_b(x, y, (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/* 1095 */         buffer.func_181662_b((x + w), y, (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/* 1096 */         buffer.func_181662_b((x + w), (y + h), (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/* 1097 */         buffer.func_181662_b(x, (y + h), (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/*      */       } 
/* 1099 */       if ((sides & 0x10) != 0) {
/* 1100 */         buffer.func_181662_b(x, y, z).func_181669_b(r, g, b, a).func_181675_d();
/* 1101 */         buffer.func_181662_b(x, y, (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/* 1102 */         buffer.func_181662_b(x, (y + h), (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/* 1103 */         buffer.func_181662_b(x, (y + h), z).func_181669_b(r, g, b, a).func_181675_d();
/*      */       } 
/* 1105 */       if ((sides & 0x20) != 0) {
/* 1106 */         buffer.func_181662_b((x + w), y, (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/* 1107 */         buffer.func_181662_b((x + w), y, z).func_181669_b(r, g, b, a).func_181675_d();
/* 1108 */         buffer.func_181662_b((x + w), (y + h), z).func_181669_b(r, g, b, a).func_181675_d();
/* 1109 */         buffer.func_181662_b((x + w), (y + h), (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/*      */       } 
/*      */     }
/*      */     
/*      */     public static void drawLines(BufferBuilder buffer, float x, float y, float z, float w, float h, float d, int r, int g, int b, int a, int sides) {
/* 1114 */       if ((sides & 0x11) != 0) {
/* 1115 */         buffer.func_181662_b(x, y, z).func_181669_b(r, g, b, a).func_181675_d();
/* 1116 */         buffer.func_181662_b(x, y, (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/*      */       } 
/* 1118 */       if ((sides & 0x12) != 0) {
/* 1119 */         buffer.func_181662_b(x, (y + h), z).func_181669_b(r, g, b, a).func_181675_d();
/* 1120 */         buffer.func_181662_b(x, (y + h), (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/*      */       } 
/* 1122 */       if ((sides & 0x21) != 0) {
/* 1123 */         buffer.func_181662_b((x + w), y, z).func_181669_b(r, g, b, a).func_181675_d();
/* 1124 */         buffer.func_181662_b((x + w), y, (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/*      */       } 
/* 1126 */       if ((sides & 0x22) != 0) {
/* 1127 */         buffer.func_181662_b((x + w), (y + h), z).func_181669_b(r, g, b, a).func_181675_d();
/* 1128 */         buffer.func_181662_b((x + w), (y + h), (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/*      */       } 
/* 1130 */       if ((sides & 0x5) != 0) {
/* 1131 */         buffer.func_181662_b(x, y, z).func_181669_b(r, g, b, a).func_181675_d();
/* 1132 */         buffer.func_181662_b((x + w), y, z).func_181669_b(r, g, b, a).func_181675_d();
/*      */       } 
/* 1134 */       if ((sides & 0x6) != 0) {
/* 1135 */         buffer.func_181662_b(x, (y + h), z).func_181669_b(r, g, b, a).func_181675_d();
/* 1136 */         buffer.func_181662_b((x + w), (y + h), z).func_181669_b(r, g, b, a).func_181675_d();
/*      */       } 
/* 1138 */       if ((sides & 0x9) != 0) {
/* 1139 */         buffer.func_181662_b(x, y, (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/* 1140 */         buffer.func_181662_b((x + w), y, (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/*      */       } 
/* 1142 */       if ((sides & 0xA) != 0) {
/* 1143 */         buffer.func_181662_b(x, (y + h), (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/* 1144 */         buffer.func_181662_b((x + w), (y + h), (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/*      */       } 
/* 1146 */       if ((sides & 0x14) != 0) {
/* 1147 */         buffer.func_181662_b(x, y, z).func_181669_b(r, g, b, a).func_181675_d();
/* 1148 */         buffer.func_181662_b(x, (y + h), z).func_181669_b(r, g, b, a).func_181675_d();
/*      */       } 
/* 1150 */       if ((sides & 0x24) != 0) {
/* 1151 */         buffer.func_181662_b((x + w), y, z).func_181669_b(r, g, b, a).func_181675_d();
/* 1152 */         buffer.func_181662_b((x + w), (y + h), z).func_181669_b(r, g, b, a).func_181675_d();
/*      */       } 
/* 1154 */       if ((sides & 0x18) != 0) {
/* 1155 */         buffer.func_181662_b(x, y, (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/* 1156 */         buffer.func_181662_b(x, (y + h), (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/*      */       } 
/* 1158 */       if ((sides & 0x28) != 0) {
/* 1159 */         buffer.func_181662_b((x + w), y, (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/* 1160 */         buffer.func_181662_b((x + w), (y + h), (z + d)).func_181669_b(r, g, b, a).func_181675_d();
/*      */       } 
/*      */     }
/*      */     
/*      */     public static void drawBoundingBox(AxisAlignedBB bb, float width, float red, float green, float blue, float alpha) {
/* 1165 */       GlStateManager.func_179094_E();
/* 1166 */       GlStateManager.func_179147_l();
/* 1167 */       GlStateManager.func_179097_i();
/* 1168 */       GlStateManager.func_179120_a(770, 771, 0, 1);
/* 1169 */       GlStateManager.func_179090_x();
/* 1170 */       GlStateManager.func_179132_a(false);
/* 1171 */       GL11.glEnable(2848);
/* 1172 */       GL11.glHint(3154, 4354);
/* 1173 */       GL11.glLineWidth(width);
/* 1174 */       Tessellator tessellator = Tessellator.func_178181_a();
/* 1175 */       BufferBuilder bufferbuilder = tessellator.func_178180_c();
/* 1176 */       bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
/* 1177 */       bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1178 */       bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1179 */       bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1180 */       bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1181 */       bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1182 */       bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1183 */       bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1184 */       bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1185 */       bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1186 */       bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1187 */       bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1188 */       bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72334_f).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1189 */       bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1190 */       bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72338_b, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1191 */       bufferbuilder.func_181662_b(bb.field_72336_d, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1192 */       bufferbuilder.func_181662_b(bb.field_72340_a, bb.field_72337_e, bb.field_72339_c).func_181666_a(red, green, blue, alpha).func_181675_d();
/* 1193 */       tessellator.func_78381_a();
/* 1194 */       GL11.glDisable(2848);
/* 1195 */       GlStateManager.func_179132_a(true);
/* 1196 */       GlStateManager.func_179126_j();
/* 1197 */       GlStateManager.func_179098_w();
/* 1198 */       GlStateManager.func_179084_k();
/* 1199 */       GlStateManager.func_179121_F();
/*      */     }
/*      */     
/*      */     public static void drawFullBox(AxisAlignedBB bb, BlockPos blockPos, float width, int argb, int alpha2) {
/* 1203 */       int a = argb >>> 24 & 0xFF;
/* 1204 */       int r = argb >>> 16 & 0xFF;
/* 1205 */       int g = argb >>> 8 & 0xFF;
/* 1206 */       int b = argb & 0xFF;
/* 1207 */       drawFullBox(bb, blockPos, width, r, g, b, a, alpha2);
/*      */     }
/*      */     
/*      */     public static void drawFullBox(AxisAlignedBB bb, BlockPos blockPos, float width, int red, int green, int blue, int alpha, int alpha2) {
/* 1211 */       prepare(7);
/* 1212 */       drawBox(blockPos, red, green, blue, alpha, 63);
/* 1213 */       release();
/* 1214 */       drawBoundingBox(bb, width, red, green, blue, alpha2);
/*      */     }
/*      */     
/*      */     public static void drawHalfBox(BlockPos blockPos, int argb, int sides) {
/* 1218 */       int a = argb >>> 24 & 0xFF;
/* 1219 */       int r = argb >>> 16 & 0xFF;
/* 1220 */       int g = argb >>> 8 & 0xFF;
/* 1221 */       int b = argb & 0xFF;
/* 1222 */       drawHalfBox(blockPos, r, g, b, a, sides);
/*      */     }
/*      */     
/*      */     public static void drawHalfBox(BlockPos blockPos, int r, int g, int b, int a, int sides) {
/* 1226 */       drawBox(INSTANCE.func_178180_c(), blockPos.func_177958_n(), blockPos.func_177956_o(), blockPos.func_177952_p(), 1.0F, 0.5F, 1.0F, r, g, b, a, sides);
/*      */     }
/*      */   }
/*      */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/util/RenderUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */