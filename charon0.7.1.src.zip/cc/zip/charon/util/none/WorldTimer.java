/*    */ package cc.zip.charon.util.none;
/*    */ 
/*    */ public class WorldTimer {
/*  4 */   private float OverrideSpeed = 1.0F;
/*    */   
/*    */   private void useTimer() {
/*  7 */     if (this.OverrideSpeed != 1.0F && this.OverrideSpeed > 0.1F) {
/*  8 */       Wrapper.mc.field_71428_T.field_194149_e = 50.0F / this.OverrideSpeed;
/*    */     }
/*    */   }
/*    */   
/*    */   public void SetOverrideSpeed(float f) {
/* 13 */     this.OverrideSpeed = f;
/* 14 */     useTimer();
/*    */   }
/*    */   
/*    */   public void resetTime() {
/* 18 */     Wrapper.mc.field_71428_T.field_194149_e = 50.0F;
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/util/none/WorldTimer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */