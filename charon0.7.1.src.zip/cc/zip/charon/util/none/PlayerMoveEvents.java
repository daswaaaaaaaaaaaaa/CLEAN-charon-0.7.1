/*    */ package cc.zip.charon.util.none;
/*    */ 
/*    */ import net.minecraft.entity.MoverType;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PlayerMoveEvents
/*    */   extends EventBig
/*    */ {
/*    */   MoverType type;
/*    */   public double x;
/*    */   public double y;
/*    */   public double z;
/*    */   
/*    */   public PlayerMoveEvents(MoverType moverType, double x, double y, double z) {
/* 16 */     this.type = moverType;
/* 17 */     this.x = x;
/* 18 */     this.y = y;
/* 19 */     this.z = z;
/*    */   }
/*    */   
/*    */   public MoverType getType() {
/* 23 */     return this.type;
/*    */   }
/*    */   
/*    */   public void setType(MoverType type) {
/* 27 */     this.type = type;
/*    */   }
/*    */   
/*    */   public double getX() {
/* 31 */     return this.x;
/*    */   }
/*    */   
/*    */   public double getY() {
/* 35 */     return this.y;
/*    */   }
/*    */   
/*    */   public double getZ() {
/* 39 */     return this.z;
/*    */   }
/*    */   
/*    */   public void setX(double x) {
/* 43 */     this.x = x;
/*    */   }
/*    */   
/*    */   public void setY(double y) {
/* 47 */     this.y = y;
/*    */   }
/*    */   
/*    */   public void setZ(double z) {
/* 51 */     this.z = z;
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/util/none/PlayerMoveEvents.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */