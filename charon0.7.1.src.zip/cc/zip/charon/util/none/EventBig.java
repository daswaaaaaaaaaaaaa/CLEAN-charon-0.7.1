package cc.zip.charon.util.none;

import cc.eventhan.Cancellable;

public class EventBig extends Cancellable {}


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/util/none/EventBig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */