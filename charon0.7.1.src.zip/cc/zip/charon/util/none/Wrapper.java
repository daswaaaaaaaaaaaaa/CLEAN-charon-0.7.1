/*    */ package cc.zip.charon.util.none;
/*    */ 
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.entity.EntityPlayerSP;
/*    */ import net.minecraft.client.gui.FontRenderer;
/*    */ import net.minecraft.world.World;
/*    */ import org.lwjgl.input.Keyboard;
/*    */ 
/*    */ public class Wrapper {
/* 10 */   public static Minecraft mc = Minecraft.func_71410_x();
/* 11 */   public static FontRenderer fontRenderer = mc.field_71466_p;
/*    */   public static EntityPlayerSP getPlayer() {
/* 13 */     return (getMinecraft()).field_71439_g;
/*    */   }
/*    */   public static Minecraft getMinecraft() {
/* 16 */     return mc;
/*    */   }
/*    */   public static World getWorld() {
/* 19 */     return (World)(getMinecraft()).field_71441_e;
/*    */   }
/*    */   public static int getKey(String keyname) {
/* 22 */     return Keyboard.getKeyIndex(keyname.toUpperCase());
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/util/none/Wrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */