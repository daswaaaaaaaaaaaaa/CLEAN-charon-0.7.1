/*     */ package cc.zip.charon.util.none;
/*     */ 
/*     */ import cc.zip.charon.features.command.Command;
/*     */ import cc.zip.charon.util.EntityUtil;
/*     */ import cc.zip.charon.util.RotationUtil;
/*     */ import cc.zip.charon.util.Util;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import net.minecraft.block.Block;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.NonNullList;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.RayTraceResult;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ import net.minecraft.world.World;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BlockUtil2
/*     */   implements Util
/*     */ {
/*  46 */   public static List<Block> unSolidBlocks = Arrays.asList(new Block[] { (Block)Blocks.field_150356_k, Blocks.field_150457_bL, Blocks.field_150433_aE, Blocks.field_150404_cg, Blocks.field_185764_cQ, (Block)Blocks.field_150465_bP, Blocks.field_150457_bL, Blocks.field_150473_bD, (Block)Blocks.field_150479_bC, Blocks.field_150471_bO, Blocks.field_150442_at, Blocks.field_150430_aB, Blocks.field_150468_ap, (Block)Blocks.field_150441_bU, (Block)Blocks.field_150455_bV, (Block)Blocks.field_150413_aR, (Block)Blocks.field_150416_aS, Blocks.field_150437_az, Blocks.field_150429_aA, (Block)Blocks.field_150488_af, Blocks.field_150350_a, (Block)Blocks.field_150427_aO, Blocks.field_150384_bq, (Block)Blocks.field_150355_j, (Block)Blocks.field_150358_i, (Block)Blocks.field_150353_l, (Block)Blocks.field_150356_k, Blocks.field_150345_g, (Block)Blocks.field_150328_O, (Block)Blocks.field_150327_N, (Block)Blocks.field_150338_P, (Block)Blocks.field_150337_Q, Blocks.field_150464_aj, Blocks.field_150459_bM, Blocks.field_150469_bN, Blocks.field_185773_cZ, (Block)Blocks.field_150436_aH, Blocks.field_150393_bb, Blocks.field_150394_bc, Blocks.field_150392_bi, Blocks.field_150388_bm, Blocks.field_150375_by, Blocks.field_185766_cS, Blocks.field_185765_cR, (Block)Blocks.field_150329_H, (Block)Blocks.field_150330_I, Blocks.field_150395_bd, (Block)Blocks.field_150480_ab, Blocks.field_150448_aq, Blocks.field_150408_cc, Blocks.field_150319_E, Blocks.field_150318_D, Blocks.field_150478_aa });
/*     */   
/*     */   public static List<BlockPos> getBlockSphere(float breakRange, Class clazz) {
/*  49 */     NonNullList positions = NonNullList.func_191196_a();
/*  50 */     positions.addAll((Collection)getSphere(EntityUtil.getPlayerPos((EntityPlayer)Util.mc.field_71439_g), breakRange, (int)breakRange, false, true, 0).stream().filter(pos -> clazz.isInstance(Util.mc.field_71441_e.func_180495_p(pos).func_177230_c())).collect(Collectors.toList()));
/*  51 */     return (List<BlockPos>)positions;
/*     */   }
/*     */   
/*     */   public static List<EnumFacing> getPossibleSides(BlockPos pos) {
/*  55 */     ArrayList<EnumFacing> facings = new ArrayList<>();
/*  56 */     for (EnumFacing side : EnumFacing.values()) {
/*     */       
/*  58 */       BlockPos neighbour = pos.func_177972_a(side); IBlockState blockState;
/*  59 */       if (Util.mc.field_71441_e.func_180495_p(neighbour).func_177230_c().func_176209_a(Util.mc.field_71441_e.func_180495_p(neighbour), false) && !(blockState = Util.mc.field_71441_e.func_180495_p(neighbour)).func_185904_a().func_76222_j())
/*  60 */         facings.add(side); 
/*     */     } 
/*  62 */     return facings;
/*     */   }
/*     */   
/*     */   public static EnumFacing getFirstFacing(BlockPos pos) {
/*  66 */     Iterator<EnumFacing> iterator = getPossibleSides(pos).iterator();
/*  67 */     if (iterator.hasNext()) {
/*  68 */       EnumFacing facing = iterator.next();
/*  69 */       return facing;
/*     */     } 
/*  71 */     return null;
/*     */   }
/*     */   
/*     */   public static EnumFacing getRayTraceFacing(BlockPos pos) {
/*  75 */     RayTraceResult result = Util.mc.field_71441_e.func_72933_a(new Vec3d(Util.mc.field_71439_g.field_70165_t, Util.mc.field_71439_g.field_70163_u + Util.mc.field_71439_g.func_70047_e(), Util.mc.field_71439_g.field_70161_v), new Vec3d(pos.func_177958_n() + 0.5D, pos.func_177958_n() - 0.5D, pos.func_177958_n() + 0.5D));
/*  76 */     if (result == null || result.field_178784_b == null) {
/*  77 */       return EnumFacing.UP;
/*     */     }
/*  79 */     return result.field_178784_b;
/*     */   }
/*     */   
/*     */   public static int isPositionPlaceable(BlockPos pos, boolean rayTrace) {
/*  83 */     return isPositionPlaceable(pos, rayTrace, true);
/*     */   }
/*     */   
/*     */   public static int isPositionPlaceable(BlockPos pos, boolean rayTrace, boolean entityCheck) {
/*  87 */     Block block = Util.mc.field_71441_e.func_180495_p(pos).func_177230_c();
/*  88 */     if (!(block instanceof net.minecraft.block.BlockAir) && !(block instanceof net.minecraft.block.BlockLiquid) && !(block instanceof net.minecraft.block.BlockTallGrass) && !(block instanceof net.minecraft.block.BlockFire) && !(block instanceof net.minecraft.block.BlockDeadBush) && !(block instanceof net.minecraft.block.BlockSnow)) {
/*  89 */       return 0;
/*     */     }
/*  91 */     if (!rayTracePlaceCheck(pos, rayTrace, 0.0F)) {
/*  92 */       return -1;
/*     */     }
/*  94 */     if (entityCheck) {
/*  95 */       for (Entity entity : Util.mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(pos))) {
/*  96 */         if (entity instanceof net.minecraft.entity.item.EntityItem || entity instanceof net.minecraft.entity.item.EntityXPOrb)
/*  97 */           continue;  return 1;
/*     */       } 
/*     */     }
/* 100 */     for (EnumFacing side : getPossibleSides(pos)) {
/* 101 */       if (!canBeClicked(pos.func_177972_a(side)))
/* 102 */         continue;  return 3;
/*     */     } 
/* 104 */     return 2;
/*     */   }
/*     */   
/*     */   public static void rightClickBlock(BlockPos pos, Vec3d vec, EnumHand hand, EnumFacing direction, boolean packet) {
/* 108 */     if (packet) {
/* 109 */       float f = (float)(vec.field_72450_a - pos.func_177958_n());
/* 110 */       float f1 = (float)(vec.field_72448_b - pos.func_177956_o());
/* 111 */       float f2 = (float)(vec.field_72449_c - pos.func_177952_p());
/* 112 */       Util.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerTryUseItemOnBlock(pos, direction, hand, f, f1, f2));
/*     */     } else {
/* 114 */       Util.mc.field_71442_b.func_187099_a(Util.mc.field_71439_g, Util.mc.field_71441_e, pos, direction, vec, hand);
/*     */     } 
/* 116 */     Util.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
/* 117 */     Util.mc.field_71467_ac = 4;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Vec3d[] getHelpingBlocks(Vec3d vec3d) {
/* 122 */     return new Vec3d[] { new Vec3d(vec3d.field_72450_a, vec3d.field_72448_b - 1.0D, vec3d.field_72449_c), new Vec3d((vec3d.field_72450_a != 0.0D) ? (vec3d.field_72450_a * 2.0D) : vec3d.field_72450_a, vec3d.field_72448_b, (vec3d.field_72450_a != 0.0D) ? vec3d.field_72449_c : (vec3d.field_72449_c * 2.0D)), new Vec3d((vec3d.field_72450_a == 0.0D) ? (vec3d.field_72450_a + 1.0D) : vec3d.field_72450_a, vec3d.field_72448_b, (vec3d.field_72450_a == 0.0D) ? vec3d.field_72449_c : (vec3d.field_72449_c + 1.0D)), new Vec3d((vec3d.field_72450_a == 0.0D) ? (vec3d.field_72450_a - 1.0D) : vec3d.field_72450_a, vec3d.field_72448_b, (vec3d.field_72450_a == 0.0D) ? vec3d.field_72449_c : (vec3d.field_72449_c - 1.0D)), new Vec3d(vec3d.field_72450_a, vec3d.field_72448_b + 1.0D, vec3d.field_72449_c) };
/*     */   }
/*     */   
/*     */   public static List<BlockPos> possiblePlacePositions(float placeRange) {
/* 126 */     NonNullList positions = NonNullList.func_191196_a();
/* 127 */     positions.addAll((Collection)getSphere(EntityUtil.getPlayerPos((EntityPlayer)Util.mc.field_71439_g), placeRange, (int)placeRange, false, true, 0).stream().filter(BlockUtil2::canPlaceCrystal).collect(Collectors.toList()));
/* 128 */     return (List<BlockPos>)positions;
/*     */   }
/*     */   
/*     */   public static List<BlockPos> getSphere(BlockPos pos, float r, int h, boolean hollow, boolean sphere, int plus_y) {
/* 132 */     ArrayList<BlockPos> circleblocks = new ArrayList<>();
/* 133 */     int cx = pos.func_177958_n();
/* 134 */     int cy = pos.func_177956_o();
/* 135 */     int cz = pos.func_177952_p();
/* 136 */     int x = cx - (int)r;
/* 137 */     while (x <= cx + r) {
/* 138 */       int z = cz - (int)r;
/* 139 */       while (z <= cz + r) {
/* 140 */         int y = sphere ? (cy - (int)r) : cy;
/*     */         while (true) {
/* 142 */           float f = y;
/* 143 */           float f2 = sphere ? (cy + r) : (cy + h);
/* 144 */           if (f >= f2)
/* 145 */             break;  double dist = ((cx - x) * (cx - x) + (cz - z) * (cz - z) + (sphere ? ((cy - y) * (cy - y)) : 0));
/* 146 */           if (dist < (r * r) && (!hollow || dist >= ((r - 1.0F) * (r - 1.0F)))) {
/* 147 */             BlockPos l = new BlockPos(x, y + plus_y, z);
/* 148 */             circleblocks.add(l);
/*     */           } 
/* 150 */           y++;
/*     */         } 
/* 152 */         z++;
/*     */       } 
/* 154 */       x++;
/*     */     } 
/* 156 */     return circleblocks;
/*     */   }
/*     */   
/*     */   public static List<BlockPos> getDisc(BlockPos pos, float r) {
/* 160 */     ArrayList<BlockPos> circleblocks = new ArrayList<>();
/* 161 */     int cx = pos.func_177958_n();
/* 162 */     int cy = pos.func_177956_o();
/* 163 */     int cz = pos.func_177952_p();
/* 164 */     int x = cx - (int)r;
/* 165 */     while (x <= cx + r) {
/* 166 */       int z = cz - (int)r;
/* 167 */       while (z <= cz + r) {
/* 168 */         double dist = ((cx - x) * (cx - x) + (cz - z) * (cz - z));
/* 169 */         if (dist < (r * r)) {
/* 170 */           BlockPos position = new BlockPos(x, cy, z);
/* 171 */           circleblocks.add(position);
/*     */         } 
/* 173 */         z++;
/*     */       } 
/* 175 */       x++;
/*     */     } 
/* 177 */     return circleblocks;
/*     */   }
/*     */   
/*     */   public static boolean canPlaceCrystal(BlockPos blockPos) {
/* 181 */     BlockPos boost = blockPos.func_177982_a(0, 1, 0);
/* 182 */     BlockPos boost2 = blockPos.func_177982_a(0, 2, 0);
/*     */     try {
/* 184 */       return ((Util.mc.field_71441_e.func_180495_p(blockPos).func_177230_c() == Blocks.field_150357_h || Util.mc.field_71441_e.func_180495_p(blockPos).func_177230_c() == Blocks.field_150343_Z) && Util.mc.field_71441_e.func_180495_p(boost).func_177230_c() == Blocks.field_150350_a && Util.mc.field_71441_e.func_180495_p(boost2).func_177230_c() == Blocks.field_150350_a && Util.mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(boost)).isEmpty() && Util.mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(boost2)).isEmpty());
/*     */     }
/* 186 */     catch (Exception e) {
/* 187 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static List<BlockPos> possiblePlacePositions(float placeRange, boolean specialEntityCheck, boolean oneDot15) {
/* 192 */     NonNullList positions = NonNullList.func_191196_a();
/* 193 */     positions.addAll((Collection)getSphere(EntityUtil.getPlayerPos((EntityPlayer)Util.mc.field_71439_g), placeRange, (int)placeRange, false, true, 0).stream().filter(pos -> canPlaceCrystal(pos, specialEntityCheck, oneDot15)).collect(Collectors.toList()));
/* 194 */     return (List<BlockPos>)positions;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean canPlaceCrystal(BlockPos blockPos, boolean specialEntityCheck, boolean oneDot15) {
/* 199 */     BlockPos boost = blockPos.func_177982_a(0, 1, 0);
/* 200 */     BlockPos boost2 = blockPos.func_177982_a(0, 2, 0);
/*     */     try {
/* 202 */       if (Util.mc.field_71441_e.func_180495_p(blockPos).func_177230_c() != Blocks.field_150357_h && Util.mc.field_71441_e.func_180495_p(blockPos).func_177230_c() != Blocks.field_150343_Z) {
/* 203 */         return false;
/*     */       }
/* 205 */       if ((Util.mc.field_71441_e.func_180495_p(boost).func_177230_c() != Blocks.field_150350_a || Util.mc.field_71441_e.func_180495_p(boost2).func_177230_c() != Blocks.field_150350_a) && !oneDot15) {
/* 206 */         return false;
/*     */       }
/* 208 */       if (specialEntityCheck) {
/* 209 */         for (Entity entity : Util.mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(boost))) {
/* 210 */           if (entity instanceof net.minecraft.entity.item.EntityEnderCrystal)
/* 211 */             continue;  return false;
/*     */         } 
/* 213 */         if (!oneDot15) {
/* 214 */           for (Entity entity : Util.mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(boost2))) {
/* 215 */             if (entity instanceof net.minecraft.entity.item.EntityEnderCrystal)
/* 216 */               continue;  return false;
/*     */           } 
/*     */         }
/*     */       } else {
/*     */         
/* 221 */         return (Util.mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(boost)).isEmpty() && (oneDot15 || Util.mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(boost2)).isEmpty()));
/*     */       } 
/* 223 */     } catch (Exception ignored) {
/* 224 */       return false;
/*     */     } 
/*     */     
/* 227 */     return true;
/*     */   }
/*     */   
/*     */   public static boolean canBeClicked(BlockPos pos) {
/* 231 */     return getBlock(pos).func_176209_a(getState(pos), false);
/*     */   }
/*     */   
/*     */   private static Block getBlock(BlockPos pos) {
/* 235 */     return getState(pos).func_177230_c();
/*     */   }
/*     */   
/*     */   private static IBlockState getState(BlockPos pos) {
/* 239 */     return Util.mc.field_71441_e.func_180495_p(pos);
/*     */   }
/*     */   
/*     */   public static boolean isBlockAboveEntitySolid(Entity entity) {
/* 243 */     if (entity != null) {
/* 244 */       BlockPos pos = new BlockPos(entity.field_70165_t, entity.field_70163_u + 2.0D, entity.field_70161_v);
/* 245 */       return isBlockSolid(pos);
/*     */     } 
/* 247 */     return false;
/*     */   }
/*     */   
/*     */   public static void debugPos(String message, BlockPos pos) {
/* 251 */     Command.sendMessage(message + pos.func_177958_n() + "x, " + pos.func_177956_o() + "y, " + pos.func_177952_p() + "z");
/*     */   }
/*     */   
/*     */   public static void placeCrystalOnBlock(BlockPos pos, EnumHand hand) {
/* 255 */     RayTraceResult result = Util.mc.field_71441_e.func_72933_a(new Vec3d(Util.mc.field_71439_g.field_70165_t, Util.mc.field_71439_g.field_70163_u + Util.mc.field_71439_g.func_70047_e(), Util.mc.field_71439_g.field_70161_v), new Vec3d(pos.func_177958_n() + 0.5D, pos.func_177956_o() - 0.5D, pos.func_177952_p() + 0.5D));
/* 256 */     EnumFacing facing = (result == null || result.field_178784_b == null) ? EnumFacing.UP : result.field_178784_b;
/* 257 */     Util.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerTryUseItemOnBlock(pos, facing, hand, 0.0F, 0.0F, 0.0F));
/*     */   }
/*     */   
/*     */   public static BlockPos[] toBlockPos(Vec3d[] vec3ds) {
/* 261 */     BlockPos[] list = new BlockPos[vec3ds.length];
/* 262 */     for (int i = 0; i < vec3ds.length; i++) {
/* 263 */       list[i] = new BlockPos(vec3ds[i]);
/*     */     }
/* 265 */     return list;
/*     */   }
/*     */   
/*     */   public static Vec3d posToVec3d(BlockPos pos) {
/* 269 */     return new Vec3d((Vec3i)pos);
/*     */   }
/*     */   
/*     */   public static BlockPos vec3dToPos(Vec3d vec3d) {
/* 273 */     return new BlockPos(vec3d);
/*     */   }
/*     */   
/*     */   public static Boolean isPosInFov(BlockPos pos) {
/* 277 */     int dirnumber = RotationUtil.getDirection4D();
/* 278 */     if (dirnumber == 0 && pos.func_177952_p() - (Util.mc.field_71439_g.func_174791_d()).field_72449_c < 0.0D) {
/* 279 */       return Boolean.valueOf(false);
/*     */     }
/* 281 */     if (dirnumber == 1 && pos.func_177958_n() - (Util.mc.field_71439_g.func_174791_d()).field_72450_a > 0.0D) {
/* 282 */       return Boolean.valueOf(false);
/*     */     }
/* 284 */     if (dirnumber == 2 && pos.func_177952_p() - (Util.mc.field_71439_g.func_174791_d()).field_72449_c > 0.0D) {
/* 285 */       return Boolean.valueOf(false);
/*     */     }
/* 287 */     return Boolean.valueOf((dirnumber != 3 || pos.func_177958_n() - (Util.mc.field_71439_g.func_174791_d()).field_72450_a >= 0.0D));
/*     */   }
/*     */   
/*     */   public static boolean isBlockBelowEntitySolid(Entity entity) {
/* 291 */     if (entity != null) {
/* 292 */       BlockPos pos = new BlockPos(entity.field_70165_t, entity.field_70163_u - 1.0D, entity.field_70161_v);
/* 293 */       return isBlockSolid(pos);
/*     */     } 
/* 295 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean isBlockSolid(BlockPos pos) {
/* 299 */     return !isBlockUnSolid(pos);
/*     */   }
/*     */   
/*     */   public static boolean isBlockUnSolid(BlockPos pos) {
/* 303 */     return isBlockUnSolid(Util.mc.field_71441_e.func_180495_p(pos).func_177230_c());
/*     */   }
/*     */   
/*     */   public static boolean isBlockUnSolid(Block block) {
/* 307 */     return unSolidBlocks.contains(block);
/*     */   }
/*     */   
/*     */   public static Vec3d[] convertVec3ds(Vec3d vec3d, Vec3d[] input) {
/* 311 */     Vec3d[] output = new Vec3d[input.length];
/* 312 */     for (int i = 0; i < input.length; i++) {
/* 313 */       output[i] = vec3d.func_178787_e(input[i]);
/*     */     }
/* 315 */     return output;
/*     */   }
/*     */   
/*     */   public static Vec3d[] convertVec3ds(EntityPlayer entity, Vec3d[] input) {
/* 319 */     return convertVec3ds(entity.func_174791_d(), input);
/*     */   }
/*     */   
/*     */   public static boolean canBreak(BlockPos pos) {
/* 323 */     IBlockState blockState = Util.mc.field_71441_e.func_180495_p(pos);
/* 324 */     Block block = blockState.func_177230_c();
/* 325 */     return (block.func_176195_g(blockState, (World)Util.mc.field_71441_e, pos) != -1.0F);
/*     */   }
/*     */   
/*     */   public static boolean isValidBlock(BlockPos pos) {
/* 329 */     Block block = Util.mc.field_71441_e.func_180495_p(pos).func_177230_c();
/* 330 */     return (!(block instanceof net.minecraft.block.BlockLiquid) && block.func_149688_o(null) != Material.field_151579_a);
/*     */   }
/*     */   
/*     */   public static boolean isScaffoldPos(BlockPos pos) {
/* 334 */     return (Util.mc.field_71441_e.func_175623_d(pos) || Util.mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150431_aC || Util.mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150329_H || Util.mc.field_71441_e.func_180495_p(pos).func_177230_c() instanceof net.minecraft.block.BlockLiquid);
/*     */   }
/*     */   
/*     */   public static boolean rayTracePlaceCheck(BlockPos pos, boolean shouldCheck, float height) {
/* 338 */     return (!shouldCheck || Util.mc.field_71441_e.func_147447_a(new Vec3d(Util.mc.field_71439_g.field_70165_t, Util.mc.field_71439_g.field_70163_u + Util.mc.field_71439_g.func_70047_e(), Util.mc.field_71439_g.field_70161_v), new Vec3d(pos.func_177958_n(), (pos.func_177956_o() + height), pos.func_177952_p()), false, true, false) == null);
/*     */   }
/*     */   
/*     */   public static boolean rayTracePlaceCheck(BlockPos pos, boolean shouldCheck) {
/* 342 */     return rayTracePlaceCheck(pos, shouldCheck, 1.0F);
/*     */   }
/*     */   
/*     */   public static boolean rayTracePlaceCheck(BlockPos pos) {
/* 346 */     return rayTracePlaceCheck(pos, true);
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/util/none/BlockUtil2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */