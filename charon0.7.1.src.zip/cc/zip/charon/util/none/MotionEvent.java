/*    */ package cc.zip.charon.util.none;
/*    */ 
/*    */ public class MotionEvent
/*    */   extends EventBig
/*    */ {
/*    */   public double x;
/*    */   public double y;
/*    */   public double z;
/*    */   
/*    */   public MotionEvent(double x, double y, double z) {
/* 11 */     this.x = x;
/* 12 */     this.y = y;
/* 13 */     this.z = z;
/*    */   }
/*    */   
/*    */   public double getX() {
/* 17 */     return this.x;
/*    */   }
/*    */   
/*    */   public double getY() {
/* 21 */     return this.y;
/*    */   }
/*    */   
/*    */   public double getZ() {
/* 25 */     return this.z;
/*    */   }
/*    */   
/*    */   public void setX(double x) {
/* 29 */     this.x = x;
/*    */   }
/*    */   
/*    */   public void setY(double y) {
/* 33 */     this.y = y;
/*    */   }
/*    */   
/*    */   public void setZ(double z) {
/* 37 */     this.z = z;
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/util/none/MotionEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */