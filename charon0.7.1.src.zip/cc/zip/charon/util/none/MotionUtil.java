/*    */ package cc.zip.charon.util.none;
/*    */ 
/*    */ import cc.zip.charon.util.Util;
/*    */ import net.minecraft.entity.EntityLivingBase;
/*    */ import net.minecraft.potion.Potion;
/*    */ 
/*    */ public class MotionUtil
/*    */   implements Util {
/*    */   public static boolean isMoving(EntityLivingBase entity) {
/* 10 */     return (entity.field_191988_bg != 0.0F || entity.field_70702_br != 0.0F);
/*    */   }
/*    */ 
/*    */   
/*    */   public static void setSpeed(EntityLivingBase entity, double speed) {
/* 15 */     double[] dir = forward(speed);
/* 16 */     entity.field_70159_w = dir[0];
/* 17 */     entity.field_70179_y = dir[1];
/*    */   }
/*    */   
/*    */   public static double getBaseMoveSpeed() {
/* 21 */     double baseSpeed = 0.2873D;
/* 22 */     if (mc.field_71439_g != null && mc.field_71439_g.func_70644_a(Potion.func_188412_a(1))) {
/* 23 */       int amplifier = mc.field_71439_g.func_70660_b(Potion.func_188412_a(1)).func_76458_c();
/* 24 */       baseSpeed *= 1.0D + 0.2D * (amplifier + 1);
/*    */     } 
/*    */     
/* 27 */     return baseSpeed;
/*    */   }
/*    */   
/*    */   public static double getSpeed(EntityLivingBase entity) {
/* 31 */     return Math.sqrt(entity.field_70159_w * entity.field_70159_w + entity.field_70179_y * entity.field_70179_y);
/*    */   }
/*    */   
/*    */   public static double[] forward(double speed) {
/* 35 */     float forward = mc.field_71439_g.field_71158_b.field_192832_b;
/* 36 */     float side = mc.field_71439_g.field_71158_b.field_78902_a;
/* 37 */     float yaw = mc.field_71439_g.field_70126_B + (mc.field_71439_g.field_70177_z - mc.field_71439_g.field_70126_B) * mc.func_184121_ak();
/* 38 */     if (forward != 0.0F) {
/* 39 */       if (side > 0.0F) {
/* 40 */         yaw += ((forward > 0.0F) ? -45 : 45);
/* 41 */       } else if (side < 0.0F) {
/* 42 */         yaw += ((forward > 0.0F) ? 45 : -45);
/*    */       } 
/* 44 */       side = 0.0F;
/* 45 */       if (forward > 0.0F) {
/* 46 */         forward = 1.0F;
/* 47 */       } else if (forward < 0.0F) {
/* 48 */         forward = -1.0F;
/*    */       } 
/*    */     } 
/* 51 */     double sin = Math.sin(Math.toRadians((yaw + 90.0F)));
/* 52 */     double cos = Math.cos(Math.toRadians((yaw + 90.0F)));
/* 53 */     double posX = forward * speed * cos + side * speed * sin;
/* 54 */     double posZ = forward * speed * sin - side * speed * cos;
/* 55 */     return new double[] { posX, posZ };
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/util/none/MotionUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */