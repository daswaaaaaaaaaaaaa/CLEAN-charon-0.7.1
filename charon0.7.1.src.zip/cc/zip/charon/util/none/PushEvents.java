/*    */ package cc.zip.charon.util.none;
/*    */ 
/*    */ import cc.zip.charon.event.EventStage;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraftforge.fml.common.eventhandler.Cancelable;
/*    */ 
/*    */ @Cancelable
/*    */ public class PushEvents extends EventStage {
/*    */   public Entity entity;
/*    */   public double x;
/*    */   public double y;
/*    */   public double z;
/*    */   public boolean airbone;
/*    */   
/*    */   public PushEvents(Entity entity, double x, double y, double z, boolean airbone) {
/* 16 */     super(0);
/* 17 */     this.entity = entity;
/* 18 */     this.x = x;
/* 19 */     this.y = y;
/* 20 */     this.z = z;
/* 21 */     this.airbone = airbone;
/*    */   }
/*    */   
/*    */   public PushEvents(int stage) {
/* 25 */     super(stage);
/*    */   }
/*    */   
/*    */   public PushEvents(int stage, Entity entity) {
/* 29 */     super(stage);
/* 30 */     this.entity = entity;
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/util/none/PushEvents.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */