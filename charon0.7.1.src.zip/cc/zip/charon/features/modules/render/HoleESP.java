/*    */ package cc.zip.charon.features.modules.render;
/*    */ 
/*    */ import cc.zip.charon.event.events.Render3DEvent;
/*    */ import cc.zip.charon.features.modules.Module;
/*    */ import cc.zip.charon.features.setting.Setting;
/*    */ import cc.zip.charon.util.BlockUtil;
/*    */ import cc.zip.charon.util.RenderUtil;
/*    */ import java.awt.Color;
/*    */ import net.minecraft.init.Blocks;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.util.math.Vec3i;
/*    */ 
/*    */ public class HoleESP
/*    */   extends Module
/*    */ {
/* 16 */   private static HoleESP INSTANCE = new HoleESP();
/* 17 */   private final Setting<Integer> range = register(new Setting("RangeX", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(10)));
/* 18 */   private final Setting<Integer> rangeY = register(new Setting("RangeY", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(10)));
/* 19 */   private final Setting<Integer> red = register(new Setting("Red", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255)));
/* 20 */   private final Setting<Integer> green = register(new Setting("Green", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255)));
/* 21 */   private final Setting<Integer> blue = register(new Setting("Blue", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255)));
/* 22 */   private final Setting<Integer> alpha = register(new Setting("Alpha", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255)));
/* 23 */   private final Setting<Integer> boxAlpha = register(new Setting("BoxAlpha", Integer.valueOf(125), Integer.valueOf(0), Integer.valueOf(255)));
/* 24 */   private final Setting<Float> lineWidth = register(new Setting("LineWidth", Float.valueOf(1.0F), Float.valueOf(0.1F), Float.valueOf(5.0F)));
/* 25 */   private final Setting<Integer> safeRed = register(new Setting("BedrockRed", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255)));
/* 26 */   private final Setting<Integer> safeGreen = register(new Setting("BedrockGreen", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255)));
/* 27 */   private final Setting<Integer> safeBlue = register(new Setting("BedrockBlue", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255)));
/* 28 */   private final Setting<Integer> safeAlpha = register(new Setting("BedrockAlpha", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255)));
/* 29 */   public Setting<Boolean> future = register(new Setting("FutureRender", Boolean.valueOf(true)));
/* 30 */   public Setting<Boolean> fov = register(new Setting("InFov", Boolean.valueOf(true)));
/* 31 */   public Setting<Boolean> renderOwn = register(new Setting("RenderOwn", Boolean.valueOf(true)));
/* 32 */   public Setting<Boolean> box = register(new Setting("Box", Boolean.valueOf(true)));
/* 33 */   public Setting<Boolean> outline = register(new Setting("Outline", Boolean.valueOf(true)));
/* 34 */   private final Setting<Integer> cRed = register(new Setting("OL-Red", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), v -> ((Boolean)this.outline.getValue()).booleanValue()));
/* 35 */   private final Setting<Integer> cGreen = register(new Setting("OL-Green", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), v -> ((Boolean)this.outline.getValue()).booleanValue()));
/* 36 */   private final Setting<Integer> cBlue = register(new Setting("OL-Blue", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), v -> ((Boolean)this.outline.getValue()).booleanValue()));
/* 37 */   private final Setting<Integer> cAlpha = register(new Setting("OL-Alpha", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), v -> ((Boolean)this.outline.getValue()).booleanValue()));
/* 38 */   private final Setting<Integer> safecRed = register(new Setting("OL-BedrockRed", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), v -> ((Boolean)this.outline.getValue()).booleanValue()));
/* 39 */   private final Setting<Integer> safecGreen = register(new Setting("OL-BedrockGreen", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), v -> ((Boolean)this.outline.getValue()).booleanValue()));
/* 40 */   private final Setting<Integer> safecBlue = register(new Setting("OL-BedrockBlue", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), v -> ((Boolean)this.outline.getValue()).booleanValue()));
/* 41 */   private final Setting<Integer> safecAlpha = register(new Setting("OL-BedrockAlpha", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), v -> ((Boolean)this.outline.getValue()).booleanValue()));
/*    */   
/*    */   public HoleESP() {
/* 44 */     super("HoleESP", "Shows safe spots.", Module.Category.RENDER, false, false, false);
/* 45 */     setInstance();
/*    */   }
/*    */   
/*    */   public static HoleESP getInstance() {
/* 49 */     if (INSTANCE == null) {
/* 50 */       INSTANCE = new HoleESP();
/*    */     }
/* 52 */     return INSTANCE;
/*    */   }
/*    */   
/*    */   private void setInstance() {
/* 56 */     INSTANCE = this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onRender3D(Render3DEvent event) {
/* 61 */     assert mc.field_175622_Z != null;
/* 62 */     Vec3i playerPos = new Vec3i(mc.field_175622_Z.field_70165_t, mc.field_175622_Z.field_70163_u, mc.field_175622_Z.field_70161_v);
/* 63 */     for (int x = playerPos.func_177958_n() - ((Integer)this.range.getValue()).intValue(); x < playerPos.func_177958_n() + ((Integer)this.range.getValue()).intValue(); x++) {
/* 64 */       for (int z = playerPos.func_177952_p() - ((Integer)this.range.getValue()).intValue(); z < playerPos.func_177952_p() + ((Integer)this.range.getValue()).intValue(); z++) {
/* 65 */         for (int y = playerPos.func_177956_o() + ((Integer)this.rangeY.getValue()).intValue(); y > playerPos.func_177956_o() - ((Integer)this.rangeY.getValue()).intValue(); y--) {
/* 66 */           BlockPos pos = new BlockPos(x, y, z);
/* 67 */           if (mc.field_71441_e.func_180495_p(pos).func_177230_c().equals(Blocks.field_150350_a) && mc.field_71441_e.func_180495_p(pos.func_177982_a(0, 1, 0)).func_177230_c().equals(Blocks.field_150350_a) && mc.field_71441_e.func_180495_p(pos.func_177982_a(0, 2, 0)).func_177230_c().equals(Blocks.field_150350_a) && (!pos.equals(new BlockPos(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u, mc.field_71439_g.field_70161_v)) || ((Boolean)this.renderOwn.getValue()).booleanValue()) && (BlockUtil.isPosInFov(pos).booleanValue() || !((Boolean)this.fov.getValue()).booleanValue()))
/*    */           {
/* 69 */             if (mc.field_71441_e.func_180495_p(pos.func_177978_c()).func_177230_c() == Blocks.field_150357_h && mc.field_71441_e.func_180495_p(pos.func_177974_f()).func_177230_c() == Blocks.field_150357_h && mc.field_71441_e.func_180495_p(pos.func_177976_e()).func_177230_c() == Blocks.field_150357_h && mc.field_71441_e.func_180495_p(pos.func_177968_d()).func_177230_c() == Blocks.field_150357_h && mc.field_71441_e.func_180495_p(pos.func_177977_b()).func_177230_c() == Blocks.field_150357_h) {
/* 70 */               RenderUtil.drawBoxESP(((Boolean)this.future.getValue()).booleanValue() ? pos.func_177977_b() : pos, new Color(((Integer)this.safeRed.getValue()).intValue(), ((Integer)this.safeGreen.getValue()).intValue(), ((Integer)this.safeBlue.getValue()).intValue(), ((Integer)this.safeAlpha.getValue()).intValue()), ((Boolean)this.outline.getValue()).booleanValue(), new Color(((Integer)this.safecRed.getValue()).intValue(), ((Integer)this.safecGreen.getValue()).intValue(), ((Integer)this.safecBlue.getValue()).intValue(), ((Integer)this.safecAlpha.getValue()).intValue()), ((Float)this.lineWidth.getValue()).floatValue(), ((Boolean)this.outline.getValue()).booleanValue(), ((Boolean)this.box.getValue()).booleanValue(), ((Integer)this.boxAlpha.getValue()).intValue(), true);
/*    */             
/*    */             }
/* 73 */             else if (BlockUtil.isBlockUnSafe(mc.field_71441_e.func_180495_p(pos.func_177977_b()).func_177230_c()) && BlockUtil.isBlockUnSafe(mc.field_71441_e.func_180495_p(pos.func_177974_f()).func_177230_c()) && BlockUtil.isBlockUnSafe(mc.field_71441_e.func_180495_p(pos.func_177976_e()).func_177230_c()) && BlockUtil.isBlockUnSafe(mc.field_71441_e.func_180495_p(pos.func_177968_d()).func_177230_c()) && BlockUtil.isBlockUnSafe(mc.field_71441_e.func_180495_p(pos.func_177978_c()).func_177230_c())) {
/*    */               
/* 75 */               RenderUtil.drawBoxESP(((Boolean)this.future.getValue()).booleanValue() ? pos.func_177977_b() : pos, new Color(((Integer)this.red.getValue()).intValue(), ((Integer)this.green.getValue()).intValue(), ((Integer)this.blue.getValue()).intValue(), ((Integer)this.alpha.getValue()).intValue()), ((Boolean)this.outline.getValue()).booleanValue(), new Color(((Integer)this.cRed.getValue()).intValue(), ((Integer)this.cGreen.getValue()).intValue(), ((Integer)this.cBlue.getValue()).intValue(), ((Integer)this.cAlpha.getValue()).intValue()), ((Float)this.lineWidth.getValue()).floatValue(), ((Boolean)this.outline.getValue()).booleanValue(), ((Boolean)this.box.getValue()).booleanValue(), ((Integer)this.boxAlpha.getValue()).intValue(), true);
/*    */             } 
/*    */           }
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/render/HoleESP.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */