/*    */ package cc.zip.charon.features.modules.render;
/*    */ 
/*    */ import cc.zip.charon.features.modules.Module;
/*    */ import cc.zip.charon.features.setting.Setting;
/*    */ import net.minecraftforge.client.event.RenderPlayerEvent;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ public class Wireframe
/*    */   extends Module {
/* 10 */   private static Wireframe INSTANCE = new Wireframe();
/* 11 */   public final Setting<Float> alpha = register(new Setting("PAlpha", Float.valueOf(255.0F), Float.valueOf(0.1F), Float.valueOf(255.0F)));
/* 12 */   public final Setting<Float> cAlpha = register(new Setting("CAlpha", Float.valueOf(255.0F), Float.valueOf(0.1F), Float.valueOf(255.0F)));
/* 13 */   public final Setting<Float> lineWidth = register(new Setting("PLineWidth", Float.valueOf(1.0F), Float.valueOf(0.1F), Float.valueOf(3.0F)));
/* 14 */   public final Setting<Float> crystalLineWidth = register(new Setting("CLineWidth", Float.valueOf(1.0F), Float.valueOf(0.1F), Float.valueOf(3.0F)));
/* 15 */   public Setting<RenderMode> mode = register(new Setting("PMode", RenderMode.SOLID));
/* 16 */   public Setting<RenderMode> cMode = register(new Setting("CMode", RenderMode.SOLID));
/* 17 */   public Setting<Boolean> players = register(new Setting("Players", Boolean.FALSE));
/* 18 */   public Setting<Boolean> playerModel = register(new Setting("PlayerModel", Boolean.FALSE));
/* 19 */   public Setting<Boolean> crystals = register(new Setting("Crystals", Boolean.FALSE));
/* 20 */   public Setting<Boolean> crystalModel = register(new Setting("CrystalModel", Boolean.FALSE));
/*    */   
/*    */   public Wireframe() {
/* 23 */     super("Wireframe", "Draws a wireframe esp around other players.", Module.Category.RENDER, false, false, false);
/* 24 */     setInstance();
/*    */   }
/*    */   
/*    */   public static Wireframe getINSTANCE() {
/* 28 */     if (INSTANCE == null) {
/* 29 */       INSTANCE = new Wireframe();
/*    */     }
/* 31 */     return INSTANCE;
/*    */   }
/*    */   
/*    */   private void setInstance() {
/* 35 */     INSTANCE = this;
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onRenderPlayerEvent(RenderPlayerEvent.Pre event) {
/* 40 */     (event.getEntityPlayer()).field_70737_aN = 0;
/*    */   }
/*    */   
/*    */   public enum RenderMode {
/* 44 */     SOLID,
/* 45 */     WIREFRAME;
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/render/Wireframe.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */