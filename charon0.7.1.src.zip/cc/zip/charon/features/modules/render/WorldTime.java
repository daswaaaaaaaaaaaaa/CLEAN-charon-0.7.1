/*    */ package cc.zip.charon.features.modules.render;
/*    */ 
/*    */ import cc.zip.charon.features.modules.Module;
/*    */ import cc.zip.charon.features.setting.Setting;
/*    */ 
/*    */ public class WorldTime extends Module {
/*    */   public WorldTime() {
/*  8 */     super("WorldTime", "world timeeeee", Module.Category.RENDER, true, false, false);
/*    */ 
/*    */     
/* 11 */     this.time = register(new Setting("Time", Integer.valueOf(24000), Integer.valueOf(0), Integer.valueOf(24000)));
/*    */   } private final Setting<Integer> time;
/*    */   public void onUpdate() {
/* 14 */     if (nullCheck()) {
/*    */       return;
/*    */     }
/* 17 */     mc.field_71441_e.func_72877_b(((Integer)this.time.getValue()).intValue());
/* 18 */     mc.field_71441_e.func_72877_b(((Integer)this.time.getValue()).intValue());
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/render/WorldTime.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */