/*    */ package cc.zip.charon.features.modules.render;
/*    */ 
/*    */ import cc.zip.charon.features.modules.Module;
/*    */ import cc.zip.charon.features.setting.Setting;
/*    */ 
/*    */ public class NoHitBox
/*    */   extends Module {
/*  8 */   private static NoHitBox INSTANCE = new NoHitBox();
/*  9 */   public Setting<Boolean> pickaxe = register(new Setting("Pickaxe", Boolean.valueOf(true)));
/* 10 */   public Setting<Boolean> crystal = register(new Setting("Crystal", Boolean.valueOf(true)));
/* 11 */   public Setting<Boolean> gapple = register(new Setting("Gapple", Boolean.valueOf(true)));
/*    */   
/*    */   public NoHitBox() {
/* 14 */     super("NoHitBox", "NoHitBox.", Module.Category.RENDER, false, false, false);
/* 15 */     setInstance();
/*    */   }
/*    */   
/*    */   public static NoHitBox getINSTANCE() {
/* 19 */     if (INSTANCE == null) {
/* 20 */       INSTANCE = new NoHitBox();
/*    */     }
/* 22 */     return INSTANCE;
/*    */   }
/*    */   
/*    */   private void setInstance() {
/* 26 */     INSTANCE = this;
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/render/NoHitBox.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */