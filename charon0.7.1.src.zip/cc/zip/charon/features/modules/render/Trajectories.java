/*     */ package cc.zip.charon.features.modules.render;
/*     */ 
/*     */ import cc.zip.charon.event.events.Render3DEvent;
/*     */ import cc.zip.charon.features.modules.Module;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.RayTraceResult;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import org.lwjgl.util.glu.Cylinder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Trajectories
/*     */   extends Module
/*     */ {
/*     */   public Trajectories() {
/*  26 */     super("Trajectories", "Draws trajectories.", Module.Category.RENDER, false, false, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onRender3D(Render3DEvent event) {
/*  31 */     if (mc.field_71441_e != null && mc.field_71439_g != null && mc.func_175598_ae() != null) {
/*  32 */       double renderPosX = mc.field_71439_g.field_70142_S + (mc.field_71439_g.field_70165_t - mc.field_71439_g.field_70142_S) * event.getPartialTicks();
/*  33 */       double renderPosY = mc.field_71439_g.field_70137_T + (mc.field_71439_g.field_70163_u - mc.field_71439_g.field_70137_T) * event.getPartialTicks();
/*  34 */       double renderPosZ = mc.field_71439_g.field_70136_U + (mc.field_71439_g.field_70161_v - mc.field_71439_g.field_70136_U) * event.getPartialTicks();
/*  35 */       mc.field_71439_g.func_184586_b(EnumHand.MAIN_HAND);
/*  36 */       if (mc.field_71474_y.field_74320_O == 0 && (mc.field_71439_g.func_184586_b(EnumHand.MAIN_HAND).func_77973_b() instanceof net.minecraft.item.ItemBow || mc.field_71439_g.func_184586_b(EnumHand.MAIN_HAND).func_77973_b() instanceof net.minecraft.item.ItemFishingRod || mc.field_71439_g.func_184586_b(EnumHand.MAIN_HAND).func_77973_b() instanceof net.minecraft.item.ItemEnderPearl || mc.field_71439_g.func_184586_b(EnumHand.MAIN_HAND).func_77973_b() instanceof net.minecraft.item.ItemEgg || mc.field_71439_g.func_184586_b(EnumHand.MAIN_HAND).func_77973_b() instanceof net.minecraft.item.ItemSnowball || mc.field_71439_g.func_184586_b(EnumHand.MAIN_HAND).func_77973_b() instanceof net.minecraft.item.ItemExpBottle)) {
/*  37 */         GL11.glPushMatrix();
/*  38 */         Item item = mc.field_71439_g.func_184586_b(EnumHand.MAIN_HAND).func_77973_b();
/*  39 */         double posX = renderPosX - (MathHelper.func_76134_b(mc.field_71439_g.field_70177_z / 180.0F * 3.1415927F) * 0.16F);
/*  40 */         double posY = renderPosY + mc.field_71439_g.func_70047_e() - 0.1000000014901161D;
/*  41 */         double posZ = renderPosZ - (MathHelper.func_76126_a(mc.field_71439_g.field_70177_z / 180.0F * 3.1415927F) * 0.16F);
/*  42 */         double motionX = (-MathHelper.func_76126_a(mc.field_71439_g.field_70177_z / 180.0F * 3.1415927F) * MathHelper.func_76134_b(mc.field_71439_g.field_70125_A / 180.0F * 3.1415927F)) * ((item instanceof net.minecraft.item.ItemBow) ? 1.0D : 0.4D);
/*  43 */         double motionY = -MathHelper.func_76126_a(mc.field_71439_g.field_70125_A / 180.0F * 3.1415927F) * ((item instanceof net.minecraft.item.ItemBow) ? 1.0D : 0.4D);
/*  44 */         double motionZ = (MathHelper.func_76134_b(mc.field_71439_g.field_70177_z / 180.0F * 3.1415927F) * MathHelper.func_76134_b(mc.field_71439_g.field_70125_A / 180.0F * 3.1415927F)) * ((item instanceof net.minecraft.item.ItemBow) ? 1.0D : 0.4D);
/*  45 */         int var6 = 72000 - mc.field_71439_g.func_184605_cv();
/*  46 */         float power = var6 / 20.0F;
/*  47 */         power = (power * power + power * 2.0F) / 3.0F;
/*  48 */         if (power > 1.0F) {
/*  49 */           power = 1.0F;
/*     */         }
/*  51 */         float distance = MathHelper.func_76133_a(motionX * motionX + motionY * motionY + motionZ * motionZ);
/*  52 */         motionX /= distance;
/*  53 */         motionY /= distance;
/*  54 */         motionZ /= distance;
/*  55 */         float pow = (item instanceof net.minecraft.item.ItemBow) ? (power * 2.0F) : ((item instanceof net.minecraft.item.ItemFishingRod) ? 1.25F : ((mc.field_71439_g.func_184586_b(EnumHand.MAIN_HAND).func_77973_b() == Items.field_151062_by) ? 0.9F : 1.0F));
/*  56 */         motionX *= (pow * ((item instanceof net.minecraft.item.ItemFishingRod) ? 0.75F : ((mc.field_71439_g.func_184586_b(EnumHand.MAIN_HAND).func_77973_b() == Items.field_151062_by) ? 0.75F : 1.5F)));
/*  57 */         motionY *= (pow * ((item instanceof net.minecraft.item.ItemFishingRod) ? 0.75F : ((mc.field_71439_g.func_184586_b(EnumHand.MAIN_HAND).func_77973_b() == Items.field_151062_by) ? 0.75F : 1.5F)));
/*  58 */         motionZ *= (pow * ((item instanceof net.minecraft.item.ItemFishingRod) ? 0.75F : ((mc.field_71439_g.func_184586_b(EnumHand.MAIN_HAND).func_77973_b() == Items.field_151062_by) ? 0.75F : 1.5F)));
/*  59 */         enableGL3D(2.0F);
/*  60 */         GlStateManager.func_179131_c(0.0F, 1.0F, 0.0F, 1.0F);
/*  61 */         GL11.glEnable(2848);
/*  62 */         float size = (float)((item instanceof net.minecraft.item.ItemBow) ? 0.3D : 0.25D);
/*  63 */         boolean hasLanded = false;
/*  64 */         Entity landingOnEntity = null;
/*  65 */         RayTraceResult landingPosition = null;
/*  66 */         while (!hasLanded && posY > 0.0D) {
/*  67 */           Vec3d present = new Vec3d(posX, posY, posZ);
/*  68 */           Vec3d future = new Vec3d(posX + motionX, posY + motionY, posZ + motionZ);
/*  69 */           RayTraceResult possibleLandingStrip = mc.field_71441_e.func_147447_a(present, future, false, true, false);
/*  70 */           if (possibleLandingStrip != null && possibleLandingStrip.field_72313_a != RayTraceResult.Type.MISS) {
/*  71 */             landingPosition = possibleLandingStrip;
/*  72 */             hasLanded = true;
/*     */           } 
/*  74 */           AxisAlignedBB arrowBox = new AxisAlignedBB(posX - size, posY - size, posZ - size, posX + size, posY + size, posZ + size);
/*  75 */           List entities = getEntitiesWithinAABB(arrowBox.func_72317_d(motionX, motionY, motionZ).func_72321_a(1.0D, 1.0D, 1.0D));
/*  76 */           for (Object entity : entities) {
/*  77 */             Entity boundingBox = (Entity)entity;
/*  78 */             if (boundingBox.func_70067_L() && boundingBox != mc.field_71439_g) {
/*  79 */               float var8 = 0.3F;
/*  80 */               AxisAlignedBB var9 = boundingBox.func_174813_aQ().func_72321_a(0.30000001192092896D, 0.30000001192092896D, 0.30000001192092896D);
/*  81 */               RayTraceResult possibleEntityLanding = var9.func_72327_a(present, future);
/*  82 */               if (possibleEntityLanding == null) {
/*     */                 continue;
/*     */               }
/*  85 */               hasLanded = true;
/*  86 */               landingOnEntity = boundingBox;
/*  87 */               landingPosition = possibleEntityLanding;
/*     */             } 
/*     */           } 
/*  90 */           if (landingOnEntity != null) {
/*  91 */             GlStateManager.func_179131_c(1.0F, 0.0F, 0.0F, 1.0F);
/*     */           }
/*  93 */           posX += motionX;
/*  94 */           posY += motionY;
/*  95 */           posZ += motionZ;
/*  96 */           float motionAdjustment = 0.99F;
/*  97 */           motionX *= 0.9900000095367432D;
/*  98 */           motionY *= 0.9900000095367432D;
/*  99 */           motionZ *= 0.9900000095367432D;
/* 100 */           motionY -= (item instanceof net.minecraft.item.ItemBow) ? 0.05D : 0.03D;
/* 101 */           drawLine3D(posX - renderPosX, posY - renderPosY, posZ - renderPosZ);
/*     */         } 
/* 103 */         if (landingPosition != null && landingPosition.field_72313_a == RayTraceResult.Type.BLOCK) {
/* 104 */           GlStateManager.func_179137_b(posX - renderPosX, posY - renderPosY, posZ - renderPosZ);
/* 105 */           int side = landingPosition.field_178784_b.func_176745_a();
/* 106 */           if (side == 2) {
/* 107 */             GlStateManager.func_179114_b(90.0F, 1.0F, 0.0F, 0.0F);
/* 108 */           } else if (side == 3) {
/* 109 */             GlStateManager.func_179114_b(90.0F, 1.0F, 0.0F, 0.0F);
/* 110 */           } else if (side == 4) {
/* 111 */             GlStateManager.func_179114_b(90.0F, 0.0F, 0.0F, 1.0F);
/* 112 */           } else if (side == 5) {
/* 113 */             GlStateManager.func_179114_b(90.0F, 0.0F, 0.0F, 1.0F);
/*     */           } 
/* 115 */           Cylinder c = new Cylinder();
/* 116 */           GlStateManager.func_179114_b(-90.0F, 1.0F, 0.0F, 0.0F);
/* 117 */           c.setDrawStyle(100011);
/* 118 */           if (landingOnEntity != null) {
/* 119 */             GlStateManager.func_179131_c(0.0F, 0.0F, 0.0F, 1.0F);
/* 120 */             GL11.glLineWidth(2.5F);
/* 121 */             c.draw(0.6F, 0.3F, 0.0F, 4, 1);
/* 122 */             GL11.glLineWidth(0.1F);
/* 123 */             GlStateManager.func_179131_c(1.0F, 0.0F, 0.0F, 1.0F);
/*     */           } 
/* 125 */           c.draw(0.6F, 0.3F, 0.0F, 4, 1);
/*     */         } 
/* 127 */         disableGL3D();
/* 128 */         GL11.glPopMatrix();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void enableGL3D(float lineWidth) {
/* 134 */     GL11.glDisable(3008);
/* 135 */     GL11.glEnable(3042);
/* 136 */     GL11.glBlendFunc(770, 771);
/* 137 */     GL11.glDisable(3553);
/* 138 */     GL11.glDisable(2929);
/* 139 */     GL11.glDepthMask(false);
/* 140 */     GL11.glEnable(2884);
/* 141 */     mc.field_71460_t.func_175072_h();
/* 142 */     GL11.glEnable(2848);
/* 143 */     GL11.glHint(3154, 4354);
/* 144 */     GL11.glHint(3155, 4354);
/* 145 */     GL11.glLineWidth(lineWidth);
/*     */   }
/*     */   
/*     */   public void disableGL3D() {
/* 149 */     GL11.glEnable(3553);
/* 150 */     GL11.glEnable(2929);
/* 151 */     GL11.glDisable(3042);
/* 152 */     GL11.glEnable(3008);
/* 153 */     GL11.glDepthMask(true);
/* 154 */     GL11.glCullFace(1029);
/* 155 */     GL11.glDisable(2848);
/* 156 */     GL11.glHint(3154, 4352);
/* 157 */     GL11.glHint(3155, 4352);
/*     */   }
/*     */   
/*     */   public void drawLine3D(double var1, double var2, double var3) {
/* 161 */     GL11.glVertex3d(var1, var2, var3);
/*     */   }
/*     */   
/*     */   private List getEntitiesWithinAABB(AxisAlignedBB bb) {
/* 165 */     ArrayList list = new ArrayList();
/* 166 */     int chunkMinX = MathHelper.func_76128_c((bb.field_72340_a - 2.0D) / 16.0D);
/* 167 */     int chunkMaxX = MathHelper.func_76128_c((bb.field_72336_d + 2.0D) / 16.0D);
/* 168 */     int chunkMinZ = MathHelper.func_76128_c((bb.field_72339_c - 2.0D) / 16.0D);
/* 169 */     int chunkMaxZ = MathHelper.func_76128_c((bb.field_72334_f + 2.0D) / 16.0D);
/* 170 */     for (int x = chunkMinX; x <= chunkMaxX; x++) {
/* 171 */       for (int z = chunkMinZ; z <= chunkMaxZ; z++) {
/* 172 */         if (mc.field_71441_e.func_72863_F().func_186026_b(x, z) != null) {
/* 173 */           mc.field_71441_e.func_72964_e(x, z).func_177414_a((Entity)mc.field_71439_g, bb, list, null);
/*     */         }
/*     */       } 
/*     */     } 
/* 177 */     return list;
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/render/Trajectories.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */