/*     */ package cc.zip.charon.features.modules.render;
/*     */ 
/*     */ import cc.zip.charon.event.events.Render3DEvent;
/*     */ import cc.zip.charon.features.modules.Module;
/*     */ import cc.zip.charon.features.setting.Setting;
/*     */ import cc.zip.charon.util.EntityUtil;
/*     */ import cc.zip.charon.util.RenderUtil;
/*     */ import java.awt.Color;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.RenderGlobal;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ESP
/*     */   extends Module
/*     */ {
/*  23 */   private static ESP INSTANCE = new ESP();
/*  24 */   private final Setting<Boolean> items = register(new Setting("Items", Boolean.valueOf(false)));
/*  25 */   private final Setting<Boolean> xporbs = register(new Setting("XpOrbs", Boolean.valueOf(false)));
/*  26 */   private final Setting<Boolean> xpbottles = register(new Setting("XpBottles", Boolean.valueOf(false)));
/*  27 */   private final Setting<Boolean> pearl = register(new Setting("Pearls", Boolean.valueOf(false)));
/*  28 */   private final Setting<Integer> red = register(new Setting("Red", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255)));
/*  29 */   private final Setting<Integer> green = register(new Setting("Green", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255)));
/*  30 */   private final Setting<Integer> blue = register(new Setting("Blue", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255)));
/*  31 */   private final Setting<Integer> boxAlpha = register(new Setting("BoxAlpha", Integer.valueOf(120), Integer.valueOf(0), Integer.valueOf(255)));
/*  32 */   private final Setting<Integer> alpha = register(new Setting("Alpha", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255)));
/*     */   
/*     */   public ESP() {
/*  35 */     super("ESP", "Renders a nice ESP.", Module.Category.RENDER, false, false, false);
/*  36 */     setInstance();
/*     */   }
/*     */   
/*     */   public static ESP getInstance() {
/*  40 */     if (INSTANCE == null) {
/*  41 */       INSTANCE = new ESP();
/*     */     }
/*  43 */     return INSTANCE;
/*     */   }
/*     */   
/*     */   private void setInstance() {
/*  47 */     INSTANCE = this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onRender3D(Render3DEvent event) {
/*  55 */     if (((Boolean)this.items.getValue()).booleanValue()) {
/*  56 */       int i = 0;
/*  57 */       for (Entity entity : mc.field_71441_e.field_72996_f) {
/*  58 */         if (!(entity instanceof net.minecraft.entity.item.EntityItem) || mc.field_71439_g.func_70068_e(entity) >= 2500.0D)
/*  59 */           continue;  Vec3d interp = EntityUtil.getInterpolatedRenderPos(entity, mc.func_184121_ak());
/*  60 */         AxisAlignedBB bb = new AxisAlignedBB((entity.func_174813_aQ()).field_72340_a - 0.05D - entity.field_70165_t + interp.field_72450_a, (entity.func_174813_aQ()).field_72338_b - 0.0D - entity.field_70163_u + interp.field_72448_b, (entity.func_174813_aQ()).field_72339_c - 0.05D - entity.field_70161_v + interp.field_72449_c, (entity.func_174813_aQ()).field_72336_d + 0.05D - entity.field_70165_t + interp.field_72450_a, (entity.func_174813_aQ()).field_72337_e + 0.1D - entity.field_70163_u + interp.field_72448_b, (entity.func_174813_aQ()).field_72334_f + 0.05D - entity.field_70161_v + interp.field_72449_c);
/*  61 */         GlStateManager.func_179094_E();
/*  62 */         GlStateManager.func_179147_l();
/*  63 */         GlStateManager.func_179097_i();
/*  64 */         GlStateManager.func_179120_a(770, 771, 0, 1);
/*  65 */         GlStateManager.func_179090_x();
/*  66 */         GlStateManager.func_179132_a(false);
/*  67 */         GL11.glEnable(2848);
/*  68 */         GL11.glHint(3154, 4354);
/*  69 */         GL11.glLineWidth(1.0F);
/*  70 */         RenderGlobal.func_189696_b(bb, ((Integer)this.red.getValue()).intValue() / 255.0F, ((Integer)this.green.getValue()).intValue() / 255.0F, ((Integer)this.blue.getValue()).intValue() / 255.0F, ((Integer)this.boxAlpha.getValue()).intValue() / 255.0F);
/*  71 */         GL11.glDisable(2848);
/*  72 */         GlStateManager.func_179132_a(true);
/*  73 */         GlStateManager.func_179126_j();
/*  74 */         GlStateManager.func_179098_w();
/*  75 */         GlStateManager.func_179084_k();
/*  76 */         GlStateManager.func_179121_F();
/*  77 */         RenderUtil.drawBlockOutline(bb, new Color(((Integer)this.red.getValue()).intValue(), ((Integer)this.green.getValue()).intValue(), ((Integer)this.blue.getValue()).intValue(), ((Integer)this.alpha.getValue()).intValue()), 1.0F);
/*  78 */         if (++i < 50);
/*     */       } 
/*     */     } 
/*     */     
/*  82 */     if (((Boolean)this.xporbs.getValue()).booleanValue()) {
/*  83 */       int i = 0;
/*  84 */       for (Entity entity : mc.field_71441_e.field_72996_f) {
/*  85 */         if (!(entity instanceof net.minecraft.entity.item.EntityXPOrb) || mc.field_71439_g.func_70068_e(entity) >= 2500.0D)
/*  86 */           continue;  Vec3d interp = EntityUtil.getInterpolatedRenderPos(entity, mc.func_184121_ak());
/*  87 */         AxisAlignedBB bb = new AxisAlignedBB((entity.func_174813_aQ()).field_72340_a - 0.05D - entity.field_70165_t + interp.field_72450_a, (entity.func_174813_aQ()).field_72338_b - 0.0D - entity.field_70163_u + interp.field_72448_b, (entity.func_174813_aQ()).field_72339_c - 0.05D - entity.field_70161_v + interp.field_72449_c, (entity.func_174813_aQ()).field_72336_d + 0.05D - entity.field_70165_t + interp.field_72450_a, (entity.func_174813_aQ()).field_72337_e + 0.1D - entity.field_70163_u + interp.field_72448_b, (entity.func_174813_aQ()).field_72334_f + 0.05D - entity.field_70161_v + interp.field_72449_c);
/*  88 */         GlStateManager.func_179094_E();
/*  89 */         GlStateManager.func_179147_l();
/*  90 */         GlStateManager.func_179097_i();
/*  91 */         GlStateManager.func_179120_a(770, 771, 0, 1);
/*  92 */         GlStateManager.func_179090_x();
/*  93 */         GlStateManager.func_179132_a(false);
/*  94 */         GL11.glEnable(2848);
/*  95 */         GL11.glHint(3154, 4354);
/*  96 */         GL11.glLineWidth(1.0F);
/*  97 */         RenderGlobal.func_189696_b(bb, ((Integer)this.red.getValue()).intValue() / 255.0F, ((Integer)this.green.getValue()).intValue() / 255.0F, ((Integer)this.blue.getValue()).intValue() / 255.0F, ((Integer)this.boxAlpha.getValue()).intValue() / 255.0F);
/*  98 */         GL11.glDisable(2848);
/*  99 */         GlStateManager.func_179132_a(true);
/* 100 */         GlStateManager.func_179126_j();
/* 101 */         GlStateManager.func_179098_w();
/* 102 */         GlStateManager.func_179084_k();
/* 103 */         GlStateManager.func_179121_F();
/* 104 */         RenderUtil.drawBlockOutline(bb, new Color(((Integer)this.red.getValue()).intValue(), ((Integer)this.green.getValue()).intValue(), ((Integer)this.blue.getValue()).intValue(), ((Integer)this.alpha.getValue()).intValue()), 1.0F);
/* 105 */         if (++i < 50);
/*     */       } 
/*     */     } 
/*     */     
/* 109 */     if (((Boolean)this.pearl.getValue()).booleanValue()) {
/* 110 */       int i = 0;
/* 111 */       for (Entity entity : mc.field_71441_e.field_72996_f) {
/* 112 */         if (!(entity instanceof net.minecraft.entity.item.EntityEnderPearl) || mc.field_71439_g.func_70068_e(entity) >= 2500.0D)
/* 113 */           continue;  Vec3d interp = EntityUtil.getInterpolatedRenderPos(entity, mc.func_184121_ak());
/* 114 */         AxisAlignedBB bb = new AxisAlignedBB((entity.func_174813_aQ()).field_72340_a - 0.05D - entity.field_70165_t + interp.field_72450_a, (entity.func_174813_aQ()).field_72338_b - 0.0D - entity.field_70163_u + interp.field_72448_b, (entity.func_174813_aQ()).field_72339_c - 0.05D - entity.field_70161_v + interp.field_72449_c, (entity.func_174813_aQ()).field_72336_d + 0.05D - entity.field_70165_t + interp.field_72450_a, (entity.func_174813_aQ()).field_72337_e + 0.1D - entity.field_70163_u + interp.field_72448_b, (entity.func_174813_aQ()).field_72334_f + 0.05D - entity.field_70161_v + interp.field_72449_c);
/* 115 */         GlStateManager.func_179094_E();
/* 116 */         GlStateManager.func_179147_l();
/* 117 */         GlStateManager.func_179097_i();
/* 118 */         GlStateManager.func_179120_a(770, 771, 0, 1);
/* 119 */         GlStateManager.func_179090_x();
/* 120 */         GlStateManager.func_179132_a(false);
/* 121 */         GL11.glEnable(2848);
/* 122 */         GL11.glHint(3154, 4354);
/* 123 */         GL11.glLineWidth(1.0F);
/* 124 */         RenderGlobal.func_189696_b(bb, ((Integer)this.red.getValue()).intValue() / 255.0F, ((Integer)this.green.getValue()).intValue() / 255.0F, ((Integer)this.blue.getValue()).intValue() / 255.0F, ((Integer)this.boxAlpha.getValue()).intValue() / 255.0F);
/* 125 */         GL11.glDisable(2848);
/* 126 */         GlStateManager.func_179132_a(true);
/* 127 */         GlStateManager.func_179126_j();
/* 128 */         GlStateManager.func_179098_w();
/* 129 */         GlStateManager.func_179084_k();
/* 130 */         GlStateManager.func_179121_F();
/* 131 */         RenderUtil.drawBlockOutline(bb, new Color(((Integer)this.red.getValue()).intValue(), ((Integer)this.green.getValue()).intValue(), ((Integer)this.blue.getValue()).intValue(), ((Integer)this.alpha.getValue()).intValue()), 1.0F);
/* 132 */         if (++i < 50);
/*     */       } 
/*     */     } 
/*     */     
/* 136 */     if (((Boolean)this.xpbottles.getValue()).booleanValue()) {
/* 137 */       int i = 0;
/* 138 */       for (Entity entity : mc.field_71441_e.field_72996_f) {
/* 139 */         if (!(entity instanceof net.minecraft.entity.item.EntityExpBottle) || mc.field_71439_g.func_70068_e(entity) >= 2500.0D)
/* 140 */           continue;  Vec3d interp = EntityUtil.getInterpolatedRenderPos(entity, mc.func_184121_ak());
/* 141 */         AxisAlignedBB bb = new AxisAlignedBB((entity.func_174813_aQ()).field_72340_a - 0.05D - entity.field_70165_t + interp.field_72450_a, (entity.func_174813_aQ()).field_72338_b - 0.0D - entity.field_70163_u + interp.field_72448_b, (entity.func_174813_aQ()).field_72339_c - 0.05D - entity.field_70161_v + interp.field_72449_c, (entity.func_174813_aQ()).field_72336_d + 0.05D - entity.field_70165_t + interp.field_72450_a, (entity.func_174813_aQ()).field_72337_e + 0.1D - entity.field_70163_u + interp.field_72448_b, (entity.func_174813_aQ()).field_72334_f + 0.05D - entity.field_70161_v + interp.field_72449_c);
/* 142 */         GlStateManager.func_179094_E();
/* 143 */         GlStateManager.func_179147_l();
/* 144 */         GlStateManager.func_179097_i();
/* 145 */         GlStateManager.func_179120_a(770, 771, 0, 1);
/* 146 */         GlStateManager.func_179090_x();
/* 147 */         GlStateManager.func_179132_a(false);
/* 148 */         GL11.glEnable(2848);
/* 149 */         GL11.glHint(3154, 4354);
/* 150 */         GL11.glLineWidth(1.0F);
/* 151 */         RenderGlobal.func_189696_b(bb, ((Integer)this.red.getValue()).intValue() / 255.0F, ((Integer)this.green.getValue()).intValue() / 255.0F, ((Integer)this.blue.getValue()).intValue() / 255.0F, ((Integer)this.boxAlpha.getValue()).intValue() / 255.0F);
/* 152 */         GL11.glDisable(2848);
/* 153 */         GlStateManager.func_179132_a(true);
/* 154 */         GlStateManager.func_179126_j();
/* 155 */         GlStateManager.func_179098_w();
/* 156 */         GlStateManager.func_179084_k();
/* 157 */         GlStateManager.func_179121_F();
/* 158 */         RenderUtil.drawBlockOutline(bb, new Color(((Integer)this.red.getValue()).intValue(), ((Integer)this.green.getValue()).intValue(), ((Integer)this.blue.getValue()).intValue(), ((Integer)this.alpha.getValue()).intValue()), 1.0F);
/* 159 */         if (++i < 50);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/render/ESP.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */