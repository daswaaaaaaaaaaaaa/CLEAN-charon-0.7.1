/*    */ package cc.zip.charon.features.modules.render;
/*    */ 
/*    */ import cc.zip.charon.features.modules.Module;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ViewCustom
/*    */   extends Module
/*    */ {
/*    */   public ViewCustom() {
/* 11 */     super("ViewCustom", "Custommss", Module.Category.RENDER, true, false, false);
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/render/ViewCustom.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */