/*     */ package cc.zip.charon.features.modules.render;
/*     */ 
/*     */ import cc.zip.charon.event.events.Render2DEvent;
/*     */ import cc.zip.charon.features.modules.Module;
/*     */ import cc.zip.charon.features.setting.Setting;
/*     */ import cc.zip.charon.util.EntityUtil;
/*     */ import cc.zip.charon.util.RenderUtil;
/*     */ import cc.zip.charon.util.Util;
/*     */ import com.google.common.collect.Maps;
/*     */ import java.awt.Color;
/*     */ import java.util.Map;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import org.lwjgl.opengl.Display;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class ArrowESP
/*     */   extends Module
/*     */ {
/*  23 */   private final Setting<Integer> red = register(new Setting("Red", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255)));
/*  24 */   private final Setting<Integer> green = register(new Setting("Green", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255)));
/*  25 */   private final Setting<Integer> blue = register(new Setting("Blue", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255)));
/*  26 */   private final Setting<Integer> radius = register(new Setting("Placement", Integer.valueOf(45), Integer.valueOf(10), Integer.valueOf(200)));
/*  27 */   private final Setting<Float> size = register(new Setting("Size", Float.valueOf(10.0F), Float.valueOf(5.0F), Float.valueOf(25.0F)));
/*  28 */   private final Setting<Boolean> outline = register(new Setting("Outline", Boolean.valueOf(true)));
/*  29 */   private final Setting<Float> outlineWidth = register(new Setting("Outline-Width", Float.valueOf(1.0F), Float.valueOf(0.1F), Float.valueOf(3.0F)));
/*  30 */   private final Setting<Integer> fadeDistance = register(new Setting("Range", Integer.valueOf(100), Integer.valueOf(10), Integer.valueOf(200)));
/*  31 */   private final Setting<Boolean> invisibles = register(new Setting("Invisibles", Boolean.valueOf(false)));
/*  32 */   private final EntityListener entityListener = new EntityListener();
/*     */   
/*     */   public ArrowESP() {
/*  35 */     super("ArrowESP", "Arrow tracers ", Module.Category.RENDER, true, false, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onRender2D(Render2DEvent event) {
/*  40 */     this.entityListener.render();
/*  41 */     mc.field_71441_e.field_72996_f.forEach(o -> {
/*     */           if (o instanceof EntityPlayer && isValid((EntityPlayer)o)) {
/*     */             EntityPlayer entity = (EntityPlayer)o;
/*     */             Vec3d pos = this.entityListener.getEntityLowerBounds().get(entity);
/*     */             if (pos != null && !isOnScreen(pos) && !RenderUtil.isInViewFrustrum((Entity)entity)) {
/*     */               Color color = EntityUtil.getColor((Entity)entity, ((Integer)this.red.getValue()).intValue(), ((Integer)this.green.getValue()).intValue(), ((Integer)this.blue.getValue()).intValue(), (int)MathHelper.func_76131_a(255.0F - 255.0F / ((Integer)this.fadeDistance.getValue()).intValue() * mc.field_71439_g.func_70032_d((Entity)entity), 100.0F, 255.0F), true);
/*     */               int x = Display.getWidth() / 2 / ((mc.field_71474_y.field_74335_Z == 0) ? 1 : mc.field_71474_y.field_74335_Z);
/*     */               int y = Display.getHeight() / 2 / ((mc.field_71474_y.field_74335_Z == 0) ? 1 : mc.field_71474_y.field_74335_Z);
/*     */               float yaw = getRotations((EntityLivingBase)entity) - mc.field_71439_g.field_70177_z;
/*     */               GL11.glTranslatef(x, y, 0.0F);
/*     */               GL11.glRotatef(yaw, 0.0F, 0.0F, 1.0F);
/*     */               GL11.glTranslatef(-x, -y, 0.0F);
/*     */               RenderUtil.drawTracerPointer(x, (y - ((Integer)this.radius.getValue()).intValue()), ((Float)this.size.getValue()).floatValue(), 2.0F, 1.0F, ((Boolean)this.outline.getValue()).booleanValue(), ((Float)this.outlineWidth.getValue()).floatValue(), color.getRGB());
/*     */               GL11.glTranslatef(x, y, 0.0F);
/*     */               GL11.glRotatef(-yaw, 0.0F, 0.0F, 1.0F);
/*     */               GL11.glTranslatef(-x, -y, 0.0F);
/*     */             } 
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isOnScreen(Vec3d pos) {
/*  64 */     if (pos.field_72450_a <= -1.0D) return false; 
/*  65 */     if (pos.field_72448_b >= 1.0D) return false; 
/*  66 */     if (pos.field_72450_a <= -1.0D) return false; 
/*  67 */     if (pos.field_72449_c >= 1.0D) return false; 
/*  68 */     int n = (mc.field_71474_y.field_74335_Z == 0) ? 1 : mc.field_71474_y.field_74335_Z;
/*  69 */     if (pos.field_72450_a / n < 0.0D) return false; 
/*  70 */     int n2 = (mc.field_71474_y.field_74335_Z == 0) ? 1 : mc.field_71474_y.field_74335_Z;
/*  71 */     if (pos.field_72450_a / n2 > Display.getWidth()) return false; 
/*  72 */     int n3 = (mc.field_71474_y.field_74335_Z == 0) ? 1 : mc.field_71474_y.field_74335_Z;
/*  73 */     if (pos.field_72448_b / n3 < 0.0D) return false; 
/*  74 */     int n4 = (mc.field_71474_y.field_74335_Z == 0) ? 1 : mc.field_71474_y.field_74335_Z;
/*  75 */     return (pos.field_72448_b / n4 <= Display.getHeight());
/*     */   }
/*     */   
/*     */   private boolean isValid(EntityPlayer entity) {
/*  79 */     return (entity != mc.field_71439_g && (!entity.func_82150_aj() || ((Boolean)this.invisibles.getValue()).booleanValue()) && entity.func_70089_S());
/*     */   }
/*     */   
/*     */   private float getRotations(EntityLivingBase ent) {
/*  83 */     double x = ent.field_70165_t - mc.field_71439_g.field_70165_t;
/*  84 */     double z = ent.field_70161_v - mc.field_71439_g.field_70161_v;
/*  85 */     return (float)-(Math.atan2(x, z) * 57.29577951308232D);
/*     */   }
/*     */   
/*     */   private static class EntityListener {
/*  89 */     private final Map<Entity, Vec3d> entityUpperBounds = Maps.newHashMap();
/*  90 */     private final Map<Entity, Vec3d> entityLowerBounds = Maps.newHashMap();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void render() {
/*  96 */       if (!this.entityUpperBounds.isEmpty()) {
/*  97 */         this.entityUpperBounds.clear();
/*     */       }
/*  99 */       if (!this.entityLowerBounds.isEmpty()) {
/* 100 */         this.entityLowerBounds.clear();
/*     */       }
/* 102 */       for (Entity e : Util.mc.field_71441_e.field_72996_f) {
/* 103 */         Vec3d bound = getEntityRenderPosition(e);
/* 104 */         bound.func_178787_e(new Vec3d(0.0D, e.field_70131_O + 0.2D, 0.0D));
/* 105 */         Vec3d upperBounds = RenderUtil.to2D(bound.field_72450_a, bound.field_72448_b, bound.field_72449_c);
/* 106 */         Vec3d lowerBounds = RenderUtil.to2D(bound.field_72450_a, bound.field_72448_b - 2.0D, bound.field_72449_c);
/* 107 */         if (upperBounds == null || lowerBounds == null)
/* 108 */           continue;  this.entityUpperBounds.put(e, upperBounds);
/* 109 */         this.entityLowerBounds.put(e, lowerBounds);
/*     */       } 
/*     */     }
/*     */     
/*     */     private Vec3d getEntityRenderPosition(Entity entity) {
/* 114 */       double partial = Util.mc.field_71428_T.field_194147_b;
/* 115 */       double x = entity.field_70142_S + (entity.field_70165_t - entity.field_70142_S) * partial - (Util.mc.func_175598_ae()).field_78730_l;
/* 116 */       double y = entity.field_70137_T + (entity.field_70163_u - entity.field_70137_T) * partial - (Util.mc.func_175598_ae()).field_78731_m;
/* 117 */       double z = entity.field_70136_U + (entity.field_70161_v - entity.field_70136_U) * partial - (Util.mc.func_175598_ae()).field_78728_n;
/* 118 */       return new Vec3d(x, y, z);
/*     */     }
/*     */     
/*     */     public Map<Entity, Vec3d> getEntityLowerBounds() {
/* 122 */       return this.entityLowerBounds;
/*     */     }
/*     */     
/*     */     private EntityListener() {}
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/render/ArrowESP.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */