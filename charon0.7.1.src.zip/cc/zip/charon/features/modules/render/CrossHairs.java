/*    */ package cc.zip.charon.features.modules.render;
/*    */ import cc.zip.charon.features.modules.Module;
/*    */ import cc.zip.charon.features.setting.Setting;
/*    */ import cc.zip.charon.util.RenderUtil;
/*    */ import cc.zip.charon.util.Timer;
/*    */ import net.minecraftforge.client.event.RenderGameOverlayEvent;
/*    */ 
/*    */ public class CrossHairs extends Module {
/*    */   private final Setting<Boolean> custom;
/*    */   public Setting<Modes> modes;
/*    */   public Setting<Float> thickness;
/*    */   
/*    */   public CrossHairs() {
/* 14 */     super("CrossHairs", "fff.", Module.Category.RENDER, true, false, false);
/*    */     
/* 16 */     this.custom = register(new Setting("Custom", Boolean.valueOf(true)));
/* 17 */     this.modes = register(new Setting("Swing", Modes.Dynamic));
/* 18 */     this.thickness = register(new Setting("thickness", Float.valueOf(2.0F), Float.valueOf(0.0F), Float.valueOf(5.0F)));
/* 19 */     this.separation = register(new Setting("separation", Float.valueOf(2.0F), Float.valueOf(0.0F), Float.valueOf(10.0F)));
/* 20 */     this.width = register(new Setting("width", Float.valueOf(4.0F), Float.valueOf(0.0F), Float.valueOf(10.0F)));
/* 21 */     this.bend = register(new Setting("bend", Float.valueOf(2.0F), Float.valueOf(0.0F), Float.valueOf(5.0F)));
/*    */ 
/*    */     
/* 24 */     this.hitTimer = new Timer();
/*    */   } public Setting<Float> separation; public Setting<Float> width; public Setting<Float> bend; Timer hitTimer; public enum Modes {
/*    */     Dynamic, Static; }
/*    */   @SubscribeEvent
/*    */   public void onRenderGameOverlay(RenderGameOverlayEvent event) {
/* 29 */     if (((Boolean)this.custom.getValue()).booleanValue() && event.getType() == RenderGameOverlayEvent.ElementType.CROSSHAIRS) {
/* 30 */       event.setCanceled(true);
/*    */     }
/* 32 */     RenderUtil.drawCrosshairs(((Float)this.separation.getValue()).floatValue(), ((Float)this.bend.getValue()).floatValue(), ((Float)this.width.getValue()).floatValue(), ((Float)this.thickness.getValue()).floatValue(), (this.modes.getValue() == Modes.Static), 155);
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/render/CrossHairs.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */