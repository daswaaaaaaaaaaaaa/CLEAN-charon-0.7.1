/*    */ package cc.zip.charon.features.modules.render;
/*    */ 
/*    */ import cc.zip.charon.event.events.Render3DEvent;
/*    */ import cc.zip.charon.features.modules.Module;
/*    */ import cc.zip.charon.features.modules.client.ClickGui;
/*    */ import cc.zip.charon.features.setting.Setting;
/*    */ import cc.zip.charon.util.ColorUtil;
/*    */ import cc.zip.charon.util.RenderUtil;
/*    */ import java.awt.Color;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.util.math.RayTraceResult;
/*    */ 
/*    */ public class BlockHighlight
/*    */   extends Module
/*    */ {
/* 16 */   private final Setting<Float> lineWidth = register(new Setting("LineWidth", Float.valueOf(1.0F), Float.valueOf(0.1F), Float.valueOf(5.0F)));
/* 17 */   private final Setting<Integer> cAlpha = register(new Setting("Alpha", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255)));
/*    */   
/*    */   public BlockHighlight() {
/* 20 */     super("BlockHighlight", "Highlights the block u look at.", Module.Category.RENDER, false, false, false);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onRender3D(Render3DEvent event) {
/* 25 */     RayTraceResult ray = mc.field_71476_x;
/* 26 */     if (ray != null && ray.field_72313_a == RayTraceResult.Type.BLOCK) {
/* 27 */       BlockPos blockpos = ray.func_178782_a();
/* 28 */       RenderUtil.drawBlockOutline(blockpos, ((Boolean)(ClickGui.getInstance()).rainbow.getValue()).booleanValue() ? ColorUtil.rainbow(((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()) : new Color(((Integer)(ClickGui.getInstance()).red.getValue()).intValue(), ((Integer)(ClickGui.getInstance()).green.getValue()).intValue(), ((Integer)(ClickGui.getInstance()).blue.getValue()).intValue(), ((Integer)this.cAlpha.getValue()).intValue()), ((Float)this.lineWidth.getValue()).floatValue(), false);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/render/BlockHighlight.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */