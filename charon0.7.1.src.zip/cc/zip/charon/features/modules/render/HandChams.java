/*    */ package cc.zip.charon.features.modules.render;
/*    */ 
/*    */ import cc.zip.charon.features.modules.Module;
/*    */ import cc.zip.charon.features.setting.Setting;
/*    */ 
/*    */ public class HandChams
/*    */   extends Module {
/*  8 */   private static HandChams INSTANCE = new HandChams();
/*  9 */   public Setting<RenderMode> mode = register(new Setting("Mode", RenderMode.SOLID));
/* 10 */   public Setting<Integer> red = register(new Setting("Red", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255)));
/* 11 */   public Setting<Integer> green = register(new Setting("Green", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255)));
/* 12 */   public Setting<Integer> blue = register(new Setting("Blue", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255)));
/* 13 */   public Setting<Integer> alpha = register(new Setting("Alpha", Integer.valueOf(240), Integer.valueOf(0), Integer.valueOf(255)));
/*    */   
/*    */   public HandChams() {
/* 16 */     super("HandChams", "Changes your hand color.", Module.Category.RENDER, false, false, false);
/* 17 */     setInstance();
/*    */   }
/*    */   
/*    */   public static HandChams getINSTANCE() {
/* 21 */     if (INSTANCE == null) {
/* 22 */       INSTANCE = new HandChams();
/*    */     }
/* 24 */     return INSTANCE;
/*    */   }
/*    */   
/*    */   private void setInstance() {
/* 28 */     INSTANCE = this;
/*    */   }
/*    */   
/*    */   public enum RenderMode {
/* 32 */     SOLID,
/* 33 */     WIREFRAME;
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/render/HandChams.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */