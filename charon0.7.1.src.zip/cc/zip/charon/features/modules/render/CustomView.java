/*    */ package cc.zip.charon.features.modules.render;
/*    */ 
/*    */ import cc.zip.charon.features.modules.Module;
/*    */ import cc.zip.charon.features.setting.Setting;
/*    */ import net.minecraftforge.client.event.EntityViewRenderEvent;
/*    */ import net.minecraftforge.common.MinecraftForge;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ public class CustomView
/*    */   extends Module {
/*    */   private final Setting<Integer> custom_fov;
/*    */   
/*    */   public CustomView() {
/* 14 */     super("CustomView", "tf", Module.Category.RENDER, true, false, false);
/*    */ 
/*    */     
/* 17 */     this.custom_fov = register(new Setting("custom fov", Integer.valueOf(100), Integer.valueOf(90), Integer.valueOf(169)));
/* 18 */     this.cancelEating = register(new Setting("cancelEating", Boolean.valueOf(true)));
/*    */   }
/*    */   public Setting<Boolean> cancelEating; private float fov;
/*    */   
/*    */   public void onEnable() {
/* 23 */     this.fov = mc.field_71474_y.field_74334_X;
/* 24 */     MinecraftForge.EVENT_BUS.register(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 29 */     mc.field_71474_y.field_74334_X = this.fov;
/* 30 */     MinecraftForge.EVENT_BUS.unregister(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onUpdate() {
/* 35 */     mc.field_71474_y.field_74334_X = ((Integer)this.custom_fov.getValue()).intValue();
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void fov_event(EntityViewRenderEvent.FOVModifier m) {
/* 40 */     m.setFOV(((Integer)this.custom_fov.getValue()).intValue());
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/render/CustomView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */