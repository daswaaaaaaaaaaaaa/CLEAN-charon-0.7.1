/*     */ package cc.zip.charon.features.modules.render;
/*     */ 
/*     */ import cc.zip.charon.Charon;
/*     */ import cc.zip.charon.event.events.Render3DEvent;
/*     */ import cc.zip.charon.features.modules.Module;
/*     */ import cc.zip.charon.features.modules.client.ClickGui;
/*     */ import cc.zip.charon.features.setting.Setting;
/*     */ import cc.zip.charon.util.BlockUtil;
/*     */ import java.util.HashMap;
/*     */ import net.minecraft.client.gui.Gui;
/*     */ import net.minecraft.client.model.ModelPlayer;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class Skeleton
/*     */   extends Module
/*     */ {
/*  21 */   private static final HashMap<EntityPlayer, float[][]> entities = (HashMap)new HashMap<>();
/*  22 */   private final Setting<Float> lineWidth = register(new Setting("LineWidth", Float.valueOf(1.0F), Float.valueOf(0.1F), Float.valueOf(5.0F)));
/*  23 */   private final Setting<Boolean> invisibles = register(new Setting("Invisibles", Boolean.valueOf(false)));
/*  24 */   private final Setting<Integer> alpha = register(new Setting("Alpha", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255)));
/*     */   
/*     */   public Skeleton() {
/*  27 */     super("Skeleton", "Draws a skeleton inside the player.", Module.Category.RENDER, false, false, false);
/*     */   }
/*     */   
/*     */   public static void addEntity(EntityPlayer e, ModelPlayer model) {
/*  31 */     entities.put(e, new float[][] { { model.field_78116_c.field_78795_f, model.field_78116_c.field_78796_g, model.field_78116_c.field_78808_h }, { model.field_178723_h.field_78795_f, model.field_178723_h.field_78796_g, model.field_178723_h.field_78808_h }, { model.field_178724_i.field_78795_f, model.field_178724_i.field_78796_g, model.field_178724_i.field_78808_h }, { model.field_178721_j.field_78795_f, model.field_178721_j.field_78796_g, model.field_178721_j.field_78808_h }, { model.field_178722_k.field_78795_f, model.field_178722_k.field_78796_g, model.field_178722_k.field_78808_h } });
/*     */   }
/*     */   
/*     */   private Vec3d getVec3(Render3DEvent event, EntityPlayer e) {
/*  35 */     float pt = event.getPartialTicks();
/*  36 */     double x = e.field_70142_S + (e.field_70165_t - e.field_70142_S) * pt;
/*  37 */     double y = e.field_70137_T + (e.field_70163_u - e.field_70137_T) * pt;
/*  38 */     double z = e.field_70136_U + (e.field_70161_v - e.field_70136_U) * pt;
/*  39 */     return new Vec3d(x, y, z);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onRender3D(Render3DEvent event) {
/*  44 */     if (fullNullCheck()) {
/*     */       return;
/*     */     }
/*  47 */     startEnd(true);
/*  48 */     GL11.glEnable(2903);
/*  49 */     GL11.glDisable(2848);
/*  50 */     entities.keySet().removeIf(this::doesntContain);
/*  51 */     mc.field_71441_e.field_73010_i.forEach(e -> drawSkeleton(event, e));
/*  52 */     Gui.func_73734_a(0, 0, 0, 0, 0);
/*  53 */     startEnd(false);
/*     */   }
/*     */   
/*     */   private void drawSkeleton(Render3DEvent event, EntityPlayer e) {
/*  57 */     if (!BlockUtil.isPosInFov(new BlockPos(e.field_70165_t, e.field_70163_u, e.field_70161_v)).booleanValue()) {
/*     */       return;
/*     */     }
/*  60 */     if (e.func_82150_aj() && !((Boolean)this.invisibles.getValue()).booleanValue()) {
/*     */       return;
/*     */     }
/*  63 */     float[][] entPos = entities.get(e);
/*  64 */     if (entPos != null && e.func_70089_S() && !e.field_70128_L && e != mc.field_71439_g && !e.func_70608_bn()) {
/*  65 */       GL11.glPushMatrix();
/*  66 */       GL11.glEnable(2848);
/*  67 */       GL11.glLineWidth(((Float)this.lineWidth.getValue()).floatValue());
/*  68 */       if (Charon.friendManager.isFriend(e.func_70005_c_())) {
/*  69 */         GlStateManager.func_179131_c(0.0F, 191.0F, 230.0F, ((Integer)this.alpha.getValue()).intValue());
/*     */       } else {
/*  71 */         GlStateManager.func_179131_c(((Integer)(ClickGui.getInstance()).red.getValue()).intValue() / 255.0F, ((Integer)(ClickGui.getInstance()).green.getValue()).intValue() / 255.0F, ((Integer)(ClickGui.getInstance()).blue.getValue()).intValue() / 255.0F, ((Integer)this.alpha.getValue()).intValue());
/*     */       } 
/*  73 */       Vec3d vec = getVec3(event, e);
/*  74 */       double x = vec.field_72450_a - (mc.func_175598_ae()).field_78725_b;
/*  75 */       double y = vec.field_72448_b - (mc.func_175598_ae()).field_78726_c;
/*  76 */       double z = vec.field_72449_c - (mc.func_175598_ae()).field_78723_d;
/*  77 */       GL11.glTranslated(x, y, z);
/*  78 */       float xOff = e.field_70760_ar + (e.field_70761_aq - e.field_70760_ar) * event.getPartialTicks();
/*  79 */       GL11.glRotatef(-xOff, 0.0F, 1.0F, 0.0F);
/*  80 */       GL11.glTranslated(0.0D, 0.0D, e.func_70093_af() ? -0.235D : 0.0D);
/*  81 */       float yOff = e.func_70093_af() ? 0.6F : 0.75F;
/*  82 */       GL11.glPushMatrix();
/*  83 */       GL11.glTranslated(-0.125D, yOff, 0.0D);
/*  84 */       if (entPos[3][0] != 0.0F) {
/*  85 */         GL11.glRotatef(entPos[3][0] * 57.295776F, 1.0F, 0.0F, 0.0F);
/*     */       }
/*  87 */       if (entPos[3][1] != 0.0F) {
/*  88 */         GL11.glRotatef(entPos[3][1] * 57.295776F, 0.0F, 1.0F, 0.0F);
/*     */       }
/*  90 */       if (entPos[3][2] != 0.0F) {
/*  91 */         GL11.glRotatef(entPos[3][2] * 57.295776F, 0.0F, 0.0F, 1.0F);
/*     */       }
/*  93 */       GL11.glBegin(3);
/*  94 */       GL11.glVertex3d(0.0D, 0.0D, 0.0D);
/*  95 */       GL11.glVertex3d(0.0D, -yOff, 0.0D);
/*  96 */       GL11.glEnd();
/*  97 */       GL11.glPopMatrix();
/*  98 */       GL11.glPushMatrix();
/*  99 */       GL11.glTranslated(0.125D, yOff, 0.0D);
/* 100 */       if (entPos[4][0] != 0.0F) {
/* 101 */         GL11.glRotatef(entPos[4][0] * 57.295776F, 1.0F, 0.0F, 0.0F);
/*     */       }
/* 103 */       if (entPos[4][1] != 0.0F) {
/* 104 */         GL11.glRotatef(entPos[4][1] * 57.295776F, 0.0F, 1.0F, 0.0F);
/*     */       }
/* 106 */       if (entPos[4][2] != 0.0F) {
/* 107 */         GL11.glRotatef(entPos[4][2] * 57.295776F, 0.0F, 0.0F, 1.0F);
/*     */       }
/* 109 */       GL11.glBegin(3);
/* 110 */       GL11.glVertex3d(0.0D, 0.0D, 0.0D);
/* 111 */       GL11.glVertex3d(0.0D, -yOff, 0.0D);
/* 112 */       GL11.glEnd();
/* 113 */       GL11.glPopMatrix();
/* 114 */       GL11.glTranslated(0.0D, 0.0D, e.func_70093_af() ? 0.25D : 0.0D);
/* 115 */       GL11.glPushMatrix();
/* 116 */       GL11.glTranslated(0.0D, e.func_70093_af() ? -0.05D : 0.0D, e.func_70093_af() ? -0.01725D : 0.0D);
/* 117 */       GL11.glPushMatrix();
/* 118 */       GL11.glTranslated(-0.375D, yOff + 0.55D, 0.0D);
/* 119 */       if (entPos[1][0] != 0.0F) {
/* 120 */         GL11.glRotatef(entPos[1][0] * 57.295776F, 1.0F, 0.0F, 0.0F);
/*     */       }
/* 122 */       if (entPos[1][1] != 0.0F) {
/* 123 */         GL11.glRotatef(entPos[1][1] * 57.295776F, 0.0F, 1.0F, 0.0F);
/*     */       }
/* 125 */       if (entPos[1][2] != 0.0F) {
/* 126 */         GL11.glRotatef(-entPos[1][2] * 57.295776F, 0.0F, 0.0F, 1.0F);
/*     */       }
/* 128 */       GL11.glBegin(3);
/* 129 */       GL11.glVertex3d(0.0D, 0.0D, 0.0D);
/* 130 */       GL11.glVertex3d(0.0D, -0.5D, 0.0D);
/* 131 */       GL11.glEnd();
/* 132 */       GL11.glPopMatrix();
/* 133 */       GL11.glPushMatrix();
/* 134 */       GL11.glTranslated(0.375D, yOff + 0.55D, 0.0D);
/* 135 */       if (entPos[2][0] != 0.0F) {
/* 136 */         GL11.glRotatef(entPos[2][0] * 57.295776F, 1.0F, 0.0F, 0.0F);
/*     */       }
/* 138 */       if (entPos[2][1] != 0.0F) {
/* 139 */         GL11.glRotatef(entPos[2][1] * 57.295776F, 0.0F, 1.0F, 0.0F);
/*     */       }
/* 141 */       if (entPos[2][2] != 0.0F) {
/* 142 */         GL11.glRotatef(-entPos[2][2] * 57.295776F, 0.0F, 0.0F, 1.0F);
/*     */       }
/* 144 */       GL11.glBegin(3);
/* 145 */       GL11.glVertex3d(0.0D, 0.0D, 0.0D);
/* 146 */       GL11.glVertex3d(0.0D, -0.5D, 0.0D);
/* 147 */       GL11.glEnd();
/* 148 */       GL11.glPopMatrix();
/* 149 */       GL11.glRotatef(xOff - e.field_70759_as, 0.0F, 1.0F, 0.0F);
/* 150 */       GL11.glPushMatrix();
/* 151 */       GL11.glTranslated(0.0D, yOff + 0.55D, 0.0D);
/* 152 */       if (entPos[0][0] != 0.0F) {
/* 153 */         GL11.glRotatef(entPos[0][0] * 57.295776F, 1.0F, 0.0F, 0.0F);
/*     */       }
/* 155 */       GL11.glBegin(3);
/* 156 */       GL11.glVertex3d(0.0D, 0.0D, 0.0D);
/* 157 */       GL11.glVertex3d(0.0D, 0.3D, 0.0D);
/* 158 */       GL11.glEnd();
/* 159 */       GL11.glPopMatrix();
/* 160 */       GL11.glPopMatrix();
/* 161 */       GL11.glRotatef(e.func_70093_af() ? 25.0F : 0.0F, 1.0F, 0.0F, 0.0F);
/* 162 */       GL11.glTranslated(0.0D, e.func_70093_af() ? -0.16175D : 0.0D, e.func_70093_af() ? -0.48025D : 0.0D);
/* 163 */       GL11.glPushMatrix();
/* 164 */       GL11.glTranslated(0.0D, yOff, 0.0D);
/* 165 */       GL11.glBegin(3);
/* 166 */       GL11.glVertex3d(-0.125D, 0.0D, 0.0D);
/* 167 */       GL11.glVertex3d(0.125D, 0.0D, 0.0D);
/* 168 */       GL11.glEnd();
/* 169 */       GL11.glPopMatrix();
/* 170 */       GL11.glPushMatrix();
/* 171 */       GL11.glTranslated(0.0D, yOff, 0.0D);
/* 172 */       GL11.glBegin(3);
/* 173 */       GL11.glVertex3d(0.0D, 0.0D, 0.0D);
/* 174 */       GL11.glVertex3d(0.0D, 0.55D, 0.0D);
/* 175 */       GL11.glEnd();
/* 176 */       GL11.glPopMatrix();
/* 177 */       GL11.glPushMatrix();
/* 178 */       GL11.glTranslated(0.0D, yOff + 0.55D, 0.0D);
/* 179 */       GL11.glBegin(3);
/* 180 */       GL11.glVertex3d(-0.375D, 0.0D, 0.0D);
/* 181 */       GL11.glVertex3d(0.375D, 0.0D, 0.0D);
/* 182 */       GL11.glEnd();
/* 183 */       GL11.glPopMatrix();
/* 184 */       GL11.glPopMatrix();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void startEnd(boolean revert) {
/* 189 */     if (revert) {
/* 190 */       GlStateManager.func_179094_E();
/* 191 */       GlStateManager.func_179147_l();
/* 192 */       GL11.glEnable(2848);
/* 193 */       GlStateManager.func_179097_i();
/* 194 */       GlStateManager.func_179090_x();
/* 195 */       GL11.glHint(3154, 4354);
/*     */     } else {
/* 197 */       GlStateManager.func_179084_k();
/* 198 */       GlStateManager.func_179098_w();
/* 199 */       GL11.glDisable(2848);
/* 200 */       GlStateManager.func_179126_j();
/* 201 */       GlStateManager.func_179121_F();
/*     */     } 
/* 203 */     GlStateManager.func_179132_a((!revert));
/*     */   }
/*     */   
/*     */   private boolean doesntContain(EntityPlayer entityPlayer) {
/* 207 */     return !mc.field_71441_e.field_73010_i.contains(entityPlayer);
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/render/Skeleton.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */