/*     */ package cc.zip.charon.features.modules.combat;
/*     */ 
/*     */ import cc.zip.charon.event.events.PacketEvent;
/*     */ import cc.zip.charon.event.events.ProcessRightClickBlockEvent;
/*     */ import cc.zip.charon.features.modules.Module;
/*     */ import cc.zip.charon.features.setting.Setting;
/*     */ import cc.zip.charon.util.EntityUtil;
/*     */ import cc.zip.charon.util.InventoryUtil;
/*     */ import cc.zip.charon.util.Timer;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.ConcurrentLinkedQueue;
/*     */ import net.minecraft.block.BlockObsidian;
/*     */ import net.minecraft.block.BlockWeb;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.inventory.EntityEquipmentSlot;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
/*     */ import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import org.lwjgl.input.Mouse;
/*     */ 
/*     */ public class Offhand
/*     */   extends Module {
/*     */   private static Offhand instance;
/*  31 */   private final Queue<InventoryUtil.Task> taskList = new ConcurrentLinkedQueue<>();
/*  32 */   private final Timer timer = new Timer();
/*  33 */   private final Timer secondTimer = new Timer();
/*  34 */   public Setting<Boolean> crystal = register(new Setting("Crystal", Boolean.valueOf(true)));
/*  35 */   public Setting<Float> crystalHealth = register(new Setting("CrystalHP", Float.valueOf(13.0F), Float.valueOf(0.1F), Float.valueOf(36.0F)));
/*  36 */   public Setting<Float> crystalHoleHealth = register(new Setting("CrystalHoleHP", Float.valueOf(3.5F), Float.valueOf(0.1F), Float.valueOf(36.0F)));
/*  37 */   public Setting<Boolean> gapple = register(new Setting("Gapple", Boolean.valueOf(true)));
/*  38 */   public Setting<Boolean> armorCheck = register(new Setting("ArmorCheck", Boolean.valueOf(true)));
/*  39 */   public Setting<Integer> actions = register(new Setting("Packets", Integer.valueOf(4), Integer.valueOf(1), Integer.valueOf(4)));
/*  40 */   public Mode2 currentMode = Mode2.TOTEMS;
/*  41 */   public int totems = 0;
/*  42 */   public int crystals = 0;
/*  43 */   public int gapples = 0;
/*  44 */   public int lastTotemSlot = -1;
/*  45 */   public int lastGappleSlot = -1;
/*  46 */   public int lastCrystalSlot = -1;
/*  47 */   public int lastObbySlot = -1;
/*  48 */   public int lastWebSlot = -1;
/*     */   public boolean holdingCrystal = false;
/*     */   public boolean holdingTotem = false;
/*     */   public boolean holdingGapple = false;
/*     */   public boolean didSwitchThisTick = false;
/*     */   private boolean second = false;
/*     */   private boolean switchedForHealthReason = false;
/*     */   
/*     */   public Offhand() {
/*  57 */     super("Offhand", "Allows you to switch up your Offhand.", Module.Category.COMBAT, true, false, false);
/*  58 */     instance = this;
/*     */   }
/*     */   
/*     */   public static Offhand getInstance() {
/*  62 */     if (instance == null) {
/*  63 */       instance = new Offhand();
/*     */     }
/*  65 */     return instance;
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onUpdateWalkingPlayer(ProcessRightClickBlockEvent event) {
/*  70 */     if (event.hand == EnumHand.MAIN_HAND && event.stack.func_77973_b() == Items.field_185158_cP && mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151153_ao && mc.field_71476_x != null && event.pos == mc.field_71476_x.func_178782_a()) {
/*  71 */       event.setCanceled(true);
/*  72 */       mc.field_71439_g.func_184598_c(EnumHand.OFF_HAND);
/*  73 */       mc.field_71442_b.func_187101_a((EntityPlayer)mc.field_71439_g, (World)mc.field_71441_e, EnumHand.OFF_HAND);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*  79 */     if (this.timer.passedMs(50L)) {
/*  80 */       if (mc.field_71439_g != null && mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151153_ao && mc.field_71439_g.func_184614_ca().func_77973_b() == Items.field_185158_cP && Mouse.isButtonDown(1)) {
/*  81 */         mc.field_71439_g.func_184598_c(EnumHand.OFF_HAND);
/*  82 */         mc.field_71474_y.field_74313_G.field_74513_e = Mouse.isButtonDown(1);
/*     */       } 
/*  84 */     } else if (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151153_ao && mc.field_71439_g.func_184614_ca().func_77973_b() == Items.field_185158_cP) {
/*  85 */       mc.field_71474_y.field_74313_G.field_74513_e = false;
/*     */     } 
/*  87 */     if (nullCheck()) {
/*     */       return;
/*     */     }
/*  90 */     doOffhand();
/*  91 */     if (this.secondTimer.passedMs(50L) && this.second) {
/*  92 */       this.second = false;
/*  93 */       this.timer.reset();
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketSend(PacketEvent.Send event) {
/*  99 */     if (!fullNullCheck() && mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151153_ao && mc.field_71439_g.func_184614_ca().func_77973_b() == Items.field_185158_cP && mc.field_71474_y.field_74313_G.func_151470_d())
/*     */     {
/* 101 */       if (event.getPacket() instanceof CPacketPlayerTryUseItemOnBlock)
/* 102 */       { CPacketPlayerTryUseItemOnBlock packet2 = (CPacketPlayerTryUseItemOnBlock)event.getPacket();
/* 103 */         if (packet2.func_187022_c() == EnumHand.MAIN_HAND) {
/* 104 */           if (this.timer.passedMs(50L)) {
/* 105 */             mc.field_71439_g.func_184598_c(EnumHand.OFF_HAND);
/* 106 */             mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerTryUseItem(EnumHand.OFF_HAND));
/*     */           } 
/* 108 */           event.setCanceled(true);
/*     */         }  }
/* 110 */       else { CPacketPlayerTryUseItem packet; if (event.getPacket() instanceof CPacketPlayerTryUseItem && (packet = (CPacketPlayerTryUseItem)event.getPacket()).func_187028_a() == EnumHand.OFF_HAND && !this.timer.passedMs(50L)) {
/* 111 */           event.setCanceled(true);
/*     */         } }
/*     */     
/*     */     }
/*     */   }
/*     */   
/*     */   public String getDisplayInfo() {
/* 118 */     if (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP) {
/* 119 */       return "Crystals";
/*     */     }
/* 121 */     if (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_190929_cY) {
/* 122 */       return "Totems";
/*     */     }
/* 124 */     if (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151153_ao) {
/* 125 */       return "Gapples";
/*     */     }
/* 127 */     return null;
/*     */   }
/*     */   
/*     */   public void doOffhand() {
/* 131 */     this.didSwitchThisTick = false;
/* 132 */     this.holdingCrystal = (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP);
/* 133 */     this.holdingTotem = (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_190929_cY);
/* 134 */     this.holdingGapple = (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151153_ao);
/* 135 */     this.totems = mc.field_71439_g.field_71071_by.field_70462_a.stream().filter(itemStack -> (itemStack.func_77973_b() == Items.field_190929_cY)).mapToInt(ItemStack::func_190916_E).sum();
/* 136 */     if (this.holdingTotem) {
/* 137 */       this.totems += mc.field_71439_g.field_71071_by.field_184439_c.stream().filter(itemStack -> (itemStack.func_77973_b() == Items.field_190929_cY)).mapToInt(ItemStack::func_190916_E).sum();
/*     */     }
/* 139 */     this.crystals = mc.field_71439_g.field_71071_by.field_70462_a.stream().filter(itemStack -> (itemStack.func_77973_b() == Items.field_185158_cP)).mapToInt(ItemStack::func_190916_E).sum();
/* 140 */     if (this.holdingCrystal) {
/* 141 */       this.crystals += mc.field_71439_g.field_71071_by.field_184439_c.stream().filter(itemStack -> (itemStack.func_77973_b() == Items.field_185158_cP)).mapToInt(ItemStack::func_190916_E).sum();
/*     */     }
/* 143 */     this.gapples = mc.field_71439_g.field_71071_by.field_70462_a.stream().filter(itemStack -> (itemStack.func_77973_b() == Items.field_151153_ao)).mapToInt(ItemStack::func_190916_E).sum();
/* 144 */     if (this.holdingGapple) {
/* 145 */       this.gapples += mc.field_71439_g.field_71071_by.field_184439_c.stream().filter(itemStack -> (itemStack.func_77973_b() == Items.field_151153_ao)).mapToInt(ItemStack::func_190916_E).sum();
/*     */     }
/* 147 */     doSwitch();
/*     */   }
/*     */   public void doSwitch() {
/*     */     int lastSlot;
/* 151 */     this.currentMode = Mode2.TOTEMS;
/* 152 */     if (((Boolean)this.gapple.getValue()).booleanValue() && mc.field_71439_g.func_184614_ca().func_77973_b() instanceof net.minecraft.item.ItemSword && mc.field_71474_y.field_74313_G.func_151470_d()) {
/* 153 */       this.currentMode = Mode2.GAPPLES;
/* 154 */     } else if (this.currentMode != Mode2.CRYSTALS && ((Boolean)this.crystal.getValue()).booleanValue() && ((EntityUtil.isSafe((Entity)mc.field_71439_g) && EntityUtil.getHealth((Entity)mc.field_71439_g, true) > ((Float)this.crystalHoleHealth.getValue()).floatValue()) || EntityUtil.getHealth((Entity)mc.field_71439_g, true) > ((Float)this.crystalHealth.getValue()).floatValue())) {
/* 155 */       this.currentMode = Mode2.CRYSTALS;
/*     */     } 
/* 157 */     if (this.currentMode == Mode2.CRYSTALS && this.crystals == 0) {
/* 158 */       setMode(Mode2.TOTEMS);
/*     */     }
/* 160 */     if (this.currentMode == Mode2.CRYSTALS && ((!EntityUtil.isSafe((Entity)mc.field_71439_g) && EntityUtil.getHealth((Entity)mc.field_71439_g, true) <= ((Float)this.crystalHealth.getValue()).floatValue()) || EntityUtil.getHealth((Entity)mc.field_71439_g, true) <= ((Float)this.crystalHoleHealth.getValue()).floatValue())) {
/* 161 */       if (this.currentMode == Mode2.CRYSTALS) {
/* 162 */         this.switchedForHealthReason = true;
/*     */       }
/* 164 */       setMode(Mode2.TOTEMS);
/*     */     } 
/* 166 */     if (this.switchedForHealthReason && ((EntityUtil.isSafe((Entity)mc.field_71439_g) && EntityUtil.getHealth((Entity)mc.field_71439_g, true) > ((Float)this.crystalHoleHealth.getValue()).floatValue()) || EntityUtil.getHealth((Entity)mc.field_71439_g, true) > ((Float)this.crystalHealth.getValue()).floatValue())) {
/* 167 */       setMode(Mode2.CRYSTALS);
/* 168 */       this.switchedForHealthReason = false;
/*     */     } 
/* 170 */     if (this.currentMode == Mode2.CRYSTALS && ((Boolean)this.armorCheck.getValue()).booleanValue() && (mc.field_71439_g.func_184582_a(EntityEquipmentSlot.CHEST).func_77973_b() == Items.field_190931_a || mc.field_71439_g.func_184582_a(EntityEquipmentSlot.HEAD).func_77973_b() == Items.field_190931_a || mc.field_71439_g.func_184582_a(EntityEquipmentSlot.LEGS).func_77973_b() == Items.field_190931_a || mc.field_71439_g.func_184582_a(EntityEquipmentSlot.FEET).func_77973_b() == Items.field_190931_a)) {
/* 171 */       setMode(Mode2.TOTEMS);
/*     */     }
/* 173 */     if (mc.field_71462_r instanceof net.minecraft.client.gui.inventory.GuiContainer && !(mc.field_71462_r instanceof net.minecraft.client.gui.inventory.GuiInventory)) {
/*     */       return;
/*     */     }
/* 176 */     Item currentOffhandItem = mc.field_71439_g.func_184592_cb().func_77973_b();
/* 177 */     switch (this.currentMode) {
/*     */       case TOTEMS:
/* 179 */         if (this.totems <= 0 || this.holdingTotem)
/* 180 */           break;  this.lastTotemSlot = InventoryUtil.findItemInventorySlot(Items.field_190929_cY, false);
/* 181 */         lastSlot = getLastSlot(currentOffhandItem, this.lastTotemSlot);
/* 182 */         putItemInOffhand(this.lastTotemSlot, lastSlot);
/*     */         break;
/*     */       
/*     */       case GAPPLES:
/* 186 */         if (this.gapples <= 0 || this.holdingGapple)
/* 187 */           break;  this.lastGappleSlot = InventoryUtil.findItemInventorySlot(Items.field_151153_ao, false);
/* 188 */         lastSlot = getLastSlot(currentOffhandItem, this.lastGappleSlot);
/* 189 */         putItemInOffhand(this.lastGappleSlot, lastSlot);
/*     */         break;
/*     */       
/*     */       default:
/* 193 */         if (this.crystals <= 0 || this.holdingCrystal)
/* 194 */           break;  this.lastCrystalSlot = InventoryUtil.findItemInventorySlot(Items.field_185158_cP, false);
/* 195 */         lastSlot = getLastSlot(currentOffhandItem, this.lastCrystalSlot);
/* 196 */         putItemInOffhand(this.lastCrystalSlot, lastSlot);
/*     */         break;
/*     */     } 
/* 199 */     for (int i = 0; i < ((Integer)this.actions.getValue()).intValue(); i++) {
/* 200 */       InventoryUtil.Task task = this.taskList.poll();
/* 201 */       if (task != null) {
/* 202 */         task.run();
/* 203 */         if (task.isSwitching())
/* 204 */           this.didSwitchThisTick = true; 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   private int getLastSlot(Item item, int slotIn) {
/* 209 */     if (item == Items.field_185158_cP) {
/* 210 */       return this.lastCrystalSlot;
/*     */     }
/* 212 */     if (item == Items.field_151153_ao) {
/* 213 */       return this.lastGappleSlot;
/*     */     }
/* 215 */     if (item == Items.field_190929_cY) {
/* 216 */       return this.lastTotemSlot;
/*     */     }
/* 218 */     if (InventoryUtil.isBlock(item, BlockObsidian.class)) {
/* 219 */       return this.lastObbySlot;
/*     */     }
/* 221 */     if (InventoryUtil.isBlock(item, BlockWeb.class)) {
/* 222 */       return this.lastWebSlot;
/*     */     }
/* 224 */     if (item == Items.field_190931_a) {
/* 225 */       return -1;
/*     */     }
/* 227 */     return slotIn;
/*     */   }
/*     */   
/*     */   private void putItemInOffhand(int slotIn, int slotOut) {
/* 231 */     if (slotIn != -1 && this.taskList.isEmpty()) {
/* 232 */       this.taskList.add(new InventoryUtil.Task(slotIn));
/* 233 */       this.taskList.add(new InventoryUtil.Task(45));
/* 234 */       this.taskList.add(new InventoryUtil.Task(slotOut));
/* 235 */       this.taskList.add(new InventoryUtil.Task());
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setMode(Mode2 mode) {
/* 240 */     this.currentMode = (this.currentMode == mode) ? Mode2.TOTEMS : mode;
/*     */   }
/*     */   
/*     */   public enum Mode2 {
/* 244 */     TOTEMS,
/* 245 */     GAPPLES,
/* 246 */     CRYSTALS;
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/combat/Offhand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */