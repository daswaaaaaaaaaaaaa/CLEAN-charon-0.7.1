/*     */ package cc.zip.charon.features.modules.combat;
/*     */ 
/*     */ import cc.zip.charon.Charon;
/*     */ import cc.zip.charon.features.command.Command;
/*     */ import cc.zip.charon.features.modules.Module;
/*     */ import cc.zip.charon.features.setting.Setting;
/*     */ import cc.zip.charon.util.Timer;
/*     */ import com.mojang.realmsclient.gui.ChatFormatting;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.inventory.ClickType;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketEntityAction;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
/*     */ import net.minecraft.tileentity.TileEntity;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BedAura
/*     */   extends Module
/*     */ {
/*  44 */   private final Setting<Integer> packets = register(new Setting("Packets", Integer.valueOf(2), Integer.valueOf(1), Integer.valueOf(4), "Amount of packets you want to send."));
/*  45 */   private final Timer timer = new Timer(); private final boolean resetTimer = false; public Setting<Integer> range; public Setting<Integer> placedelay; public Setting<Boolean> announceUsage; public Setting<Boolean> placeesp; private int playerHotbarSlot; private int lastHotbarSlot;
/*     */   private EntityPlayer closestTarget;
/*     */   
/*     */   public BedAura() {
/*  49 */     super("BedAura", "Auto Bed", Module.Category.COMBAT, true, false, false);
/*     */ 
/*     */     
/*  52 */     this.range = register(new Setting("Range", Integer.valueOf(6), Integer.valueOf(0), Integer.valueOf(9)));
/*  53 */     this.placedelay = register(new Setting("Place Delay", Integer.valueOf(15), Integer.valueOf(8), Integer.valueOf(20)));
/*  54 */     this.announceUsage = register(new Setting("Message", Boolean.valueOf(true)));
/*  55 */     this.placeesp = register(new Setting("ESP", Boolean.valueOf(true)));
/*  56 */     this.playerHotbarSlot = -1;
/*  57 */     this.lastHotbarSlot = -1;
/*     */ 
/*     */     
/*  60 */     this.bedSlot = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  66 */     this.nowTop = false;
/*     */   }
/*     */   private String lastTickTargetName; private int bedSlot; private BlockPos placeTarget; private float rotVar; private int blocksPlaced; private double diffXZ; private boolean firstRun; private boolean nowTop;
/*     */   
/*     */   public void onEnable() {
/*  71 */     if (mc.field_71439_g == null) {
/*  72 */       toggle();
/*     */       
/*     */       return;
/*     */     } 
/*  76 */     MinecraftForge.EVENT_BUS.register(this);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  82 */     this.firstRun = true;
/*     */ 
/*     */     
/*  85 */     this.blocksPlaced = 0;
/*     */ 
/*     */     
/*  88 */     this.playerHotbarSlot = mc.field_71439_g.field_71071_by.field_70461_c;
/*  89 */     this.lastHotbarSlot = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  97 */     if (mc.field_71439_g == null) {
/*     */       return;
/*     */     }
/*     */     
/* 101 */     MinecraftForge.EVENT_BUS.unregister(this);
/*     */     
/* 103 */     if (this.lastHotbarSlot != this.playerHotbarSlot && this.playerHotbarSlot != -1) {
/* 104 */       mc.field_71439_g.field_71071_by.field_70461_c = this.playerHotbarSlot;
/*     */     }
/*     */     
/* 107 */     this.playerHotbarSlot = -1;
/* 108 */     this.lastHotbarSlot = -1;
/*     */ 
/*     */     
/* 111 */     this.blocksPlaced = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/* 119 */     if (mc.field_71439_g == null) {
/*     */       return;
/*     */     }
/* 122 */     if (mc.field_71439_g.field_71093_bK == 0) {
/* 123 */       Command.sendMessage("You are in the overworld!");
/* 124 */       toggle();
/*     */     } 
/*     */     try {
/* 127 */       findClosestTarget();
/* 128 */     } catch (NullPointerException nullPointerException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 135 */     if (this.closestTarget == null && mc.field_71439_g.field_71093_bK != 0 && 
/* 136 */       this.firstRun) {
/* 137 */       this.firstRun = false;
/* 138 */       if (((Boolean)this.announceUsage.getValue()).booleanValue()) {
/* 139 */         Command.sendMessage(ChatFormatting.RED + "targen when?");
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 144 */     if (this.firstRun && this.closestTarget != null && mc.field_71439_g.field_71093_bK != 0) {
/* 145 */       this.firstRun = false;
/* 146 */       this.lastTickTargetName = this.closestTarget.func_70005_c_();
/* 147 */       if (((Boolean)this.announceUsage.getValue()).booleanValue()) {
/* 148 */         Command.sendMessage(ChatFormatting.RED + "target: " + ChatFormatting.WHITE.toString() + this.lastTickTargetName);
/*     */       }
/*     */     } 
/*     */     
/* 152 */     if (this.closestTarget != null && this.lastTickTargetName != null && 
/* 153 */       !this.lastTickTargetName.equals(this.closestTarget.func_70005_c_())) {
/* 154 */       this.lastTickTargetName = this.closestTarget.func_70005_c_();
/* 155 */       if (((Boolean)this.announceUsage.getValue()).booleanValue()) {
/* 156 */         Command.sendMessage(ChatFormatting.RED + " New target: " + ChatFormatting.WHITE.toString() + this.lastTickTargetName);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 166 */       this.diffXZ = mc.field_71439_g.func_174791_d().func_72438_d(this.closestTarget.func_174791_d());
/* 167 */     } catch (NullPointerException nullPointerException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 178 */       if (this.closestTarget != null) {
/* 179 */         this.placeTarget = new BlockPos(this.closestTarget.func_174791_d().func_72441_c(1.0D, 1.0D, 0.0D));
/* 180 */         this.nowTop = false;
/* 181 */         this.rotVar = 90.0F;
/*     */         
/* 183 */         BlockPos block1 = this.placeTarget;
/* 184 */         if (!canPlaceBed(block1)) {
/* 185 */           this.placeTarget = new BlockPos(this.closestTarget.func_174791_d().func_72441_c(-1.0D, 1.0D, 0.0D));
/* 186 */           this.rotVar = -90.0F;
/* 187 */           this.nowTop = false;
/*     */         } 
/* 189 */         BlockPos block2 = this.placeTarget;
/* 190 */         if (!canPlaceBed(block2)) {
/* 191 */           this.placeTarget = new BlockPos(this.closestTarget.func_174791_d().func_72441_c(0.0D, 1.0D, 1.0D));
/* 192 */           this.rotVar = 180.0F;
/* 193 */           this.nowTop = false;
/*     */         } 
/* 195 */         BlockPos block3 = this.placeTarget;
/* 196 */         if (!canPlaceBed(block3)) {
/* 197 */           this.placeTarget = new BlockPos(this.closestTarget.func_174791_d().func_72441_c(0.0D, 1.0D, -1.0D));
/* 198 */           this.rotVar = 0.0F;
/* 199 */           this.nowTop = false;
/*     */         } 
/* 201 */         BlockPos block4 = this.placeTarget;
/* 202 */         if (!canPlaceBed(block4)) {
/* 203 */           this.placeTarget = new BlockPos(this.closestTarget.func_174791_d().func_72441_c(0.0D, 2.0D, -1.0D));
/* 204 */           this.rotVar = 0.0F;
/* 205 */           this.nowTop = true;
/*     */         } 
/* 207 */         BlockPos blockt1 = this.placeTarget;
/* 208 */         if (this.nowTop && !canPlaceBed(blockt1)) {
/* 209 */           this.placeTarget = new BlockPos(this.closestTarget.func_174791_d().func_72441_c(-1.0D, 2.0D, 0.0D));
/* 210 */           this.rotVar = -90.0F;
/*     */         } 
/* 212 */         BlockPos blockt2 = this.placeTarget;
/* 213 */         if (this.nowTop && !canPlaceBed(blockt2)) {
/* 214 */           this.placeTarget = new BlockPos(this.closestTarget.func_174791_d().func_72441_c(0.0D, 2.0D, 1.0D));
/* 215 */           this.rotVar = 180.0F;
/*     */         } 
/* 217 */         BlockPos blockt3 = this.placeTarget;
/* 218 */         if (this.nowTop && !canPlaceBed(blockt3)) {
/* 219 */           this.placeTarget = new BlockPos(this.closestTarget.func_174791_d().func_72441_c(1.0D, 2.0D, 0.0D));
/* 220 */           this.rotVar = 90.0F;
/*     */         } 
/*     */       } 
/*     */       
/* 224 */       mc.field_71441_e.field_147482_g.stream()
/* 225 */         .filter(e -> e instanceof net.minecraft.tileentity.TileEntityBed)
/* 226 */         .filter(e -> (mc.field_71439_g.func_70011_f(e.func_174877_v().func_177958_n(), e.func_174877_v().func_177956_o(), e.func_174877_v().func_177952_p()) <= ((Integer)this.range.getValue()).intValue()))
/* 227 */         .sorted(Comparator.comparing(e -> Double.valueOf(mc.field_71439_g.func_70011_f(e.func_174877_v().func_177958_n(), e.func_174877_v().func_177956_o(), e.func_174877_v().func_177952_p()))))
/* 228 */         .forEach(bed -> {
/*     */             if (mc.field_71439_g.field_71093_bK != 0) {
/*     */               mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerTryUseItemOnBlock(bed.func_174877_v(), EnumFacing.UP, EnumHand.OFF_HAND, 0.0F, 0.0F, 0.0F));
/*     */             }
/*     */           });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 239 */       if (mc.field_71439_g.field_70173_aa % ((Integer)this.placedelay.getValue()).intValue() == 0 && this.closestTarget != null)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 247 */         findBeds();
/*     */         
/* 249 */         mc.field_71439_g.field_70173_aa++;
/*     */         
/* 251 */         doDaMagic();
/*     */       }
/*     */     
/*     */     }
/* 255 */     catch (NullPointerException npe) {
/* 256 */       npe.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void doDaMagic() {
/* 267 */     if (this.diffXZ <= ((Integer)this.range.getValue()).intValue()) {
/* 268 */       for (int i = 0; i < 9 && 
/* 269 */         this.bedSlot == -1; i++) {
/*     */ 
/*     */         
/* 272 */         ItemStack stack = mc.field_71439_g.field_71071_by.func_70301_a(i);
/* 273 */         if (stack.func_77973_b() instanceof net.minecraft.item.ItemBed) {
/* 274 */           this.bedSlot = i;
/* 275 */           if (i != -1) {
/* 276 */             mc.field_71439_g.field_71071_by.field_70461_c = this.bedSlot;
/*     */           }
/*     */           break;
/*     */         } 
/*     */       } 
/* 281 */       this.bedSlot = -1;
/* 282 */       if (this.blocksPlaced == 0 && mc.field_71439_g.field_71071_by.func_70301_a(mc.field_71439_g.field_71071_by.field_70461_c).func_77973_b() instanceof net.minecraft.item.ItemBed) {
/* 283 */         mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)mc.field_71439_g, CPacketEntityAction.Action.START_SNEAKING));
/* 284 */         mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Rotation(this.rotVar, 0.0F, mc.field_71439_g.field_70122_E));
/* 285 */         placeBlock(new BlockPos((Vec3i)this.placeTarget), EnumFacing.DOWN);
/* 286 */         mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)mc.field_71439_g, CPacketEntityAction.Action.STOP_SNEAKING));
/* 287 */         this.blocksPlaced = 1;
/* 288 */         this.nowTop = false;
/*     */       } 
/*     */       
/* 291 */       this.blocksPlaced = 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void findBeds() {
/* 299 */     if ((mc.field_71462_r == null || !(mc.field_71462_r instanceof net.minecraft.client.gui.inventory.GuiContainer)) && 
/* 300 */       mc.field_71439_g.field_71071_by.func_70301_a(0).func_77973_b() != Items.field_151104_aV) {
/* 301 */       for (int i = 9; i < 36; i++) {
/* 302 */         if (mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b() == Items.field_151104_aV) {
/* 303 */           mc.field_71442_b.func_187098_a(mc.field_71439_g.field_71069_bz.field_75152_c, i, 0, ClickType.SWAP, (EntityPlayer)mc.field_71439_g);
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean canPlaceBed(BlockPos pos) {
/* 315 */     return ((mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150350_a || mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150324_C) && mc.field_71441_e
/* 316 */       .func_72872_a(Entity.class, new AxisAlignedBB(pos)).isEmpty());
/*     */   }
/*     */ 
/*     */   
/*     */   private void findClosestTarget() {
/* 321 */     List<EntityPlayer> playerList = mc.field_71441_e.field_73010_i;
/* 322 */     this.closestTarget = null;
/* 323 */     for (EntityPlayer target : playerList) {
/*     */ 
/*     */       
/* 326 */       if (target == mc.field_71439_g) {
/*     */         continue;
/*     */       }
/* 329 */       if (Charon.friendManager.isFriend(target.func_70005_c_())) {
/*     */         continue;
/*     */       }
/* 332 */       if (!isLiving((Entity)target)) {
/*     */         continue;
/*     */       }
/* 335 */       if (target.func_110143_aJ() <= 0.0F) {
/*     */         continue;
/*     */       }
/* 338 */       if (this.closestTarget == null) {
/* 339 */         this.closestTarget = target;
/*     */         continue;
/*     */       } 
/* 342 */       if (mc.field_71439_g.func_70032_d((Entity)target) < mc.field_71439_g.func_70032_d((Entity)this.closestTarget)) {
/* 343 */         this.closestTarget = target;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void placeBlock(BlockPos pos, EnumFacing side) {
/* 350 */     BlockPos neighbour = pos.func_177972_a(side);
/* 351 */     EnumFacing opposite = side.func_176734_d();
/* 352 */     Vec3d hitVec = (new Vec3d((Vec3i)neighbour)).func_72441_c(0.5D, 0.5D, 0.5D).func_178787_e((new Vec3d(opposite.func_176730_m())).func_186678_a(0.5D));
/* 353 */     mc.field_71442_b.func_187099_a(mc.field_71439_g, mc.field_71441_e, neighbour, opposite, hitVec, EnumHand.MAIN_HAND);
/*     */   }
/*     */   
/*     */   public static boolean isLiving(Entity e) {
/* 357 */     return e instanceof net.minecraft.entity.EntityLivingBase;
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/combat/BedAura.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */