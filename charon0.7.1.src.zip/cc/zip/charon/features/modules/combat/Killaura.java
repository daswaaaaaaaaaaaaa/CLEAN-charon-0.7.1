/*     */ package cc.zip.charon.features.modules.combat;
/*     */ 
/*     */ import cc.zip.charon.Charon;
/*     */ import cc.zip.charon.event.events.UpdateWalkingPlayerEvent;
/*     */ import cc.zip.charon.features.modules.Module;
/*     */ import cc.zip.charon.features.setting.Setting;
/*     */ import cc.zip.charon.util.DamageUtil;
/*     */ import cc.zip.charon.util.EntityUtil;
/*     */ import cc.zip.charon.util.MathUtil;
/*     */ import cc.zip.charon.util.Timer;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ public class Killaura extends Module {
/*     */   public static Entity target;
/*  17 */   private final Timer timer = new Timer();
/*  18 */   public Setting<Float> range = register(new Setting("Range", Float.valueOf(6.0F), Float.valueOf(0.1F), Float.valueOf(7.0F)));
/*  19 */   public Setting<Boolean> delay = register(new Setting("HitDelay", Boolean.valueOf(true)));
/*  20 */   public Setting<Boolean> rotate = register(new Setting("Rotate", Boolean.valueOf(true)));
/*  21 */   public Setting<Boolean> onlySharp = register(new Setting("SwordOnly", Boolean.valueOf(true)));
/*  22 */   public Setting<Float> raytrace = register(new Setting("Raytrace", Float.valueOf(6.0F), Float.valueOf(0.1F), Float.valueOf(7.0F), "Wall Range."));
/*  23 */   public Setting<Boolean> players = register(new Setting("Players", Boolean.valueOf(true)));
/*  24 */   public Setting<Boolean> mobs = register(new Setting("Mobs", Boolean.valueOf(false)));
/*  25 */   public Setting<Boolean> animals = register(new Setting("Animals", Boolean.valueOf(false)));
/*  26 */   public Setting<Boolean> vehicles = register(new Setting("Entities", Boolean.valueOf(false)));
/*  27 */   public Setting<Boolean> projectiles = register(new Setting("Projectiles", Boolean.valueOf(false)));
/*  28 */   public Setting<Boolean> tps = register(new Setting("TpsSync", Boolean.valueOf(true)));
/*  29 */   public Setting<Boolean> packet = register(new Setting("Packet", Boolean.valueOf(false)));
/*     */   
/*     */   public Killaura() {
/*  32 */     super("Killaura", "Kills aura.", Module.Category.COMBAT, true, false, false);
/*     */   }
/*     */   
/*     */   public void onTick() {
/*  36 */     if (!((Boolean)this.rotate.getValue()).booleanValue())
/*  37 */       doKillaura(); 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onUpdateWalkingPlayerEvent(UpdateWalkingPlayerEvent event) {
/*  42 */     if (event.getStage() == 0 && ((Boolean)this.rotate.getValue()).booleanValue())
/*  43 */       doKillaura(); 
/*     */   }
/*     */   
/*     */   private void doKillaura() {
/*  47 */     if (((Boolean)this.onlySharp.getValue()).booleanValue() && !EntityUtil.holdingWeapon((EntityPlayer)mc.field_71439_g)) {
/*  48 */       target = null;
/*     */       return;
/*     */     } 
/*  51 */     int wait = !((Boolean)this.delay.getValue()).booleanValue() ? 0 : (int)(DamageUtil.getCooldownByWeapon((EntityPlayer)mc.field_71439_g) * (((Boolean)this.tps.getValue()).booleanValue() ? Charon.serverManager.getTpsFactor() : 1.0F));
/*  52 */     if (!this.timer.passedMs(wait))
/*     */       return; 
/*  54 */     target = getTarget();
/*  55 */     if (target == null)
/*     */       return; 
/*  57 */     if (((Boolean)this.rotate.getValue()).booleanValue())
/*  58 */       Charon.rotationManager.lookAtEntity(target); 
/*  59 */     EntityUtil.attackEntity(target, ((Boolean)this.packet.getValue()).booleanValue(), true);
/*  60 */     this.timer.reset();
/*     */   }
/*     */   
/*     */   private Entity getTarget() {
/*  64 */     Entity target = null;
/*  65 */     double distance = ((Float)this.range.getValue()).floatValue();
/*  66 */     double maxHealth = 36.0D;
/*  67 */     for (Entity entity : mc.field_71441_e.field_73010_i) {
/*  68 */       if (((!((Boolean)this.players.getValue()).booleanValue() || !(entity instanceof EntityPlayer)) && (!((Boolean)this.animals.getValue()).booleanValue() || !EntityUtil.isPassive(entity)) && (!((Boolean)this.mobs.getValue()).booleanValue() || !EntityUtil.isMobAggressive(entity)) && (!((Boolean)this.vehicles.getValue()).booleanValue() || !EntityUtil.isVehicle(entity)) && (!((Boolean)this.projectiles.getValue()).booleanValue() || !EntityUtil.isProjectile(entity))) || (entity instanceof net.minecraft.entity.EntityLivingBase && 
/*  69 */         EntityUtil.isntValid(entity, distance)))
/*     */         continue; 
/*  71 */       if (!mc.field_71439_g.func_70685_l(entity) && !EntityUtil.canEntityFeetBeSeen(entity) && mc.field_71439_g.func_70068_e(entity) > MathUtil.square(((Float)this.raytrace.getValue()).floatValue()))
/*     */         continue; 
/*  73 */       if (target == null) {
/*  74 */         target = entity;
/*  75 */         distance = mc.field_71439_g.func_70068_e(entity);
/*  76 */         maxHealth = EntityUtil.getHealth(entity);
/*     */         continue;
/*     */       } 
/*  79 */       if (entity instanceof EntityPlayer && DamageUtil.isArmorLow((EntityPlayer)entity, 18)) {
/*  80 */         target = entity;
/*     */         break;
/*     */       } 
/*  83 */       if (mc.field_71439_g.func_70068_e(entity) < distance) {
/*  84 */         target = entity;
/*  85 */         distance = mc.field_71439_g.func_70068_e(entity);
/*  86 */         maxHealth = EntityUtil.getHealth(entity);
/*     */       } 
/*  88 */       if (EntityUtil.getHealth(entity) < maxHealth) {
/*  89 */         target = entity;
/*  90 */         distance = mc.field_71439_g.func_70068_e(entity);
/*  91 */         maxHealth = EntityUtil.getHealth(entity);
/*     */       } 
/*     */     } 
/*  94 */     return target;
/*     */   }
/*     */   
/*     */   public String getDisplayInfo() {
/*  98 */     if (target instanceof EntityPlayer)
/*  99 */       return target.func_70005_c_(); 
/* 100 */     return null;
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/combat/Killaura.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */