/*     */ package cc.zip.charon.features.modules.combat;
/*     */ import cc.zip.charon.event.events.UpdateWalkingPlayerEvent;
/*     */ import cc.zip.charon.features.modules.Module;
/*     */ import cc.zip.charon.features.setting.Setting;
/*     */ import cc.zip.charon.util.BlockUtil;
/*     */ import cc.zip.charon.util.EntityUtil;
/*     */ import cc.zip.charon.util.InventoryUtil;
/*     */ import cc.zip.charon.util.Timer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import net.minecraft.block.BlockEnderChest;
/*     */ import net.minecraft.block.BlockObsidian;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ public class Selftrap extends Module {
/*  21 */   private final Setting<Integer> blocksPerTick = register(new Setting("BlocksPerTick", Integer.valueOf(8), Integer.valueOf(1), Integer.valueOf(20)));
/*  22 */   private final Setting<Integer> delay = register(new Setting("Delay", Integer.valueOf(50), Integer.valueOf(0), Integer.valueOf(250)));
/*  23 */   private final Setting<Boolean> rotate = register(new Setting("Rotate", Boolean.valueOf(true)));
/*  24 */   private final Setting<Integer> disableTime = register(new Setting("DisableTime", Integer.valueOf(200), Integer.valueOf(50), Integer.valueOf(300)));
/*  25 */   private final Setting<Boolean> disable = register(new Setting("AutoDisable", Boolean.valueOf(true)));
/*  26 */   private final Setting<Boolean> packet = register(new Setting("PacketPlace", Boolean.valueOf(false)));
/*  27 */   private final Timer offTimer = new Timer();
/*  28 */   private final Timer timer = new Timer();
/*  29 */   private final Map<BlockPos, Integer> retries = new HashMap<>();
/*  30 */   private final Timer retryTimer = new Timer();
/*  31 */   private int blocksThisTick = 0;
/*     */   private boolean isSneaking;
/*     */   private boolean hasOffhand = false;
/*     */   
/*     */   public Selftrap() {
/*  36 */     super("Selftrap", "Lure your enemies in!", Module.Category.COMBAT, true, false, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  41 */     if (fullNullCheck()) {
/*  42 */       disable();
/*     */     }
/*  44 */     this.offTimer.reset();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onTick() {
/*  49 */     if (isOn() && (((Integer)this.blocksPerTick.getValue()).intValue() != 1 || !((Boolean)this.rotate.getValue()).booleanValue())) {
/*  50 */       doHoleFill();
/*     */     }
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onUpdateWalkingPlayer(UpdateWalkingPlayerEvent event) {
/*  56 */     if (isOn() && event.getStage() == 0 && ((Integer)this.blocksPerTick.getValue()).intValue() == 1 && ((Boolean)this.rotate.getValue()).booleanValue()) {
/*  57 */       doHoleFill();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  63 */     this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
/*  64 */     this.retries.clear();
/*  65 */     this.hasOffhand = false;
/*     */   }
/*     */   
/*     */   private void doHoleFill() {
/*  69 */     if (check()) {
/*     */       return;
/*     */     }
/*  72 */     for (BlockPos position : getPositions()) {
/*  73 */       int placeability = BlockUtil.isPositionPlaceable(position, false);
/*  74 */       if (placeability == 1 && (this.retries.get(position) == null || ((Integer)this.retries.get(position)).intValue() < 4)) {
/*  75 */         placeBlock(position);
/*  76 */         this.retries.put(position, Integer.valueOf((this.retries.get(position) == null) ? 1 : (((Integer)this.retries.get(position)).intValue() + 1)));
/*     */       } 
/*  78 */       if (placeability != 3)
/*  79 */         continue;  placeBlock(position);
/*     */     } 
/*     */   }
/*     */   
/*     */   private List<BlockPos> getPositions() {
/*  84 */     ArrayList<BlockPos> positions = new ArrayList<>();
/*  85 */     positions.add(new BlockPos(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 2.0D, mc.field_71439_g.field_70161_v));
/*  86 */     int placeability = BlockUtil.isPositionPlaceable(positions.get(0), false);
/*  87 */     switch (placeability) {
/*     */       case 0:
/*  89 */         return new ArrayList<>();
/*     */       
/*     */       case 3:
/*  92 */         return positions;
/*     */       
/*     */       case 1:
/*  95 */         if (BlockUtil.isPositionPlaceable(positions.get(0), false, false) == 3) {
/*  96 */           return positions;
/*     */         }
/*     */       
/*     */       case 2:
/* 100 */         positions.add(new BlockPos(mc.field_71439_g.field_70165_t + 1.0D, mc.field_71439_g.field_70163_u + 1.0D, mc.field_71439_g.field_70161_v));
/* 101 */         positions.add(new BlockPos(mc.field_71439_g.field_70165_t + 1.0D, mc.field_71439_g.field_70163_u + 2.0D, mc.field_71439_g.field_70161_v));
/*     */         break;
/*     */     } 
/* 104 */     positions.sort(Comparator.comparingDouble(Vec3i::func_177956_o));
/* 105 */     return positions;
/*     */   }
/*     */   
/*     */   private void placeBlock(BlockPos pos) {
/* 109 */     if (this.blocksThisTick < ((Integer)this.blocksPerTick.getValue()).intValue()) {
/* 110 */       boolean smartRotate = (((Integer)this.blocksPerTick.getValue()).intValue() == 1 && ((Boolean)this.rotate.getValue()).booleanValue());
/* 111 */       int originalSlot = mc.field_71439_g.field_71071_by.field_70461_c;
/* 112 */       int obbySlot = InventoryUtil.findHotbarBlock(BlockObsidian.class);
/* 113 */       int eChestSot = InventoryUtil.findHotbarBlock(BlockEnderChest.class);
/* 114 */       if (obbySlot == -1 && eChestSot == -1) {
/* 115 */         toggle();
/*     */       }
/* 117 */       mc.field_71439_g.field_71071_by.field_70461_c = (obbySlot == -1) ? eChestSot : obbySlot;
/* 118 */       mc.field_71442_b.func_78765_e();
/* 119 */       this.isSneaking = smartRotate ? BlockUtil.placeBlockSmartRotate(pos, this.hasOffhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, true, ((Boolean)this.packet.getValue()).booleanValue(), this.isSneaking) : BlockUtil.placeBlock(pos, this.hasOffhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), this.isSneaking);
/* 120 */       mc.field_71439_g.field_71071_by.field_70461_c = originalSlot;
/* 121 */       mc.field_71442_b.func_78765_e();
/* 122 */       this.timer.reset();
/* 123 */       this.blocksThisTick++;
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean check() {
/* 128 */     if (fullNullCheck()) {
/* 129 */       disable();
/* 130 */       return true;
/*     */     } 
/* 132 */     int obbySlot = InventoryUtil.findHotbarBlock(BlockObsidian.class);
/* 133 */     int eChestSot = InventoryUtil.findHotbarBlock(BlockEnderChest.class);
/* 134 */     if (obbySlot == -1 && eChestSot == -1) {
/* 135 */       toggle();
/*     */     }
/* 137 */     this.blocksThisTick = 0;
/* 138 */     this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
/* 139 */     if (this.retryTimer.passedMs(2000L)) {
/* 140 */       this.retries.clear();
/* 141 */       this.retryTimer.reset();
/*     */     } 
/* 143 */     if (!EntityUtil.isSafe((Entity)mc.field_71439_g)) {
/* 144 */       this.offTimer.reset();
/* 145 */       return true;
/*     */     } 
/* 147 */     if (((Boolean)this.disable.getValue()).booleanValue() && this.offTimer.passedMs(((Integer)this.disableTime.getValue()).intValue())) {
/* 148 */       disable();
/* 149 */       return true;
/*     */     } 
/* 151 */     return !this.timer.passedMs(((Integer)this.delay.getValue()).intValue());
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/combat/Selftrap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */