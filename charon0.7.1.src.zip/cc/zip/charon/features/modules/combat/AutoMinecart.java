/*     */ package cc.zip.charon.features.modules.combat;
/*     */ import cc.zip.charon.features.command.Command;
/*     */ import cc.zip.charon.features.modules.Module;
/*     */ import cc.zip.charon.features.setting.Setting;
/*     */ import cc.zip.charon.util.BlockUtil;
/*     */ import cc.zip.charon.util.EntityUtil;
/*     */ import cc.zip.charon.util.InventoryUtil;
/*     */ import cc.zip.charon.util.MathUtil;
/*     */ import com.mojang.realmsclient.gui.ChatFormatting;
/*     */ import net.minecraft.block.BlockWeb;
/*     */ import net.minecraft.block.material.Material;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.item.EntityMinecartTNT;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.inventory.ClickType;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.util.math.Vec3i;
/*     */ 
/*     */ public class AutoMinecart extends Module {
/*  26 */   private final Setting<Boolean> web = register(new Setting("Web", Boolean.FALSE));
/*  27 */   private final Setting<Boolean> rotate = register(new Setting("Rotate", Boolean.FALSE));
/*  28 */   private final Setting<Boolean> packet = register(new Setting("PacketPlace", Boolean.FALSE));
/*  29 */   private final Setting<Integer> blocksPerTick = register(new Setting("BlocksPerTick", Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(4)));
/*  30 */   private final Setting<Integer> delay = register(new Setting("Carts", Integer.valueOf(20), Integer.valueOf(0), Integer.valueOf(50)));
/*  31 */   public Setting<Float> minHP = register(new Setting("MinHP", Float.valueOf(4.0F), Float.valueOf(0.0F), Float.valueOf(36.0F)));
/*     */   int wait;
/*     */   int waitFlint;
/*     */   int originalSlot;
/*     */   private boolean check;
/*     */   
/*     */   public AutoMinecart() {
/*  38 */     super("CartAura", "Places and explodes minecarts on other players.", Module.Category.COMBAT, true, false, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  43 */     if (fullNullCheck()) {
/*  44 */       toggle();
/*     */     }
/*  46 */     this.wait = 0;
/*  47 */     this.waitFlint = 0;
/*  48 */     this.originalSlot = mc.field_71439_g.field_71071_by.field_70461_c;
/*  49 */     this.check = true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*  55 */     if (fullNullCheck()) {
/*  56 */       toggle();
/*     */     }
/*  58 */     int i = InventoryUtil.findStackInventory(Items.field_151142_bV);
/*  59 */     for (int j = 0; j < 9; j++) {
/*  60 */       if (mc.field_71439_g.field_71071_by.func_70301_a(j).func_77973_b() == Items.field_190931_a && i != -1) {
/*  61 */         mc.field_71442_b.func_187098_a(mc.field_71439_g.field_71069_bz.field_75152_c, i, 0, ClickType.QUICK_MOVE, (EntityPlayer)mc.field_71439_g);
/*  62 */         mc.field_71442_b.func_78765_e();
/*     */       } 
/*  64 */     }  int webSlot = InventoryUtil.findHotbarBlock(BlockWeb.class);
/*  65 */     int tntSlot = InventoryUtil.getItemHotbar(Items.field_151142_bV);
/*  66 */     int flintSlot = InventoryUtil.getItemHotbar(Items.field_151033_d);
/*  67 */     int railSlot = InventoryUtil.findHotbarBlock(Blocks.field_150408_cc);
/*  68 */     int picSlot = InventoryUtil.getItemHotbar(Items.field_151046_w);
/*  69 */     if (tntSlot == -1 || railSlot == -1 || flintSlot == -1 || picSlot == -1 || (((Boolean)this.web.getValue()).booleanValue() && webSlot == -1)) {
/*  70 */       Command.sendMessage("<" + getDisplayName() + "> " + ChatFormatting.RED + "No (tnt minecart/activator rail/flint/pic/webs) in hotbar disabling...");
/*  71 */       toggle();
/*     */     }  EntityPlayer target;
/*  73 */     if ((target = getTarget()) == null) {
/*     */       return;
/*     */     }
/*  76 */     BlockPos pos = new BlockPos(target.field_70165_t, target.field_70163_u, target.field_70161_v);
/*  77 */     Vec3d hitVec = (new Vec3d((Vec3i)pos)).func_72441_c(0.0D, -0.5D, 0.0D);
/*  78 */     if (mc.field_71439_g.func_174818_b(pos) <= MathUtil.square(6.0D)) {
/*  79 */       this.check = true;
/*  80 */       if (mc.field_71441_e.func_180495_p(pos).func_177230_c() != Blocks.field_150408_cc && !mc.field_71441_e.func_72872_a(EntityMinecartTNT.class, new AxisAlignedBB(pos)).isEmpty()) {
/*  81 */         InventoryUtil.switchToHotbarSlot(flintSlot, false);
/*  82 */         BlockUtil.rightClickBlock(pos.func_177977_b(), hitVec, EnumHand.MAIN_HAND, EnumFacing.UP, ((Boolean)this.packet.getValue()).booleanValue());
/*     */       } 
/*  84 */       if (mc.field_71441_e.func_180495_p(pos).func_177230_c() != Blocks.field_150408_cc && mc.field_71441_e.func_72872_a(EntityMinecartTNT.class, new AxisAlignedBB(pos)).isEmpty() && mc.field_71441_e.func_72872_a(EntityMinecartTNT.class, new AxisAlignedBB(pos.func_177984_a())).isEmpty() && mc.field_71441_e.func_72872_a(EntityMinecartTNT.class, new AxisAlignedBB(pos.func_177977_b())).isEmpty()) {
/*  85 */         InventoryUtil.switchToHotbarSlot(railSlot, false);
/*  86 */         BlockUtil.rightClickBlock(pos.func_177977_b(), hitVec, EnumHand.MAIN_HAND, EnumFacing.UP, ((Boolean)this.packet.getValue()).booleanValue());
/*  87 */         this.wait = 0;
/*     */       } 
/*  89 */       if (((Boolean)this.web.getValue()).booleanValue() && this.wait != 0 && mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150408_cc && !target.field_70134_J && (BlockUtil.isPositionPlaceable(pos.func_177984_a(), false) == 1 || BlockUtil.isPositionPlaceable(pos.func_177984_a(), false) == 3) && mc.field_71441_e.func_72872_a(EntityMinecartTNT.class, new AxisAlignedBB(pos.func_177984_a())).isEmpty()) {
/*  90 */         InventoryUtil.switchToHotbarSlot(webSlot, false);
/*  91 */         BlockUtil.placeBlock(pos.func_177984_a(), EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), false);
/*     */       } 
/*  93 */       if (mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150408_cc) {
/*  94 */         InventoryUtil.switchToHotbarSlot(tntSlot, false);
/*  95 */         for (int u = 0; u < ((Integer)this.blocksPerTick.getValue()).intValue(); u++) {
/*  96 */           BlockUtil.rightClickBlock(pos, hitVec, EnumHand.MAIN_HAND, EnumFacing.UP, ((Boolean)this.packet.getValue()).booleanValue());
/*     */         }
/*     */       } 
/*  99 */       if (this.wait < ((Integer)this.delay.getValue()).intValue()) {
/* 100 */         this.wait++;
/*     */         return;
/*     */       } 
/* 103 */       this.check = false;
/* 104 */       this.wait = 0;
/* 105 */       InventoryUtil.switchToHotbarSlot(picSlot, false);
/* 106 */       if (mc.field_71441_e.func_180495_p(pos).func_177230_c() == Blocks.field_150408_cc && !mc.field_71441_e.func_72872_a(EntityMinecartTNT.class, new AxisAlignedBB(pos)).isEmpty()) {
/* 107 */         mc.field_71442_b.func_180512_c(pos, EnumFacing.UP);
/*     */       }
/* 109 */       InventoryUtil.switchToHotbarSlot(flintSlot, false);
/* 110 */       if (mc.field_71441_e.func_180495_p(pos).func_177230_c().func_176194_O().func_177621_b().func_185904_a() != Material.field_151581_o && !mc.field_71441_e.func_72872_a(EntityMinecartTNT.class, new AxisAlignedBB(pos)).isEmpty()) {
/* 111 */         BlockUtil.rightClickBlock(pos.func_177977_b(), hitVec, EnumHand.MAIN_HAND, EnumFacing.UP, ((Boolean)this.packet.getValue()).booleanValue());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDisplayInfo() {
/* 118 */     if (this.check) {
/* 119 */       return ChatFormatting.GREEN + "Placing";
/*     */     }
/* 121 */     return ChatFormatting.RED + "Breaking";
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/* 126 */     mc.field_71439_g.field_71071_by.field_70461_c = this.originalSlot;
/*     */   }
/*     */   
/*     */   private EntityPlayer getTarget() {
/* 130 */     EntityPlayer target = null;
/* 131 */     double distance = Math.pow(6.0D, 2.0D) + 1.0D;
/* 132 */     for (EntityPlayer player : mc.field_71441_e.field_73010_i) {
/* 133 */       if (EntityUtil.isntValid((Entity)player, 6.0D) || player.func_70090_H() || player.func_180799_ab() || !EntityUtil.isTrapped(player, false, false, false, false, false) || player.func_110143_aJ() + player.func_110139_bj() > ((Float)this.minHP.getValue()).floatValue())
/*     */         continue; 
/* 135 */       if (target == null) {
/* 136 */         target = player;
/* 137 */         distance = mc.field_71439_g.func_70068_e((Entity)player);
/*     */         continue;
/*     */       } 
/* 140 */       if (mc.field_71439_g.func_70068_e((Entity)player) >= distance)
/* 141 */         continue;  target = player;
/* 142 */       distance = mc.field_71439_g.func_70068_e((Entity)player);
/*     */     } 
/* 144 */     return target;
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/combat/AutoMinecart.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */