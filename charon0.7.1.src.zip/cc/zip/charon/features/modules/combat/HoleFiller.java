/*     */ package cc.zip.charon.features.modules.combat;
/*     */ 
/*     */ import cc.zip.charon.features.modules.Module;
/*     */ import cc.zip.charon.features.setting.Setting;
/*     */ import cc.zip.charon.util.BlockUtil;
/*     */ import cc.zip.charon.util.EntityUtil;
/*     */ import cc.zip.charon.util.InventoryUtil;
/*     */ import cc.zip.charon.util.TestUtil;
/*     */ import cc.zip.charon.util.Timer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import net.minecraft.block.BlockEnderChest;
/*     */ import net.minecraft.block.BlockObsidian;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HoleFiller
/*     */   extends Module
/*     */ {
/*     */   private static final BlockPos[] surroundOffset;
/*  28 */   private static HoleFiller INSTANCE = new HoleFiller(); static {
/*  29 */     surroundOffset = BlockUtil.toBlockPos(EntityUtil.getOffsets(0, true));
/*     */   }
/*     */   
/*     */   private final Setting<Integer> range;
/*     */   private final Setting<Integer> delay;
/*     */   private final Setting<Integer> blocksPerTick;
/*     */   private final Timer offTimer;
/*     */   private final Timer timer;
/*     */   private final Map<BlockPos, Integer> retries;
/*     */   private final Timer retryTimer;
/*     */   private int blocksThisTick;
/*     */   private ArrayList<BlockPos> holes;
/*     */   private int trie;
/*     */   
/*     */   public HoleFiller() {
/*  44 */     super("HoleFiller", "Fills holes around you.", Module.Category.COMBAT, true, false, true);
/*  45 */     this.range = register(new Setting("PlaceRange", Integer.valueOf(8), Integer.valueOf(0), Integer.valueOf(10)));
/*  46 */     this.delay = register(new Setting("Delay", Integer.valueOf(50), Integer.valueOf(0), Integer.valueOf(250)));
/*  47 */     this.blocksPerTick = register(new Setting("BlocksPerTick", Integer.valueOf(20), Integer.valueOf(8), Integer.valueOf(30)));
/*  48 */     this.offTimer = new Timer();
/*  49 */     this.timer = new Timer();
/*  50 */     this.blocksThisTick = 0;
/*  51 */     this.retries = new HashMap<>();
/*  52 */     this.retryTimer = new Timer();
/*  53 */     this.holes = new ArrayList<>();
/*  54 */     setInstance();
/*     */   }
/*     */   
/*     */   public static HoleFiller getInstance() {
/*  58 */     if (INSTANCE == null) {
/*  59 */       INSTANCE = new HoleFiller();
/*     */     }
/*  61 */     return INSTANCE;
/*     */   }
/*     */   
/*     */   private void setInstance() {
/*  65 */     INSTANCE = this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  70 */     if (fullNullCheck()) {
/*  71 */       disable();
/*     */     }
/*  73 */     this.offTimer.reset();
/*  74 */     this.trie = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onTick() {
/*  79 */     if (isOn()) {
/*  80 */       doHoleFill();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  86 */     this.retries.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void doHoleFill() {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: invokespecial check : ()Z
/*     */     //   4: ifeq -> 8
/*     */     //   7: return
/*     */     //   8: aload_0
/*     */     //   9: new java/util/ArrayList
/*     */     //   12: dup
/*     */     //   13: invokespecial <init> : ()V
/*     */     //   16: putfield holes : Ljava/util/ArrayList;
/*     */     //   19: getstatic cc/zip/charon/features/modules/combat/HoleFiller.mc : Lnet/minecraft/client/Minecraft;
/*     */     //   22: getfield field_71439_g : Lnet/minecraft/client/entity/EntityPlayerSP;
/*     */     //   25: invokevirtual func_180425_c : ()Lnet/minecraft/util/math/BlockPos;
/*     */     //   28: aload_0
/*     */     //   29: getfield range : Lcc/zip/charon/features/setting/Setting;
/*     */     //   32: invokevirtual getValue : ()Ljava/lang/Object;
/*     */     //   35: checkcast java/lang/Integer
/*     */     //   38: invokevirtual intValue : ()I
/*     */     //   41: ineg
/*     */     //   42: aload_0
/*     */     //   43: getfield range : Lcc/zip/charon/features/setting/Setting;
/*     */     //   46: invokevirtual getValue : ()Ljava/lang/Object;
/*     */     //   49: checkcast java/lang/Integer
/*     */     //   52: invokevirtual intValue : ()I
/*     */     //   55: ineg
/*     */     //   56: aload_0
/*     */     //   57: getfield range : Lcc/zip/charon/features/setting/Setting;
/*     */     //   60: invokevirtual getValue : ()Ljava/lang/Object;
/*     */     //   63: checkcast java/lang/Integer
/*     */     //   66: invokevirtual intValue : ()I
/*     */     //   69: ineg
/*     */     //   70: invokevirtual func_177982_a : (III)Lnet/minecraft/util/math/BlockPos;
/*     */     //   73: getstatic cc/zip/charon/features/modules/combat/HoleFiller.mc : Lnet/minecraft/client/Minecraft;
/*     */     //   76: getfield field_71439_g : Lnet/minecraft/client/entity/EntityPlayerSP;
/*     */     //   79: invokevirtual func_180425_c : ()Lnet/minecraft/util/math/BlockPos;
/*     */     //   82: aload_0
/*     */     //   83: getfield range : Lcc/zip/charon/features/setting/Setting;
/*     */     //   86: invokevirtual getValue : ()Ljava/lang/Object;
/*     */     //   89: checkcast java/lang/Integer
/*     */     //   92: invokevirtual intValue : ()I
/*     */     //   95: aload_0
/*     */     //   96: getfield range : Lcc/zip/charon/features/setting/Setting;
/*     */     //   99: invokevirtual getValue : ()Ljava/lang/Object;
/*     */     //   102: checkcast java/lang/Integer
/*     */     //   105: invokevirtual intValue : ()I
/*     */     //   108: aload_0
/*     */     //   109: getfield range : Lcc/zip/charon/features/setting/Setting;
/*     */     //   112: invokevirtual getValue : ()Ljava/lang/Object;
/*     */     //   115: checkcast java/lang/Integer
/*     */     //   118: invokevirtual intValue : ()I
/*     */     //   121: invokevirtual func_177982_a : (III)Lnet/minecraft/util/math/BlockPos;
/*     */     //   124: invokestatic func_177980_a : (Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/math/BlockPos;)Ljava/lang/Iterable;
/*     */     //   127: astore_1
/*     */     //   128: aload_1
/*     */     //   129: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   134: astore_2
/*     */     //   135: aload_2
/*     */     //   136: invokeinterface hasNext : ()Z
/*     */     //   141: ifeq -> 582
/*     */     //   144: aload_2
/*     */     //   145: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   150: checkcast net/minecraft/util/math/BlockPos
/*     */     //   153: astore_3
/*     */     //   154: getstatic cc/zip/charon/features/modules/combat/HoleFiller.mc : Lnet/minecraft/client/Minecraft;
/*     */     //   157: getfield field_71441_e : Lnet/minecraft/client/multiplayer/WorldClient;
/*     */     //   160: aload_3
/*     */     //   161: invokevirtual func_180495_p : (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
/*     */     //   164: invokeinterface func_185904_a : ()Lnet/minecraft/block/material/Material;
/*     */     //   169: invokevirtual func_76230_c : ()Z
/*     */     //   172: ifne -> 579
/*     */     //   175: getstatic cc/zip/charon/features/modules/combat/HoleFiller.mc : Lnet/minecraft/client/Minecraft;
/*     */     //   178: getfield field_71441_e : Lnet/minecraft/client/multiplayer/WorldClient;
/*     */     //   181: aload_3
/*     */     //   182: iconst_0
/*     */     //   183: iconst_1
/*     */     //   184: iconst_0
/*     */     //   185: invokevirtual func_177982_a : (III)Lnet/minecraft/util/math/BlockPos;
/*     */     //   188: invokevirtual func_180495_p : (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
/*     */     //   191: invokeinterface func_185904_a : ()Lnet/minecraft/block/material/Material;
/*     */     //   196: invokevirtual func_76230_c : ()Z
/*     */     //   199: ifne -> 579
/*     */     //   202: getstatic cc/zip/charon/features/modules/combat/HoleFiller.mc : Lnet/minecraft/client/Minecraft;
/*     */     //   205: getfield field_71441_e : Lnet/minecraft/client/multiplayer/WorldClient;
/*     */     //   208: aload_3
/*     */     //   209: iconst_1
/*     */     //   210: iconst_0
/*     */     //   211: iconst_0
/*     */     //   212: invokevirtual func_177982_a : (III)Lnet/minecraft/util/math/BlockPos;
/*     */     //   215: invokevirtual func_180495_p : (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
/*     */     //   218: invokeinterface func_177230_c : ()Lnet/minecraft/block/Block;
/*     */     //   223: getstatic net/minecraft/init/Blocks.field_150357_h : Lnet/minecraft/block/Block;
/*     */     //   226: if_acmpne -> 233
/*     */     //   229: iconst_1
/*     */     //   230: goto -> 234
/*     */     //   233: iconst_0
/*     */     //   234: getstatic cc/zip/charon/features/modules/combat/HoleFiller.mc : Lnet/minecraft/client/Minecraft;
/*     */     //   237: getfield field_71441_e : Lnet/minecraft/client/multiplayer/WorldClient;
/*     */     //   240: aload_3
/*     */     //   241: iconst_1
/*     */     //   242: iconst_0
/*     */     //   243: iconst_0
/*     */     //   244: invokevirtual func_177982_a : (III)Lnet/minecraft/util/math/BlockPos;
/*     */     //   247: invokevirtual func_180495_p : (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
/*     */     //   250: invokeinterface func_177230_c : ()Lnet/minecraft/block/Block;
/*     */     //   255: getstatic net/minecraft/init/Blocks.field_150343_Z : Lnet/minecraft/block/Block;
/*     */     //   258: if_acmpne -> 265
/*     */     //   261: iconst_1
/*     */     //   262: goto -> 266
/*     */     //   265: iconst_0
/*     */     //   266: ior
/*     */     //   267: ifeq -> 559
/*     */     //   270: getstatic cc/zip/charon/features/modules/combat/HoleFiller.mc : Lnet/minecraft/client/Minecraft;
/*     */     //   273: getfield field_71441_e : Lnet/minecraft/client/multiplayer/WorldClient;
/*     */     //   276: aload_3
/*     */     //   277: iconst_0
/*     */     //   278: iconst_0
/*     */     //   279: iconst_1
/*     */     //   280: invokevirtual func_177982_a : (III)Lnet/minecraft/util/math/BlockPos;
/*     */     //   283: invokevirtual func_180495_p : (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
/*     */     //   286: invokeinterface func_177230_c : ()Lnet/minecraft/block/Block;
/*     */     //   291: getstatic net/minecraft/init/Blocks.field_150357_h : Lnet/minecraft/block/Block;
/*     */     //   294: if_acmpne -> 301
/*     */     //   297: iconst_1
/*     */     //   298: goto -> 302
/*     */     //   301: iconst_0
/*     */     //   302: getstatic cc/zip/charon/features/modules/combat/HoleFiller.mc : Lnet/minecraft/client/Minecraft;
/*     */     //   305: getfield field_71441_e : Lnet/minecraft/client/multiplayer/WorldClient;
/*     */     //   308: aload_3
/*     */     //   309: iconst_0
/*     */     //   310: iconst_0
/*     */     //   311: iconst_1
/*     */     //   312: invokevirtual func_177982_a : (III)Lnet/minecraft/util/math/BlockPos;
/*     */     //   315: invokevirtual func_180495_p : (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
/*     */     //   318: invokeinterface func_177230_c : ()Lnet/minecraft/block/Block;
/*     */     //   323: getstatic net/minecraft/init/Blocks.field_150343_Z : Lnet/minecraft/block/Block;
/*     */     //   326: if_acmpne -> 333
/*     */     //   329: iconst_1
/*     */     //   330: goto -> 334
/*     */     //   333: iconst_0
/*     */     //   334: ior
/*     */     //   335: ifeq -> 559
/*     */     //   338: getstatic cc/zip/charon/features/modules/combat/HoleFiller.mc : Lnet/minecraft/client/Minecraft;
/*     */     //   341: getfield field_71441_e : Lnet/minecraft/client/multiplayer/WorldClient;
/*     */     //   344: aload_3
/*     */     //   345: iconst_m1
/*     */     //   346: iconst_0
/*     */     //   347: iconst_0
/*     */     //   348: invokevirtual func_177982_a : (III)Lnet/minecraft/util/math/BlockPos;
/*     */     //   351: invokevirtual func_180495_p : (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
/*     */     //   354: invokeinterface func_177230_c : ()Lnet/minecraft/block/Block;
/*     */     //   359: getstatic net/minecraft/init/Blocks.field_150357_h : Lnet/minecraft/block/Block;
/*     */     //   362: if_acmpne -> 369
/*     */     //   365: iconst_1
/*     */     //   366: goto -> 370
/*     */     //   369: iconst_0
/*     */     //   370: getstatic cc/zip/charon/features/modules/combat/HoleFiller.mc : Lnet/minecraft/client/Minecraft;
/*     */     //   373: getfield field_71441_e : Lnet/minecraft/client/multiplayer/WorldClient;
/*     */     //   376: aload_3
/*     */     //   377: iconst_m1
/*     */     //   378: iconst_0
/*     */     //   379: iconst_0
/*     */     //   380: invokevirtual func_177982_a : (III)Lnet/minecraft/util/math/BlockPos;
/*     */     //   383: invokevirtual func_180495_p : (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
/*     */     //   386: invokeinterface func_177230_c : ()Lnet/minecraft/block/Block;
/*     */     //   391: getstatic net/minecraft/init/Blocks.field_150343_Z : Lnet/minecraft/block/Block;
/*     */     //   394: if_acmpne -> 401
/*     */     //   397: iconst_1
/*     */     //   398: goto -> 402
/*     */     //   401: iconst_0
/*     */     //   402: ior
/*     */     //   403: ifeq -> 559
/*     */     //   406: getstatic cc/zip/charon/features/modules/combat/HoleFiller.mc : Lnet/minecraft/client/Minecraft;
/*     */     //   409: getfield field_71441_e : Lnet/minecraft/client/multiplayer/WorldClient;
/*     */     //   412: aload_3
/*     */     //   413: iconst_0
/*     */     //   414: iconst_0
/*     */     //   415: iconst_m1
/*     */     //   416: invokevirtual func_177982_a : (III)Lnet/minecraft/util/math/BlockPos;
/*     */     //   419: invokevirtual func_180495_p : (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
/*     */     //   422: invokeinterface func_177230_c : ()Lnet/minecraft/block/Block;
/*     */     //   427: getstatic net/minecraft/init/Blocks.field_150357_h : Lnet/minecraft/block/Block;
/*     */     //   430: if_acmpne -> 437
/*     */     //   433: iconst_1
/*     */     //   434: goto -> 438
/*     */     //   437: iconst_0
/*     */     //   438: getstatic cc/zip/charon/features/modules/combat/HoleFiller.mc : Lnet/minecraft/client/Minecraft;
/*     */     //   441: getfield field_71441_e : Lnet/minecraft/client/multiplayer/WorldClient;
/*     */     //   444: aload_3
/*     */     //   445: iconst_0
/*     */     //   446: iconst_0
/*     */     //   447: iconst_m1
/*     */     //   448: invokevirtual func_177982_a : (III)Lnet/minecraft/util/math/BlockPos;
/*     */     //   451: invokevirtual func_180495_p : (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
/*     */     //   454: invokeinterface func_177230_c : ()Lnet/minecraft/block/Block;
/*     */     //   459: getstatic net/minecraft/init/Blocks.field_150343_Z : Lnet/minecraft/block/Block;
/*     */     //   462: if_acmpne -> 469
/*     */     //   465: iconst_1
/*     */     //   466: goto -> 470
/*     */     //   469: iconst_0
/*     */     //   470: ior
/*     */     //   471: ifeq -> 559
/*     */     //   474: getstatic cc/zip/charon/features/modules/combat/HoleFiller.mc : Lnet/minecraft/client/Minecraft;
/*     */     //   477: getfield field_71441_e : Lnet/minecraft/client/multiplayer/WorldClient;
/*     */     //   480: aload_3
/*     */     //   481: iconst_0
/*     */     //   482: iconst_0
/*     */     //   483: iconst_0
/*     */     //   484: invokevirtual func_177982_a : (III)Lnet/minecraft/util/math/BlockPos;
/*     */     //   487: invokevirtual func_180495_p : (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
/*     */     //   490: invokeinterface func_185904_a : ()Lnet/minecraft/block/material/Material;
/*     */     //   495: getstatic net/minecraft/block/material/Material.field_151579_a : Lnet/minecraft/block/material/Material;
/*     */     //   498: if_acmpne -> 559
/*     */     //   501: getstatic cc/zip/charon/features/modules/combat/HoleFiller.mc : Lnet/minecraft/client/Minecraft;
/*     */     //   504: getfield field_71441_e : Lnet/minecraft/client/multiplayer/WorldClient;
/*     */     //   507: aload_3
/*     */     //   508: iconst_0
/*     */     //   509: iconst_1
/*     */     //   510: iconst_0
/*     */     //   511: invokevirtual func_177982_a : (III)Lnet/minecraft/util/math/BlockPos;
/*     */     //   514: invokevirtual func_180495_p : (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
/*     */     //   517: invokeinterface func_185904_a : ()Lnet/minecraft/block/material/Material;
/*     */     //   522: getstatic net/minecraft/block/material/Material.field_151579_a : Lnet/minecraft/block/material/Material;
/*     */     //   525: if_acmpne -> 559
/*     */     //   528: getstatic cc/zip/charon/features/modules/combat/HoleFiller.mc : Lnet/minecraft/client/Minecraft;
/*     */     //   531: getfield field_71441_e : Lnet/minecraft/client/multiplayer/WorldClient;
/*     */     //   534: aload_3
/*     */     //   535: iconst_0
/*     */     //   536: iconst_2
/*     */     //   537: iconst_0
/*     */     //   538: invokevirtual func_177982_a : (III)Lnet/minecraft/util/math/BlockPos;
/*     */     //   541: invokevirtual func_180495_p : (Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/state/IBlockState;
/*     */     //   544: invokeinterface func_185904_a : ()Lnet/minecraft/block/material/Material;
/*     */     //   549: getstatic net/minecraft/block/material/Material.field_151579_a : Lnet/minecraft/block/material/Material;
/*     */     //   552: if_acmpne -> 559
/*     */     //   555: iconst_1
/*     */     //   556: goto -> 560
/*     */     //   559: iconst_0
/*     */     //   560: istore #4
/*     */     //   562: iload #4
/*     */     //   564: ifne -> 570
/*     */     //   567: goto -> 135
/*     */     //   570: aload_0
/*     */     //   571: getfield holes : Ljava/util/ArrayList;
/*     */     //   574: aload_3
/*     */     //   575: invokevirtual add : (Ljava/lang/Object;)Z
/*     */     //   578: pop
/*     */     //   579: goto -> 135
/*     */     //   582: aload_0
/*     */     //   583: getfield holes : Ljava/util/ArrayList;
/*     */     //   586: aload_0
/*     */     //   587: <illegal opcode> accept : (Lcc/zip/charon/features/modules/combat/HoleFiller;)Ljava/util/function/Consumer;
/*     */     //   592: invokevirtual forEach : (Ljava/util/function/Consumer;)V
/*     */     //   595: aload_0
/*     */     //   596: invokevirtual toggle : ()V
/*     */     //   599: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #90	-> 0
/*     */     //   #91	-> 7
/*     */     //   #93	-> 8
/*     */     //   #94	-> 19
/*     */     //   #95	-> 128
/*     */     //   #96	-> 154
/*     */     //   #97	-> 202
/*     */     //   #98	-> 562
/*     */     //   #99	-> 567
/*     */     //   #101	-> 570
/*     */     //   #103	-> 579
/*     */     //   #104	-> 582
/*     */     //   #105	-> 595
/*     */     //   #106	-> 599
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   562	17	4	solidNeighbours	Z
/*     */     //   154	425	3	pos	Lnet/minecraft/util/math/BlockPos;
/*     */     //   0	600	0	this	Lcc/zip/charon/features/modules/combat/HoleFiller;
/*     */     //   128	472	1	blocks	Ljava/lang/Iterable;
/*     */     // Local variable type table:
/*     */     //   start	length	slot	name	signature
/*     */     //   128	472	1	blocks	Ljava/lang/Iterable<Lnet/minecraft/util/math/BlockPos;>;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void placeBlock(BlockPos pos) {
/* 109 */     for (Entity entity : mc.field_71441_e.func_72839_b(null, new AxisAlignedBB(pos))) {
/* 110 */       if (entity instanceof net.minecraft.entity.EntityLivingBase) {
/*     */         return;
/*     */       }
/*     */     } 
/* 114 */     if (this.blocksThisTick < ((Integer)this.blocksPerTick.getValue()).intValue()) {
/* 115 */       int obbySlot = InventoryUtil.findHotbarBlock(BlockObsidian.class);
/* 116 */       int eChestSot = InventoryUtil.findHotbarBlock(BlockEnderChest.class);
/* 117 */       if (obbySlot == -1 && eChestSot == -1) {
/* 118 */         toggle();
/*     */       }
/* 120 */       int originalSlot = mc.field_71439_g.field_71071_by.field_70461_c;
/* 121 */       mc.field_71439_g.field_71071_by.field_70461_c = (obbySlot == -1) ? eChestSot : obbySlot;
/* 122 */       mc.field_71442_b.func_78765_e();
/* 123 */       TestUtil.placeBlock(pos);
/* 124 */       if (mc.field_71439_g.field_71071_by.field_70461_c != originalSlot) {
/* 125 */         mc.field_71439_g.field_71071_by.field_70461_c = originalSlot;
/* 126 */         mc.field_71442_b.func_78765_e();
/*     */       } 
/* 128 */       this.timer.reset();
/* 129 */       this.blocksThisTick++;
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean check() {
/* 134 */     if (fullNullCheck()) {
/* 135 */       disable();
/* 136 */       return true;
/*     */     } 
/* 138 */     this.blocksThisTick = 0;
/* 139 */     if (this.retryTimer.passedMs(2000L)) {
/* 140 */       this.retries.clear();
/* 141 */       this.retryTimer.reset();
/*     */     } 
/* 143 */     return !this.timer.passedMs(((Integer)this.delay.getValue()).intValue());
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/combat/HoleFiller.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */