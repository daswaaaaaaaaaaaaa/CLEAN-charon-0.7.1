/*     */ package cc.zip.charon.features.modules.combat;
/*     */ import cc.zip.charon.Charon;
/*     */ import cc.zip.charon.features.command.Command;
/*     */ import cc.zip.charon.features.modules.Module;
/*     */ import cc.zip.charon.features.setting.Setting;
/*     */ import cc.zip.charon.util.BlockUtil;
/*     */ import cc.zip.charon.util.EntityUtil;
/*     */ import cc.zip.charon.util.InventoryUtil;
/*     */ import cc.zip.charon.util.MathUtil;
/*     */ import cc.zip.charon.util.Timer;
/*     */ import com.mojang.realmsclient.gui.ChatFormatting;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.minecraft.block.BlockEnderChest;
/*     */ import net.minecraft.block.BlockObsidian;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ 
/*     */ public class AutoTrap extends Module {
/*  24 */   private final Setting<Integer> delay = register(new Setting("Delay", Integer.valueOf(50), Integer.valueOf(0), Integer.valueOf(250))); public static boolean isPlacing = false;
/*  25 */   private final Setting<Integer> blocksPerPlace = register(new Setting("BlocksPerTick", Integer.valueOf(8), Integer.valueOf(1), Integer.valueOf(30)));
/*  26 */   private final Setting<Boolean> rotate = register(new Setting("Rotate", Boolean.valueOf(true)));
/*  27 */   private final Setting<Boolean> raytrace = register(new Setting("Raytrace", Boolean.valueOf(false)));
/*  28 */   private final Setting<Boolean> antiScaffold = register(new Setting("AntiScaffold", Boolean.valueOf(false)));
/*  29 */   private final Setting<Boolean> antiStep = register(new Setting("AntiStep", Boolean.valueOf(false)));
/*  30 */   private final Timer timer = new Timer();
/*  31 */   private final Map<BlockPos, Integer> retries = new HashMap<>();
/*  32 */   private final Timer retryTimer = new Timer();
/*     */   public EntityPlayer target;
/*     */   private boolean didPlace = false;
/*     */   private boolean switchedItem;
/*     */   private boolean isSneaking;
/*     */   private int lastHotbarSlot;
/*  38 */   private int placements = 0;
/*     */   private boolean smartRotate = false;
/*  40 */   private BlockPos startPos = null;
/*     */   
/*     */   public AutoTrap() {
/*  43 */     super("AutoTrap", "Traps other players", Module.Category.COMBAT, true, false, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  48 */     if (fullNullCheck()) {
/*     */       return;
/*     */     }
/*  51 */     this.startPos = EntityUtil.getRoundedBlockPos((Entity)mc.field_71439_g);
/*  52 */     this.lastHotbarSlot = mc.field_71439_g.field_71071_by.field_70461_c;
/*  53 */     this.retries.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onTick() {
/*  58 */     if (fullNullCheck()) {
/*     */       return;
/*     */     }
/*  61 */     this.smartRotate = false;
/*  62 */     doTrap();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDisplayInfo() {
/*  67 */     if (this.target != null) {
/*  68 */       return this.target.func_70005_c_();
/*     */     }
/*  70 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  75 */     isPlacing = false;
/*  76 */     this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
/*     */   }
/*     */   
/*     */   private void doTrap() {
/*  80 */     if (check()) {
/*     */       return;
/*     */     }
/*  83 */     doStaticTrap();
/*  84 */     if (this.didPlace) {
/*  85 */       this.timer.reset();
/*     */     }
/*     */   }
/*     */   
/*     */   private void doStaticTrap() {
/*  90 */     List<Vec3d> placeTargets = EntityUtil.targets(this.target.func_174791_d(), ((Boolean)this.antiScaffold.getValue()).booleanValue(), ((Boolean)this.antiStep.getValue()).booleanValue(), false, false, false, ((Boolean)this.raytrace.getValue()).booleanValue());
/*  91 */     placeList(placeTargets);
/*     */   }
/*     */   
/*     */   private void placeList(List<Vec3d> list) {
/*  95 */     list.sort((vec3d, vec3d2) -> Double.compare(mc.field_71439_g.func_70092_e(vec3d2.field_72450_a, vec3d2.field_72448_b, vec3d2.field_72449_c), mc.field_71439_g.func_70092_e(vec3d.field_72450_a, vec3d.field_72448_b, vec3d.field_72449_c)));
/*  96 */     list.sort(Comparator.comparingDouble(vec3d -> vec3d.field_72448_b));
/*  97 */     for (Vec3d vec3d3 : list) {
/*  98 */       BlockPos position = new BlockPos(vec3d3);
/*  99 */       int placeability = BlockUtil.isPositionPlaceable(position, ((Boolean)this.raytrace.getValue()).booleanValue());
/* 100 */       if (placeability == 1 && (this.retries.get(position) == null || ((Integer)this.retries.get(position)).intValue() < 4)) {
/* 101 */         placeBlock(position);
/* 102 */         this.retries.put(position, Integer.valueOf((this.retries.get(position) == null) ? 1 : (((Integer)this.retries.get(position)).intValue() + 1)));
/* 103 */         this.retryTimer.reset();
/*     */         continue;
/*     */       } 
/* 106 */       if (placeability != 3)
/* 107 */         continue;  placeBlock(position);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean check() {
/* 112 */     isPlacing = false;
/* 113 */     this.didPlace = false;
/* 114 */     this.placements = 0;
/* 115 */     int obbySlot2 = InventoryUtil.findHotbarBlock(BlockObsidian.class);
/* 116 */     if (obbySlot2 == -1) {
/* 117 */       toggle();
/*     */     }
/* 119 */     int obbySlot = InventoryUtil.findHotbarBlock(BlockObsidian.class);
/* 120 */     if (isOff()) {
/* 121 */       return true;
/*     */     }
/* 123 */     if (!this.startPos.equals(EntityUtil.getRoundedBlockPos((Entity)mc.field_71439_g))) {
/* 124 */       disable();
/* 125 */       return true;
/*     */     } 
/* 127 */     if (this.retryTimer.passedMs(2000L)) {
/* 128 */       this.retries.clear();
/* 129 */       this.retryTimer.reset();
/*     */     } 
/* 131 */     if (obbySlot == -1) {
/* 132 */       Command.sendMessage("<" + getDisplayName() + "> " + ChatFormatting.RED + "No Obsidian in hotbar disabling...");
/* 133 */       disable();
/* 134 */       return true;
/*     */     } 
/* 136 */     if (mc.field_71439_g.field_71071_by.field_70461_c != this.lastHotbarSlot && mc.field_71439_g.field_71071_by.field_70461_c != obbySlot) {
/* 137 */       this.lastHotbarSlot = mc.field_71439_g.field_71071_by.field_70461_c;
/*     */     }
/* 139 */     this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
/* 140 */     this.target = getTarget(10.0D, true);
/* 141 */     return (this.target == null || !this.timer.passedMs(((Integer)this.delay.getValue()).intValue()));
/*     */   }
/*     */   
/*     */   private EntityPlayer getTarget(double range, boolean trapped) {
/* 145 */     EntityPlayer target = null;
/* 146 */     double distance = Math.pow(range, 2.0D) + 1.0D;
/* 147 */     for (EntityPlayer player : mc.field_71441_e.field_73010_i) {
/* 148 */       if (EntityUtil.isntValid((Entity)player, range) || (trapped && EntityUtil.isTrapped(player, ((Boolean)this.antiScaffold.getValue()).booleanValue(), ((Boolean)this.antiStep.getValue()).booleanValue(), false, false, false)) || Charon.speedManager.getPlayerSpeed(player) > 10.0D)
/*     */         continue; 
/* 150 */       if (target == null) {
/* 151 */         target = player;
/* 152 */         distance = mc.field_71439_g.func_70068_e((Entity)player);
/*     */         continue;
/*     */       } 
/* 155 */       if (mc.field_71439_g.func_70068_e((Entity)player) >= distance)
/* 156 */         continue;  target = player;
/* 157 */       distance = mc.field_71439_g.func_70068_e((Entity)player);
/*     */     } 
/* 159 */     return target;
/*     */   }
/*     */   
/*     */   private void placeBlock(BlockPos pos) {
/* 163 */     if (this.placements < ((Integer)this.blocksPerPlace.getValue()).intValue() && mc.field_71439_g.func_174818_b(pos) <= MathUtil.square(5.0D)) {
/* 164 */       isPlacing = true;
/* 165 */       int originalSlot = mc.field_71439_g.field_71071_by.field_70461_c;
/* 166 */       int obbySlot = InventoryUtil.findHotbarBlock(BlockObsidian.class);
/* 167 */       int eChestSot = InventoryUtil.findHotbarBlock(BlockEnderChest.class);
/* 168 */       if (obbySlot == -1 && eChestSot == -1) {
/* 169 */         toggle();
/*     */       }
/* 171 */       if (this.smartRotate) {
/* 172 */         mc.field_71439_g.field_71071_by.field_70461_c = (obbySlot == -1) ? eChestSot : obbySlot;
/* 173 */         mc.field_71442_b.func_78765_e();
/* 174 */         this.isSneaking = BlockUtil.placeBlockSmartRotate(pos, EnumHand.MAIN_HAND, true, true, this.isSneaking);
/* 175 */         mc.field_71439_g.field_71071_by.field_70461_c = originalSlot;
/* 176 */         mc.field_71442_b.func_78765_e();
/*     */       } else {
/* 178 */         mc.field_71439_g.field_71071_by.field_70461_c = (obbySlot == -1) ? eChestSot : obbySlot;
/* 179 */         mc.field_71442_b.func_78765_e();
/* 180 */         this.isSneaking = BlockUtil.placeBlock(pos, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), true, this.isSneaking);
/* 181 */         mc.field_71439_g.field_71071_by.field_70461_c = originalSlot;
/* 182 */         mc.field_71442_b.func_78765_e();
/*     */       } 
/* 184 */       this.didPlace = true;
/* 185 */       this.placements++;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/combat/AutoTrap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */