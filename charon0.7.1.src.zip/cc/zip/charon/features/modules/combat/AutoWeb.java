/*     */ package cc.zip.charon.features.modules.combat;
/*     */ import cc.zip.charon.Charon;
/*     */ import cc.zip.charon.features.command.Command;
/*     */ import cc.zip.charon.features.modules.Module;
/*     */ import cc.zip.charon.features.setting.Setting;
/*     */ import cc.zip.charon.util.BlockUtil;
/*     */ import cc.zip.charon.util.EntityUtil;
/*     */ import cc.zip.charon.util.InventoryUtil;
/*     */ import cc.zip.charon.util.MathUtil;
/*     */ import cc.zip.charon.util.Timer;
/*     */ import com.mojang.realmsclient.gui.ChatFormatting;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.block.BlockWeb;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ 
/*     */ public class AutoWeb extends Module {
/*  22 */   private final Setting<Integer> delay = register(new Setting("Delay", Integer.valueOf(50), Integer.valueOf(0), Integer.valueOf(250))); public static boolean isPlacing = false;
/*  23 */   private final Setting<Integer> blocksPerPlace = register(new Setting("BlocksPerTick", Integer.valueOf(8), Integer.valueOf(1), Integer.valueOf(30)));
/*  24 */   private final Setting<Boolean> packet = register(new Setting("PacketPlace", Boolean.valueOf(false)));
/*  25 */   private final Setting<Boolean> disable = register(new Setting("AutoDisable", Boolean.valueOf(false)));
/*  26 */   private final Setting<Boolean> rotate = register(new Setting("Rotate", Boolean.valueOf(true)));
/*  27 */   private final Setting<Boolean> raytrace = register(new Setting("Raytrace", Boolean.valueOf(false)));
/*  28 */   private final Setting<Boolean> lowerbody = register(new Setting("Feet", Boolean.valueOf(true)));
/*  29 */   private final Setting<Boolean> upperBody = register(new Setting("Face", Boolean.valueOf(false)));
/*  30 */   private final Timer timer = new Timer();
/*     */   public EntityPlayer target;
/*     */   private boolean didPlace = false;
/*     */   private boolean switchedItem;
/*     */   private boolean isSneaking;
/*     */   private int lastHotbarSlot;
/*  36 */   private int placements = 0;
/*     */   private boolean smartRotate = false;
/*  38 */   private BlockPos startPos = null;
/*     */   
/*     */   public AutoWeb() {
/*  41 */     super("AutoWeb", "Traps other players in webs", Module.Category.COMBAT, true, false, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  46 */     if (fullNullCheck()) {
/*     */       return;
/*     */     }
/*  49 */     this.startPos = EntityUtil.getRoundedBlockPos((Entity)mc.field_71439_g);
/*  50 */     this.lastHotbarSlot = mc.field_71439_g.field_71071_by.field_70461_c;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onTick() {
/*  55 */     this.smartRotate = false;
/*  56 */     doTrap();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDisplayInfo() {
/*  61 */     if (this.target != null) {
/*  62 */       return this.target.func_70005_c_();
/*     */     }
/*  64 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  69 */     isPlacing = false;
/*  70 */     this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
/*  71 */     switchItem(true);
/*     */   }
/*     */   
/*     */   private void doTrap() {
/*  75 */     if (check()) {
/*     */       return;
/*     */     }
/*  78 */     doWebTrap();
/*  79 */     if (this.didPlace) {
/*  80 */       this.timer.reset();
/*     */     }
/*     */   }
/*     */   
/*     */   private void doWebTrap() {
/*  85 */     List<Vec3d> placeTargets = getPlacements();
/*  86 */     placeList(placeTargets);
/*     */   }
/*     */   
/*     */   private List<Vec3d> getPlacements() {
/*  90 */     ArrayList<Vec3d> list = new ArrayList<>();
/*  91 */     Vec3d baseVec = this.target.func_174791_d();
/*  92 */     if (((Boolean)this.lowerbody.getValue()).booleanValue()) {
/*  93 */       list.add(baseVec);
/*     */     }
/*  95 */     if (((Boolean)this.upperBody.getValue()).booleanValue()) {
/*  96 */       list.add(baseVec.func_72441_c(0.0D, 1.0D, 0.0D));
/*     */     }
/*  98 */     return list;
/*     */   }
/*     */   
/*     */   private void placeList(List<Vec3d> list) {
/* 102 */     list.sort((vec3d, vec3d2) -> Double.compare(mc.field_71439_g.func_70092_e(vec3d2.field_72450_a, vec3d2.field_72448_b, vec3d2.field_72449_c), mc.field_71439_g.func_70092_e(vec3d.field_72450_a, vec3d.field_72448_b, vec3d.field_72449_c)));
/* 103 */     list.sort(Comparator.comparingDouble(vec3d -> vec3d.field_72448_b));
/* 104 */     for (Vec3d vec3d3 : list) {
/* 105 */       BlockPos position = new BlockPos(vec3d3);
/* 106 */       int placeability = BlockUtil.isPositionPlaceable(position, ((Boolean)this.raytrace.getValue()).booleanValue());
/* 107 */       if (placeability != 3 && placeability != 1)
/* 108 */         continue;  placeBlock(position);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean check() {
/* 113 */     isPlacing = false;
/* 114 */     this.didPlace = false;
/* 115 */     this.placements = 0;
/* 116 */     int obbySlot = InventoryUtil.findHotbarBlock(BlockWeb.class);
/* 117 */     if (isOff()) {
/* 118 */       return true;
/*     */     }
/* 120 */     if (((Boolean)this.disable.getValue()).booleanValue() && !this.startPos.equals(EntityUtil.getRoundedBlockPos((Entity)mc.field_71439_g))) {
/* 121 */       disable();
/* 122 */       return true;
/*     */     } 
/* 124 */     if (obbySlot == -1) {
/* 125 */       Command.sendMessage("<" + getDisplayName() + "> " + ChatFormatting.RED + "No Webs in hotbar disabling...");
/* 126 */       toggle();
/* 127 */       return true;
/*     */     } 
/* 129 */     if (mc.field_71439_g.field_71071_by.field_70461_c != this.lastHotbarSlot && mc.field_71439_g.field_71071_by.field_70461_c != obbySlot) {
/* 130 */       this.lastHotbarSlot = mc.field_71439_g.field_71071_by.field_70461_c;
/*     */     }
/* 132 */     switchItem(true);
/* 133 */     this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
/* 134 */     this.target = getTarget(10.0D);
/* 135 */     return (this.target == null || !this.timer.passedMs(((Integer)this.delay.getValue()).intValue()));
/*     */   }
/*     */   
/*     */   private EntityPlayer getTarget(double range) {
/* 139 */     EntityPlayer target = null;
/* 140 */     double distance = Math.pow(range, 2.0D) + 1.0D;
/* 141 */     for (EntityPlayer player : mc.field_71441_e.field_73010_i) {
/* 142 */       if (EntityUtil.isntValid((Entity)player, range) || player.field_70134_J || Charon.speedManager.getPlayerSpeed(player) > 30.0D)
/*     */         continue; 
/* 144 */       if (target == null) {
/* 145 */         target = player;
/* 146 */         distance = mc.field_71439_g.func_70068_e((Entity)player);
/*     */         continue;
/*     */       } 
/* 149 */       if (mc.field_71439_g.func_70068_e((Entity)player) >= distance)
/* 150 */         continue;  target = player;
/* 151 */       distance = mc.field_71439_g.func_70068_e((Entity)player);
/*     */     } 
/* 153 */     return target;
/*     */   }
/*     */   
/*     */   private void placeBlock(BlockPos pos) {
/* 157 */     if (this.placements < ((Integer)this.blocksPerPlace.getValue()).intValue() && mc.field_71439_g.func_174818_b(pos) <= MathUtil.square(6.0D) && switchItem(false)) {
/* 158 */       isPlacing = true;
/* 159 */       this.isSneaking = this.smartRotate ? BlockUtil.placeBlockSmartRotate(pos, EnumHand.MAIN_HAND, true, ((Boolean)this.packet.getValue()).booleanValue(), this.isSneaking) : BlockUtil.placeBlock(pos, EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.packet.getValue()).booleanValue(), this.isSneaking);
/* 160 */       this.didPlace = true;
/* 161 */       this.placements++;
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean switchItem(boolean back) {
/* 166 */     boolean[] value = InventoryUtil.switchItem(back, this.lastHotbarSlot, this.switchedItem, InventoryUtil.Switch.NORMAL, BlockWeb.class);
/* 167 */     this.switchedItem = value[0];
/* 168 */     return value[1];
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/combat/AutoWeb.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */