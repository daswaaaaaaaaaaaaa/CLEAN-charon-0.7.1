/*    */ package cc.zip.charon.features.modules.combat;
/*    */ 
/*    */ import cc.zip.charon.Charon;
/*    */ import cc.zip.charon.features.modules.Module;
/*    */ import cc.zip.charon.features.setting.Setting;
/*    */ import cc.zip.charon.util.InventoryUtil;
/*    */ import cc.zip.charon.util.MappingUtil;
/*    */ import cc.zip.charon.util.Util;
/*    */ import cc.zip.charon.util.WorldUtil;
/*    */ import java.lang.reflect.Field;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.init.Blocks;
/*    */ import net.minecraft.network.Packet;
/*    */ import net.minecraft.network.play.client.CPacketChatMessage;
/*    */ import net.minecraft.network.play.client.CPacketPlayer;
/*    */ import net.minecraft.util.Timer;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ 
/*    */ public class SelfFill
/*    */   extends Module {
/*    */   private BlockPos playerPos;
/* 22 */   private final Setting<Modes> mode = register(new Setting("Settings", Modes.Silent));
/* 23 */   private final Setting<Boolean> test2 = register(new Setting("Test", Boolean.valueOf(false), v -> (this.mode.getValue() == Modes.Silent)));
/* 24 */   private final Setting<Boolean> futureBeta = register(new Setting("SilentJump", Boolean.valueOf(false), v -> (this.mode.getValue() == Modes.Silent)));
/* 25 */   private final Setting<Boolean> toggleRStep = register(new Setting("ToggleRStep", Boolean.valueOf(false), v -> (this.mode.getValue() == Modes.Silent)));
/* 26 */   private final Setting<Boolean> test = register(new Setting("Test", Boolean.valueOf(false), v -> (this.mode.getValue() == Modes.Silent)));
/* 27 */   private final Setting<Settings> setting = register(new Setting("Settings", Settings.Obsidian, v -> (this.mode.getValue() == Modes.Silent)));
/*    */   public SelfFill() {
/* 29 */     super("Burrow", "SelfFills yourself in a hole.", Module.Category.MOVEMENT, true, false, true);
/*    */   }
/*    */   
/*    */   public enum Settings {
/* 33 */     Obsidian, EnderChest; }
/* 34 */   public enum Modes { Silent, SuolOp; }
/*    */ 
/*    */ 
/*    */   
/*    */   public void onEnable() {
/* 39 */     if (this.mode.getValue() == Modes.Silent) {
/* 40 */       if (((Boolean)this.futureBeta.getValue()).booleanValue()) setTimer(50.0F); 
/* 41 */       if (((Boolean)this.toggleRStep.getValue()).booleanValue()) Charon.moduleManager.getModuleByName("ReverseStep").disable(); 
/* 42 */       this.playerPos = new BlockPos(Util.mc.field_71439_g.field_70165_t, Util.mc.field_71439_g.field_70163_u, Util.mc.field_71439_g.field_70161_v);
/* 43 */       if (this.setting.getValue() == Settings.Obsidian && 
/* 44 */         Util.mc.field_71441_e.func_180495_p(this.playerPos).func_177230_c().equals(Blocks.field_150343_Z)) {
/* 45 */         disable();
/*    */         
/*    */         return;
/*    */       } 
/* 49 */       if (this.setting.getValue() == Settings.EnderChest && 
/* 50 */         Util.mc.field_71441_e.func_180495_p(this.playerPos).func_177230_c().equals(Blocks.field_150477_bB)) {
/* 51 */         disable();
/*    */         
/*    */         return;
/*    */       } 
/*    */       
/* 56 */       Util.mc.field_71439_g.func_70664_aZ();
/*    */     } 
/* 58 */     if (this.mode.getValue() == Modes.SuolOp) { mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketChatMessage("/setblock ~ ~ ~ obsidian")); disable(); }
/*    */   
/*    */   }
/*    */   public void onDisable() {
/* 62 */     if (this.mode.getValue() == Modes.Silent) { if (((Boolean)this.toggleRStep.getValue()).booleanValue()) Charon.moduleManager.getModuleByName("ReverseStep").enable();  setTimer(1.0F); }
/*    */   
/*    */   }
/*    */   
/*    */   public void onUpdate() {
/* 67 */     if (this.mode.getValue() == Modes.Silent) {
/* 68 */       if (nullCheck()) {
/*    */         return;
/*    */       }
/* 71 */       if (Util.mc.field_71439_g.field_70163_u > this.playerPos.func_177956_o() + 1.04D) {
/*    */         
/* 73 */         if (((Boolean)this.test2.getValue()).booleanValue()) mc.func_147114_u().func_147297_a((Packet)new CPacketPlayer.Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + 3.0D, mc.field_71439_g.field_70161_v, false)); 
/* 74 */         if (this.setting.getValue() == Settings.Obsidian) WorldUtil.placeBlock(this.playerPos, InventoryUtil.findHotbarBlock(Blocks.field_150343_Z)); 
/* 75 */         if (this.setting.getValue() == Settings.EnderChest) WorldUtil.placeBlock(this.playerPos, InventoryUtil.findHotbarBlock(Blocks.field_150477_bB)); 
/* 76 */         if (((Boolean)this.test2.getValue()).booleanValue()) mc.func_147114_u().func_147297_a((Packet)new CPacketPlayer.Position(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u - 3.0D, mc.field_71439_g.field_70161_v, true)); 
/* 77 */         if (!((Boolean)this.test2.getValue()).booleanValue()) Util.mc.field_71439_g.func_70664_aZ(); 
/* 78 */         disable();
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public String getDisplayInfo() {
/* 85 */     if (this.mode.getValue() == Modes.Silent) return "SemiFast"; 
/* 86 */     if (this.mode.getValue() == Modes.SuolOp) return "SuolFill"; 
/* 87 */     return "Burrow";
/*    */   }
/*    */   
/*    */   private void setTimer(float value) {
/*    */     try {
/* 92 */       Field timer = Minecraft.class.getDeclaredField(MappingUtil.timer);
/* 93 */       timer.setAccessible(true);
/* 94 */       Field tickLength = Timer.class.getDeclaredField(MappingUtil.tickLength);
/* 95 */       tickLength.setAccessible(true);
/* 96 */       tickLength.setFloat(timer.get(Util.mc), 50.0F / value);
/*    */     }
/* 98 */     catch (Exception e) {
/* 99 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/combat/SelfFill.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */