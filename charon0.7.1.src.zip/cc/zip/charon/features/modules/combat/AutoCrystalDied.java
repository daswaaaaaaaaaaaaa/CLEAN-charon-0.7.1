/*     */ package cc.zip.charon.features.modules.combat;
/*     */ import cc.zip.charon.Charon;
/*     */ import cc.zip.charon.event.events.PacketEvent;
/*     */ import cc.zip.charon.features.modules.Module;
/*     */ import cc.zip.charon.features.modules.client.ClickGui;
/*     */ import cc.zip.charon.features.modules.misc.AutoGG;
/*     */ import cc.zip.charon.features.setting.Setting;
/*     */ import cc.zip.charon.util.ColorUtil;
/*     */ import cc.zip.charon.util.EntityUtil;
/*     */ import cc.zip.charon.util.RenderUtil;
/*     */ import cc.zip.charon.util.Timer;
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.SharedMonsterAttributes;
/*     */ import net.minecraft.entity.item.EntityEnderCrystal;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.init.MobEffects;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketPlayer;
/*     */ import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
/*     */ import net.minecraft.network.play.client.CPacketUseEntity;
/*     */ import net.minecraft.network.play.server.SPacketSpawnObject;
/*     */ import net.minecraft.util.CombatRules;
/*     */ import net.minecraft.util.DamageSource;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.NonNullList;
/*     */ import net.minecraft.util.math.AxisAlignedBB;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.RayTraceResult;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ import net.minecraft.world.Explosion;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ public class AutoCrystalDied extends Module {
/*  41 */   private final Timer placeTimer = new Timer();
/*  42 */   private final Timer breakTimer = new Timer();
/*  43 */   private final Timer preditTimer = new Timer();
/*  44 */   private final Timer manualTimer = new Timer();
/*  45 */   private final Setting<Integer> attackFactor = register(new Setting("PredictDelay", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(200)));
/*  46 */   private final Setting<Integer> red = register(new Setting("Red", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255)));
/*  47 */   private final Setting<Integer> green = register(new Setting("Green", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255)));
/*  48 */   private final Setting<Integer> blue = register(new Setting("Blue", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255)));
/*  49 */   private final Setting<Integer> alpha = register(new Setting("Alpha", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255)));
/*  50 */   private final Setting<Integer> boxAlpha = register(new Setting("BoxAlpha", Integer.valueOf(125), Integer.valueOf(0), Integer.valueOf(255)));
/*  51 */   private final Setting<Float> lineWidth = register(new Setting("LineWidth", Float.valueOf(1.0F), Float.valueOf(0.1F), Float.valueOf(5.0F)));
/*  52 */   public Setting<Boolean> place = register(new Setting("Place", Boolean.valueOf(true)));
/*  53 */   public Setting<Float> placeDelay = register(new Setting("PlaceDelay", Float.valueOf(4.0F), Float.valueOf(0.0F), Float.valueOf(300.0F)));
/*  54 */   public Setting<Float> placeRange = register(new Setting("PlaceRange", Float.valueOf(4.0F), Float.valueOf(0.1F), Float.valueOf(7.0F)));
/*  55 */   public Setting<Boolean> explode = register(new Setting("Break", Boolean.valueOf(true)));
/*  56 */   public Setting<Boolean> packetBreak = register(new Setting("PacketBreak", Boolean.valueOf(true)));
/*  57 */   public Setting<Boolean> predicts = register(new Setting("Predict", Boolean.valueOf(true)));
/*  58 */   public Setting<Boolean> rotate = register(new Setting("Rotate", Boolean.valueOf(true)));
/*  59 */   public Setting<Float> breakDelay = register(new Setting("BreakDelay", Float.valueOf(4.0F), Float.valueOf(0.0F), Float.valueOf(300.0F)));
/*  60 */   public Setting<Float> breakRange = register(new Setting("BreakRange", Float.valueOf(4.0F), Float.valueOf(0.1F), Float.valueOf(7.0F)));
/*  61 */   public Setting<Float> breakWallRange = register(new Setting("BreakWallRange", Float.valueOf(4.0F), Float.valueOf(0.1F), Float.valueOf(7.0F)));
/*  62 */   public Setting<Boolean> opPlace = register(new Setting("1.13 Place", Boolean.valueOf(true)));
/*  63 */   public Setting<Boolean> suicide = register(new Setting("AntiSuicide", Boolean.valueOf(true)));
/*  64 */   public Setting<Boolean> autoswitch = register(new Setting("AutoSwitch", Boolean.valueOf(true)));
/*  65 */   public Setting<Boolean> ignoreUseAmount = register(new Setting("IgnoreUseAmount", Boolean.valueOf(true)));
/*  66 */   public Setting<Integer> wasteAmount = register(new Setting("UseAmount", Integer.valueOf(4), Integer.valueOf(1), Integer.valueOf(5)));
/*  67 */   public Setting<Boolean> facePlaceSword = register(new Setting("FacePlaceSword", Boolean.valueOf(true)));
/*  68 */   public Setting<Float> targetRange = register(new Setting("TargetRange", Float.valueOf(4.0F), Float.valueOf(1.0F), Float.valueOf(12.0F)));
/*  69 */   public Setting<Float> minDamage = register(new Setting("MinDamage", Float.valueOf(4.0F), Float.valueOf(0.1F), Float.valueOf(20.0F)));
/*  70 */   public Setting<Float> facePlace = register(new Setting("FacePlaceHP", Float.valueOf(4.0F), Float.valueOf(0.0F), Float.valueOf(36.0F)));
/*  71 */   public Setting<Float> breakMaxSelfDamage = register(new Setting("BreakMaxSelf", Float.valueOf(4.0F), Float.valueOf(0.1F), Float.valueOf(12.0F)));
/*  72 */   public Setting<Float> breakMinDmg = register(new Setting("BreakMinDmg", Float.valueOf(4.0F), Float.valueOf(0.1F), Float.valueOf(7.0F)));
/*  73 */   public Setting<Float> minArmor = register(new Setting("MinArmor", Float.valueOf(4.0F), Float.valueOf(0.1F), Float.valueOf(80.0F)));
/*  74 */   public Setting<SwingMode> swingMode = register(new Setting("Swing", SwingMode.MainHand));
/*  75 */   public Setting<Boolean> render = register(new Setting("Render", Boolean.valueOf(true)));
/*  76 */   public Setting<Boolean> renderDmg = register(new Setting("RenderDmg", Boolean.valueOf(true)));
/*  77 */   public Setting<Boolean> box = register(new Setting("Box", Boolean.valueOf(true)));
/*  78 */   public Setting<Boolean> outline = register(new Setting("Outline", Boolean.valueOf(true)));
/*  79 */   private final Setting<Integer> cRed = register(new Setting("OL-Red", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), v -> ((Boolean)this.outline.getValue()).booleanValue()));
/*  80 */   private final Setting<Integer> cGreen = register(new Setting("OL-Green", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), v -> ((Boolean)this.outline.getValue()).booleanValue()));
/*  81 */   private final Setting<Integer> cBlue = register(new Setting("OL-Blue", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), v -> ((Boolean)this.outline.getValue()).booleanValue()));
/*  82 */   private final Setting<Integer> cAlpha = register(new Setting("OL-Alpha", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), v -> ((Boolean)this.outline.getValue()).booleanValue()));
/*     */   EntityEnderCrystal crystal;
/*     */   private EntityLivingBase target;
/*     */   private BlockPos pos;
/*     */   private int hotBarSlot;
/*     */   private boolean armor;
/*     */   private boolean armorTarget;
/*     */   private int crystalCount;
/*     */   private int predictWait;
/*     */   private int predictPackets;
/*     */   private boolean packetCalc;
/*  93 */   private float yaw = 0.0F;
/*     */   private EntityLivingBase realTarget;
/*     */   private int predict;
/*  96 */   private float pitch = 0.0F;
/*     */   private boolean rotating = false;
/*     */   
/*     */   public AutoCrystalDied() {
/* 100 */     super("AutoCrystalOyv", "NiggaHack ac best ac", Module.Category.COMBAT, true, false, false);
/*     */   }
/*     */   
/*     */   public static List<BlockPos> getSphere(BlockPos loc, float r, int h, boolean hollow, boolean sphere, int plus_y) {
/* 104 */     ArrayList<BlockPos> circleblocks = new ArrayList<>();
/* 105 */     int cx = loc.func_177958_n();
/* 106 */     int cy = loc.func_177956_o();
/* 107 */     int cz = loc.func_177952_p();
/* 108 */     int x = cx - (int)r;
/* 109 */     while (x <= cx + r) {
/* 110 */       int z = cz - (int)r;
/* 111 */       while (z <= cz + r) {
/* 112 */         int y = sphere ? (cy - (int)r) : cy;
/*     */         
/*     */         while (true) {
/* 115 */           float f = sphere ? (cy + r) : (cy + h), f2 = f;
/* 116 */           if (y >= f)
/* 117 */             break;  double dist = ((cx - x) * (cx - x) + (cz - z) * (cz - z) + (sphere ? ((cy - y) * (cy - y)) : 0));
/* 118 */           if (dist < (r * r) && (!hollow || dist >= ((r - 1.0F) * (r - 1.0F)))) {
/* 119 */             BlockPos l = new BlockPos(x, y + plus_y, z);
/* 120 */             circleblocks.add(l);
/*     */           } 
/* 122 */           y++;
/*     */         } 
/* 124 */         z++;
/*     */       } 
/* 126 */       x++;
/*     */     } 
/* 128 */     return circleblocks;
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onPacketSend(PacketEvent.Send event) {
/* 133 */     if (event.getStage() == 0 && ((Boolean)this.rotate.getValue()).booleanValue() && this.rotating && event.getPacket() instanceof CPacketPlayer) {
/* 134 */       CPacketPlayer packet = (CPacketPlayer)event.getPacket();
/* 135 */       packet.field_149476_e = this.yaw;
/* 136 */       packet.field_149473_f = this.pitch;
/* 137 */       this.rotating = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void rotateTo(Entity entity) {
/* 142 */     if (((Boolean)this.rotate.getValue()).booleanValue()) {
/* 143 */       float[] angle = MathUtil.calcAngle(mc.field_71439_g.func_174824_e(mc.func_184121_ak()), entity.func_174791_d());
/* 144 */       this.yaw = angle[0];
/* 145 */       this.pitch = angle[1];
/* 146 */       this.rotating = true;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void rotateToPos(BlockPos pos) {
/* 151 */     if (((Boolean)this.rotate.getValue()).booleanValue()) {
/* 152 */       float[] angle = MathUtil.calcAngle(mc.field_71439_g.func_174824_e(mc.func_184121_ak()), new Vec3d((pos.func_177958_n() + 0.5F), (pos.func_177956_o() - 0.5F), (pos.func_177952_p() + 0.5F)));
/* 153 */       this.yaw = angle[0];
/* 154 */       this.pitch = angle[1];
/* 155 */       this.rotating = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/* 161 */     this.placeTimer.reset();
/* 162 */     this.breakTimer.reset();
/* 163 */     this.predictWait = 0;
/* 164 */     this.hotBarSlot = -1;
/* 165 */     this.pos = null;
/* 166 */     this.crystal = null;
/* 167 */     this.predict = 0;
/* 168 */     this.predictPackets = 1;
/* 169 */     this.target = null;
/* 170 */     this.packetCalc = false;
/* 171 */     this.realTarget = null;
/* 172 */     this.armor = false;
/* 173 */     this.armorTarget = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/* 178 */     this.rotating = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onTick() {
/* 183 */     onCrystal();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDisplayInfo() {
/* 188 */     if (this.realTarget != null) {
/* 189 */       return this.realTarget.func_70005_c_();
/*     */     }
/* 191 */     return null;
/*     */   }
/*     */   
/*     */   public void onCrystal() {
/* 195 */     if (mc.field_71441_e == null || mc.field_71439_g == null) {
/*     */       return;
/*     */     }
/* 198 */     this.realTarget = null;
/* 199 */     manualBreaker();
/* 200 */     this.crystalCount = 0;
/* 201 */     if (!((Boolean)this.ignoreUseAmount.getValue()).booleanValue()) {
/* 202 */       for (Entity crystal : mc.field_71441_e.field_72996_f) {
/* 203 */         if (!(crystal instanceof EntityEnderCrystal) || !IsValidCrystal(crystal))
/* 204 */           continue;  boolean count = false;
/* 205 */         double damage = calculateDamage(this.target.func_180425_c().func_177958_n() + 0.5D, this.target.func_180425_c().func_177956_o() + 1.0D, this.target.func_180425_c().func_177952_p() + 0.5D, (Entity)this.target);
/* 206 */         if (damage >= ((Float)this.minDamage.getValue()).floatValue()) {
/* 207 */           count = true;
/*     */         }
/* 209 */         if (!count)
/* 210 */           continue;  this.crystalCount++;
/*     */       } 
/*     */     }
/* 213 */     this.hotBarSlot = -1;
/* 214 */     if (mc.field_71439_g.func_184592_cb().func_77973_b() != Items.field_185158_cP) {
/*     */       
/* 216 */       int crystalSlot = (mc.field_71439_g.func_184614_ca().func_77973_b() == Items.field_185158_cP) ? mc.field_71439_g.field_71071_by.field_70461_c : -1, n = crystalSlot;
/* 217 */       if (crystalSlot == -1) {
/* 218 */         for (int l = 0; l < 9; ) {
/* 219 */           if (mc.field_71439_g.field_71071_by.func_70301_a(l).func_77973_b() != Items.field_185158_cP) { l++; continue; }
/* 220 */            crystalSlot = l;
/* 221 */           this.hotBarSlot = l;
/*     */         } 
/*     */       }
/*     */       
/* 225 */       if (crystalSlot == -1) {
/* 226 */         this.pos = null;
/* 227 */         this.target = null;
/*     */         return;
/*     */       } 
/*     */     } 
/* 231 */     if (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151153_ao && mc.field_71439_g.func_184614_ca().func_77973_b() != Items.field_185158_cP) {
/* 232 */       this.pos = null;
/* 233 */       this.target = null;
/*     */       return;
/*     */     } 
/* 236 */     if (this.target == null) {
/* 237 */       this.target = (EntityLivingBase)getTarget();
/*     */     }
/* 239 */     if (this.target == null) {
/* 240 */       this.crystal = null;
/*     */       return;
/*     */     } 
/* 243 */     if (this.target.func_70032_d((Entity)mc.field_71439_g) > 12.0F) {
/* 244 */       this.crystal = null;
/* 245 */       this.target = null;
/*     */     } 
/* 247 */     this.crystal = mc.field_71441_e.field_72996_f.stream().filter(this::IsValidCrystal).map(p_Entity -> (EntityEnderCrystal)p_Entity).min(Comparator.comparing(p_Entity -> Float.valueOf(this.target.func_70032_d((Entity)p_Entity)))).orElse(null);
/* 248 */     if (this.crystal != null && ((Boolean)this.explode.getValue()).booleanValue() && this.breakTimer.passedMs(((Float)this.breakDelay.getValue()).longValue())) {
/* 249 */       this.breakTimer.reset();
/* 250 */       if (((Boolean)this.packetBreak.getValue()).booleanValue()) {
/* 251 */         rotateTo((Entity)this.crystal);
/* 252 */         mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketUseEntity((Entity)this.crystal));
/*     */       } else {
/* 254 */         rotateTo((Entity)this.crystal);
/* 255 */         mc.field_71442_b.func_78764_a((EntityPlayer)mc.field_71439_g, (Entity)this.crystal);
/*     */       } 
/* 257 */       if (this.swingMode.getValue() == SwingMode.MainHand) {
/* 258 */         mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
/* 259 */       } else if (this.swingMode.getValue() == SwingMode.OffHand) {
/* 260 */         mc.field_71439_g.func_184609_a(EnumHand.OFF_HAND);
/*     */       } 
/*     */     } 
/* 263 */     if (this.placeTimer.passedMs(((Float)this.placeDelay.getValue()).longValue()) && ((Boolean)this.place.getValue()).booleanValue()) {
/* 264 */       this.placeTimer.reset();
/* 265 */       double damage = 0.5D;
/* 266 */       for (BlockPos blockPos : placePostions(((Float)this.placeRange.getValue()).floatValue())) {
/*     */         double targetRange;
/*     */         
/* 269 */         if (blockPos == null || this.target == null || !mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(blockPos)).isEmpty() || (targetRange = this.target.func_70011_f(blockPos.func_177958_n(), blockPos.func_177956_o(), blockPos.func_177952_p())) > ((Float)this.targetRange.getValue()).floatValue() || this.target.field_70128_L || this.target.func_110143_aJ() + this.target.func_110139_bj() <= 0.0F)
/*     */           continue; 
/* 271 */         double targetDmg = calculateDamage(blockPos.func_177958_n() + 0.5D, blockPos.func_177956_o() + 1.0D, blockPos.func_177952_p() + 0.5D, (Entity)this.target);
/* 272 */         this.armor = false;
/* 273 */         for (ItemStack is : this.target.func_184193_aE()) {
/* 274 */           float green = (is.func_77958_k() - is.func_77952_i()) / is.func_77958_k();
/* 275 */           float red = 1.0F - green;
/* 276 */           int dmg = 100 - (int)(red * 100.0F);
/* 277 */           if (dmg > ((Float)this.minArmor.getValue()).floatValue())
/* 278 */             continue;  this.armor = true;
/*     */         } 
/* 280 */         if (targetDmg < ((Float)this.minDamage.getValue()).floatValue() && (((Boolean)this.facePlaceSword.getValue()).booleanValue() ? (this.target.func_110139_bj() + this.target.func_110143_aJ() > ((Float)this.facePlace.getValue()).floatValue()) : (mc.field_71439_g.func_184614_ca().func_77973_b() instanceof net.minecraft.item.ItemSword || this.target.func_110139_bj() + this.target.func_110143_aJ() > ((Float)this.facePlace.getValue()).floatValue())) && (((Boolean)this.facePlaceSword.getValue()).booleanValue() ? !this.armor : (mc.field_71439_g.func_184614_ca().func_77973_b() instanceof net.minecraft.item.ItemSword || !this.armor))) continue;  double selfDmg; if (((selfDmg = calculateDamage(blockPos.func_177958_n() + 0.5D, blockPos.func_177956_o() + 1.0D, blockPos.func_177952_p() + 0.5D, (Entity)mc.field_71439_g)) + (((Boolean)this.suicide.getValue()).booleanValue() ? 2.0D : 0.5D) >= (mc.field_71439_g.func_110143_aJ() + mc.field_71439_g.func_110139_bj()) && selfDmg >= targetDmg && targetDmg < (this.target.func_110143_aJ() + this.target.func_110139_bj())) || damage >= targetDmg)
/*     */           continue; 
/* 282 */         this.pos = blockPos;
/* 283 */         damage = targetDmg;
/*     */       } 
/* 285 */       if (damage == 0.5D) {
/* 286 */         this.pos = null;
/* 287 */         this.target = null;
/* 288 */         this.realTarget = null;
/*     */         return;
/*     */       } 
/* 291 */       this.realTarget = this.target;
/* 292 */       if (AutoGG.getINSTANCE().isOn()) {
/* 293 */         AutoGG autoGG = (AutoGG)Charon.moduleManager.getModuleByName("AutoGG");
/* 294 */         autoGG.addTargetedPlayer(this.target.func_70005_c_());
/*     */       } 
/* 296 */       if (this.hotBarSlot != -1 && ((Boolean)this.autoswitch.getValue()).booleanValue() && !mc.field_71439_g.func_70644_a(MobEffects.field_76437_t)) {
/* 297 */         mc.field_71439_g.field_71071_by.field_70461_c = this.hotBarSlot;
/*     */       }
/* 299 */       if (!((Boolean)this.ignoreUseAmount.getValue()).booleanValue()) {
/* 300 */         int crystalLimit = ((Integer)this.wasteAmount.getValue()).intValue();
/* 301 */         if (this.crystalCount >= crystalLimit) {
/*     */           return;
/*     */         }
/* 304 */         if (damage < ((Float)this.minDamage.getValue()).floatValue()) {
/* 305 */           crystalLimit = 1;
/*     */         }
/* 307 */         if (this.crystalCount < crystalLimit && this.pos != null) {
/* 308 */           rotateToPos(this.pos);
/* 309 */           mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerTryUseItemOnBlock(this.pos, EnumFacing.UP, (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP) ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, 0.0F, 0.0F, 0.0F));
/*     */         } 
/* 311 */       } else if (this.pos != null) {
/* 312 */         rotateToPos(this.pos);
/* 313 */         mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerTryUseItemOnBlock(this.pos, EnumFacing.UP, (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP) ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, 0.0F, 0.0F, 0.0F));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent(priority = EventPriority.HIGHEST, receiveCanceled = true)
/*     */   public void onPacketReceive(PacketEvent.Receive event) {
/*     */     SPacketSpawnObject packet;
/* 321 */     if (event.getPacket() instanceof SPacketSpawnObject && (packet = (SPacketSpawnObject)event.getPacket()).func_148993_l() == 51 && ((Boolean)this.predicts.getValue()).booleanValue() && this.preditTimer.passedMs(((Integer)this.attackFactor.getValue()).longValue()) && ((Boolean)this.predicts.getValue()).booleanValue() && ((Boolean)this.explode.getValue()).booleanValue() && ((Boolean)this.packetBreak.getValue()).booleanValue() && this.target != null) {
/* 322 */       if (!isPredicting(packet)) {
/*     */         return;
/*     */       }
/* 325 */       CPacketUseEntity predict = new CPacketUseEntity();
/* 326 */       predict.field_149567_a = packet.func_149001_c();
/* 327 */       predict.field_149566_b = CPacketUseEntity.Action.ATTACK;
/* 328 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)predict);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onRender3D(Render3DEvent event) {
/* 334 */     if (this.pos != null && ((Boolean)this.render.getValue()).booleanValue() && this.target != null) {
/* 335 */       RenderUtil.drawBoxESP(this.pos, ((Boolean)(ClickGui.getInstance()).rainbow.getValue()).booleanValue() ? ColorUtil.rainbow(((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()) : new Color(((Integer)this.red.getValue()).intValue(), ((Integer)this.green.getValue()).intValue(), ((Integer)this.blue.getValue()).intValue(), ((Integer)this.alpha.getValue()).intValue()), ((Boolean)this.outline.getValue()).booleanValue(), ((Boolean)(ClickGui.getInstance()).rainbow.getValue()).booleanValue() ? ColorUtil.rainbow(((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()) : new Color(((Integer)this.cRed.getValue()).intValue(), ((Integer)this.cGreen.getValue()).intValue(), ((Integer)this.cBlue.getValue()).intValue(), ((Integer)this.cAlpha.getValue()).intValue()), ((Float)this.lineWidth.getValue()).floatValue(), ((Boolean)this.outline.getValue()).booleanValue(), ((Boolean)this.box.getValue()).booleanValue(), ((Integer)this.boxAlpha.getValue()).intValue(), true);
/* 336 */       if (((Boolean)this.renderDmg.getValue()).booleanValue()) {
/* 337 */         double renderDamage = calculateDamage(this.pos.func_177958_n() + 0.5D, this.pos.func_177956_o() + 1.0D, this.pos.func_177952_p() + 0.5D, (Entity)this.target);
/* 338 */         RenderUtil.drawText(this.pos, ((Math.floor(renderDamage) == renderDamage) ? (String)Integer.valueOf((int)renderDamage) : String.format("%.1f", new Object[] { Double.valueOf(renderDamage) })) + "");
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isPredicting(SPacketSpawnObject packet) {
/* 344 */     BlockPos packPos = new BlockPos(packet.func_186880_c(), packet.func_186882_d(), packet.func_186881_e());
/* 345 */     if (mc.field_71439_g.func_70011_f(packet.func_186880_c(), packet.func_186882_d(), packet.func_186881_e()) > ((Float)this.breakRange.getValue()).floatValue()) {
/* 346 */       return false;
/*     */     }
/* 348 */     if (!canSeePos(packPos) && mc.field_71439_g.func_70011_f(packet.func_186880_c(), packet.func_186882_d(), packet.func_186881_e()) > ((Float)this.breakWallRange.getValue()).floatValue()) {
/* 349 */       return false;
/*     */     }
/* 351 */     double targetDmg = calculateDamage(packet.func_186880_c() + 0.5D, packet.func_186882_d() + 1.0D, packet.func_186881_e() + 0.5D, (Entity)this.target);
/* 352 */     if (EntityUtil.isInHole((Entity)mc.field_71439_g) && targetDmg >= 1.0D) {
/* 353 */       return true;
/*     */     }
/* 355 */     double selfDmg = calculateDamage(packet.func_186880_c() + 0.5D, packet.func_186882_d() + 1.0D, packet.func_186881_e() + 0.5D, (Entity)mc.field_71439_g);
/* 356 */     double d = ((Boolean)this.suicide.getValue()).booleanValue() ? 2.0D : 0.5D;
/* 357 */     if (selfDmg + d < (mc.field_71439_g.func_110143_aJ() + mc.field_71439_g.func_110139_bj()) && targetDmg >= (this.target.func_110139_bj() + this.target.func_110143_aJ())) {
/* 358 */       return true;
/*     */     }
/* 360 */     this.armorTarget = false;
/* 361 */     for (ItemStack is : this.target.func_184193_aE()) {
/* 362 */       float green = (is.func_77958_k() - is.func_77952_i()) / is.func_77958_k();
/* 363 */       float red = 1.0F - green;
/* 364 */       int dmg = 100 - (int)(red * 100.0F);
/* 365 */       if (dmg > ((Float)this.minArmor.getValue()).floatValue())
/* 366 */         continue;  this.armorTarget = true;
/*     */     } 
/* 368 */     if (targetDmg >= ((Float)this.breakMinDmg.getValue()).floatValue() && selfDmg <= ((Float)this.breakMaxSelfDamage.getValue()).floatValue()) {
/* 369 */       return true;
/*     */     }
/* 371 */     return (EntityUtil.isInHole((Entity)this.target) && this.target.func_110143_aJ() + this.target.func_110139_bj() <= ((Float)this.facePlace.getValue()).floatValue());
/*     */   }
/*     */   
/*     */   private boolean IsValidCrystal(Entity p_Entity) {
/* 375 */     if (p_Entity == null) {
/* 376 */       return false;
/*     */     }
/* 378 */     if (!(p_Entity instanceof EntityEnderCrystal)) {
/* 379 */       return false;
/*     */     }
/* 381 */     if (this.target == null) {
/* 382 */       return false;
/*     */     }
/* 384 */     if (p_Entity.func_70032_d((Entity)mc.field_71439_g) > ((Float)this.breakRange.getValue()).floatValue()) {
/* 385 */       return false;
/*     */     }
/* 387 */     if (!mc.field_71439_g.func_70685_l(p_Entity) && p_Entity.func_70032_d((Entity)mc.field_71439_g) > ((Float)this.breakWallRange.getValue()).floatValue()) {
/* 388 */       return false;
/*     */     }
/* 390 */     if (this.target.field_70128_L || this.target.func_110143_aJ() + this.target.func_110139_bj() <= 0.0F) {
/* 391 */       return false;
/*     */     }
/* 393 */     double targetDmg = calculateDamage(p_Entity.func_180425_c().func_177958_n() + 0.5D, p_Entity.func_180425_c().func_177956_o() + 1.0D, p_Entity.func_180425_c().func_177952_p() + 0.5D, (Entity)this.target);
/* 394 */     if (EntityUtil.isInHole((Entity)mc.field_71439_g) && targetDmg >= 1.0D) {
/* 395 */       return true;
/*     */     }
/* 397 */     double selfDmg = calculateDamage(p_Entity.func_180425_c().func_177958_n() + 0.5D, p_Entity.func_180425_c().func_177956_o() + 1.0D, p_Entity.func_180425_c().func_177952_p() + 0.5D, (Entity)mc.field_71439_g);
/* 398 */     double d = ((Boolean)this.suicide.getValue()).booleanValue() ? 2.0D : 0.5D;
/* 399 */     if (selfDmg + d < (mc.field_71439_g.func_110143_aJ() + mc.field_71439_g.func_110139_bj()) && targetDmg >= (this.target.func_110139_bj() + this.target.func_110143_aJ())) {
/* 400 */       return true;
/*     */     }
/* 402 */     this.armorTarget = false;
/* 403 */     for (ItemStack is : this.target.func_184193_aE()) {
/* 404 */       float green = (is.func_77958_k() - is.func_77952_i()) / is.func_77958_k();
/* 405 */       float red = 1.0F - green;
/* 406 */       int dmg = 100 - (int)(red * 100.0F);
/* 407 */       if (dmg > ((Float)this.minArmor.getValue()).floatValue())
/* 408 */         continue;  this.armorTarget = true;
/*     */     } 
/* 410 */     if (targetDmg >= ((Float)this.breakMinDmg.getValue()).floatValue() && selfDmg <= ((Float)this.breakMaxSelfDamage.getValue()).floatValue()) {
/* 411 */       return true;
/*     */     }
/* 413 */     return (EntityUtil.isInHole((Entity)this.target) && this.target.func_110143_aJ() + this.target.func_110139_bj() <= ((Float)this.facePlace.getValue()).floatValue());
/*     */   }
/*     */   
/*     */   EntityPlayer getTarget() {
/* 417 */     EntityPlayer closestPlayer = null;
/* 418 */     for (EntityPlayer entity : mc.field_71441_e.field_73010_i) {
/* 419 */       if (mc.field_71439_g == null || mc.field_71439_g.field_70128_L || entity.field_70128_L || entity == mc.field_71439_g || Charon.friendManager.isFriend(entity.func_70005_c_()) || entity.func_70032_d((Entity)mc.field_71439_g) > 12.0F)
/*     */         continue; 
/* 421 */       this.armorTarget = false;
/* 422 */       for (ItemStack is : entity.func_184193_aE()) {
/* 423 */         float green = (is.func_77958_k() - is.func_77952_i()) / is.func_77958_k();
/* 424 */         float red = 1.0F - green;
/* 425 */         int dmg = 100 - (int)(red * 100.0F);
/* 426 */         if (dmg > ((Float)this.minArmor.getValue()).floatValue())
/* 427 */           continue;  this.armorTarget = true;
/*     */       } 
/* 429 */       if (EntityUtil.isInHole((Entity)entity) && entity.func_110139_bj() + entity.func_110143_aJ() > ((Float)this.facePlace.getValue()).floatValue() && !this.armorTarget && ((Float)this.minDamage.getValue()).floatValue() > 2.2F)
/*     */         continue; 
/* 431 */       if (closestPlayer == null) {
/* 432 */         closestPlayer = entity;
/*     */         continue;
/*     */       } 
/* 435 */       if (closestPlayer.func_70032_d((Entity)mc.field_71439_g) <= entity.func_70032_d((Entity)mc.field_71439_g))
/*     */         continue; 
/* 437 */       closestPlayer = entity;
/*     */     } 
/* 439 */     return closestPlayer;
/*     */   }
/*     */   
/*     */   private void manualBreaker() {
/*     */     RayTraceResult result;
/* 444 */     if (this.manualTimer.passedMs(200L) && mc.field_71474_y.field_74313_G.func_151470_d() && mc.field_71439_g.func_184592_cb().func_77973_b() != Items.field_151153_ao && mc.field_71439_g.field_71071_by.func_70448_g().func_77973_b() != Items.field_151153_ao && mc.field_71439_g.field_71071_by.func_70448_g().func_77973_b() != Items.field_151031_f && mc.field_71439_g.field_71071_by.func_70448_g().func_77973_b() != Items.field_151062_by && (result = mc.field_71476_x) != null) {
/* 445 */       if (result.field_72313_a.equals(RayTraceResult.Type.ENTITY)) {
/* 446 */         Entity entity = result.field_72308_g;
/* 447 */         if (entity instanceof EntityEnderCrystal) {
/* 448 */           if (((Boolean)this.packetBreak.getValue()).booleanValue()) {
/* 449 */             mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketUseEntity(entity));
/*     */           } else {
/* 451 */             mc.field_71442_b.func_78764_a((EntityPlayer)mc.field_71439_g, entity);
/*     */           } 
/* 453 */           this.manualTimer.reset();
/*     */         } 
/* 455 */       } else if (result.field_72313_a.equals(RayTraceResult.Type.BLOCK)) {
/* 456 */         BlockPos mousePos = new BlockPos(mc.field_71476_x.func_178782_a().func_177958_n(), mc.field_71476_x.func_178782_a().func_177956_o() + 1.0D, mc.field_71476_x.func_178782_a().func_177952_p());
/* 457 */         for (Entity target : mc.field_71441_e.func_72839_b(null, new AxisAlignedBB(mousePos))) {
/* 458 */           if (!(target instanceof EntityEnderCrystal))
/* 459 */             continue;  if (((Boolean)this.packetBreak.getValue()).booleanValue()) {
/* 460 */             mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketUseEntity(target));
/*     */           } else {
/* 462 */             mc.field_71442_b.func_78764_a((EntityPlayer)mc.field_71439_g, target);
/*     */           } 
/* 464 */           this.manualTimer.reset();
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean canSeePos(BlockPos pos) {
/* 471 */     return (mc.field_71441_e.func_147447_a(new Vec3d(mc.field_71439_g.field_70165_t, mc.field_71439_g.field_70163_u + mc.field_71439_g.func_70047_e(), mc.field_71439_g.field_70161_v), new Vec3d(pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p()), false, true, false) == null);
/*     */   }
/*     */   
/*     */   private NonNullList<BlockPos> placePostions(float placeRange) {
/* 475 */     NonNullList<BlockPos> positions = NonNullList.func_191196_a();
/* 476 */     positions.addAll((Collection)getSphere(new BlockPos(Math.floor(mc.field_71439_g.field_70165_t), Math.floor(mc.field_71439_g.field_70163_u), Math.floor(mc.field_71439_g.field_70161_v)), placeRange, (int)placeRange, false, true, 0).stream().filter(pos -> canPlaceCrystal(pos, true)).collect(Collectors.toList()));
/* 477 */     return positions;
/*     */   }
/*     */   
/*     */   private boolean canPlaceCrystal(BlockPos blockPos, boolean specialEntityCheck) {
/* 481 */     BlockPos boost = blockPos.func_177982_a(0, 1, 0);
/* 482 */     BlockPos boost2 = blockPos.func_177982_a(0, 2, 0);
/*     */     try {
/* 484 */       if (!((Boolean)this.opPlace.getValue()).booleanValue()) {
/* 485 */         if (mc.field_71441_e.func_180495_p(blockPos).func_177230_c() != Blocks.field_150357_h && mc.field_71441_e.func_180495_p(blockPos).func_177230_c() != Blocks.field_150343_Z) {
/* 486 */           return false;
/*     */         }
/* 488 */         if (mc.field_71441_e.func_180495_p(boost).func_177230_c() != Blocks.field_150350_a || mc.field_71441_e.func_180495_p(boost2).func_177230_c() != Blocks.field_150350_a) {
/* 489 */           return false;
/*     */         }
/* 491 */         if (!specialEntityCheck) {
/* 492 */           return (mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(boost)).isEmpty() && mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(boost2)).isEmpty());
/*     */         }
/* 494 */         for (Entity entity : mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(boost))) {
/* 495 */           if (entity instanceof EntityEnderCrystal)
/* 496 */             continue;  return false;
/*     */         } 
/* 498 */         for (Entity entity : mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(boost2))) {
/* 499 */           if (entity instanceof EntityEnderCrystal)
/* 500 */             continue;  return false;
/*     */         } 
/*     */       } else {
/* 503 */         if (mc.field_71441_e.func_180495_p(blockPos).func_177230_c() != Blocks.field_150357_h && mc.field_71441_e.func_180495_p(blockPos).func_177230_c() != Blocks.field_150343_Z) {
/* 504 */           return false;
/*     */         }
/* 506 */         if (mc.field_71441_e.func_180495_p(boost).func_177230_c() != Blocks.field_150350_a) {
/* 507 */           return false;
/*     */         }
/* 509 */         if (!specialEntityCheck) {
/* 510 */           return mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(boost)).isEmpty();
/*     */         }
/* 512 */         for (Entity entity : mc.field_71441_e.func_72872_a(Entity.class, new AxisAlignedBB(boost))) {
/* 513 */           if (entity instanceof EntityEnderCrystal)
/* 514 */             continue;  return false;
/*     */         } 
/*     */       } 
/* 517 */     } catch (Exception ignored) {
/* 518 */       return false;
/*     */     } 
/* 520 */     return true;
/*     */   }
/*     */   
/*     */   private float calculateDamage(double posX, double posY, double posZ, Entity entity) {
/* 524 */     float doubleExplosionSize = 12.0F;
/* 525 */     double distancedsize = entity.func_70011_f(posX, posY, posZ) / 12.0D;
/* 526 */     Vec3d vec3d = new Vec3d(posX, posY, posZ);
/* 527 */     double blockDensity = 0.0D;
/*     */     try {
/* 529 */       blockDensity = entity.field_70170_p.func_72842_a(vec3d, entity.func_174813_aQ());
/* 530 */     } catch (Exception exception) {}
/*     */ 
/*     */     
/* 533 */     double v = (1.0D - distancedsize) * blockDensity;
/* 534 */     float damage = (int)((v * v + v) / 2.0D * 7.0D * 12.0D + 1.0D);
/* 535 */     double finald = 1.0D;
/* 536 */     if (entity instanceof EntityLivingBase) {
/* 537 */       finald = getBlastReduction((EntityLivingBase)entity, getDamageMultiplied(damage), new Explosion((World)mc.field_71441_e, null, posX, posY, posZ, 6.0F, false, true));
/*     */     }
/* 539 */     return (float)finald;
/*     */   }
/*     */   
/*     */   private float getBlastReduction(EntityLivingBase entity, float damageI, Explosion explosion) {
/* 543 */     float damage = damageI;
/* 544 */     if (entity instanceof EntityPlayer) {
/* 545 */       EntityPlayer ep = (EntityPlayer)entity;
/* 546 */       DamageSource ds = DamageSource.func_94539_a(explosion);
/* 547 */       damage = CombatRules.func_189427_a(damage, ep.func_70658_aO(), (float)ep.func_110148_a(SharedMonsterAttributes.field_189429_h).func_111126_e());
/* 548 */       int k = 0;
/*     */       try {
/* 550 */         k = EnchantmentHelper.func_77508_a(ep.func_184193_aE(), ds);
/* 551 */       } catch (Exception exception) {}
/*     */ 
/*     */       
/* 554 */       float f = MathHelper.func_76131_a(k, 0.0F, 20.0F);
/* 555 */       damage *= 1.0F - f / 25.0F;
/* 556 */       if (entity.func_70644_a(MobEffects.field_76429_m)) {
/* 557 */         damage -= damage / 4.0F;
/*     */       }
/* 559 */       damage = Math.max(damage, 0.0F);
/* 560 */       return damage;
/*     */     } 
/* 562 */     damage = CombatRules.func_189427_a(damage, entity.func_70658_aO(), (float)entity.func_110148_a(SharedMonsterAttributes.field_189429_h).func_111126_e());
/* 563 */     return damage;
/*     */   }
/*     */   
/*     */   private float getDamageMultiplied(float damage) {
/* 567 */     int diff = mc.field_71441_e.func_175659_aa().func_151525_a();
/* 568 */     return damage * ((diff == 0) ? 0.0F : ((diff == 2) ? 1.0F : ((diff == 1) ? 0.5F : 1.5F)));
/*     */   }
/*     */   
/*     */   public enum SwingMode {
/* 572 */     MainHand,
/* 573 */     OffHand,
/* 574 */     None;
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/combat/AutoCrystalDied.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */