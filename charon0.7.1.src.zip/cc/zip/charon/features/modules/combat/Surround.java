/*     */ package cc.zip.charon.features.modules.combat;
/*     */ import cc.zip.charon.Charon;
/*     */ import cc.zip.charon.features.command.Command;
/*     */ import cc.zip.charon.features.modules.Module;
/*     */ import cc.zip.charon.features.setting.Setting;
/*     */ import cc.zip.charon.util.BlockUtil;
/*     */ import cc.zip.charon.util.EntityUtil;
/*     */ import cc.zip.charon.util.InventoryUtil;
/*     */ import cc.zip.charon.util.Timer;
/*     */ import cc.zip.charon.util.Util;
/*     */ import com.mojang.realmsclient.gui.ChatFormatting;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import net.minecraft.block.BlockEnderChest;
/*     */ import net.minecraft.block.BlockObsidian;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraft.util.math.Vec3d;
/*     */ 
/*     */ public class Surround extends Module {
/*  22 */   private final Setting<Integer> blocksPerTick = register(new Setting("BlocksPerTick", Integer.valueOf(12), Integer.valueOf(1), Integer.valueOf(20))); public static boolean isPlacing = false;
/*  23 */   private final Setting<Integer> delay = register(new Setting("Delay", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(250)));
/*  24 */   private final Setting<Boolean> noGhost = register(new Setting("PacketPlace", Boolean.valueOf(false)));
/*  25 */   private final Setting<Boolean> center = register(new Setting("TPCenter", Boolean.valueOf(false)));
/*  26 */   private final Setting<Boolean> rotate = register(new Setting("Rotate", Boolean.valueOf(true)));
/*  27 */   private final Timer timer = new Timer();
/*  28 */   private final Timer retryTimer = new Timer();
/*  29 */   private final Set<Vec3d> extendingBlocks = new HashSet<>();
/*  30 */   private final Map<BlockPos, Integer> retries = new HashMap<>();
/*     */   private int isSafe;
/*     */   private BlockPos startPos;
/*     */   private boolean didPlace = false;
/*     */   private boolean switchedItem;
/*     */   private int lastHotbarSlot;
/*     */   private boolean isSneaking;
/*  37 */   private int placements = 0;
/*  38 */   private int extenders = 1;
/*  39 */   private int obbySlot = -1;
/*     */   private boolean offHand = false;
/*     */   
/*     */   public Surround() {
/*  43 */     super("Surround", "Surrounds you with Obsidian", Module.Category.COMBAT, true, false, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  48 */     if (fullNullCheck()) {
/*  49 */       disable();
/*     */     }
/*  51 */     this.lastHotbarSlot = Util.mc.field_71439_g.field_71071_by.field_70461_c;
/*  52 */     this.startPos = EntityUtil.getRoundedBlockPos((Entity)Util.mc.field_71439_g);
/*  53 */     if (((Boolean)this.center.getValue()).booleanValue()) {
/*  54 */       Charon.positionManager.setPositionPacket(this.startPos.func_177958_n() + 0.5D, this.startPos.func_177956_o(), this.startPos.func_177952_p() + 0.5D, true, true, true);
/*     */     }
/*  56 */     this.retries.clear();
/*  57 */     this.retryTimer.reset();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onTick() {
/*  62 */     doFeetPlace();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  67 */     if (nullCheck()) {
/*     */       return;
/*     */     }
/*  70 */     isPlacing = false;
/*  71 */     this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDisplayInfo() {
/*  76 */     switch (this.isSafe) {
/*     */       case 0:
/*  78 */         return ChatFormatting.RED + "Unsafe";
/*     */       
/*     */       case 1:
/*  81 */         return ChatFormatting.YELLOW + "Safe";
/*     */     } 
/*     */     
/*  84 */     return ChatFormatting.GREEN + "Safe";
/*     */   }
/*     */   
/*     */   private void doFeetPlace() {
/*  88 */     if (check()) {
/*     */       return;
/*     */     }
/*  91 */     if (!EntityUtil.isSafe((Entity)Util.mc.field_71439_g, 0, true)) {
/*  92 */       this.isSafe = 0;
/*  93 */       placeBlocks(Util.mc.field_71439_g.func_174791_d(), EntityUtil.getUnsafeBlockArray((Entity)Util.mc.field_71439_g, 0, true), true, false, false);
/*  94 */     } else if (!EntityUtil.isSafe((Entity)Util.mc.field_71439_g, -1, false)) {
/*  95 */       this.isSafe = 1;
/*  96 */       placeBlocks(Util.mc.field_71439_g.func_174791_d(), EntityUtil.getUnsafeBlockArray((Entity)Util.mc.field_71439_g, -1, false), false, false, true);
/*     */     } else {
/*  98 */       this.isSafe = 2;
/*     */     } 
/* 100 */     processExtendingBlocks();
/* 101 */     if (this.didPlace) {
/* 102 */       this.timer.reset();
/*     */     }
/*     */   }
/*     */   
/*     */   private void processExtendingBlocks() {
/* 107 */     if (this.extendingBlocks.size() == 2 && this.extenders < 1) {
/* 108 */       Vec3d[] array = new Vec3d[2];
/* 109 */       int i = 0;
/* 110 */       Iterator<Vec3d> iterator = this.extendingBlocks.iterator();
/* 111 */       while (iterator.hasNext()) {
/*     */         
/* 113 */         Vec3d vec3d = iterator.next();
/* 114 */         i++;
/*     */       } 
/* 116 */       int placementsBefore = this.placements;
/* 117 */       if (areClose(array) != null) {
/* 118 */         placeBlocks(areClose(array), EntityUtil.getUnsafeBlockArrayFromVec3d(areClose(array), 0, true), true, false, true);
/*     */       }
/* 120 */       if (placementsBefore < this.placements) {
/* 121 */         this.extendingBlocks.clear();
/*     */       }
/* 123 */     } else if (this.extendingBlocks.size() > 2 || this.extenders >= 1) {
/* 124 */       this.extendingBlocks.clear();
/*     */     } 
/*     */   }
/*     */   
/*     */   private Vec3d areClose(Vec3d[] vec3ds) {
/* 129 */     int matches = 0;
/* 130 */     for (Vec3d vec3d : vec3ds) {
/* 131 */       for (Vec3d pos : EntityUtil.getUnsafeBlockArray((Entity)Util.mc.field_71439_g, 0, true)) {
/* 132 */         if (vec3d.equals(pos))
/* 133 */           matches++; 
/*     */       } 
/*     */     } 
/* 136 */     if (matches == 2) {
/* 137 */       return Util.mc.field_71439_g.func_174791_d().func_178787_e(vec3ds[0].func_178787_e(vec3ds[1]));
/*     */     }
/* 139 */     return null;
/*     */   }
/*     */   
/*     */   private boolean placeBlocks(Vec3d pos, Vec3d[] vec3ds, boolean hasHelpingBlocks, boolean isHelping, boolean isExtending) {
/* 143 */     boolean gotHelp = true;
/* 144 */     for (Vec3d vec3d : vec3ds) {
/* 145 */       gotHelp = true;
/* 146 */       BlockPos position = (new BlockPos(pos)).func_177963_a(vec3d.field_72450_a, vec3d.field_72448_b, vec3d.field_72449_c);
/* 147 */       switch (BlockUtil.isPositionPlaceable(position, false)) {
/*     */         case 1:
/* 149 */           if (this.retries.get(position) == null || ((Integer)this.retries.get(position)).intValue() < 4) {
/* 150 */             placeBlock(position);
/* 151 */             this.retries.put(position, Integer.valueOf((this.retries.get(position) == null) ? 1 : (((Integer)this.retries.get(position)).intValue() + 1)));
/* 152 */             this.retryTimer.reset();
/*     */             break;
/*     */           } 
/* 155 */           if (Charon.speedManager.getSpeedKpH() != 0.0D || isExtending || this.extenders >= 1)
/* 156 */             break;  placeBlocks(Util.mc.field_71439_g.func_174791_d().func_178787_e(vec3d), EntityUtil.getUnsafeBlockArrayFromVec3d(Util.mc.field_71439_g.func_174791_d().func_178787_e(vec3d), 0, true), hasHelpingBlocks, false, true);
/* 157 */           this.extendingBlocks.add(vec3d);
/* 158 */           this.extenders++;
/*     */           break;
/*     */         
/*     */         case 2:
/* 162 */           if (!hasHelpingBlocks)
/* 163 */             break;  gotHelp = placeBlocks(pos, BlockUtil.getHelpingBlocks(vec3d), false, true, true);
/*     */         
/*     */         case 3:
/* 166 */           if (gotHelp) {
/* 167 */             placeBlock(position);
/*     */           }
/* 169 */           if (!isHelping)
/* 170 */             break;  return true;
/*     */       } 
/*     */     
/*     */     } 
/* 174 */     return false;
/*     */   }
/*     */   
/*     */   private boolean check() {
/* 178 */     if (nullCheck()) {
/* 179 */       return true;
/*     */     }
/* 181 */     int obbySlot = InventoryUtil.findHotbarBlock(BlockObsidian.class);
/* 182 */     int eChestSot = InventoryUtil.findHotbarBlock(BlockEnderChest.class);
/* 183 */     if (obbySlot == -1 && eChestSot == -1) {
/* 184 */       toggle();
/*     */     }
/* 186 */     this.offHand = InventoryUtil.isBlock(Util.mc.field_71439_g.func_184592_cb().func_77973_b(), BlockObsidian.class);
/* 187 */     isPlacing = false;
/* 188 */     this.didPlace = false;
/* 189 */     this.extenders = 1;
/* 190 */     this.placements = 0;
/* 191 */     this.obbySlot = InventoryUtil.findHotbarBlock(BlockObsidian.class);
/* 192 */     int echestSlot = InventoryUtil.findHotbarBlock(BlockEnderChest.class);
/* 193 */     if (isOff()) {
/* 194 */       return true;
/*     */     }
/* 196 */     if (this.retryTimer.passedMs(2500L)) {
/* 197 */       this.retries.clear();
/* 198 */       this.retryTimer.reset();
/*     */     } 
/* 200 */     if (this.obbySlot == -1 && !this.offHand && echestSlot == -1) {
/* 201 */       Command.sendMessage("<" + getDisplayName() + "> " + ChatFormatting.RED + "No Obsidian in hotbar disabling...");
/* 202 */       disable();
/* 203 */       return true;
/*     */     } 
/* 205 */     this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
/* 206 */     if (Util.mc.field_71439_g.field_71071_by.field_70461_c != this.lastHotbarSlot && Util.mc.field_71439_g.field_71071_by.field_70461_c != this.obbySlot && Util.mc.field_71439_g.field_71071_by.field_70461_c != echestSlot) {
/* 207 */       this.lastHotbarSlot = Util.mc.field_71439_g.field_71071_by.field_70461_c;
/*     */     }
/* 209 */     if (!this.startPos.equals(EntityUtil.getRoundedBlockPos((Entity)Util.mc.field_71439_g))) {
/* 210 */       disable();
/* 211 */       return true;
/*     */     } 
/* 213 */     return !this.timer.passedMs(((Integer)this.delay.getValue()).intValue());
/*     */   }
/*     */   
/*     */   private void placeBlock(BlockPos pos) {
/* 217 */     if (this.placements < ((Integer)this.blocksPerTick.getValue()).intValue()) {
/* 218 */       int originalSlot = Util.mc.field_71439_g.field_71071_by.field_70461_c;
/* 219 */       int obbySlot = InventoryUtil.findHotbarBlock(BlockObsidian.class);
/* 220 */       int eChestSot = InventoryUtil.findHotbarBlock(BlockEnderChest.class);
/* 221 */       if (obbySlot == -1 && eChestSot == -1) {
/* 222 */         toggle();
/*     */       }
/* 224 */       isPlacing = true;
/* 225 */       Util.mc.field_71439_g.field_71071_by.field_70461_c = (obbySlot == -1) ? eChestSot : obbySlot;
/* 226 */       Util.mc.field_71442_b.func_78765_e();
/* 227 */       this.isSneaking = BlockUtil.placeBlock(pos, this.offHand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, ((Boolean)this.rotate.getValue()).booleanValue(), ((Boolean)this.noGhost.getValue()).booleanValue(), this.isSneaking);
/* 228 */       Util.mc.field_71439_g.field_71071_by.field_70461_c = originalSlot;
/* 229 */       Util.mc.field_71442_b.func_78765_e();
/* 230 */       this.didPlace = true;
/* 231 */       this.placements++;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/combat/Surround.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */