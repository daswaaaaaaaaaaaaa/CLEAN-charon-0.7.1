/*     */ package cc.zip.charon.features.modules;
/*     */ 
/*     */ import cc.zip.charon.Charon;
/*     */ import cc.zip.charon.event.events.ClientEvent;
/*     */ import cc.zip.charon.event.events.Render2DEvent;
/*     */ import cc.zip.charon.event.events.Render3DEvent;
/*     */ import cc.zip.charon.features.Feature;
/*     */ import cc.zip.charon.features.command.Command;
/*     */ import cc.zip.charon.features.modules.client.HUD;
/*     */ import cc.zip.charon.features.setting.Bind;
/*     */ import cc.zip.charon.features.setting.Setting;
/*     */ import com.mojang.realmsclient.gui.ChatFormatting;
/*     */ import net.minecraft.util.text.ITextComponent;
/*     */ import net.minecraft.util.text.TextComponentString;
/*     */ import net.minecraftforge.common.MinecraftForge;
/*     */ import net.minecraftforge.fml.common.eventhandler.Event;
/*     */ 
/*     */ public class Module extends Feature {
/*     */   private final String description;
/*  20 */   public Setting<Boolean> enabled = register(new Setting("Enabled", Boolean.valueOf(false))); private final Category category;
/*  21 */   public Setting<Boolean> drawn = register(new Setting("Drawn", Boolean.valueOf(true)));
/*  22 */   public Setting<Bind> bind = register(new Setting("Keybind", new Bind(-1)));
/*     */   public Setting<String> displayName;
/*     */   public boolean hasListener;
/*     */   public boolean alwaysListening;
/*     */   public boolean hidden;
/*  27 */   public float arrayListOffset = 0.0F;
/*  28 */   public float arrayListVOffset = 0.0F;
/*     */   public float offset;
/*     */   public float vOffset;
/*     */   public boolean sliding;
/*     */   
/*     */   public Module(String name, String description, Category category, boolean hasListener, boolean hidden, boolean alwaysListening) {
/*  34 */     super(name);
/*  35 */     this.displayName = register(new Setting("DisplayName", name));
/*  36 */     this.description = description;
/*  37 */     this.category = category;
/*  38 */     this.hasListener = hasListener;
/*  39 */     this.hidden = hidden;
/*  40 */     this.alwaysListening = alwaysListening;
/*     */   }
/*     */   
/*     */   public boolean isSliding() {
/*  44 */     return this.sliding;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {}
/*     */ 
/*     */   
/*     */   public void onDisable() {}
/*     */ 
/*     */   
/*     */   public void onToggle() {}
/*     */ 
/*     */   
/*     */   public void onLoad() {}
/*     */ 
/*     */   
/*     */   public void onTick() {}
/*     */ 
/*     */   
/*     */   public void onLogin() {}
/*     */ 
/*     */   
/*     */   public void onLogout() {}
/*     */ 
/*     */   
/*     */   public void onUpdate() {}
/*     */ 
/*     */   
/*     */   public void onRender2D(Render2DEvent event) {}
/*     */ 
/*     */   
/*     */   public void onRender3D(Render3DEvent event) {}
/*     */ 
/*     */   
/*     */   public void onUnload() {}
/*     */   
/*     */   public String getDisplayInfo() {
/*  81 */     return null;
/*     */   }
/*     */   
/*     */   public boolean isOn() {
/*  85 */     return ((Boolean)this.enabled.getValue()).booleanValue();
/*     */   }
/*     */   
/*     */   public boolean isOff() {
/*  89 */     return !((Boolean)this.enabled.getValue()).booleanValue();
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean enabled) {
/*  93 */     if (enabled) {
/*  94 */       enable();
/*     */     } else {
/*  96 */       disable();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void enable() {
/* 101 */     this.enabled.setValue(Boolean.TRUE);
/* 102 */     onToggle();
/* 103 */     onEnable();
/* 104 */     if (((Boolean)(HUD.getInstance()).notifyToggles.getValue()).booleanValue()) {
/* 105 */       TextComponentString text = new TextComponentString(Charon.commandManager.getClientMessage() + " " + ChatFormatting.AQUA + getDisplayName() + ChatFormatting.GRAY + " : " + ChatFormatting.GREEN + "Enabled.");
/* 106 */       mc.field_71456_v.func_146158_b().func_146234_a((ITextComponent)text, 1);
/*     */     } 
/* 108 */     if (isOn() && this.hasListener && !this.alwaysListening) {
/* 109 */       MinecraftForge.EVENT_BUS.register(this);
/*     */     }
/*     */   }
/*     */   
/*     */   public void disable() {
/* 114 */     if (this.hasListener && !this.alwaysListening) {
/* 115 */       MinecraftForge.EVENT_BUS.unregister(this);
/*     */     }
/* 117 */     this.enabled.setValue(Boolean.valueOf(false));
/* 118 */     if (((Boolean)(HUD.getInstance()).notifyToggles.getValue()).booleanValue()) {
/* 119 */       TextComponentString text = new TextComponentString(Charon.commandManager.getClientMessage() + " " + ChatFormatting.AQUA + getDisplayName() + ChatFormatting.GRAY + " : " + ChatFormatting.RED + "Disabled.");
/* 120 */       mc.field_71456_v.func_146158_b().func_146234_a((ITextComponent)text, 1);
/*     */     } 
/*     */     
/* 123 */     onToggle();
/* 124 */     onDisable();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void toggle() {
/* 130 */     ClientEvent event = new ClientEvent(!isEnabled() ? 1 : 0, this);
/* 131 */     MinecraftForge.EVENT_BUS.post((Event)event);
/* 132 */     if (!event.isCanceled()) {
/* 133 */       setEnabled(!isEnabled());
/*     */     }
/*     */   }
/*     */   
/*     */   public String getDisplayName() {
/* 138 */     return (String)this.displayName.getValue();
/*     */   }
/*     */   
/*     */   public void setDisplayName(String name) {
/* 142 */     Module module = Charon.moduleManager.getModuleByDisplayName(name);
/* 143 */     Module originalModule = Charon.moduleManager.getModuleByName(name);
/* 144 */     if (module == null && originalModule == null) {
/* 145 */       Command.sendMessage(getDisplayName() + ", name: " + getName() + ", has been renamed to: " + name);
/* 146 */       this.displayName.setValue(name);
/*     */       return;
/*     */     } 
/* 149 */     Command.sendMessage(ChatFormatting.RED + "A module of this name already exists.");
/*     */   }
/*     */   
/*     */   public String getDescription() {
/* 153 */     return this.description;
/*     */   }
/*     */   
/*     */   public boolean isDrawn() {
/* 157 */     return ((Boolean)this.drawn.getValue()).booleanValue();
/*     */   }
/*     */   
/*     */   public void setDrawn(boolean drawn) {
/* 161 */     this.drawn.setValue(Boolean.valueOf(drawn));
/*     */   }
/*     */   
/*     */   public Category getCategory() {
/* 165 */     return this.category;
/*     */   }
/*     */   
/*     */   public String getInfo() {
/* 169 */     return null;
/*     */   }
/*     */   
/*     */   public Bind getBind() {
/* 173 */     return (Bind)this.bind.getValue();
/*     */   }
/*     */   
/*     */   public void setBind(int key) {
/* 177 */     this.bind.setValue(new Bind(key));
/*     */   }
/*     */   
/*     */   public boolean listening() {
/* 181 */     return ((this.hasListener && isOn()) || this.alwaysListening);
/*     */   }
/*     */   
/*     */   public String getFullArrayString() {
/* 185 */     return getDisplayName() + ChatFormatting.GRAY + ((getDisplayInfo() != null) ? (" <" + ChatFormatting.GRAY + getDisplayInfo() + ChatFormatting.GRAY + ">") : "");
/*     */   }
/*     */   
/*     */   public enum Category {
/* 189 */     COMBAT("Combat"),
/* 190 */     MISC("Misc"),
/* 191 */     RENDER("Render"),
/* 192 */     MOVEMENT("Movement"),
/* 193 */     PLAYER("Player"),
/* 194 */     CLIENT("Client"),
/* 195 */     DISRPC("DIS-RPC");
/*     */     
/*     */     private final String name;
/*     */     
/*     */     Category(String name) {
/* 200 */       this.name = name;
/*     */     }
/*     */     
/*     */     public String getName() {
/* 204 */       return this.name;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/Module.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */