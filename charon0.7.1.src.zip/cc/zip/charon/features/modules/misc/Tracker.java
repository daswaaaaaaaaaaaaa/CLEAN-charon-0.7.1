/*    */ package cc.zip.charon.features.modules.misc;
/*    */ 
/*    */ import cc.zip.charon.event.events.DeathEvent;
/*    */ import cc.zip.charon.features.command.Command;
/*    */ import cc.zip.charon.features.modules.Module;
/*    */ import cc.zip.charon.features.modules.client.HUD;
/*    */ import cc.zip.charon.util.EntityUtil;
/*    */ import cc.zip.charon.util.TextUtil;
/*    */ import java.util.Objects;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ 
/*    */ public class Tracker
/*    */   extends Module
/*    */ {
/*    */   private static Tracker instance;
/*    */   private EntityPlayer trackedPlayer;
/* 20 */   private int usedExp = 0;
/* 21 */   private int usedStacks = 0;
/*    */   
/*    */   public Tracker() {
/* 24 */     super("Duel", "Tracks players in 1v1s.", Module.Category.MISC, true, false, false);
/* 25 */     instance = this;
/*    */   }
/*    */   
/*    */   public static Tracker getInstance() {
/* 29 */     if (instance == null) {
/* 30 */       instance = new Tracker();
/*    */     }
/* 32 */     return instance;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onUpdate() {
/* 37 */     if (this.trackedPlayer == null) {
/* 38 */       this.trackedPlayer = EntityUtil.getClosestEnemy(1000.0D);
/* 39 */     } else if (this.usedStacks != this.usedExp / 64) {
/* 40 */       this.usedStacks = this.usedExp / 64;
/* 41 */       Command.sendMessage(TextUtil.coloredString(this.trackedPlayer.func_70005_c_() + " has used " + this.usedStacks + " stacks of XP!", (TextUtil.Color)(HUD.getInstance()).commandColor.getValue()));
/*    */     } 
/*    */   }
/*    */   
/*    */   public void onSpawnEntity(Entity entity) {
/* 46 */     if (entity instanceof net.minecraft.entity.item.EntityExpBottle && Objects.equals(mc.field_71441_e.func_72890_a(entity, 3.0D), this.trackedPlayer)) {
/* 47 */       this.usedExp++;
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 53 */     this.trackedPlayer = null;
/* 54 */     this.usedExp = 0;
/* 55 */     this.usedStacks = 0;
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onDeath(DeathEvent event) {
/* 60 */     if (event.player.equals(this.trackedPlayer)) {
/* 61 */       this.usedExp = 0;
/* 62 */       this.usedStacks = 0;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public String getDisplayInfo() {
/* 68 */     if (this.trackedPlayer != null) {
/* 69 */       return this.trackedPlayer.func_70005_c_();
/*    */     }
/* 71 */     return null;
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/misc/Tracker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */