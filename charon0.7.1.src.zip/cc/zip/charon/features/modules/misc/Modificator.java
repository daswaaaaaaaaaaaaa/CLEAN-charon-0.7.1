/*    */ package cc.zip.charon.features.modules.misc;
/*    */ 
/*    */ import cc.zip.charon.features.modules.Module;
/*    */ import cc.zip.charon.features.setting.Setting;
/*    */ 
/*    */ public class Modificator
/*    */   extends Module
/*    */ {
/*    */   public Setting<Boolean> timersetting;
/*    */   
/*    */   public Modificator() {
/* 12 */     super("Modificator", "troll", Module.Category.MISC, true, false, false);
/*    */     
/* 14 */     this.timersetting = register(new Setting("--Timer--", Boolean.valueOf(true)));
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/misc/Modificator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */