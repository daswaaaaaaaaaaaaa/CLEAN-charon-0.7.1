/*    */ package cc.zip.charon.features.modules.misc;
/*    */ 
/*    */ import cc.zip.charon.Charon;
/*    */ import cc.zip.charon.features.command.Command;
/*    */ import cc.zip.charon.features.modules.Module;
/*    */ import com.mojang.realmsclient.gui.ChatFormatting;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.util.math.RayTraceResult;
/*    */ import org.lwjgl.input.Mouse;
/*    */ 
/*    */ public class MCF
/*    */   extends Module
/*    */ {
/*    */   private boolean clicked = false;
/*    */   
/*    */   public MCF() {
/* 17 */     super("MCF", "Middleclick Friends.", Module.Category.MISC, true, false, false);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onUpdate() {
/* 22 */     if (Mouse.isButtonDown(2)) {
/* 23 */       if (!this.clicked && mc.field_71462_r == null) {
/* 24 */         onClick();
/*    */       }
/* 26 */       this.clicked = true;
/*    */     } else {
/* 28 */       this.clicked = false;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   private void onClick() {
/* 34 */     RayTraceResult result = mc.field_71476_x; Entity entity;
/* 35 */     if (result != null && result.field_72313_a == RayTraceResult.Type.ENTITY && entity = result.field_72308_g instanceof net.minecraft.entity.player.EntityPlayer) {
/* 36 */       if (Charon.friendManager.isFriend(entity.func_70005_c_())) {
/* 37 */         Charon.friendManager.removeFriend(entity.func_70005_c_());
/* 38 */         Command.sendMessage(ChatFormatting.RED + entity.func_70005_c_() + ChatFormatting.RED + " has been unfriended.");
/*    */       } else {
/* 40 */         Charon.friendManager.addFriend(entity.func_70005_c_());
/* 41 */         Command.sendMessage(ChatFormatting.AQUA + entity.func_70005_c_() + ChatFormatting.AQUA + " has been friended.");
/*    */       } 
/*    */     }
/* 44 */     this.clicked = true;
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/misc/MCF.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */