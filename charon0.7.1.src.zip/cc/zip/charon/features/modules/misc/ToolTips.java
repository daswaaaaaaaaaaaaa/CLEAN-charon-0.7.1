/*     */ package cc.zip.charon.features.modules.misc;
/*     */ 
/*     */ import cc.zip.charon.event.events.Render2DEvent;
/*     */ import cc.zip.charon.features.modules.Module;
/*     */ import cc.zip.charon.features.modules.client.ClickGui;
/*     */ import cc.zip.charon.util.ColorUtil;
/*     */ import cc.zip.charon.util.RenderUtil;
/*     */ import cc.zip.charon.util.Timer;
/*     */ import java.awt.Color;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.RenderHelper;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.inventory.IInventory;
/*     */ import net.minecraft.inventory.ItemStackHelper;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemShulkerBox;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.nbt.NBTTagCompound;
/*     */ import net.minecraft.tileentity.TileEntityShulkerBox;
/*     */ import net.minecraft.util.NonNullList;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraft.world.World;
/*     */ import net.minecraftforge.event.entity.player.ItemTooltipEvent;
/*     */ import net.minecraftforge.fml.common.eventhandler.EventPriority;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ public class ToolTips extends Module {
/*  30 */   private static final ResourceLocation SHULKER_GUI_TEXTURE = new ResourceLocation("textures/gui/container/shulker_box.png");
/*  31 */   private static ToolTips INSTANCE = new ToolTips();
/*  32 */   public Map<EntityPlayer, ItemStack> spiedPlayers = new ConcurrentHashMap<>();
/*  33 */   public Map<EntityPlayer, Timer> playerTimers = new ConcurrentHashMap<>();
/*  34 */   private int textRadarY = 0;
/*     */   
/*     */   public ToolTips() {
/*  37 */     super("ShulkerViewer", "Several tweaks for tooltips.", Module.Category.MISC, true, false, false);
/*  38 */     setInstance();
/*     */   }
/*     */   
/*     */   public static ToolTips getInstance() {
/*  42 */     if (INSTANCE == null) {
/*  43 */       INSTANCE = new ToolTips();
/*     */     }
/*  45 */     return INSTANCE;
/*     */   }
/*     */   
/*     */   public static void displayInv(ItemStack stack, String name) {
/*     */     try {
/*  50 */       Item item = stack.func_77973_b();
/*  51 */       TileEntityShulkerBox entityBox = new TileEntityShulkerBox();
/*  52 */       ItemShulkerBox shulker = (ItemShulkerBox)item;
/*  53 */       entityBox.field_145854_h = shulker.func_179223_d();
/*  54 */       entityBox.func_145834_a((World)mc.field_71441_e);
/*  55 */       ItemStackHelper.func_191283_b(stack.func_77978_p().func_74775_l("BlockEntityTag"), entityBox.field_190596_f);
/*  56 */       entityBox.func_145839_a(stack.func_77978_p().func_74775_l("BlockEntityTag"));
/*  57 */       entityBox.func_190575_a((name == null) ? stack.func_82833_r() : name);
/*  58 */       (new Thread(() -> {
/*     */             try {
/*     */               Thread.sleep(200L);
/*  61 */             } catch (InterruptedException interruptedException) {}
/*     */ 
/*     */             
/*     */             mc.field_71439_g.func_71007_a((IInventory)entityBox);
/*  65 */           })).start();
/*  66 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void setInstance() {
/*  72 */     INSTANCE = this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*  77 */     if (fullNullCheck()) {
/*     */       return;
/*     */     }
/*  80 */     for (EntityPlayer player : mc.field_71441_e.field_73010_i) {
/*  81 */       if (player == null || !(player.func_184614_ca().func_77973_b() instanceof ItemShulkerBox) || mc.field_71439_g == player)
/*     */         continue; 
/*  83 */       ItemStack stack = player.func_184614_ca();
/*  84 */       this.spiedPlayers.put(player, stack);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onRender2D(Render2DEvent event) {
/*  90 */     if (fullNullCheck()) {
/*     */       return;
/*     */     }
/*  93 */     int x = -3;
/*  94 */     int y = 124;
/*  95 */     this.textRadarY = 0;
/*  96 */     for (EntityPlayer player : mc.field_71441_e.field_73010_i) {
/*     */       
/*  98 */       if (this.spiedPlayers.get(player) == null)
/*  99 */         continue;  if (player.func_184614_ca() == null || !(player.func_184614_ca().func_77973_b() instanceof ItemShulkerBox)) {
/* 100 */         Timer playerTimer = this.playerTimers.get(player);
/* 101 */         if (playerTimer == null)
/* 102 */         { Timer timer = new Timer();
/* 103 */           timer.reset();
/* 104 */           this.playerTimers.put(player, timer); }
/* 105 */         else if (playerTimer.passedS(3.0D)) { continue; }
/*     */       
/*     */       } else {
/* 108 */         Timer playerTimer; if (player.func_184614_ca().func_77973_b() instanceof ItemShulkerBox && (playerTimer = this.playerTimers.get(player)) != null) {
/* 109 */           playerTimer.reset();
/* 110 */           this.playerTimers.put(player, playerTimer);
/*     */         } 
/* 112 */       }  ItemStack stack = this.spiedPlayers.get(player);
/* 113 */       renderShulkerToolTip(stack, x, y, player.func_70005_c_());
/* 114 */       y += 78; this.textRadarY = y - 10 - 114 + 2;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent(priority = EventPriority.HIGHEST)
/*     */   public void makeTooltip(ItemTooltipEvent event) {}
/*     */ 
/*     */   
/*     */   public void renderShulkerToolTip(ItemStack stack, int x, int y, String name) {
/* 124 */     NBTTagCompound tagCompound = stack.func_77978_p(); NBTTagCompound blockEntityTag;
/* 125 */     if (tagCompound != null && tagCompound.func_150297_b("BlockEntityTag", 10) && (blockEntityTag = tagCompound.func_74775_l("BlockEntityTag")).func_150297_b("Items", 9)) {
/* 126 */       GlStateManager.func_179098_w();
/* 127 */       GlStateManager.func_179140_f();
/* 128 */       GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/* 129 */       GlStateManager.func_179147_l();
/* 130 */       GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
/* 131 */       mc.func_110434_K().func_110577_a(SHULKER_GUI_TEXTURE);
/* 132 */       RenderUtil.drawTexturedRect(x, y, 0, 0, 176, 16, 500);
/* 133 */       RenderUtil.drawTexturedRect(x, y + 16, 0, 16, 176, 57, 500);
/* 134 */       RenderUtil.drawTexturedRect(x, y + 16 + 54, 0, 160, 176, 8, 500);
/* 135 */       GlStateManager.func_179097_i();
/* 136 */       Color color = new Color(((Integer)(ClickGui.getInstance()).red.getValue()).intValue(), ((Integer)(ClickGui.getInstance()).green.getValue()).intValue(), ((Integer)(ClickGui.getInstance()).blue.getValue()).intValue(), 200);
/* 137 */       this.renderer.drawStringWithShadow((name == null) ? stack.func_82833_r() : name, (x + 8), (y + 6), ColorUtil.toRGBA(color));
/* 138 */       GlStateManager.func_179126_j();
/* 139 */       RenderHelper.func_74520_c();
/* 140 */       GlStateManager.func_179091_B();
/* 141 */       GlStateManager.func_179142_g();
/* 142 */       GlStateManager.func_179145_e();
/* 143 */       NonNullList nonnulllist = NonNullList.func_191197_a(27, ItemStack.field_190927_a);
/* 144 */       ItemStackHelper.func_191283_b(blockEntityTag, nonnulllist);
/* 145 */       for (int i = 0; i < nonnulllist.size(); i++) {
/* 146 */         int iX = x + i % 9 * 18 + 8;
/* 147 */         int iY = y + i / 9 * 18 + 18;
/* 148 */         ItemStack itemStack = (ItemStack)nonnulllist.get(i);
/* 149 */         (mc.func_175597_ag()).field_178112_h.field_77023_b = 501.0F;
/* 150 */         RenderUtil.itemRender.func_180450_b(itemStack, iX, iY);
/* 151 */         RenderUtil.itemRender.func_180453_a(mc.field_71466_p, itemStack, iX, iY, null);
/* 152 */         (mc.func_175597_ag()).field_178112_h.field_77023_b = 0.0F;
/*     */       } 
/* 154 */       GlStateManager.func_179140_f();
/* 155 */       GlStateManager.func_179084_k();
/* 156 */       GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/misc/ToolTips.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */