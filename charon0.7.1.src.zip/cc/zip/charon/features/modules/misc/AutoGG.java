/*     */ package cc.zip.charon.features.modules.misc;
/*     */ 
/*     */ import cc.zip.charon.features.modules.Module;
/*     */ import cc.zip.charon.features.setting.Setting;
/*     */ import java.util.Objects;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketChatMessage;
/*     */ import net.minecraftforge.event.entity.living.LivingDeathEvent;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ public class AutoGG
/*     */   extends Module {
/*  17 */   private static AutoGG INSTANCE = new AutoGG();
/*  18 */   public Setting<String> custom = register(new Setting("Custom", "Nigga-Hack.me"));
/*  19 */   public Setting<String> test = register(new Setting("Test", "null"));
/*  20 */   private ConcurrentHashMap<String, Integer> targetedPlayers = null;
/*     */   
/*     */   public AutoGG() {
/*  23 */     super("AutoGG", "Sends msg after you kill someone", Module.Category.MISC, true, false, false);
/*  24 */     setInstance();
/*     */   }
/*     */   
/*     */   public static AutoGG getINSTANCE() {
/*  28 */     if (INSTANCE == null) {
/*  29 */       INSTANCE = new AutoGG();
/*     */     }
/*  31 */     return INSTANCE;
/*     */   }
/*     */   
/*     */   private void setInstance() {
/*  35 */     INSTANCE = this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  40 */     this.targetedPlayers = new ConcurrentHashMap<>();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  45 */     this.targetedPlayers = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*  50 */     if (nullCheck()) {
/*     */       return;
/*     */     }
/*  53 */     if (this.targetedPlayers == null) {
/*  54 */       this.targetedPlayers = new ConcurrentHashMap<>();
/*     */     }
/*  56 */     for (Entity entity : mc.field_71441_e.func_72910_y()) {
/*     */       String name2;
/*     */       EntityPlayer player;
/*  59 */       if (!(entity instanceof EntityPlayer) || (player = (EntityPlayer)entity).func_110143_aJ() > 0.0F || !shouldAnnounce(name2 = player.func_70005_c_()))
/*     */         continue; 
/*  61 */       doAnnounce(name2);
/*     */     } 
/*     */     
/*  64 */     this.targetedPlayers.forEach((name, timeout) -> {
/*     */           if (timeout.intValue() <= 0) {
/*     */             this.targetedPlayers.remove(name);
/*     */           } else {
/*     */             this.targetedPlayers.put(name, Integer.valueOf(timeout.intValue() - 1));
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onLeavingDeathEvent(LivingDeathEvent event) {
/*  76 */     if (mc.field_71439_g == null) {
/*     */       return;
/*     */     }
/*  79 */     if (this.targetedPlayers == null)
/*  80 */       this.targetedPlayers = new ConcurrentHashMap<>(); 
/*     */     EntityLivingBase entity;
/*  82 */     if ((entity = event.getEntityLiving()) == null) {
/*     */       return;
/*     */     }
/*  85 */     if (!(entity instanceof EntityPlayer)) {
/*     */       return;
/*     */     }
/*  88 */     EntityPlayer player = (EntityPlayer)entity;
/*  89 */     if (player.func_110143_aJ() > 0.0F) {
/*     */       return;
/*     */     }
/*  92 */     String name = player.func_70005_c_();
/*  93 */     if (shouldAnnounce(name)) {
/*  94 */       doAnnounce(name);
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean shouldAnnounce(String name) {
/*  99 */     return this.targetedPlayers.containsKey(name);
/*     */   }
/*     */   
/*     */   private void doAnnounce(String name) {
/* 103 */     this.targetedPlayers.remove(name);
/* 104 */     mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketChatMessage((String)this.custom.getValue()));
/* 105 */     int u = 0;
/* 106 */     for (int i = 0; i < 10; i++) {
/* 107 */       u++;
/*     */     }
/* 109 */     if (!((String)this.test.getValue()).equalsIgnoreCase("null")) {
/* 110 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketChatMessage((String)this.test.getValue()));
/*     */     }
/*     */   }
/*     */   
/*     */   public void addTargetedPlayer(String name) {
/* 115 */     if (Objects.equals(name, mc.field_71439_g.func_70005_c_())) {
/*     */       return;
/*     */     }
/* 118 */     if (this.targetedPlayers == null) {
/* 119 */       this.targetedPlayers = new ConcurrentHashMap<>();
/*     */     }
/* 121 */     this.targetedPlayers.put(name, Integer.valueOf(20));
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/misc/AutoGG.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */