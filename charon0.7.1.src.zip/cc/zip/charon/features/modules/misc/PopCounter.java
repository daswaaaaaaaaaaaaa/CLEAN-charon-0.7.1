/*    */ package cc.zip.charon.features.modules.misc;
/*    */ 
/*    */ import cc.zip.charon.features.command.Command;
/*    */ import cc.zip.charon.features.modules.Module;
/*    */ import com.mojang.realmsclient.gui.ChatFormatting;
/*    */ import java.util.HashMap;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ 
/*    */ public class PopCounter
/*    */   extends Module
/*    */ {
/* 12 */   public static HashMap<String, Integer> TotemPopContainer = new HashMap<>();
/* 13 */   private static PopCounter INSTANCE = new PopCounter();
/*    */   
/*    */   public PopCounter() {
/* 16 */     super("PopNotify", "Counts other players totem pops.", Module.Category.MISC, true, false, false);
/* 17 */     setInstance();
/*    */   }
/*    */   
/*    */   public static PopCounter getInstance() {
/* 21 */     if (INSTANCE == null) {
/* 22 */       INSTANCE = new PopCounter();
/*    */     }
/* 24 */     return INSTANCE;
/*    */   }
/*    */   
/*    */   private void setInstance() {
/* 28 */     INSTANCE = this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEnable() {
/* 33 */     TotemPopContainer.clear();
/*    */   }
/*    */   
/*    */   public void onDeath(EntityPlayer player) {
/* 37 */     if (TotemPopContainer.containsKey(player.func_70005_c_())) {
/* 38 */       int l_Count = ((Integer)TotemPopContainer.get(player.func_70005_c_())).intValue();
/* 39 */       TotemPopContainer.remove(player.func_70005_c_());
/* 40 */       if (l_Count == 1) {
/* 41 */         Command.sendMessage(ChatFormatting.WHITE + player.func_70005_c_() + ChatFormatting.GRAY + " died after popping " + ChatFormatting.WHITE + l_Count + ChatFormatting.GRAY + " Totem! Charon.eu :)");
/*    */       } else {
/* 43 */         Command.sendMessage(ChatFormatting.WHITE + player.func_70005_c_() + ChatFormatting.GRAY + " died after popping " + ChatFormatting.WHITE + l_Count + ChatFormatting.GRAY + " Totems! Charon.eu :>");
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   public void onTotemPop(EntityPlayer player) {
/* 49 */     if (fullNullCheck()) {
/*    */       return;
/*    */     }
/* 52 */     if (mc.field_71439_g.equals(player)) {
/*    */       return;
/*    */     }
/* 55 */     int l_Count = 1;
/* 56 */     if (TotemPopContainer.containsKey(player.func_70005_c_())) {
/* 57 */       l_Count = ((Integer)TotemPopContainer.get(player.func_70005_c_())).intValue();
/* 58 */       TotemPopContainer.put(player.func_70005_c_(), Integer.valueOf(++l_Count));
/*    */     } else {
/* 60 */       TotemPopContainer.put(player.func_70005_c_(), Integer.valueOf(l_Count));
/*    */     } 
/* 62 */     if (l_Count == 1) {
/* 63 */       Command.sendMessage(ChatFormatting.WHITE + player.func_70005_c_() + ChatFormatting.GRAY + " popped " + ChatFormatting.WHITE + l_Count + ChatFormatting.GRAY + " Totem. Charon.eu :s");
/*    */     } else {
/* 65 */       Command.sendMessage(ChatFormatting.WHITE + player.func_70005_c_() + ChatFormatting.GRAY + " popped " + ChatFormatting.WHITE + l_Count + ChatFormatting.GRAY + " Totems. Charon.eu :p");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/misc/PopCounter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */