/*    */ package cc.zip.charon.features.modules.misc;
/*    */ 
/*    */ import cc.zip.charon.Charon;
/*    */ import cc.zip.charon.event.events.PacketEvent;
/*    */ import cc.zip.charon.features.modules.Module;
/*    */ import cc.zip.charon.features.setting.Setting;
/*    */ import net.minecraft.network.play.client.CPacketChatMessage;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ public class ChatModifier
/*    */   extends Module {
/* 12 */   private static ChatModifier INSTANCE = new ChatModifier();
/* 13 */   public Setting<Boolean> clean = register(new Setting("NoChatBackground", Boolean.valueOf(false), "Cleans your chat"));
/* 14 */   public Setting<Boolean> infinite = register(new Setting("InfiniteChat", Boolean.valueOf(false), "Makes your chat infinite."));
/*    */   public boolean check;
/*    */   
/*    */   public ChatModifier() {
/* 18 */     super("BetterChat", "Modifies your chat", Module.Category.MISC, true, false, false);
/* 19 */     setInstance();
/*    */   }
/*    */   
/*    */   public static ChatModifier getInstance() {
/* 23 */     if (INSTANCE == null) {
/* 24 */       INSTANCE = new ChatModifier();
/*    */     }
/* 26 */     return INSTANCE;
/*    */   }
/*    */   
/*    */   private void setInstance() {
/* 30 */     INSTANCE = this;
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onPacketSend(PacketEvent.Send event) {
/* 35 */     if (event.getPacket() instanceof CPacketChatMessage) {
/* 36 */       String s = ((CPacketChatMessage)event.getPacket()).func_149439_c();
/* 37 */       this.check = !s.startsWith(Charon.commandManager.getPrefix());
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/misc/ChatModifier.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */