/*    */ package cc.zip.charon.features.modules.misc;
/*    */ 
/*    */ import cc.zip.charon.event.events.PacketEvent;
/*    */ import cc.zip.charon.features.modules.Module;
/*    */ import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
/*    */ import net.minecraft.util.EnumFacing;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ public class BuildHeight
/*    */   extends Module {
/*    */   public BuildHeight() {
/* 12 */     super("BuildHeight", "Allows you to place at build height", Module.Category.MISC, true, false, false);
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onPacketSend(PacketEvent.Send event) {
/*    */     CPacketPlayerTryUseItemOnBlock packet;
/* 18 */     if (event.getStage() == 0 && event.getPacket() instanceof CPacketPlayerTryUseItemOnBlock && (packet = (CPacketPlayerTryUseItemOnBlock)event.getPacket()).func_187023_a().func_177956_o() >= 255 && packet.func_187024_b() == EnumFacing.UP)
/* 19 */       packet.field_149579_d = EnumFacing.DOWN; 
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/misc/BuildHeight.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */