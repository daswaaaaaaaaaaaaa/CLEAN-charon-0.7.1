/*    */ package cc.zip.charon.features.modules.autocrystal;
/*    */ 
/*    */ import cc.zip.charon.event.EventStage;
/*    */ import net.minecraft.network.Packet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WurstplusEventPacket
/*    */   extends EventStage
/*    */ {
/*    */   private final Packet packet;
/*    */   
/*    */   public WurstplusEventPacket(Packet packet) {
/* 17 */     this.packet = packet;
/*    */   }
/*    */   
/*    */   public Packet get_packet() {
/* 21 */     return this.packet;
/*    */   }
/*    */   
/*    */   public static class SendPacket
/*    */     extends WurstplusEventPacket {
/*    */     public SendPacket(Packet packet) {
/* 27 */       super(packet);
/*    */     }
/*    */   }
/*    */   
/*    */   public static class ReceivePacket
/*    */     extends WurstplusEventPacket {
/*    */     public ReceivePacket(Packet packet) {
/* 34 */       super(packet);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/autocrystal/WurstplusEventPacket.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */