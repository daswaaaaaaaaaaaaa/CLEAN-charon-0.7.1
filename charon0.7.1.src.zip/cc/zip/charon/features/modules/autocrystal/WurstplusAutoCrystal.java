/*     */ package cc.zip.charon.features.modules.autocrystal;public class WurstplusAutoCrystal extends Module { public Setting<Boolean> debug; public Setting<Boolean> place_crystal; public Setting<Boolean> break_crystal; private final Setting<Integer> break_trys; public Setting<Boolean> anti_weakness; private final Setting<Integer> enemyRange; private final Setting<Integer> hit_range; private final Setting<Integer> place_range; private final Setting<Integer> hit_range_wall; private final Setting<Integer> wallPlaceRange; private final Setting<Integer> place_delay; private final Setting<Integer> break_delay; private final Setting<Integer> min_player_place; private final Setting<Integer> min_player_break;
/*     */   private final Setting<Integer> max_self_damage;
/*     */   public Setting<RotateMode> rotate_mode;
/*     */   public Setting<Boolean> raytrace;
/*     */   public Setting<Boolean> auto_switch;
/*     */   public Setting<Boolean> anti_suicide;
/*     */   public Setting<Boolean> client_side;
/*     */   public Setting<Boolean> jumpy_mode;
/*     */   public Setting<Boolean> anti_stuck;
/*     */   private final Setting<Integer> antiStuckTries;
/*     */   public Setting<Boolean> endcrystal;
/*     */   public Setting<Boolean> faceplace_mode;
/*     */   private final Setting<Integer> faceplace_mode_damage;
/*     */   public Setting<Boolean> fuck_armor_mode;
/*     */   private final Setting<Integer> fuck_armor_mode_precent;
/*     */   public Setting<Boolean> stop_while_mining;
/*     */   public Setting<Boolean> faceplace_check;
/*     */   public Setting<SwingMode> swing;
/*     */   public Setting<SwingMode> render_mode;
/*     */   public Setting<Boolean> old_render;
/*     */   public Setting<Boolean> future_render;
/*     */   public Setting<Boolean> top_block;
/*     */   private final Setting<Integer> r;
/*     */   private final Setting<Integer> g;
/*     */   private final Setting<Integer> b;
/*     */   private final Setting<Integer> a;
/*     */   private final Setting<Integer> a_out;
/*     */   public Setting<Boolean> rainbow_mode;
/*     */   public Setting<Boolean> sat;
/*     */   private final Setting<Integer> brightness;
/*     */   private final Setting<Integer> height;
/*     */   public Setting<Boolean> render_damage;
/*     */   private final ConcurrentHashMap<EntityEnderCrystal, Integer> attacked_crystals;
/*     */   private final List<BlockPos> placePosList;
/*     */   private final Timer remove_visual_timer;
/*     */   private EntityPlayer autoez_target;
/*     */   
/*     */   public WurstplusAutoCrystal() {
/*  39 */     super("WurstplusAutoCrystal", "?", Module.Category.MISC, true, false, false);
/*     */ 
/*     */     
/*  42 */     this.debug = register(new Setting("debug", Boolean.valueOf(false)));
/*  43 */     this.place_crystal = register(new Setting("debug", Boolean.valueOf(true)));
/*  44 */     this.break_crystal = register(new Setting("debug", Boolean.valueOf(true)));
/*  45 */     this.break_trys = register(new Setting("BlocksPerTick", Integer.valueOf(8), Integer.valueOf(1), Integer.valueOf(30)));
/*  46 */     this.anti_weakness = register(new Setting("debug", Boolean.valueOf(true)));
/*  47 */     this.enemyRange = register(new Setting("BlocksPerTick", Integer.valueOf(8), Integer.valueOf(1), Integer.valueOf(30)));
/*  48 */     this.hit_range = register(new Setting("BlocksPerTick", Integer.valueOf(8), Integer.valueOf(1), Integer.valueOf(30)));
/*  49 */     this.place_range = register(new Setting("BlocksPerTick", Integer.valueOf(8), Integer.valueOf(1), Integer.valueOf(30)));
/*  50 */     this.hit_range_wall = register(new Setting("BlocksPerTick", Integer.valueOf(8), Integer.valueOf(1), Integer.valueOf(30)));
/*  51 */     this.wallPlaceRange = register(new Setting("BlocksPerTick", Integer.valueOf(8), Integer.valueOf(1), Integer.valueOf(30)));
/*  52 */     this.place_delay = register(new Setting("BlocksPerTick", Integer.valueOf(8), Integer.valueOf(1), Integer.valueOf(30)));
/*  53 */     this.break_delay = register(new Setting("BlocksPerTick", Integer.valueOf(8), Integer.valueOf(1), Integer.valueOf(30)));
/*  54 */     this.min_player_place = register(new Setting("BlocksPerTick", Integer.valueOf(8), Integer.valueOf(1), Integer.valueOf(30)));
/*  55 */     this.min_player_break = register(new Setting("BlocksPerTick", Integer.valueOf(8), Integer.valueOf(1), Integer.valueOf(30)));
/*  56 */     this.max_self_damage = register(new Setting("BlocksPerTick", Integer.valueOf(8), Integer.valueOf(1), Integer.valueOf(30)));
/*  57 */     this.rotate_mode = register(new Setting("Rotate", RotateMode.Off));
/*  58 */     this.raytrace = register(new Setting("debug", Boolean.valueOf(true)));
/*  59 */     this.auto_switch = register(new Setting("debug", Boolean.valueOf(true)));
/*  60 */     this.anti_suicide = register(new Setting("debug", Boolean.valueOf(true)));
/*  61 */     this.client_side = register(new Setting("debug", Boolean.valueOf(false)));
/*  62 */     this.jumpy_mode = register(new Setting("debug", Boolean.valueOf(true)));
/*  63 */     this.anti_stuck = register(new Setting("debug", Boolean.valueOf(true)));
/*  64 */     this.antiStuckTries = register(new Setting("BlocksPerTick", Integer.valueOf(8), Integer.valueOf(1), Integer.valueOf(30)));
/*  65 */     this.endcrystal = register(new Setting("debug", Boolean.valueOf(true)));
/*  66 */     this.faceplace_mode = register(new Setting("debug", Boolean.valueOf(true)));
/*  67 */     this.faceplace_mode_damage = register(new Setting("BlocksPerTick", Integer.valueOf(8), Integer.valueOf(1), Integer.valueOf(30)));
/*  68 */     this.fuck_armor_mode = register(new Setting("debug", Boolean.valueOf(true)));
/*  69 */     this.fuck_armor_mode_precent = register(new Setting("BlocksPerTick", Integer.valueOf(8), Integer.valueOf(1), Integer.valueOf(30)));
/*  70 */     this.stop_while_mining = register(new Setting("debug", Boolean.valueOf(true)));
/*  71 */     this.faceplace_check = register(new Setting("debug", Boolean.valueOf(true)));
/*  72 */     this.swing = register(new Setting("Swing", SwingMode.None));
/*  73 */     this.render_mode = register(new Setting("Swing", SwingMode.None));
/*     */     
/*  75 */     this.old_render = register(new Setting("debug", Boolean.valueOf(true)));
/*  76 */     this.future_render = register(new Setting("debug", Boolean.valueOf(true)));
/*  77 */     this.top_block = register(new Setting("debug", Boolean.valueOf(true)));
/*  78 */     this.r = register(new Setting("Red", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255)));
/*  79 */     this.g = register(new Setting("Green", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255)));
/*  80 */     this.b = register(new Setting("Blue", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255)));
/*  81 */     this.a = register(new Setting("Alpha", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255)));
/*  82 */     this.a_out = register(new Setting("Alpha", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255)));
/*  83 */     this.rainbow_mode = register(new Setting("debug", Boolean.valueOf(true)));
/*  84 */     this.sat = register(new Setting("debug", Boolean.valueOf(true)));
/*  85 */     this.brightness = register(new Setting("BlocksPerTick", Integer.valueOf(8), Integer.valueOf(1), Integer.valueOf(30)));
/*  86 */     this.height = register(new Setting("BlocksPerTick", Integer.valueOf(8), Integer.valueOf(1), Integer.valueOf(30)));
/*  87 */     this.render_damage = register(new Setting("debug", Boolean.valueOf(true)));
/*     */     
/*  89 */     this.attacked_crystals = new ConcurrentHashMap<>();
/*  90 */     this.placePosList = new CopyOnWriteArrayList<>();
/*  91 */     this.remove_visual_timer = new Timer();
/*  92 */     this.autoez_target = null;
/*  93 */     this.detail_name = null;
/*  94 */     this.detail_hp = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 100 */     this.already_attacking = false;
/*     */   }
/*     */   private String detail_name; private int detail_hp; private BlockPos render_block_init; private BlockPos render_block_old; private double render_damage_value; private float yaw; private float pitch; private boolean already_attacking; private boolean is_rotating;
/*     */   private boolean did_anything;
/*     */   private boolean outline;
/*     */   private boolean solid;
/*     */   private int place_timeout;
/*     */   private int break_timeout;
/*     */   private int break_delay_counter;
/*     */   private int place_delay_counter;
/*     */   
/* 111 */   public enum SwingMode { Mainhand,
/* 112 */     Offhand,
/* 113 */     Both,
/* 114 */     None; }
/*     */ 
/*     */   
/*     */   public enum RenderMode
/*     */   {
/* 119 */     Pretty,
/* 120 */     Solid,
/* 121 */     Outline,
/* 122 */     None;
/*     */   }
/*     */   
/*     */   public enum RotateMode
/*     */   {
/* 127 */     Off,
/* 128 */     Old,
/* 129 */     Const,
/* 130 */     God;
/*     */   } }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/autocrystal/WurstplusAutoCrystal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */