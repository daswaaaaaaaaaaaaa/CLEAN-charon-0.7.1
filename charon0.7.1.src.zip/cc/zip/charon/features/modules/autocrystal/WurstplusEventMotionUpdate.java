/*    */ package cc.zip.charon.features.modules.autocrystal;
/*    */ 
/*    */ import cc.zip.charon.event.EventStage;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WurstplusEventMotionUpdate
/*    */   extends EventStage
/*    */ {
/*    */   public int stage;
/*    */   
/*    */   public WurstplusEventMotionUpdate(int stage) {
/* 14 */     this.stage = stage;
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/autocrystal/WurstplusEventMotionUpdate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */