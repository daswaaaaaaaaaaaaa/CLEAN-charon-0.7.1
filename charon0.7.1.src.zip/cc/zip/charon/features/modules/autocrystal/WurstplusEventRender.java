/*    */ package cc.zip.charon.features.modules.autocrystal;
/*    */ 
/*    */ import cc.zip.charon.event.EventStage;
/*    */ import net.minecraft.client.Minecraft;
/*    */ import net.minecraft.client.gui.ScaledResolution;
/*    */ import net.minecraft.client.renderer.BufferBuilder;
/*    */ import net.minecraft.client.renderer.Tessellator;
/*    */ import net.minecraft.util.math.Vec3d;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WurstplusEventRender
/*    */   extends EventStage
/*    */ {
/* 22 */   private final ScaledResolution res = new ScaledResolution(Minecraft.func_71410_x());
/*    */   private final Tessellator tessellator;
/*    */   private final Vec3d render_pos;
/*    */   
/*    */   public WurstplusEventRender(Tessellator tessellator, Vec3d pos) {
/* 27 */     this.tessellator = tessellator;
/* 28 */     this.render_pos = pos;
/*    */   }
/*    */   
/*    */   public Tessellator get_tessellator() {
/* 32 */     return this.tessellator;
/*    */   }
/*    */   
/*    */   public Vec3d get_render_pos() {
/* 36 */     return this.render_pos;
/*    */   }
/*    */   
/*    */   public BufferBuilder get_buffer_build() {
/* 40 */     return this.tessellator.func_178180_c();
/*    */   }
/*    */   
/*    */   public void set_translation(Vec3d pos) {
/* 44 */     get_buffer_build().func_178969_c(-pos.field_72450_a, -pos.field_72448_b, -pos.field_72449_c);
/*    */   }
/*    */   
/*    */   public void reset_translation() {
/* 48 */     set_translation(this.render_pos);
/*    */   }
/*    */   
/*    */   public double get_screen_width() {
/* 52 */     return this.res.func_78327_c();
/*    */   }
/*    */   
/*    */   public double get_screen_height() {
/* 56 */     return this.res.func_78324_d();
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/autocrystal/WurstplusEventRender.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */