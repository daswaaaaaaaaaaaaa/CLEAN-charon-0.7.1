/*    */ package cc.zip.charon.features.modules.autocrystal;
/*    */ 
/*    */ import cc.zip.charon.event.EventStage;
/*    */ import net.minecraft.entity.Entity;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WurstplusEventEntityRemoved
/*    */   extends EventStage
/*    */ {
/*    */   private final Entity entity;
/*    */   
/*    */   public WurstplusEventEntityRemoved(Entity entity) {
/* 17 */     this.entity = entity;
/*    */   }
/*    */   
/*    */   public Entity get_entity() {
/* 21 */     return this.entity;
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/autocrystal/WurstplusEventEntityRemoved.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */