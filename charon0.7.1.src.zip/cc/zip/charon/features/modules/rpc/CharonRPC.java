/*    */ package cc.zip.charon.features.modules.rpc;
/*    */ 
/*    */ import cc.zip.charon.discordutil.CharonRPCbig;
/*    */ import cc.zip.charon.features.modules.Module;
/*    */ import cc.zip.charon.features.setting.Setting;
/*    */ 
/*    */ public class CharonRPC
/*    */   extends Module {
/*    */   public static CharonRPC INSTANCE;
/*    */   public Setting<String> state;
/*    */   public Setting<Boolean> random;
/*    */   
/*    */   public CharonRPC() {
/* 14 */     super("CharonRPC", "Discord rich presence", Module.Category.MISC, false, false, false);
/* 15 */     INSTANCE = this;
/* 16 */     this.state = register(new Setting("State", "russian-elite", "Sets the state of the DiscordRPC."));
/* 17 */     this.random = register(new Setting("Random", Boolean.valueOf(true)));
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEnable() {
/* 22 */     CharonRPCbig.start();
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 27 */     CharonRPCbig.stop();
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/rpc/CharonRPC.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */