/*    */ package cc.zip.charon.features.modules.movement;
/*    */ 
/*    */ import cc.zip.charon.features.modules.Module;
/*    */ import cc.zip.charon.features.setting.Setting;
/*    */ import cc.zip.charon.util.none.PacketEvents;
/*    */ import cc.zip.charon.util.none.PushEvents;
/*    */ import net.minecraft.entity.Entity;
/*    */ import net.minecraft.entity.projectile.EntityFishHook;
/*    */ import net.minecraft.network.play.server.SPacketEntityStatus;
/*    */ import net.minecraft.network.play.server.SPacketEntityVelocity;
/*    */ import net.minecraft.network.play.server.SPacketExplosion;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ public class Velocity extends Module {
/* 16 */   private static Velocity INSTANCE = new Velocity();
/* 17 */   public Setting<Boolean> knockBack = register(new Setting("KnockBack", Boolean.valueOf(true)));
/* 18 */   public Setting<Boolean> noPush = register(new Setting("NoPush", Boolean.valueOf(true)));
/* 19 */   public Setting<Float> horizontal = register(new Setting("Horizontal", Float.valueOf(0.0F), Float.valueOf(0.0F), Float.valueOf(100.0F)));
/* 20 */   public Setting<Float> vertical = register(new Setting("Vertical", Float.valueOf(0.0F), Float.valueOf(0.0F), Float.valueOf(100.0F)));
/* 21 */   public Setting<Boolean> explosions = register(new Setting("Explosions", Boolean.valueOf(true)));
/* 22 */   public Setting<Boolean> bobbers = register(new Setting("Bobbers", Boolean.valueOf(true)));
/* 23 */   public Setting<Boolean> water = register(new Setting("Water", Boolean.valueOf(false)));
/* 24 */   public Setting<Boolean> blocks = register(new Setting("Blocks", Boolean.valueOf(false)));
/* 25 */   public Setting<Boolean> ice = register(new Setting("Ice", Boolean.valueOf(false)));
/*    */   
/*    */   public Velocity() {
/* 28 */     super("Velocity", "Allows you to control your velocity", Module.Category.MOVEMENT, true, false, false);
/* 29 */     setInstance();
/*    */   }
/*    */   
/*    */   public static Velocity getINSTANCE() {
/* 33 */     if (INSTANCE == null) {
/* 34 */       INSTANCE = new Velocity();
/*    */     }
/* 36 */     return INSTANCE;
/*    */   }
/*    */   
/*    */   private void setInstance() {
/* 40 */     INSTANCE = this;
/*    */   }
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onPacketReceived(PacketEvents.Receive event) {
/* 46 */     if (event.getStage() == 0 && mc.field_71439_g != null) {
/*    */       SPacketEntityVelocity velocity;
/*    */ 
/*    */       
/* 50 */       if (((Boolean)this.knockBack.getValue()).booleanValue() && event.getPacket() instanceof SPacketEntityVelocity && (velocity = (SPacketEntityVelocity)event.getPacket()).func_149412_c() == mc.field_71439_g.field_145783_c) {
/* 51 */         if (((Float)this.horizontal.getValue()).floatValue() == 0.0F && ((Float)this.vertical.getValue()).floatValue() == 0.0F) {
/* 52 */           event.setCanceled(true);
/*    */           return;
/*    */         } 
/* 55 */         velocity.field_149415_b = (int)(velocity.field_149415_b * ((Float)this.horizontal.getValue()).floatValue());
/* 56 */         velocity.field_149416_c = (int)(velocity.field_149416_c * ((Float)this.vertical.getValue()).floatValue());
/* 57 */         velocity.field_149414_d = (int)(velocity.field_149414_d * ((Float)this.horizontal.getValue()).floatValue());
/*    */       }  Entity entity; SPacketEntityStatus packet;
/* 59 */       if (event.getPacket() instanceof SPacketEntityStatus && ((Boolean)this.bobbers.getValue()).booleanValue() && (packet = (SPacketEntityStatus)event.getPacket()).func_149160_c() == 31 && entity = packet.func_149161_a((World)mc.field_71441_e) instanceof EntityFishHook) {
/* 60 */         EntityFishHook fishHook = (EntityFishHook)entity;
/* 61 */         if (fishHook.field_146043_c == mc.field_71439_g) {
/* 62 */           event.setCanceled(true);
/*    */         }
/*    */       } 
/*    */       
/* 66 */       if (((Boolean)this.explosions.getValue()).booleanValue() && event.getPacket() instanceof SPacketExplosion) {
/*    */         
/* 68 */         SPacketExplosion velocity_ = (SPacketExplosion)event.getPacket();
/* 69 */         velocity_.field_149152_f *= ((Float)this.horizontal.getValue()).floatValue();
/* 70 */         velocity_.field_149153_g *= ((Float)this.vertical.getValue()).floatValue();
/* 71 */         velocity_.field_149159_h *= ((Float)this.horizontal.getValue()).floatValue();
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onPush(PushEvents event) {
/* 78 */     if (event.getStage() == 0 && ((Boolean)this.noPush.getValue()).booleanValue() && event.entity.equals(mc.field_71439_g)) {
/* 79 */       if (((Float)this.horizontal.getValue()).floatValue() == 0.0F && ((Float)this.vertical.getValue()).floatValue() == 0.0F) {
/* 80 */         event.setCanceled(true);
/*    */         return;
/*    */       } 
/* 83 */       event.x = -event.x * ((Float)this.horizontal.getValue()).floatValue();
/* 84 */       event.y = -event.y * ((Float)this.vertical.getValue()).floatValue();
/* 85 */       event.z = -event.z * ((Float)this.horizontal.getValue()).floatValue();
/* 86 */     } else if (event.getStage() == 1 && ((Boolean)this.blocks.getValue()).booleanValue()) {
/* 87 */       event.setCanceled(true);
/* 88 */     } else if (event.getStage() == 2 && ((Boolean)this.water.getValue()).booleanValue() && mc.field_71439_g != null && mc.field_71439_g.equals(event.entity)) {
/* 89 */       event.setCanceled(true);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/movement/Velocity.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */