/*     */ package cc.zip.charon.features.modules.movement;
/*     */ 
/*     */ import cc.zip.charon.Charon;
/*     */ import cc.zip.charon.event.events.ClientEvent;
/*     */ import cc.zip.charon.event.events.MoveEvent;
/*     */ import cc.zip.charon.features.modules.Module;
/*     */ import cc.zip.charon.features.setting.Setting;
/*     */ import cc.zip.charon.util.EntityUtil;
/*     */ import cc.zip.charon.util.EntityUtilTwo;
/*     */ import cc.zip.charon.util.MotionUtil;
/*     */ import cc.zip.charon.util.Timer;
/*     */ import cc.zip.charon.util.none.WorldTimer;
/*     */ import net.minecraft.entity.EntityLivingBase;
/*     */ import net.minecraft.util.MovementInput;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Speed
/*     */   extends Module
/*     */ {
/*     */   public Speed() {
/*  29 */     super("Speed", "Speed.", Module.Category.MOVEMENT, true, false, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  44 */     this.modes = register(new Setting("Mode", Mode.STRAFE));
/*  45 */     this.timersr = register(new Setting("Timer", Boolean.valueOf(true)));
/*  46 */     this.strafeJump = register(new Setting("Jump", Boolean.valueOf(true), v -> (this.modes.getValue() == Mode.INSTANT)));
/*  47 */     this.noShake = register(new Setting("NoShake", Boolean.valueOf(true)));
/*  48 */     this.useTimer = register(new Setting("UseTimer", Boolean.valueOf(true), v -> (this.modes.getValue() == Mode.INSTANT)));
/*  49 */     this.yPortSpeed = register(new Setting("YPort Speed", Double.valueOf(0.1D), Double.valueOf(0.0D), Double.valueOf(1.0D), v -> (this.modes.getValue() == Mode.YPORT)));
/*  50 */     this.motionyonoff = register(new Setting("My- on off", Boolean.valueOf(true)));
/*  51 */     this.stepyport = register(new Setting("OnStep 2", Boolean.valueOf(true)));
/*  52 */     this.timer = new Timer();
/*  53 */     this.stepheight = 2.0F;
/*  54 */     this.startY = 0.0D;
/*  55 */     this.antiShake = false;
/*  56 */     this.minY = 0.0D;
/*  57 */     this.changeY = false;
/*  58 */     this.highChainVal = 0.0D;
/*  59 */     this.lowChainVal = 0.0D;
/*  60 */     this.oneTime = false;
/*  61 */     this.bounceHeight = 0.4D;
/*  62 */     this.move = 0.26F;
/*  63 */     this.vanillaCounter = 0;
/*     */     
/*  65 */     this.timers = new WorldTimer();
/*     */     setInstance();
/*     */   }
/*  68 */   private static Speed INSTANCE = new Speed(); public Setting<Mode> modes; public Setting<Boolean> timersr; public Setting<Boolean> strafeJump; public Setting<Boolean> noShake; public Setting<Boolean> useTimer; private final Setting<Double> yPortSpeed; public Setting<Boolean> motionyonoff; public Setting<Boolean> stepyport; private Timer timer; private float stepheight; public double startY; private boolean shouldReturn() { return (Charon.moduleManager.isModuleEnabled("ElytraFlight") || Charon.moduleManager.isModuleEnabled("Flight")); }
/*     */   public boolean antiShake;
/*     */   public double minY; public boolean changeY; private double highChainVal; private double lowChainVal; private boolean oneTime; private double bounceHeight; private float move; private int vanillaCounter; private final WorldTimer timers; public static Speed getInstance() { if (INSTANCE == null)
/*     */       INSTANCE = new Speed(); 
/*     */     return INSTANCE; } private void setInstance() { INSTANCE = this; } public String getDisplayInfo() {
/*  73 */     return this.modes.currentEnumName();
/*     */   }
/*     */   
/*  76 */   public enum Mode { STRAFE, YPORT, INSTANT; }
/*     */   
/*     */   public void onDisable() {
/*  79 */     this.timer.reset();
/*  80 */     EntityUtilTwo.resetTimer();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*  85 */     if (mc.field_71439_g == null || mc.field_71441_e == null) {
/*  86 */       disable();
/*     */       
/*     */       return;
/*     */     } 
/*  90 */     if (this.modes.getValue() == Mode.YPORT) {
/*  91 */       handleYPortSpeed();
/*     */     }
/*  93 */     if (!mc.field_71439_g.func_70617_f_() || mc.field_71439_g.func_70090_H() || (mc.field_71439_g.func_180799_ab() && ((Boolean)this.stepyport.getValue()).booleanValue())) {
/*  94 */       Step.mc.field_71439_g.field_70138_W = this.stepheight;
/*     */       return;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void onToggle() {
/* 100 */     Step.mc.field_71439_g.field_70138_W = 0.6F;
/*     */     
/* 102 */     if (this.modes.getValue() == Mode.YPORT && ((Boolean)this.motionyonoff.getValue()).booleanValue()) {
/* 103 */       mc.field_71439_g.field_70181_x = -3.0D;
/*     */     }
/*     */   }
/*     */   
/*     */   private void handleYPortSpeed() {
/* 108 */     if (!MotionUtil.isMoving((EntityLivingBase)mc.field_71439_g) || (mc.field_71439_g.func_70090_H() && mc.field_71439_g.func_180799_ab()) || mc.field_71439_g.field_70123_F) {
/*     */       return;
/*     */     }
/*     */     
/* 112 */     if (mc.field_71439_g.field_70122_E) {
/* 113 */       EntityUtilTwo.setTimer(1.15F);
/* 114 */       mc.field_71439_g.func_70664_aZ();
/* 115 */       MotionUtil.setSpeed((EntityLivingBase)mc.field_71439_g, MotionUtil.getBaseMoveSpeed() + ((Double)this.yPortSpeed.getValue()).doubleValue());
/*     */     } else {
/* 117 */       mc.field_71439_g.field_70181_x = -1.0D;
/* 118 */       EntityUtilTwo.resetTimer();
/*     */     } 
/*     */   }
/*     */   @SubscribeEvent
/*     */   public void onSettingChange(ClientEvent event) {
/* 123 */     if (event.getStage() == 2 && event.getSetting().equals(this.modes) && this.modes.getPlannedValue() == Mode.INSTANT)
/* 124 */       mc.field_71439_g.field_70181_x = -0.1D; 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onMode(MoveEvent event) {
/* 129 */     if (!shouldReturn() && event.getStage() == 0 && this.modes.getValue() == Mode.INSTANT && !nullCheck() && !mc.field_71439_g.func_70093_af() && !mc.field_71439_g.func_70090_H() && !mc.field_71439_g.func_180799_ab() && (mc.field_71439_g.field_71158_b.field_192832_b != 0.0F || mc.field_71439_g.field_71158_b.field_78902_a != 0.0F)) {
/* 130 */       if (mc.field_71439_g.field_70122_E && ((Boolean)this.strafeJump.getValue()).booleanValue()) {
/* 131 */         mc.field_71439_g.field_70181_x = 0.4D;
/* 132 */         event.setY(0.4D);
/*     */       } 
/* 134 */       MovementInput movementInput = mc.field_71439_g.field_71158_b;
/* 135 */       float moveForward = movementInput.field_192832_b;
/* 136 */       float moveStrafe = movementInput.field_78902_a;
/* 137 */       float rotationYaw = mc.field_71439_g.field_70177_z;
/* 138 */       if (moveForward == 0.0D && moveStrafe == 0.0D) {
/* 139 */         event.setX(0.0D);
/* 140 */         event.setZ(0.0D);
/*     */       } else {
/* 142 */         if (moveForward != 0.0D) {
/* 143 */           if (moveStrafe > 0.0D) {
/* 144 */             rotationYaw += ((moveForward > 0.0D) ? -45 : 45);
/* 145 */           } else if (moveStrafe < 0.0D) {
/* 146 */             rotationYaw += ((moveForward > 0.0D) ? 45 : -45);
/*     */           } 
/* 148 */           moveStrafe = 0.0F;
/* 149 */           float f = (moveForward == 0.0F) ? moveForward : (moveForward = (moveForward > 0.0D) ? 1.0F : -1.0F);
/*     */         } 
/* 151 */         moveStrafe = (moveStrafe == 0.0F) ? moveStrafe : ((moveStrafe > 0.0D) ? 1.0F : -1.0F);
/* 152 */         event.setX(moveForward * EntityUtil.getMaxSpeed() * Math.cos(Math.toRadians((rotationYaw + 90.0F))) + moveStrafe * EntityUtil.getMaxSpeed() * Math.sin(Math.toRadians((rotationYaw + 90.0F))));
/* 153 */         event.setZ(moveForward * EntityUtil.getMaxSpeed() * Math.sin(Math.toRadians((rotationYaw + 90.0F))) - moveStrafe * EntityUtil.getMaxSpeed() * Math.cos(Math.toRadians((rotationYaw + 90.0F))));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/movement/Speed.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */