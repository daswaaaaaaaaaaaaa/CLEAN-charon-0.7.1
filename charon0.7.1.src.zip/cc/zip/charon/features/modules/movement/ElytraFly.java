/*     */ package cc.zip.charon.features.modules.movement;
/*     */ 
/*     */ import cc.zip.charon.event.events.MoveEvent;
/*     */ import cc.zip.charon.event.events.PacketEvent;
/*     */ import cc.zip.charon.event.events.UpdateWalkingPlayerEvent;
/*     */ import cc.zip.charon.features.modules.Module;
/*     */ import cc.zip.charon.features.setting.Setting;
/*     */ import cc.zip.charon.util.MathUtil;
/*     */ import cc.zip.charon.util.Timer;
/*     */ import net.minecraft.entity.Entity;
/*     */ import net.minecraft.entity.player.EntityPlayer;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.inventory.EntityEquipmentSlot;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketEntityAction;
/*     */ import net.minecraft.util.math.MathHelper;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ElytraFly
/*     */   extends Module
/*     */ {
/*  25 */   public Setting<Mode> mode = register(new Setting("Mode", Mode.FLY));
/*  26 */   public Setting<Integer> devMode = register(new Setting("Type", Integer.valueOf(2), Integer.valueOf(1), Integer.valueOf(3), v -> (this.mode.getValue() == Mode.BETTER), "EventMode"));
/*  27 */   public Setting<Float> speed = register(new Setting("Speed", Float.valueOf(1.0F), Float.valueOf(0.0F), Float.valueOf(10.0F), v -> (this.mode.getValue() != Mode.FLY && this.mode.getValue() != Mode.BOOST && this.mode.getValue() != Mode.BETTER), "The Speed."));
/*  28 */   public Setting<Float> vSpeed = register(new Setting("VSpeed", Float.valueOf(0.3F), Float.valueOf(0.0F), Float.valueOf(10.0F), v -> (this.mode.getValue() == Mode.BETTER), "Vertical Speed"));
/*  29 */   public Setting<Float> hSpeed = register(new Setting("HSpeed", Float.valueOf(1.0F), Float.valueOf(0.0F), Float.valueOf(10.0F), v -> (this.mode.getValue() == Mode.BETTER), "Horizontal Speed"));
/*  30 */   public Setting<Float> glide = register(new Setting("Glide", Float.valueOf(1.0E-4F), Float.valueOf(0.0F), Float.valueOf(0.2F), v -> (this.mode.getValue() == Mode.BETTER), "Glide Speed"));
/*  31 */   public Setting<Float> tooBeeSpeed = register(new Setting("TooBeeSpeed", Float.valueOf(1.8000001F), Float.valueOf(1.0F), Float.valueOf(2.0F), "Speed for flight on 2b2t"));
/*  32 */   public Setting<Boolean> autoStart = register(new Setting("AutoStart", Boolean.valueOf(true)));
/*  33 */   public Setting<Boolean> disableInLiquid = register(new Setting("NoLiquid", Boolean.valueOf(true)));
/*  34 */   public Setting<Boolean> infiniteDura = register(new Setting("InfiniteDura", Boolean.valueOf(false)));
/*  35 */   public Setting<Boolean> noKick = register(new Setting("NoKick", Boolean.valueOf(false), v -> (this.mode.getValue() == Mode.SuolBypass2)));
/*  36 */   public Setting<Boolean> allowUp = register(new Setting("AllowUp", Boolean.valueOf(true), v -> (this.mode.getValue() == Mode.BETTER)));
/*  37 */   public Setting<Boolean> lockPitch = register(new Setting("LockPitch", Boolean.valueOf(false)));
/*  38 */   private static ElytraFly INSTANCE = new ElytraFly();
/*  39 */   private final Timer timer = new Timer();
/*  40 */   private final Timer bypassTimer = new Timer();
/*     */   private boolean vertical;
/*     */   private Double posX;
/*     */   private Double flyHeight;
/*     */   private Double posZ;
/*     */   
/*     */   public ElytraFly() {
/*  47 */     super("ElytraFly", "Makes Elytra Flight better.", Module.Category.MOVEMENT, true, false, false);
/*  48 */     setInstance();
/*     */   }
/*     */   
/*     */   private void setInstance() {
/*  52 */     INSTANCE = this;
/*     */   }
/*     */   
/*     */   public static ElytraFly getInstance() {
/*  56 */     if (INSTANCE == null) {
/*  57 */       INSTANCE = new ElytraFly();
/*     */     }
/*  59 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  64 */     if (this.mode.getValue() == Mode.BETTER && !((Boolean)this.autoStart.getValue()).booleanValue() && ((Integer)this.devMode.getValue()).intValue() == 1) {
/*  65 */       mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)mc.field_71439_g, CPacketEntityAction.Action.START_FALL_FLYING));
/*     */     }
/*  67 */     this.flyHeight = null;
/*  68 */     this.posX = null;
/*  69 */     this.posZ = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDisplayInfo() {
/*  74 */     return this.mode.currentEnumName();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onUpdate() {}
/*     */ 
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onSendPacket(PacketEvent.Send event) {}
/*     */ 
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onMove(MoveEvent event) {}
/*     */ 
/*     */   
/*     */   private void setMoveSpeed(MoveEvent event, double speed) {
/*  92 */     double forward = mc.field_71439_g.field_71158_b.field_192832_b;
/*  93 */     double strafe = mc.field_71439_g.field_71158_b.field_78902_a;
/*  94 */     float yaw = mc.field_71439_g.field_70177_z;
/*  95 */     if (forward == 0.0D && strafe == 0.0D) {
/*  96 */       event.setX(0.0D);
/*  97 */       event.setZ(0.0D);
/*  98 */       mc.field_71439_g.field_70159_w = 0.0D;
/*  99 */       mc.field_71439_g.field_70179_y = 0.0D;
/*     */     } else {
/* 101 */       if (forward != 0.0D) {
/* 102 */         if (strafe > 0.0D) {
/* 103 */           yaw += ((forward > 0.0D) ? -45 : 45);
/* 104 */         } else if (strafe < 0.0D) {
/* 105 */           yaw += ((forward > 0.0D) ? 45 : -45);
/*     */         } 
/* 107 */         strafe = 0.0D;
/* 108 */         if (forward > 0.0D) {
/* 109 */           forward = 1.0D;
/* 110 */         } else if (forward < 0.0D) {
/* 111 */           forward = -1.0D;
/*     */         } 
/*     */       } 
/* 114 */       double x = forward * speed * -Math.sin(Math.toRadians(yaw)) + strafe * speed * Math.cos(Math.toRadians(yaw));
/* 115 */       double z = forward * speed * Math.cos(Math.toRadians(yaw)) - strafe * speed * -Math.sin(Math.toRadians(yaw));
/* 116 */       event.setX(x);
/* 117 */       event.setZ(z);
/* 118 */       mc.field_71439_g.field_70159_w = x;
/* 119 */       mc.field_71439_g.field_70179_y = z;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void onTick() {
/*     */     float yaw;
/* 125 */     if (!mc.field_71439_g.func_184613_cA()) {
/*     */       return;
/*     */     }
/* 128 */     switch ((Mode)this.mode.getValue()) {
/*     */       case BOOST:
/* 130 */         if (mc.field_71439_g.func_70090_H()) {
/* 131 */           mc.func_147114_u().func_147297_a((Packet)new CPacketEntityAction((Entity)mc.field_71439_g, CPacketEntityAction.Action.START_FALL_FLYING));
/*     */           return;
/*     */         } 
/* 134 */         if (mc.field_71474_y.field_74314_A.func_151470_d()) {
/* 135 */           mc.field_71439_g.field_70181_x += 0.08D;
/* 136 */         } else if (mc.field_71474_y.field_74311_E.func_151470_d()) {
/* 137 */           mc.field_71439_g.field_70181_x -= 0.04D;
/*     */         } 
/* 139 */         if (mc.field_71474_y.field_74351_w.func_151470_d()) {
/* 140 */           float f = (float)Math.toRadians(mc.field_71439_g.field_70177_z);
/* 141 */           mc.field_71439_g.field_70159_w -= (MathHelper.func_76126_a(f) * 0.05F);
/* 142 */           mc.field_71439_g.field_70179_y += (MathHelper.func_76134_b(f) * 0.05F);
/*     */           break;
/*     */         } 
/* 145 */         if (!mc.field_71474_y.field_74368_y.func_151470_d())
/* 146 */           break;  yaw = (float)Math.toRadians(mc.field_71439_g.field_70177_z);
/* 147 */         mc.field_71439_g.field_70159_w += (MathHelper.func_76126_a(yaw) * 0.05F);
/* 148 */         mc.field_71439_g.field_70179_y -= (MathHelper.func_76134_b(yaw) * 0.05F);
/*     */         break;
/*     */       
/*     */       case FLY:
/* 152 */         mc.field_71439_g.field_71075_bZ.field_75100_b = true;
/*     */         break;
/*     */     } 
/*     */   }
/*     */   @SubscribeEvent
/*     */   public void onUpdateWalkingPlayer(UpdateWalkingPlayerEvent event) {
/*     */     double rotationYaw;
/* 159 */     if (mc.field_71439_g.func_184582_a(EntityEquipmentSlot.CHEST).func_77973_b() != Items.field_185160_cR) {
/*     */       return;
/*     */     }
/* 162 */     switch (event.getStage()) {
/*     */       case 0:
/* 164 */         if (((Boolean)this.disableInLiquid.getValue()).booleanValue() && (mc.field_71439_g.func_70090_H() || mc.field_71439_g.func_180799_ab())) {
/* 165 */           if (mc.field_71439_g.func_184613_cA()) {
/* 166 */             mc.func_147114_u().func_147297_a((Packet)new CPacketEntityAction((Entity)mc.field_71439_g, CPacketEntityAction.Action.START_FALL_FLYING));
/*     */           }
/*     */           return;
/*     */         } 
/* 170 */         if (((Boolean)this.autoStart.getValue()).booleanValue() && mc.field_71474_y.field_74314_A.func_151470_d() && !mc.field_71439_g.func_184613_cA() && mc.field_71439_g.field_70181_x < 0.0D && this.timer.passedMs(250L)) {
/* 171 */           mc.func_147114_u().func_147297_a((Packet)new CPacketEntityAction((Entity)mc.field_71439_g, CPacketEntityAction.Action.START_FALL_FLYING));
/* 172 */           this.timer.reset();
/*     */         } 
/* 174 */         if (this.mode.getValue() == Mode.BETTER) {
/* 175 */           double[] dir = MathUtil.directionSpeed((((Integer)this.devMode.getValue()).intValue() == 1) ? ((Float)this.speed.getValue()).floatValue() : ((Float)this.hSpeed.getValue()).floatValue());
/* 176 */           switch (((Integer)this.devMode.getValue()).intValue()) {
/*     */             case 1:
/* 178 */               mc.field_71439_g.func_70016_h(0.0D, 0.0D, 0.0D);
/* 179 */               mc.field_71439_g.field_70747_aH = ((Float)this.speed.getValue()).floatValue();
/* 180 */               if (mc.field_71474_y.field_74314_A.func_151470_d()) {
/* 181 */                 mc.field_71439_g.field_70181_x += ((Float)this.speed.getValue()).floatValue();
/*     */               }
/* 183 */               if (mc.field_71474_y.field_74311_E.func_151470_d()) {
/* 184 */                 mc.field_71439_g.field_70181_x -= ((Float)this.speed.getValue()).floatValue();
/*     */               }
/* 186 */               if (mc.field_71439_g.field_71158_b.field_78902_a != 0.0F || mc.field_71439_g.field_71158_b.field_192832_b != 0.0F) {
/* 187 */                 mc.field_71439_g.field_70159_w = dir[0];
/* 188 */                 mc.field_71439_g.field_70179_y = dir[1];
/*     */                 break;
/*     */               } 
/* 191 */               mc.field_71439_g.field_70159_w = 0.0D;
/* 192 */               mc.field_71439_g.field_70179_y = 0.0D;
/*     */               break;
/*     */             
/*     */             case 2:
/* 196 */               if (mc.field_71439_g.func_184613_cA()) {
/* 197 */                 if (this.flyHeight == null) {
/* 198 */                   this.flyHeight = Double.valueOf(mc.field_71439_g.field_70163_u);
/*     */                 }
/*     */               } else {
/* 201 */                 this.flyHeight = null;
/*     */                 return;
/*     */               } 
/* 204 */               if (((Boolean)this.noKick.getValue()).booleanValue()) {
/* 205 */                 this.flyHeight = Double.valueOf(this.flyHeight.doubleValue() - ((Float)this.glide.getValue()).floatValue());
/*     */               }
/* 207 */               this.posX = Double.valueOf(0.0D);
/* 208 */               this.posZ = Double.valueOf(0.0D);
/* 209 */               if (mc.field_71439_g.field_71158_b.field_78902_a != 0.0F || mc.field_71439_g.field_71158_b.field_192832_b != 0.0F) {
/* 210 */                 this.posX = Double.valueOf(dir[0]);
/* 211 */                 this.posZ = Double.valueOf(dir[1]);
/*     */               } 
/* 213 */               if (mc.field_71474_y.field_74314_A.func_151470_d()) {
/* 214 */                 this.flyHeight = Double.valueOf(mc.field_71439_g.field_70163_u + ((Float)this.vSpeed.getValue()).floatValue());
/*     */               }
/* 216 */               if (mc.field_71474_y.field_74311_E.func_151470_d()) {
/* 217 */                 this.flyHeight = Double.valueOf(mc.field_71439_g.field_70163_u - ((Float)this.vSpeed.getValue()).floatValue());
/*     */               }
/* 219 */               mc.field_71439_g.func_70107_b(mc.field_71439_g.field_70165_t + this.posX.doubleValue(), this.flyHeight.doubleValue(), mc.field_71439_g.field_70161_v + this.posZ.doubleValue());
/* 220 */               mc.field_71439_g.func_70016_h(0.0D, 0.0D, 0.0D);
/*     */               break;
/*     */             
/*     */             case 3:
/* 224 */               if (mc.field_71439_g.func_184613_cA()) {
/* 225 */                 if (this.flyHeight == null || this.posX == null || this.posX.doubleValue() == 0.0D || this.posZ == null || this.posZ.doubleValue() == 0.0D) {
/* 226 */                   this.flyHeight = Double.valueOf(mc.field_71439_g.field_70163_u);
/* 227 */                   this.posX = Double.valueOf(mc.field_71439_g.field_70165_t);
/* 228 */                   this.posZ = Double.valueOf(mc.field_71439_g.field_70161_v);
/*     */                 } 
/*     */               } else {
/* 231 */                 this.flyHeight = null;
/* 232 */                 this.posX = null;
/* 233 */                 this.posZ = null;
/*     */                 return;
/*     */               } 
/* 236 */               if (((Boolean)this.noKick.getValue()).booleanValue()) {
/* 237 */                 this.flyHeight = Double.valueOf(this.flyHeight.doubleValue() - ((Float)this.glide.getValue()).floatValue());
/*     */               }
/* 239 */               if (mc.field_71439_g.field_71158_b.field_78902_a != 0.0F || mc.field_71439_g.field_71158_b.field_192832_b != 0.0F) {
/* 240 */                 this.posX = Double.valueOf(this.posX.doubleValue() + dir[0]);
/* 241 */                 this.posZ = Double.valueOf(this.posZ.doubleValue() + dir[1]);
/*     */               } 
/* 243 */               if (((Boolean)this.allowUp.getValue()).booleanValue() && mc.field_71474_y.field_74314_A.func_151470_d()) {
/* 244 */                 this.flyHeight = Double.valueOf(mc.field_71439_g.field_70163_u + (((Float)this.vSpeed.getValue()).floatValue() / 10.0F));
/*     */               }
/* 246 */               if (mc.field_71474_y.field_74311_E.func_151470_d()) {
/* 247 */                 this.flyHeight = Double.valueOf(mc.field_71439_g.field_70163_u - (((Float)this.vSpeed.getValue()).floatValue() / 10.0F));
/*     */               }
/* 249 */               mc.field_71439_g.func_70107_b(this.posX.doubleValue(), this.flyHeight.doubleValue(), this.posZ.doubleValue());
/* 250 */               mc.field_71439_g.func_70016_h(0.0D, 0.0D, 0.0D);
/*     */               break;
/*     */           } 
/*     */         } 
/* 254 */         rotationYaw = Math.toRadians(mc.field_71439_g.field_70177_z);
/* 255 */         if (mc.field_71439_g.func_184613_cA()) {
/* 256 */           float speedScaled; double[] directionSpeedPacket; switch ((Mode)this.mode.getValue()) {
/*     */             case SuolBypass:
/* 258 */               speedScaled = ((Float)this.speed.getValue()).floatValue() * 0.05F;
/* 259 */               if (mc.field_71474_y.field_74314_A.func_151470_d()) {
/* 260 */                 mc.field_71439_g.field_70181_x += speedScaled;
/*     */               }
/* 262 */               if (mc.field_71474_y.field_74311_E.func_151470_d()) {
/* 263 */                 mc.field_71439_g.field_70181_x -= speedScaled;
/*     */               }
/* 265 */               if (mc.field_71474_y.field_74351_w.func_151470_d()) {
/* 266 */                 mc.field_71439_g.field_70159_w -= Math.sin(rotationYaw) * speedScaled;
/* 267 */                 mc.field_71439_g.field_70179_y += Math.cos(rotationYaw) * speedScaled;
/*     */               } 
/* 269 */               if (!mc.field_71474_y.field_74368_y.func_151470_d())
/* 270 */                 break;  mc.field_71439_g.field_70159_w += Math.sin(rotationYaw) * speedScaled;
/* 271 */               mc.field_71439_g.field_70179_y -= Math.cos(rotationYaw) * speedScaled;
/*     */               break;
/*     */             
/*     */             case SuolBypass2:
/* 275 */               freezePlayer((EntityPlayer)mc.field_71439_g);
/* 276 */               runNoKick((EntityPlayer)mc.field_71439_g);
/* 277 */               directionSpeedPacket = MathUtil.directionSpeed(((Float)this.speed.getValue()).floatValue());
/* 278 */               if (mc.field_71439_g.field_71158_b.field_78901_c) {
/* 279 */                 mc.field_71439_g.field_70181_x = ((Float)this.speed.getValue()).floatValue();
/*     */               }
/* 281 */               if (mc.field_71439_g.field_71158_b.field_78899_d) {
/* 282 */                 mc.field_71439_g.field_70181_x = -((Float)this.speed.getValue()).floatValue();
/*     */               }
/* 284 */               if (mc.field_71439_g.field_71158_b.field_78902_a != 0.0F || mc.field_71439_g.field_71158_b.field_192832_b != 0.0F) {
/* 285 */                 mc.field_71439_g.field_70159_w = directionSpeedPacket[0];
/* 286 */                 mc.field_71439_g.field_70179_y = directionSpeedPacket[1];
/*     */               } 
/* 288 */               mc.func_147114_u().func_147297_a((Packet)new CPacketEntityAction((Entity)mc.field_71439_g, CPacketEntityAction.Action.START_FALL_FLYING));
/* 289 */               mc.func_147114_u().func_147297_a((Packet)new CPacketEntityAction((Entity)mc.field_71439_g, CPacketEntityAction.Action.START_FALL_FLYING));
/*     */               break;
/*     */           } 
/*     */         
/*     */         } 
/* 294 */         if (!((Boolean)this.infiniteDura.getValue()).booleanValue())
/* 295 */           break;  mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)mc.field_71439_g, CPacketEntityAction.Action.START_FALL_FLYING));
/*     */         break;
/*     */       
/*     */       case 1:
/* 299 */         if (!((Boolean)this.infiniteDura.getValue()).booleanValue())
/* 300 */           break;  mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketEntityAction((Entity)mc.field_71439_g, CPacketEntityAction.Action.START_FALL_FLYING));
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   private double[] forwardStrafeYaw(double forward, double strafe, double yaw) {
/* 306 */     double[] result = { forward, strafe, yaw };
/* 307 */     if ((forward != 0.0D || strafe != 0.0D) && forward != 0.0D) {
/* 308 */       if (strafe > 0.0D) {
/* 309 */         result[2] = result[2] + ((forward > 0.0D) ? -45 : 45);
/* 310 */       } else if (strafe < 0.0D) {
/* 311 */         result[2] = result[2] + ((forward > 0.0D) ? 45 : -45);
/*     */       } 
/* 313 */       result[1] = 0.0D;
/* 314 */       if (forward > 0.0D) {
/* 315 */         result[0] = 1.0D;
/* 316 */       } else if (forward < 0.0D) {
/* 317 */         result[0] = -1.0D;
/*     */       } 
/*     */     } 
/* 320 */     return result;
/*     */   }
/*     */   
/*     */   private void freezePlayer(EntityPlayer player) {
/* 324 */     player.field_70159_w = 0.0D;
/* 325 */     player.field_70181_x = 0.0D;
/* 326 */     player.field_70179_y = 0.0D;
/*     */   }
/*     */   
/*     */   private void runNoKick(EntityPlayer player) {
/* 330 */     if (((Boolean)this.noKick.getValue()).booleanValue() && !player.func_184613_cA() && player.field_70173_aa % 4 == 0) {
/* 331 */       player.field_70181_x = -0.03999999910593033D;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/* 337 */     if (fullNullCheck() || mc.field_71439_g.field_71075_bZ.field_75098_d) {
/*     */       return;
/*     */     }
/* 340 */     mc.field_71439_g.field_71075_bZ.field_75100_b = false;
/*     */   }
/*     */   
/*     */   public enum Mode {
/* 344 */     SuolBypass,
/* 345 */     SuolBypass2,
/* 346 */     BOOST,
/* 347 */     FLY,
/* 348 */     BETTER;
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/movement/ElytraFly.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */