/*    */ package cc.zip.charon.features.modules.movement;
/*    */ 
/*    */ import cc.zip.charon.features.modules.Module;
/*    */ import cc.zip.charon.features.setting.Setting;
/*    */ import cc.zip.charon.util.Util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReverseStep
/*    */   extends Module
/*    */ {
/* 17 */   private static ReverseStep INSTANCE = new ReverseStep();
/* 18 */   private final Setting<Boolean> twoBlocks = register(new Setting("2Blocks", Boolean.FALSE));
/*    */   
/*    */   public ReverseStep() {
/* 21 */     super("ReverseStep", "ReverseStep.", Module.Category.MOVEMENT, true, false, false);
/* 22 */     setInstance();
/*    */   }
/*    */   
/*    */   public static ReverseStep getInstance() {
/* 26 */     if (INSTANCE == null) {
/* 27 */       INSTANCE = new ReverseStep();
/*    */     }
/* 29 */     return INSTANCE;
/*    */   }
/*    */   
/*    */   private void setInstance() {
/* 33 */     INSTANCE = this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onUpdate() {
/* 38 */     if (Util.mc.field_71439_g == null || Util.mc.field_71441_e == null || Util.mc.field_71439_g.func_70090_H() || Util.mc.field_71439_g.func_180799_ab()) {
/*    */       return;
/*    */     }
/* 41 */     if (Util.mc.field_71439_g.field_70122_E)
/* 42 */       Util.mc.field_71439_g.field_70181_x--; 
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/movement/ReverseStep.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */