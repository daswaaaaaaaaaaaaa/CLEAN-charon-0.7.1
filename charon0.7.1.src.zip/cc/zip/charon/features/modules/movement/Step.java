/*    */ package cc.zip.charon.features.modules.movement;
/*    */ 
/*    */ import cc.zip.charon.features.modules.Module;
/*    */ import cc.zip.charon.features.setting.Setting;
/*    */ 
/*    */ public class Step extends Module {
/*    */   public Setting<Integer> stepHeight;
/*    */   private double[] selectedPositions;
/*    */   private int packets;
/*    */   private static Step instance;
/*    */   
/*    */   public Step() {
/* 13 */     super("Step", "Allows you to step up blocks", Module.Category.MOVEMENT, true, false, false);
/* 14 */     this.stepHeight = register(new Setting("Height", Integer.valueOf(2), Integer.valueOf(1), Integer.valueOf(4)));
/* 15 */     instance = this;
/*    */   }
/*    */   
/*    */   public static Step getInstance() {
/* 19 */     if (instance == null) {
/* 20 */       instance = new Step();
/*    */     }
/* 22 */     return instance;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onToggle() {
/* 27 */     mc.field_71439_g.field_70138_W = 0.6F;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onUpdate() {
/* 32 */     if (!mc.field_71439_g.func_70617_f_() || mc.field_71439_g.func_70090_H() || mc.field_71439_g.func_180799_ab()) {
/* 33 */       mc.field_71439_g.field_70138_W = ((Integer)this.stepHeight.getValue()).intValue();
/*    */       return;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/movement/Step.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */