/*   */ package cc.zip.charon.features.modules.movement;
/*   */ 
/*   */ import cc.zip.charon.features.modules.Module;
/*   */ 
/*   */ public class Scaffold
/*   */   extends Module {
/*   */   public Scaffold() {
/* 8 */     super("Scaffold", "Scaffold.", Module.Category.MOVEMENT, true, false, false);
/*   */   }
/*   */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/movement/Scaffold.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */