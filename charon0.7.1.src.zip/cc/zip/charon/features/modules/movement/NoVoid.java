/*    */ package cc.zip.charon.features.modules.movement;
/*    */ 
/*    */ import cc.zip.charon.features.modules.Module;
/*    */ import net.minecraft.util.math.RayTraceResult;
/*    */ import net.minecraft.util.math.Vec3d;
/*    */ 
/*    */ public class NoVoid
/*    */   extends Module {
/*    */   public NoVoid() {
/* 10 */     super("NoVoid", "Glitches you up from void.", Module.Category.MOVEMENT, false, false, false);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onUpdate() {
/* 15 */     if (fullNullCheck()) {
/*    */       return;
/*    */     }
/* 18 */     if (!mc.field_71439_g.field_70145_X && mc.field_71439_g.field_70163_u <= 0.0D) {
/* 19 */       RayTraceResult trace = mc.field_71441_e.func_147447_a(mc.field_71439_g.func_174791_d(), new Vec3d(mc.field_71439_g.field_70165_t, 0.0D, mc.field_71439_g.field_70161_v), false, false, false);
/* 20 */       if (trace != null && trace.field_72313_a == RayTraceResult.Type.BLOCK) {
/*    */         return;
/*    */       }
/* 23 */       mc.field_71439_g.func_70016_h(0.0D, 0.0D, 0.0D);
/* 24 */       if (mc.field_71439_g.func_184187_bx() != null)
/* 25 */         mc.field_71439_g.func_184187_bx().func_70016_h(0.0D, 0.0D, 0.0D); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/movement/NoVoid.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */