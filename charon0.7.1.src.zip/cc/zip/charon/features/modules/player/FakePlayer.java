/*    */ package cc.zip.charon.features.modules.player;
/*    */ 
/*    */ import cc.zip.charon.features.command.Command;
/*    */ import cc.zip.charon.features.modules.Module;
/*    */ import cc.zip.charon.features.setting.Setting;
/*    */ import cc.zip.charon.util.WorldUtil;
/*    */ import net.minecraft.client.entity.EntityOtherPlayerMP;
/*    */ 
/*    */ public class FakePlayer extends Module {
/*    */   private EntityOtherPlayerMP _fakePlayer;
/*    */   private EntityOtherPlayerMP fakeplayers;
/*    */   public Setting<String> name;
/*    */   public Setting<Boolean> inventory;
/*    */   public Setting<Boolean> angles;
/*    */   
/*    */   public FakePlayer() {
/* 17 */     super("FakePlayer", "Spawns a FakePlayer for testing", Module.Category.PLAYER, false, false, false);
/*    */ 
/*    */     
/* 20 */     this.name = register(new Setting("name", "CHARON.EU"));
/* 21 */     this.inventory = register(new Setting("Copy Inventory", Boolean.valueOf(true)));
/* 22 */     this.angles = register(new Setting("Copy Angles", Boolean.valueOf(true)));
/*    */   }
/*    */   
/*    */   public void onUpdate() {
/* 26 */     if (mc.field_71441_e == null)
/* 27 */       disable(); 
/*    */   }
/*    */   
/*    */   public void onEnable() {
/* 31 */     if (nullCheck()) {
/*    */       return;
/*    */     }
/* 34 */     WorldUtil.createFakePlayer((String)this.name.getValue(), ((Boolean)this.inventory.getValue()).booleanValue(), ((Boolean)this.angles.getValue()).booleanValue(), true, false, -6640);
/*    */     
/* 36 */     Command.sendMessage("done");
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 41 */     mc.field_71441_e.func_73028_b(-6640);
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/player/FakePlayer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */