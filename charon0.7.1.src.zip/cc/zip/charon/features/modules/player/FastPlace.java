/*    */ package cc.zip.charon.features.modules.player;
/*    */ 
/*    */ import cc.zip.charon.features.modules.Module;
/*    */ import cc.zip.charon.util.InventoryUtil;
/*    */ import net.minecraft.item.ItemExpBottle;
/*    */ 
/*    */ public class FastPlace
/*    */   extends Module {
/*    */   public FastPlace() {
/* 10 */     super("FastPlace", "Fast everything.", Module.Category.PLAYER, true, false, false);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onUpdate() {
/* 15 */     if (fullNullCheck()) {
/*    */       return;
/*    */     }
/* 18 */     if (InventoryUtil.holdingItem(ItemExpBottle.class))
/* 19 */       mc.field_71467_ac = 0; 
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/player/FastPlace.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */