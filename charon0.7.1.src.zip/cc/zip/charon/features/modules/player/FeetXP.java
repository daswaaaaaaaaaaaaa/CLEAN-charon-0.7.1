/*    */ package cc.zip.charon.features.modules.player;
/*    */ 
/*    */ import cc.zip.charon.Charon;
/*    */ import cc.zip.charon.event.events.UpdateWalkingPlayerEvent;
/*    */ import cc.zip.charon.features.modules.Module;
/*    */ import net.minecraft.init.Items;
/*    */ import net.minecraft.util.EnumHand;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ public class FeetXP
/*    */   extends Module {
/*    */   public FeetXP() {
/* 13 */     super("FootXP", "??.", Module.Category.PLAYER, true, false, false);
/*    */   }
/*    */ 
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onUpdateWalkingPlayer(UpdateWalkingPlayerEvent event) {
/* 19 */     boolean mainHand = (FastPlace.mc.field_71439_g.func_184614_ca().func_77973_b() == Items.field_151062_by);
/* 20 */     boolean offHand = (FastPlace.mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151062_by), bl = offHand;
/* 21 */     if (FastPlace.mc.field_71474_y.field_74313_G.func_151470_d() && ((FastPlace.mc.field_71439_g.func_184600_cs() == EnumHand.MAIN_HAND && mainHand) || (FastPlace.mc.field_71439_g.func_184600_cs() == EnumHand.OFF_HAND && offHand)))
/* 22 */       Charon.rotationManager.setPlayerYaw(-90.0F); 
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/player/FeetXP.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */