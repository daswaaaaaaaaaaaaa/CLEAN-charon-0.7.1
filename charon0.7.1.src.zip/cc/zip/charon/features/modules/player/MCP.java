/*    */ package cc.zip.charon.features.modules.player;
/*    */ 
/*    */ import cc.zip.charon.features.modules.Module;
/*    */ import cc.zip.charon.util.InventoryUtil;
/*    */ import net.minecraft.entity.player.EntityPlayer;
/*    */ import net.minecraft.init.Items;
/*    */ import net.minecraft.item.ItemEnderPearl;
/*    */ import net.minecraft.util.EnumHand;
/*    */ import net.minecraft.world.World;
/*    */ import org.lwjgl.input.Mouse;
/*    */ 
/*    */ public class MCP
/*    */   extends Module {
/*    */   public MCP() {
/* 15 */     super("MCP", "Throws a pearl", Module.Category.PLAYER, false, false, false);
/*    */   }
/*    */   private boolean clicked = false;
/*    */   
/*    */   public void onEnable() {
/* 20 */     if (fullNullCheck()) {
/* 21 */       disable();
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void onTick() {
/* 27 */     if (Mouse.isButtonDown(2)) {
/* 28 */       if (!this.clicked) {
/* 29 */         throwPearl();
/*    */       }
/* 31 */       this.clicked = true;
/*    */     } else {
/* 33 */       this.clicked = false;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   private void throwPearl() {
/* 39 */     int pearlSlot = InventoryUtil.findHotbarBlock(ItemEnderPearl.class);
/* 40 */     boolean offhand = (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151079_bi), bl = offhand;
/* 41 */     if (pearlSlot != -1 || offhand) {
/* 42 */       int oldslot = mc.field_71439_g.field_71071_by.field_70461_c;
/* 43 */       if (!offhand) {
/* 44 */         InventoryUtil.switchToHotbarSlot(pearlSlot, false);
/*    */       }
/* 46 */       mc.field_71442_b.func_187101_a((EntityPlayer)mc.field_71439_g, (World)mc.field_71441_e, offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND);
/* 47 */       if (!offhand)
/* 48 */         InventoryUtil.switchToHotbarSlot(oldslot, false); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/player/MCP.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */