/*     */ package cc.zip.charon.features.modules.player;
/*     */ 
/*     */ import cc.zip.charon.Charon;
/*     */ import cc.zip.charon.event.events.BlockEvent;
/*     */ import cc.zip.charon.event.events.Render3DEvent;
/*     */ import cc.zip.charon.features.modules.Module;
/*     */ import cc.zip.charon.features.setting.Setting;
/*     */ import cc.zip.charon.util.BlockUtil;
/*     */ import cc.zip.charon.util.InventoryUtil;
/*     */ import cc.zip.charon.util.RenderUtil;
/*     */ import cc.zip.charon.util.Timer;
/*     */ import java.awt.Color;
/*     */ import net.minecraft.block.state.IBlockState;
/*     */ import net.minecraft.init.Blocks;
/*     */ import net.minecraft.item.ItemSword;
/*     */ import net.minecraft.network.Packet;
/*     */ import net.minecraft.network.play.client.CPacketPlayerDigging;
/*     */ import net.minecraft.util.EnumHand;
/*     */ import net.minecraft.util.math.BlockPos;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ public class Speedmine
/*     */   extends Module
/*     */ {
/*  25 */   private static Speedmine INSTANCE = new Speedmine();
/*  26 */   private final Timer timer = new Timer();
/*  27 */   public Setting<Mode> mode = register(new Setting("Mode", Mode.PACKET));
/*  28 */   public Setting<Float> damage = register(new Setting("Damage", Float.valueOf(0.7F), Float.valueOf(0.0F), Float.valueOf(1.0F), v -> (this.mode.getValue() == Mode.DAMAGE)));
/*  29 */   public Setting<Boolean> webSwitch = register(new Setting("WebSwitch", Boolean.valueOf(false)));
/*  30 */   public Setting<Boolean> doubleBreak = register(new Setting("DoubleBreak", Boolean.valueOf(false)));
/*  31 */   public Setting<Boolean> render = register(new Setting("Render", Boolean.valueOf(false)));
/*  32 */   public Setting<Boolean> box = register(new Setting("Box", Boolean.valueOf(false), v -> ((Boolean)this.render.getValue()).booleanValue()));
/*  33 */   private final Setting<Integer> boxAlpha = register(new Setting("BoxAlpha", Integer.valueOf(85), Integer.valueOf(0), Integer.valueOf(255), v -> (((Boolean)this.box.getValue()).booleanValue() && ((Boolean)this.render.getValue()).booleanValue())));
/*  34 */   public Setting<Boolean> outline = register(new Setting("Outline", Boolean.valueOf(true), v -> ((Boolean)this.render.getValue()).booleanValue()));
/*  35 */   private final Setting<Float> lineWidth = register(new Setting("Width", Float.valueOf(1.0F), Float.valueOf(0.1F), Float.valueOf(5.0F), v -> (((Boolean)this.outline.getValue()).booleanValue() && ((Boolean)this.render.getValue()).booleanValue())));
/*     */   public BlockPos currentPos;
/*     */   public IBlockState currentBlockState;
/*     */   
/*     */   public Speedmine() {
/*  40 */     super("Speedmine", "Speeds up mining.", Module.Category.PLAYER, true, false, false);
/*  41 */     setInstance();
/*     */   }
/*     */   
/*     */   public static Speedmine getInstance() {
/*  45 */     if (INSTANCE == null) {
/*  46 */       INSTANCE = new Speedmine();
/*     */     }
/*  48 */     return INSTANCE;
/*     */   }
/*     */   
/*     */   private void setInstance() {
/*  52 */     INSTANCE = this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onTick() {
/*  57 */     if (this.currentPos != null) {
/*  58 */       if (!mc.field_71441_e.func_180495_p(this.currentPos).equals(this.currentBlockState) || mc.field_71441_e.func_180495_p(this.currentPos).func_177230_c() == Blocks.field_150350_a) {
/*  59 */         this.currentPos = null;
/*  60 */         this.currentBlockState = null;
/*  61 */       } else if (((Boolean)this.webSwitch.getValue()).booleanValue() && this.currentBlockState.func_177230_c() == Blocks.field_150321_G && mc.field_71439_g.func_184614_ca().func_77973_b() instanceof net.minecraft.item.ItemPickaxe) {
/*  62 */         InventoryUtil.switchToHotbarSlot(ItemSword.class, false);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*  69 */     if (fullNullCheck()) {
/*     */       return;
/*     */     }
/*  72 */     mc.field_71442_b.field_78781_i = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onRender3D(Render3DEvent event) {
/*  77 */     if (((Boolean)this.render.getValue()).booleanValue() && this.currentPos != null && this.currentBlockState.func_177230_c() == Blocks.field_150343_Z) {
/*  78 */       Color color = new Color(this.timer.passedMs((int)(2000.0F * Charon.serverManager.getTpsFactor())) ? 0 : 255, this.timer.passedMs((int)(2000.0F * Charon.serverManager.getTpsFactor())) ? 255 : 0, 0, 255);
/*  79 */       RenderUtil.drawBoxESP(this.currentPos, color, false, color, ((Float)this.lineWidth.getValue()).floatValue(), ((Boolean)this.outline.getValue()).booleanValue(), ((Boolean)this.box.getValue()).booleanValue(), ((Integer)this.boxAlpha.getValue()).intValue(), false);
/*     */     } 
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onBlockEvent(BlockEvent event) {
/*  85 */     if (fullNullCheck()) {
/*     */       return;
/*     */     }
/*  88 */     if (event.getStage() == 3 && mc.field_71442_b.field_78770_f > 0.1F) {
/*  89 */       mc.field_71442_b.field_78778_j = true;
/*     */     }
/*  91 */     if (event.getStage() == 4) {
/*     */       
/*  93 */       if (BlockUtil.canBreak(event.pos)) {
/*  94 */         mc.field_71442_b.field_78778_j = false;
/*  95 */         switch ((Mode)this.mode.getValue()) {
/*     */           case PACKET:
/*  97 */             if (this.currentPos == null) {
/*  98 */               this.currentPos = event.pos;
/*  99 */               this.currentBlockState = mc.field_71441_e.func_180495_p(this.currentPos);
/* 100 */               this.timer.reset();
/*     */             } 
/* 102 */             mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
/* 103 */             mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, event.pos, event.facing));
/* 104 */             mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, event.pos, event.facing));
/* 105 */             event.setCanceled(true);
/*     */             break;
/*     */           
/*     */           case DAMAGE:
/* 109 */             if (mc.field_71442_b.field_78770_f < ((Float)this.damage.getValue()).floatValue())
/*     */               break; 
/* 111 */             mc.field_71442_b.field_78770_f = 1.0F;
/*     */             break;
/*     */           
/*     */           case INSTANT:
/* 115 */             mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
/* 116 */             mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, event.pos, event.facing));
/* 117 */             mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, event.pos, event.facing));
/* 118 */             mc.field_71442_b.func_187103_a(event.pos);
/* 119 */             mc.field_71441_e.func_175698_g(event.pos); break;
/*     */         } 
/*     */       } 
/*     */       BlockPos above;
/* 123 */       if (((Boolean)this.doubleBreak.getValue()).booleanValue() && BlockUtil.canBreak(above = event.pos.func_177982_a(0, 1, 0)) && mc.field_71439_g.func_70011_f(above.func_177958_n(), above.func_177956_o(), above.func_177952_p()) <= 5.0D) {
/* 124 */         mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
/* 125 */         mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, above, event.facing));
/* 126 */         mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, above, event.facing));
/* 127 */         mc.field_71442_b.func_187103_a(above);
/* 128 */         mc.field_71441_e.func_175698_g(above);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDisplayInfo() {
/* 135 */     return this.mode.currentEnumName();
/*     */   }
/*     */   
/*     */   public enum Mode {
/* 139 */     PACKET,
/* 140 */     DAMAGE,
/* 141 */     INSTANT;
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/player/Speedmine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */