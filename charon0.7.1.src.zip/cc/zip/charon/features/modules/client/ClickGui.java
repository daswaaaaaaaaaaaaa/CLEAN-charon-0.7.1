/*     */ package cc.zip.charon.features.modules.client;
/*     */ 
/*     */ import cc.zip.charon.Charon;
/*     */ import cc.zip.charon.event.events.ClientEvent;
/*     */ import cc.zip.charon.features.command.Command;
/*     */ import cc.zip.charon.features.gui.Gui;
/*     */ import cc.zip.charon.features.modules.Module;
/*     */ import cc.zip.charon.features.setting.Setting;
/*     */ import com.mojang.realmsclient.gui.ChatFormatting;
/*     */ import net.minecraft.client.gui.GuiScreen;
/*     */ import net.minecraft.client.settings.GameSettings;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ 
/*     */ public class ClickGui
/*     */   extends Module {
/*  17 */   private static ClickGui INSTANCE = new ClickGui();
/*  18 */   public Setting<String> prefix = register(new Setting("Prefix", "-"));
/*  19 */   public Setting<Boolean> customFov = register(new Setting("CustomFov", Boolean.valueOf(false)));
/*  20 */   public Setting<Boolean> blurs = register(new Setting("Blur", Boolean.valueOf(true)));
/*     */ 
/*     */   
/*  23 */   public Setting<Boolean> customcolorb = register(new Setting("Custom Color", Boolean.valueOf(true)));
/*     */   
/*  25 */   public Setting<Float> fov = register(new Setting("Fov", Float.valueOf(150.0F), Float.valueOf(-180.0F), Float.valueOf(180.0F)));
/*  26 */   public Setting<Integer> red = register(new Setting("Red", Integer.valueOf(126), Integer.valueOf(0), Integer.valueOf(255)));
/*  27 */   public Setting<Integer> green = register(new Setting("Green", Integer.valueOf(198), Integer.valueOf(0), Integer.valueOf(255)));
/*  28 */   public Setting<Integer> blue = register(new Setting("Blue", Integer.valueOf(198), Integer.valueOf(0), Integer.valueOf(255)));
/*  29 */   public Setting<Integer> hoverAlpha = register(new Setting("Alpha", Integer.valueOf(198), Integer.valueOf(0), Integer.valueOf(255)));
/*     */   
/*  31 */   public Setting<Integer> redopen = register(new Setting("Red - Open", Integer.valueOf(126), Integer.valueOf(0), Integer.valueOf(255), v -> ((Boolean)this.customcolorb.getValue()).booleanValue()));
/*  32 */   public Setting<Integer> greenopen = register(new Setting("Green - Open", Integer.valueOf(198), Integer.valueOf(0), Integer.valueOf(255), v -> ((Boolean)this.customcolorb.getValue()).booleanValue()));
/*  33 */   public Setting<Integer> blueopen = register(new Setting("Blue - Open", Integer.valueOf(198), Integer.valueOf(0), Integer.valueOf(255), v -> ((Boolean)this.customcolorb.getValue()).booleanValue()));
/*  34 */   public Setting<Integer> alphaopen = register(new Setting("Alpha - Open", Integer.valueOf(198), Integer.valueOf(0), Integer.valueOf(255), v -> ((Boolean)this.customcolorb.getValue()).booleanValue()));
/*     */ 
/*     */   
/*  37 */   public Setting<Integer> topRed = register(new Setting("SecondRed", Integer.valueOf(95), Integer.valueOf(0), Integer.valueOf(255)));
/*  38 */   public Setting<Integer> topGreen = register(new Setting("SecondGreen", Integer.valueOf(95), Integer.valueOf(0), Integer.valueOf(255)));
/*  39 */   public Setting<Integer> topBlue = register(new Setting("SecondBlue", Integer.valueOf(95), Integer.valueOf(0), Integer.valueOf(255)));
/*  40 */   public Setting<Integer> alpha = register(new Setting("HoverAlpha", Integer.valueOf(240), Integer.valueOf(0), Integer.valueOf(255)));
/*  41 */   public Setting<Boolean> rainbow = register(new Setting("Rainbow", Boolean.valueOf(false)));
/*  42 */   public Setting<rainbowMode> rainbowModeHud = register(new Setting("HRainbowMode", rainbowMode.Static, v -> ((Boolean)this.rainbow.getValue()).booleanValue()));
/*  43 */   public Setting<rainbowModeArray> rainbowModeA = register(new Setting("ARainbowMode", rainbowModeArray.Static, v -> ((Boolean)this.rainbow.getValue()).booleanValue()));
/*  44 */   public Setting<Integer> rainbowHue = register(new Setting("Delay", Integer.valueOf(240), Integer.valueOf(0), Integer.valueOf(600), v -> ((Boolean)this.rainbow.getValue()).booleanValue()));
/*  45 */   public Setting<Float> rainbowBrightness = register(new Setting("Brightness ", Float.valueOf(150.0F), Float.valueOf(1.0F), Float.valueOf(255.0F), v -> ((Boolean)this.rainbow.getValue()).booleanValue()));
/*  46 */   public Setting<Float> rainbowSaturation = register(new Setting("Saturation", Float.valueOf(150.0F), Float.valueOf(1.0F), Float.valueOf(255.0F), v -> ((Boolean)this.rainbow.getValue()).booleanValue()));
/*     */   private Gui click;
/*     */   
/*     */   public ClickGui() {
/*  50 */     super("ClickGui", "Opens the ClickGui", Module.Category.CLIENT, true, false, false);
/*  51 */     setInstance();
/*     */   }
/*     */   
/*     */   public static ClickGui getInstance() {
/*  55 */     if (INSTANCE == null) {
/*  56 */       INSTANCE = new ClickGui();
/*     */     }
/*  58 */     return INSTANCE;
/*     */   }
/*     */   
/*     */   private void setInstance() {
/*  62 */     INSTANCE = this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*  67 */     if (((Boolean)this.customFov.getValue()).booleanValue()) {
/*  68 */       mc.field_71474_y.func_74304_a(GameSettings.Options.FOV, ((Float)this.fov.getValue()).floatValue());
/*     */     }
/*  70 */     if (!((Boolean)this.blurs.getValue()).booleanValue()) {
/*  71 */       mc.field_71460_t.func_147706_e().func_148021_a();
/*     */     }
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onSettingChange(ClientEvent event) {
/*  77 */     if (event.getStage() == 2 && event.getSetting().getFeature().equals(this)) {
/*  78 */       if (event.getSetting().equals(this.prefix)) {
/*  79 */         Charon.commandManager.setPrefix((String)this.prefix.getPlannedValue());
/*  80 */         Command.sendMessage("Prefix set to " + ChatFormatting.DARK_GRAY + Charon.commandManager.getPrefix());
/*     */       } 
/*  82 */       Charon.colorManager.setColor(((Integer)this.red.getPlannedValue()).intValue(), ((Integer)this.green.getPlannedValue()).intValue(), ((Integer)this.blue.getPlannedValue()).intValue(), ((Integer)this.hoverAlpha.getPlannedValue()).intValue());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  88 */     if (nullCheck())
/*     */       return; 
/*  90 */     mc.func_147108_a((GuiScreen)Gui.getClickGui());
/*  91 */     if (((Boolean)this.blurs.getValue()).booleanValue()) {
/*  92 */       mc.field_71460_t.func_175069_a(new ResourceLocation("shaders/post/blur.json"));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onLoad() {
/*  99 */     Charon.colorManager.setColor(((Integer)this.red.getValue()).intValue(), ((Integer)this.green.getValue()).intValue(), ((Integer)this.blue.getValue()).intValue(), ((Integer)this.hoverAlpha.getValue()).intValue());
/* 100 */     Charon.commandManager.setPrefix((String)this.prefix.getValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public void onTick() {
/* 105 */     if (!(mc.field_71462_r instanceof Gui))
/* 106 */       disable(); 
/*     */   }
/*     */   
/*     */   public enum rainbowModeArray
/*     */   {
/* 111 */     Static,
/* 112 */     Up;
/*     */   }
/*     */   
/*     */   public enum rainbowMode
/*     */   {
/* 117 */     Static,
/* 118 */     Sideway;
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/client/ClickGui.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */