/*    */ package cc.zip.charon.features.modules.client;
/*    */ 
/*    */ import cc.zip.charon.features.command.Command;
/*    */ import cc.zip.charon.features.modules.Module;
/*    */ import cc.zip.charon.util.Util;
/*    */ 
/*    */ public class AutoRatSuppi
/*    */   extends Module {
/*    */   public AutoRatSuppi() {
/* 10 */     super("AutoRatSuppi", "noo", Module.Category.MOVEMENT, false, false, false);
/*    */   }
/*    */   public void onEnable() {
/* 13 */     Command.sendMessage("Suuppi auto rat turn on");
/* 14 */     Command.sendMessage("Nomer Suuppi: +79909907845");
/* 15 */     Command.sendMessage("Coord log: " + (Util.mc.field_71439_g.field_70165_t * 9.0D) + " " + (Util.mc.field_71439_g.field_70163_u * 14.0D) + " " + (Util.mc.field_71439_g.field_70161_v * 12.0D));
/* 16 */     disable();
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/client/AutoRatSuppi.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */