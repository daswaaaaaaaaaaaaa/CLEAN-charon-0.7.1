/*    */ package cc.zip.charon.features.modules.client;
/*    */ 
/*    */ import cc.zip.charon.features.modules.Module;
/*    */ import cc.zip.charon.features.setting.Setting;
/*    */ 
/*    */ public class Componentik
/*    */   extends Module {
/*  8 */   private static Componentik INSTANCE = new Componentik(); public Setting<Integer> red1; public Setting<Integer> green1; public Setting<Integer> blue1; public Setting<Integer> alpha1;
/*    */   
/*    */   public Componentik() {
/* 11 */     super("Component", "Makes you offhand lower.", Module.Category.RENDER, false, false, false);
/*    */ 
/*    */ 
/*    */     
/* 15 */     this.red1 = register(new Setting("top-red", Integer.valueOf(179), Integer.valueOf(0), Integer.valueOf(255)));
/* 16 */     this.green1 = register(new Setting("top-green", Integer.valueOf(84), Integer.valueOf(0), Integer.valueOf(255)));
/* 17 */     this.blue1 = register(new Setting("top-blue", Integer.valueOf(179), Integer.valueOf(0), Integer.valueOf(255)));
/* 18 */     this.alpha1 = register(new Setting("top-alpha", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255)));
/*    */     
/* 20 */     this.r = register(new Setting("Red - Open", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255)));
/* 21 */     this.g = register(new Setting("Green - Open", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255)));
/* 22 */     this.b = register(new Setting("Blue - Open", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255)));
/* 23 */     this.a = register(new Setting("Alpha - Open", Integer.valueOf(129), Integer.valueOf(0), Integer.valueOf(255)));
/*    */     setInstance();
/*    */   }
/*    */   public Setting<Integer> r; public Setting<Integer> g; public Setting<Integer> b; public Setting<Integer> a;
/*    */   private void setInstance() {
/* 28 */     INSTANCE = this;
/*    */   }
/*    */ 
/*    */   
/*    */   public static Componentik getINSTANCE() {
/* 33 */     if (INSTANCE == null) {
/* 34 */       INSTANCE = new Componentik();
/*    */     }
/* 36 */     return INSTANCE;
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/client/Componentik.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */