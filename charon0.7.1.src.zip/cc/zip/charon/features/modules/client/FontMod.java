/*    */ package cc.zip.charon.features.modules.client;
/*    */ 
/*    */ import cc.zip.charon.Charon;
/*    */ import cc.zip.charon.event.events.ClientEvent;
/*    */ import cc.zip.charon.features.command.Command;
/*    */ import cc.zip.charon.features.modules.Module;
/*    */ import cc.zip.charon.features.setting.Setting;
/*    */ import com.mojang.realmsclient.gui.ChatFormatting;
/*    */ import java.awt.GraphicsEnvironment;
/*    */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*    */ 
/*    */ public class FontMod
/*    */   extends Module
/*    */ {
/* 15 */   private static FontMod INSTANCE = new FontMod();
/* 16 */   public Setting<String> fontName = register(new Setting("FontName", "Arial", "Name of the font."));
/* 17 */   public Setting<Boolean> antiAlias = register(new Setting("AntiAlias", Boolean.valueOf(true), "Smoother font."));
/* 18 */   public Setting<Boolean> fractionalMetrics = register(new Setting("Metrics", Boolean.valueOf(true), "Thinner font."));
/* 19 */   public Setting<Integer> fontSize = register(new Setting("Size", Integer.valueOf(18), Integer.valueOf(12), Integer.valueOf(30), "Size of the font."));
/* 20 */   public Setting<Integer> fontStyle = register(new Setting("Style", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(3), "Style of the font."));
/*    */   private boolean reloadFont = false;
/*    */   
/*    */   public FontMod() {
/* 24 */     super("CustomFont", "CustomFont for all of the clients text. Use the font command.", Module.Category.CLIENT, true, false, false);
/* 25 */     setInstance();
/*    */   }
/*    */   
/*    */   public static FontMod getInstance() {
/* 29 */     if (INSTANCE == null) {
/* 30 */       INSTANCE = new FontMod();
/*    */     }
/* 32 */     return INSTANCE;
/*    */   }
/*    */   
/*    */   public static boolean checkFont(String font, boolean message) {
/*    */     String[] fonts;
/* 37 */     for (String s : fonts = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames()) {
/* 38 */       if (!message && s.equals(font)) {
/* 39 */         return true;
/*    */       }
/* 41 */       if (message)
/* 42 */         Command.sendMessage(s); 
/*    */     } 
/* 44 */     return false;
/*    */   }
/*    */   
/*    */   private void setInstance() {
/* 48 */     INSTANCE = this;
/*    */   }
/*    */   
/*    */   @SubscribeEvent
/*    */   public void onSettingChange(ClientEvent event) {
/*    */     Setting setting;
/* 54 */     if (event.getStage() == 2 && (setting = event.getSetting()) != null && setting.getFeature().equals(this)) {
/* 55 */       if (setting.getName().equals("FontName") && !checkFont(setting.getPlannedValue().toString(), false)) {
/* 56 */         Command.sendMessage(ChatFormatting.RED + "That font doesnt exist.");
/* 57 */         event.setCanceled(true);
/*    */         return;
/*    */       } 
/* 60 */       this.reloadFont = true;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void onTick() {
/* 66 */     if (this.reloadFont) {
/* 67 */       Charon.textManager.init(false);
/* 68 */       this.reloadFont = false;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/client/FontMod.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */