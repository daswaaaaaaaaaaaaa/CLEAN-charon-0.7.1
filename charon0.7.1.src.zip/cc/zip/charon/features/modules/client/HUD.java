/*     */ package cc.zip.charon.features.modules.client;
/*     */ import cc.zip.charon.Charon;
/*     */ import cc.zip.charon.event.events.ClientEvent;
/*     */ import cc.zip.charon.features.modules.Module;
/*     */ import cc.zip.charon.features.setting.Setting;
/*     */ import cc.zip.charon.util.ColorUtil;
/*     */ import cc.zip.charon.util.EntityUtil;
/*     */ import cc.zip.charon.util.RenderUtil;
/*     */ import cc.zip.charon.util.TextUtil;
/*     */ import cc.zip.charon.util.Timer;
/*     */ import com.mojang.realmsclient.gui.ChatFormatting;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.minecraft.client.Minecraft;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.init.Items;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.potion.PotionEffect;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class HUD extends Module {
/*  28 */   private static final ResourceLocation box = new ResourceLocation("textures/gui/container/shulker_box.png");
/*  29 */   private static final ItemStack totem = new ItemStack(Items.field_190929_cY);
/*  30 */   private static HUD INSTANCE = new HUD();
/*  31 */   private final Setting<Boolean> grayNess = register(new Setting("Gray", Boolean.valueOf(true)));
/*  32 */   private final Setting<Boolean> renderingUp = register(new Setting("RenderingUp", Boolean.valueOf(false), "Orientation of the HUD-Elements."));
/*  33 */   private final Setting<Boolean> waterMark = register(new Setting("Watermark", Boolean.valueOf(false), "displays watermark"));
/*  34 */   public Setting<WatermarkSelect> watermakss = register(new Setting("Mode", WatermarkSelect.Big, v -> ((Boolean)this.waterMark.getValue()).booleanValue()));
/*  35 */   private final Setting<Boolean> arrayList = register(new Setting("ActiveModules", Boolean.valueOf(false), "Lists the active modules."));
/*  36 */   private final Setting<Boolean> coords = register(new Setting("Coords", Boolean.valueOf(false), "Your current coordinates"));
/*  37 */   private final Setting<Boolean> direction = register(new Setting("Direction", Boolean.valueOf(false), "The Direction you are facing."));
/*  38 */   private final Setting<Boolean> armor = register(new Setting("Armor", Boolean.valueOf(false), "ArmorHUD"));
/*  39 */   private final Setting<Boolean> totems = register(new Setting("Totems", Boolean.valueOf(false), "TotemHUD"));
/*  40 */   private final Setting<Boolean> greeter = register(new Setting("Welcomer", Boolean.valueOf(false), "The time"));
/*  41 */   private final Setting<Boolean> speed = register(new Setting("Speed", Boolean.valueOf(false), "Your Speed"));
/*  42 */   private final Setting<Boolean> potions = register(new Setting("Potions", Boolean.valueOf(false), "Your Speed"));
/*  43 */   private final Setting<Boolean> ping = register(new Setting("Ping", Boolean.valueOf(false), "Your response time to the server."));
/*  44 */   private final Setting<Boolean> tps = register(new Setting("TPS", Boolean.valueOf(false), "Ticks per second of the server."));
/*  45 */   private final Setting<Boolean> fps = register(new Setting("FPS", Boolean.valueOf(false), "Your frames per second."));
/*  46 */   private final Setting<Boolean> lag = register(new Setting("LagNotifier", Boolean.valueOf(false), "The time"));
/*  47 */   private final Timer timer = new Timer();
/*  48 */   private final Map<String, Integer> players = new HashMap<>();
/*  49 */   public Setting<String> command = register(new Setting("Command", "charon.eu"));
/*  50 */   public Setting<TextUtil.Color> bracketColor = register(new Setting("BracketColor", TextUtil.Color.GRAY));
/*  51 */   public Setting<TextUtil.Color> commandColor = register(new Setting("NameColor", TextUtil.Color.WHITE));
/*  52 */   public Setting<String> commandBracket = register(new Setting("Bracket", "["));
/*  53 */   public Setting<String> commandBracket2 = register(new Setting("Bracket2", "]"));
/*  54 */   public Setting<Boolean> notifyToggles = register(new Setting("ChatNotify", Boolean.valueOf(false), "notifys in chat"));
/*  55 */   public Setting<RenderingMode> chatnotify = register(new Setting("Ordering", ChatS.SILENT));
/*  56 */   public Setting<Integer> animationHorizontalTime = register(new Setting("AnimationHTime", Integer.valueOf(500), Integer.valueOf(1), Integer.valueOf(1000), v -> ((Boolean)this.arrayList.getValue()).booleanValue()));
/*  57 */   public Setting<Integer> animationVerticalTime = register(new Setting("AnimationVTime", Integer.valueOf(50), Integer.valueOf(1), Integer.valueOf(500), v -> ((Boolean)this.arrayList.getValue()).booleanValue()));
/*  58 */   public Setting<RenderingMode> renderingMode = register(new Setting("Ordering", RenderingMode.ABC));
/*  59 */   public Setting<Boolean> time = register(new Setting("Time", Boolean.valueOf(false), "The time"));
/*  60 */   public Setting<Integer> lagTime = register(new Setting("LagTime", Integer.valueOf(1000), Integer.valueOf(0), Integer.valueOf(2000)));
/*     */   private int color;
/*     */   private boolean shouldIncrement;
/*     */   private int hitMarkerTimer;
/*     */   
/*     */   public HUD() {
/*  66 */     super("HUDEditor", "HUD Elements rendered on your screen", Module.Category.CLIENT, true, false, false);
/*  67 */     setInstance();
/*     */   }
/*     */   
/*     */   public static HUD getInstance() {
/*  71 */     if (INSTANCE == null)
/*  72 */       INSTANCE = new HUD(); 
/*  73 */     return INSTANCE;
/*     */   }
/*     */   
/*     */   private void setInstance() {
/*  77 */     INSTANCE = this;
/*     */   }
/*     */   
/*     */   public void onUpdate() {
/*  81 */     if (this.shouldIncrement)
/*  82 */       this.hitMarkerTimer++; 
/*  83 */     if (this.hitMarkerTimer == 10) {
/*  84 */       this.hitMarkerTimer = 0;
/*  85 */       this.shouldIncrement = false;
/*     */     } 
/*     */   }
/*     */   public void onRender2D(Render2DEvent event) {
/*  89 */     if (fullNullCheck())
/*     */       return; 
/*  91 */     int width = this.renderer.scaledWidth;
/*  92 */     int height = this.renderer.scaledHeight;
/*  93 */     this.color = ColorUtil.toRGBA(((Integer)(ClickGui.getInstance()).red.getValue()).intValue(), ((Integer)(ClickGui.getInstance()).green.getValue()).intValue(), ((Integer)(ClickGui.getInstance()).blue.getValue()).intValue());
/*  94 */     if (((Boolean)this.waterMark.getValue()).booleanValue() && this.watermakss.getValue() == WatermarkSelect.Big) {
/*  95 */       int[] arrayOfInt = { 1 };
/*  96 */       GL11.glPushMatrix();
/*  97 */       GL11.glScalef(1.8F, 1.8F, 1.8F);
/*  98 */       this.renderer.drawString("charon.", 2.0F, 0.0F, ColorUtil.rainbow(arrayOfInt[0] * ((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB(), true);
/*  99 */       GL11.glPopMatrix();
/* 100 */       GL11.glPushMatrix();
/* 101 */       GL11.glScalef(1.3F, 1.3F, 1.3F);
/* 102 */       this.renderer.drawString("eu", 54.0F, 2.95F, ColorUtil.rainbow(arrayOfInt[0] * ((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB(), true);
/* 103 */       GL11.glPopMatrix();
/* 104 */       arrayOfInt[0] = arrayOfInt[0] + 1;
/* 105 */     } else if (((Boolean)this.waterMark.getValue()).booleanValue() && this.watermakss.getValue() == WatermarkSelect.Small) {
/* 106 */       int[] arrayOfInt = { 1 };
/* 107 */       this.renderer.drawString("charon.eu", 2.0F, 13.0F, ColorUtil.rainbow(arrayOfInt[0] * ((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB(), true);
/* 108 */       arrayOfInt[0] = arrayOfInt[0] + 1;
/*     */     } 
/*     */     
/* 111 */     int[] counter1 = { 1 };
/* 112 */     int j = (mc.field_71462_r instanceof net.minecraft.client.gui.GuiChat && !((Boolean)this.renderingUp.getValue()).booleanValue()) ? 14 : 0;
/* 113 */     if (((Boolean)this.arrayList.getValue()).booleanValue())
/* 114 */       if (((Boolean)this.renderingUp.getValue()).booleanValue()) {
/* 115 */         if (this.renderingMode.getValue() == RenderingMode.ABC) {
/* 116 */           for (int k = 0; k < Charon.moduleManager.sortedModulesABC.size(); k++) {
/* 117 */             String str = Charon.moduleManager.sortedModulesABC.get(k);
/* 118 */             this.renderer.drawString(str, (width - 2 - this.renderer.getStringWidth(str)), (2 + j * 10), ((Boolean)(ClickGui.getInstance()).rainbow.getValue()).booleanValue() ? (((ClickGui.getInstance()).rainbowModeA.getValue() == ClickGui.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * ((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB() : ColorUtil.rainbow(((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB()) : this.color, true);
/* 119 */             RenderUtil.drawRect((width - 2 - this.renderer.getStringWidth(str)), (2 + j * 10), (width - 2 - this.renderer.getStringWidth(str)), 5.0F, 1996488704);
/*     */             
/* 121 */             j++;
/* 122 */             counter1[0] = counter1[0] + 1;
/*     */           } 
/*     */         } else {
/* 125 */           for (int k = 0; k < Charon.moduleManager.sortedModules.size(); k++) {
/* 126 */             Module module = Charon.moduleManager.sortedModules.get(k);
/* 127 */             String str = module.getDisplayName() + ChatFormatting.GRAY + ((module.getDisplayInfo() != null) ? (" [" + ChatFormatting.WHITE + module.getDisplayInfo() + ChatFormatting.GRAY + "]") : "");
/* 128 */             this.renderer.drawString(str, (width - 2 - this.renderer.getStringWidth(str)), (2 + j * 10), ((Boolean)(ClickGui.getInstance()).rainbow.getValue()).booleanValue() ? (((ClickGui.getInstance()).rainbowModeA.getValue() == ClickGui.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * ((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB() : ColorUtil.rainbow(((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB()) : this.color, true);
/* 129 */             RenderUtil.drawRect((width - 2 - this.renderer.getStringWidth(str)), (2 + j * 10), (width - 2 - this.renderer.getStringWidth(str)), 5.0F, 1996488704);
/* 130 */             j++;
/* 131 */             counter1[0] = counter1[0] + 1;
/*     */           }
/*     */         
/*     */         }
/*     */       
/*     */       }
/* 137 */       else if (this.renderingMode.getValue() == RenderingMode.ABC) {
/* 138 */         for (int k = 0; k < Charon.moduleManager.sortedModulesABC.size(); k++) {
/* 139 */           String str = Charon.moduleManager.sortedModulesABC.get(k);
/* 140 */           j += 10;
/* 141 */           this.renderer.drawString(str, (width - 2 - this.renderer.getStringWidth(str)), (height - j), ((Boolean)(ClickGui.getInstance()).rainbow.getValue()).booleanValue() ? (((ClickGui.getInstance()).rainbowModeA.getValue() == ClickGui.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * ((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB() : ColorUtil.rainbow(((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB()) : this.color, true);
/* 142 */           RenderUtil.drawRect((width - 2 - this.renderer.getStringWidth(str)), (2 + j * 10), (width - 2 - this.renderer.getStringWidth(str)), 5.0F, 1996488704);
/*     */           
/* 144 */           counter1[0] = counter1[0] + 1;
/*     */         } 
/*     */       } else {
/* 147 */         for (int k = 0; k < Charon.moduleManager.sortedModules.size(); k++) {
/* 148 */           Module module = Charon.moduleManager.sortedModules.get(k);
/* 149 */           String str = module.getDisplayName() + ChatFormatting.GRAY + ((module.getDisplayInfo() != null) ? (" [" + ChatFormatting.WHITE + module.getDisplayInfo() + ChatFormatting.GRAY + "]") : "");
/* 150 */           j += 10;
/* 151 */           this.renderer.drawString(str, (width - 2 - this.renderer.getStringWidth(str)), (height - j), ((Boolean)(ClickGui.getInstance()).rainbow.getValue()).booleanValue() ? (((ClickGui.getInstance()).rainbowModeA.getValue() == ClickGui.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * ((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB() : ColorUtil.rainbow(((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB()) : this.color, true);
/* 152 */           RenderUtil.drawRect((width - 2 - this.renderer.getStringWidth(str) + 50), (2 + j * 10), (width - 2 - this.renderer.getStringWidth(str)), 5.0F, 1996488704);
/*     */           
/* 154 */           counter1[0] = counter1[0] + 1;
/*     */         } 
/*     */       }  
/* 157 */     String grayString = ((Boolean)this.grayNess.getValue()).booleanValue() ? String.valueOf(ChatFormatting.GRAY) : "";
/* 158 */     int i = (mc.field_71462_r instanceof net.minecraft.client.gui.GuiChat && ((Boolean)this.renderingUp.getValue()).booleanValue()) ? 13 : (((Boolean)this.renderingUp.getValue()).booleanValue() ? -2 : 0);
/* 159 */     if (((Boolean)this.renderingUp.getValue()).booleanValue()) {
/* 160 */       if (((Boolean)this.potions.getValue()).booleanValue()) {
/* 161 */         List<PotionEffect> effects = new ArrayList<>((Minecraft.func_71410_x()).field_71439_g.func_70651_bq());
/* 162 */         for (PotionEffect potionEffect : effects) {
/* 163 */           String str = Charon.potionManager.getColoredPotionString(potionEffect);
/* 164 */           i += 10;
/* 165 */           this.renderer.drawString(str, (width - this.renderer.getStringWidth(str) - 2), (height - 2 - i), potionEffect.func_188419_a().func_76401_j(), true);
/*     */         } 
/*     */       } 
/* 168 */       if (((Boolean)this.speed.getValue()).booleanValue()) {
/* 169 */         String str = grayString + "Speed " + ChatFormatting.WHITE + Charon.speedManager.getSpeedKpH() + " km/h";
/* 170 */         i += 10;
/* 171 */         this.renderer.drawString(str, (width - this.renderer.getStringWidth(str) - 2), (height - 2 - i), ((Boolean)(ClickGui.getInstance()).rainbow.getValue()).booleanValue() ? (((ClickGui.getInstance()).rainbowModeA.getValue() == ClickGui.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * ((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB() : ColorUtil.rainbow(((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB()) : this.color, true);
/* 172 */         counter1[0] = counter1[0] + 1;
/*     */       } 
/* 174 */       if (((Boolean)this.time.getValue()).booleanValue()) {
/* 175 */         String str = grayString + "Time " + ChatFormatting.WHITE + (new SimpleDateFormat("h:mm a")).format(new Date());
/* 176 */         i += 10;
/* 177 */         this.renderer.drawString(str, (width - this.renderer.getStringWidth(str) - 2), (height - 2 - i), ((Boolean)(ClickGui.getInstance()).rainbow.getValue()).booleanValue() ? (((ClickGui.getInstance()).rainbowModeA.getValue() == ClickGui.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * ((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB() : ColorUtil.rainbow(((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB()) : this.color, true);
/* 178 */         counter1[0] = counter1[0] + 1;
/*     */       } 
/* 180 */       if (((Boolean)this.tps.getValue()).booleanValue()) {
/* 181 */         String str = grayString + "TPS " + ChatFormatting.WHITE + Charon.serverManager.getTPS();
/* 182 */         i += 10;
/* 183 */         this.renderer.drawString(str, (width - this.renderer.getStringWidth(str) - 2), (height - 2 - i), ((Boolean)(ClickGui.getInstance()).rainbow.getValue()).booleanValue() ? (((ClickGui.getInstance()).rainbowModeA.getValue() == ClickGui.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * ((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB() : ColorUtil.rainbow(((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB()) : this.color, true);
/* 184 */         counter1[0] = counter1[0] + 1;
/*     */       } 
/* 186 */       String fpsText = grayString + "FPS " + ChatFormatting.WHITE + Minecraft.field_71470_ab;
/* 187 */       String str1 = grayString + "Ping " + ChatFormatting.WHITE + Charon.serverManager.getPing();
/* 188 */       if (this.renderer.getStringWidth(str1) > this.renderer.getStringWidth(fpsText)) {
/* 189 */         if (((Boolean)this.ping.getValue()).booleanValue()) {
/* 190 */           i += 10;
/* 191 */           this.renderer.drawString(str1, (width - this.renderer.getStringWidth(str1) - 2), (height - 2 - i), ((Boolean)(ClickGui.getInstance()).rainbow.getValue()).booleanValue() ? (((ClickGui.getInstance()).rainbowModeA.getValue() == ClickGui.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * ((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB() : ColorUtil.rainbow(((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB()) : this.color, true);
/* 192 */           counter1[0] = counter1[0] + 1;
/*     */         } 
/* 194 */         if (((Boolean)this.fps.getValue()).booleanValue()) {
/* 195 */           i += 10;
/* 196 */           this.renderer.drawString(fpsText, (width - this.renderer.getStringWidth(fpsText) - 2), (height - 2 - i), ((Boolean)(ClickGui.getInstance()).rainbow.getValue()).booleanValue() ? (((ClickGui.getInstance()).rainbowModeA.getValue() == ClickGui.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * ((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB() : ColorUtil.rainbow(((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB()) : this.color, true);
/* 197 */           counter1[0] = counter1[0] + 1;
/*     */         } 
/*     */       } else {
/* 200 */         if (((Boolean)this.fps.getValue()).booleanValue()) {
/* 201 */           i += 10;
/* 202 */           this.renderer.drawString(fpsText, (width - this.renderer.getStringWidth(fpsText) - 2), (height - 2 - i), ((Boolean)(ClickGui.getInstance()).rainbow.getValue()).booleanValue() ? (((ClickGui.getInstance()).rainbowModeA.getValue() == ClickGui.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * ((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB() : ColorUtil.rainbow(((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB()) : this.color, true);
/* 203 */           counter1[0] = counter1[0] + 1;
/*     */         } 
/* 205 */         if (((Boolean)this.ping.getValue()).booleanValue()) {
/* 206 */           i += 10;
/* 207 */           this.renderer.drawString(str1, (width - this.renderer.getStringWidth(str1) - 2), (height - 2 - i), ((Boolean)(ClickGui.getInstance()).rainbow.getValue()).booleanValue() ? (((ClickGui.getInstance()).rainbowModeA.getValue() == ClickGui.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * ((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB() : ColorUtil.rainbow(((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB()) : this.color, true);
/* 208 */           counter1[0] = counter1[0] + 1;
/*     */         } 
/*     */       } 
/*     */     } else {
/* 212 */       if (((Boolean)this.potions.getValue()).booleanValue()) {
/* 213 */         List<PotionEffect> effects = new ArrayList<>((Minecraft.func_71410_x()).field_71439_g.func_70651_bq());
/* 214 */         for (PotionEffect potionEffect : effects) {
/* 215 */           String str = Charon.potionManager.getColoredPotionString(potionEffect);
/* 216 */           this.renderer.drawString(str, (width - this.renderer.getStringWidth(str) - 2), (2 + i++ * 10), potionEffect.func_188419_a().func_76401_j(), true);
/*     */         } 
/*     */       } 
/* 219 */       if (((Boolean)this.speed.getValue()).booleanValue()) {
/* 220 */         String str = grayString + "Speed " + ChatFormatting.WHITE + Charon.speedManager.getSpeedKpH() + " km/h";
/* 221 */         this.renderer.drawString(str, (width - this.renderer.getStringWidth(str) - 2), (2 + i++ * 10), ((Boolean)(ClickGui.getInstance()).rainbow.getValue()).booleanValue() ? (((ClickGui.getInstance()).rainbowModeA.getValue() == ClickGui.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * ((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB() : ColorUtil.rainbow(((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB()) : this.color, true);
/* 222 */         counter1[0] = counter1[0] + 1;
/*     */       } 
/* 224 */       if (((Boolean)this.time.getValue()).booleanValue()) {
/* 225 */         String str = grayString + "Time " + ChatFormatting.WHITE + (new SimpleDateFormat("h:mm a")).format(new Date());
/* 226 */         this.renderer.drawString(str, (width - this.renderer.getStringWidth(str) - 2), (2 + i++ * 10), ((Boolean)(ClickGui.getInstance()).rainbow.getValue()).booleanValue() ? (((ClickGui.getInstance()).rainbowModeA.getValue() == ClickGui.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * ((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB() : ColorUtil.rainbow(((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB()) : this.color, true);
/* 227 */         counter1[0] = counter1[0] + 1;
/*     */       } 
/* 229 */       if (((Boolean)this.tps.getValue()).booleanValue()) {
/* 230 */         String str = grayString + "TPS " + ChatFormatting.WHITE + Charon.serverManager.getTPS();
/* 231 */         this.renderer.drawString(str, (width - this.renderer.getStringWidth(str) - 2), (2 + i++ * 10), ((Boolean)(ClickGui.getInstance()).rainbow.getValue()).booleanValue() ? (((ClickGui.getInstance()).rainbowModeA.getValue() == ClickGui.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * ((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB() : ColorUtil.rainbow(((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB()) : this.color, true);
/* 232 */         counter1[0] = counter1[0] + 1;
/*     */       } 
/* 234 */       String fpsText = grayString + "FPS " + ChatFormatting.WHITE + Minecraft.field_71470_ab;
/* 235 */       String str1 = grayString + "Ping " + ChatFormatting.WHITE + Charon.serverManager.getPing();
/* 236 */       if (this.renderer.getStringWidth(str1) > this.renderer.getStringWidth(fpsText)) {
/* 237 */         if (((Boolean)this.ping.getValue()).booleanValue()) {
/* 238 */           this.renderer.drawString(str1, (width - this.renderer.getStringWidth(str1) - 2), (2 + i++ * 10), ((Boolean)(ClickGui.getInstance()).rainbow.getValue()).booleanValue() ? (((ClickGui.getInstance()).rainbowModeA.getValue() == ClickGui.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * ((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB() : ColorUtil.rainbow(((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB()) : this.color, true);
/* 239 */           counter1[0] = counter1[0] + 1;
/*     */         } 
/* 241 */         if (((Boolean)this.fps.getValue()).booleanValue()) {
/* 242 */           this.renderer.drawString(fpsText, (width - this.renderer.getStringWidth(fpsText) - 2), (2 + i++ * 10), ((Boolean)(ClickGui.getInstance()).rainbow.getValue()).booleanValue() ? (((ClickGui.getInstance()).rainbowModeA.getValue() == ClickGui.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * ((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB() : ColorUtil.rainbow(((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB()) : this.color, true);
/* 243 */           counter1[0] = counter1[0] + 1;
/*     */         } 
/*     */       } else {
/* 246 */         if (((Boolean)this.fps.getValue()).booleanValue()) {
/* 247 */           this.renderer.drawString(fpsText, (width - this.renderer.getStringWidth(fpsText) - 2), (2 + i++ * 10), ((Boolean)(ClickGui.getInstance()).rainbow.getValue()).booleanValue() ? (((ClickGui.getInstance()).rainbowModeA.getValue() == ClickGui.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * ((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB() : ColorUtil.rainbow(((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB()) : this.color, true);
/* 248 */           counter1[0] = counter1[0] + 1;
/*     */         } 
/* 250 */         if (((Boolean)this.ping.getValue()).booleanValue()) {
/* 251 */           this.renderer.drawString(str1, (width - this.renderer.getStringWidth(str1) - 2), (2 + i++ * 10), ((Boolean)(ClickGui.getInstance()).rainbow.getValue()).booleanValue() ? (((ClickGui.getInstance()).rainbowModeA.getValue() == ClickGui.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * ((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB() : ColorUtil.rainbow(((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB()) : this.color, true);
/* 252 */           counter1[0] = counter1[0] + 1;
/*     */         } 
/*     */       } 
/*     */     } 
/* 256 */     boolean inHell = mc.field_71441_e.func_180494_b(mc.field_71439_g.func_180425_c()).func_185359_l().equals("Hell");
/* 257 */     int posX = (int)mc.field_71439_g.field_70165_t;
/* 258 */     int posY = (int)mc.field_71439_g.field_70163_u;
/* 259 */     int posZ = (int)mc.field_71439_g.field_70161_v;
/* 260 */     float nether = !inHell ? 0.125F : 8.0F;
/* 261 */     int hposX = (int)(mc.field_71439_g.field_70165_t * nether);
/* 262 */     int hposZ = (int)(mc.field_71439_g.field_70161_v * nether);
/* 263 */     i = (mc.field_71462_r instanceof net.minecraft.client.gui.GuiChat) ? 14 : 0;
/* 264 */     String coordinates = ChatFormatting.WHITE + "XYZ " + ChatFormatting.RESET + (inHell ? (posX + ", " + posY + ", " + posZ + ChatFormatting.WHITE + " [" + ChatFormatting.RESET + hposX + ", " + hposZ + ChatFormatting.WHITE + "]" + ChatFormatting.RESET) : (posX + ", " + posY + ", " + posZ + ChatFormatting.WHITE + " [" + ChatFormatting.RESET + hposX + ", " + hposZ + ChatFormatting.WHITE + "]"));
/* 265 */     String direction = ((Boolean)this.direction.getValue()).booleanValue() ? Charon.rotationManager.getDirection4D(false) : "";
/* 266 */     String coords = ((Boolean)this.coords.getValue()).booleanValue() ? coordinates : "";
/* 267 */     i += 10;
/* 268 */     if (((Boolean)(ClickGui.getInstance()).rainbow.getValue()).booleanValue()) {
/* 269 */       String rainbowCoords = ((Boolean)this.coords.getValue()).booleanValue() ? ("XYZ " + (inHell ? (posX + ", " + posY + ", " + posZ + " [" + hposX + ", " + hposZ + "]") : (posX + ", " + posY + ", " + posZ + " [" + hposX + ", " + hposZ + "]"))) : "";
/* 270 */       if ((ClickGui.getInstance()).rainbowModeHud.getValue() == ClickGui.rainbowMode.Static) {
/* 271 */         this.renderer.drawString(direction, 2.0F, (height - i - 11), ColorUtil.rainbow(((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB(), true);
/* 272 */         this.renderer.drawString(rainbowCoords, 2.0F, (height - i), ColorUtil.rainbow(((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB(), true);
/*     */       } else {
/* 274 */         int[] counter2 = { 1 };
/* 275 */         char[] stringToCharArray = direction.toCharArray();
/* 276 */         float s = 0.0F;
/* 277 */         for (char c : stringToCharArray) {
/* 278 */           this.renderer.drawString(String.valueOf(c), 2.0F + s, (height - i - 11), ColorUtil.rainbow(counter2[0] * ((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB(), true);
/* 279 */           s += this.renderer.getStringWidth(String.valueOf(c));
/* 280 */           counter2[0] = counter2[0] + 1;
/*     */         } 
/* 282 */         int[] counter3 = { 1 };
/* 283 */         char[] stringToCharArray2 = rainbowCoords.toCharArray();
/* 284 */         float u = 0.0F;
/* 285 */         for (char c : stringToCharArray2) {
/* 286 */           this.renderer.drawString(String.valueOf(c), 2.0F + u, (height - i), ColorUtil.rainbow(counter3[0] * ((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB(), true);
/* 287 */           u += this.renderer.getStringWidth(String.valueOf(c));
/* 288 */           counter3[0] = counter3[0] + 1;
/*     */         } 
/*     */       } 
/*     */     } else {
/* 292 */       this.renderer.drawString(direction, 2.0F, (height - i - 11), this.color, true);
/* 293 */       this.renderer.drawString(coords, 2.0F, (height - i), this.color, true);
/*     */     } 
/* 295 */     if (((Boolean)this.armor.getValue()).booleanValue())
/* 296 */       renderArmorHUD(true); 
/* 297 */     if (((Boolean)this.totems.getValue()).booleanValue())
/* 298 */       renderTotemHUD(); 
/* 299 */     if (((Boolean)this.greeter.getValue()).booleanValue())
/* 300 */       renderGreeter(); 
/* 301 */     if (((Boolean)this.lag.getValue()).booleanValue())
/* 302 */       renderLag(); 
/*     */   }
/*     */   
/*     */   public Map<String, Integer> getTextRadarPlayers() {
/* 306 */     return EntityUtil.getTextRadarPlayers();
/*     */   }
/*     */   
/*     */   public void renderGreeter() {
/* 310 */     int width = this.renderer.scaledWidth;
/* 311 */     String text = "";
/* 312 */     String text2 = "Welcome to charon.eu / ";
/* 313 */     if (((Boolean)this.greeter.getValue()).booleanValue())
/* 314 */       text = text + text2 + mc.field_71439_g.getDisplayNameString(); 
/* 315 */     if (((Boolean)(ClickGui.getInstance()).rainbow.getValue()).booleanValue()) {
/* 316 */       if ((ClickGui.getInstance()).rainbowModeHud.getValue() == ClickGui.rainbowMode.Static) {
/* 317 */         this.renderer.drawString(text, 2.0F, 2.0F, ColorUtil.rainbow(((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB(), true);
/*     */       } else {
/* 319 */         int[] counter1 = { 1 };
/* 320 */         this.renderer.drawString(text, 2.0F, 2.0F, ColorUtil.rainbow(counter1[0] * ((Integer)(ClickGui.getInstance()).rainbowHue.getValue()).intValue()).getRGB(), true);
/* 321 */         counter1[0] = counter1[0] + 1;
/*     */       } 
/*     */     } else {
/* 324 */       this.renderer.drawString(text, 2.0F, 2.0F, this.color, true);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void renderLag() {
/* 329 */     int width = this.renderer.scaledWidth;
/* 330 */     if (Charon.serverManager.isServerNotResponding()) {
/* 331 */       String text = ChatFormatting.RED + "Server not responding " + MathUtil.round((float)Charon.serverManager.serverRespondingTime() / 1000.0F, 1) + "s.";
/* 332 */       this.renderer.drawString(text, width / 2.0F - this.renderer.getStringWidth(text) / 2.0F + 2.0F, 20.0F, this.color, true);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void renderTotemHUD() {
/* 337 */     int width = this.renderer.scaledWidth;
/* 338 */     int height = this.renderer.scaledHeight;
/* 339 */     int totems = mc.field_71439_g.field_71071_by.field_70462_a.stream().filter(itemStack -> (itemStack.func_77973_b() == Items.field_190929_cY)).mapToInt(ItemStack::func_190916_E).sum();
/* 340 */     if (mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_190929_cY)
/* 341 */       totems += mc.field_71439_g.func_184592_cb().func_190916_E(); 
/* 342 */     if (totems > 0) {
/* 343 */       GlStateManager.func_179098_w();
/* 344 */       int i = width / 2;
/* 345 */       int iteration = 0;
/* 346 */       int y = height - 55 - ((mc.field_71439_g.func_70090_H() && mc.field_71442_b.func_78763_f()) ? 10 : 0);
/* 347 */       int x = i - 189 + 180 + 2;
/* 348 */       GlStateManager.func_179126_j();
/* 349 */       RenderUtil.itemRender.field_77023_b = 200.0F;
/* 350 */       RenderUtil.itemRender.func_180450_b(totem, x, y);
/* 351 */       RenderUtil.itemRender.func_180453_a(mc.field_71466_p, totem, x, y, "");
/* 352 */       RenderUtil.itemRender.field_77023_b = 0.0F;
/* 353 */       GlStateManager.func_179098_w();
/* 354 */       GlStateManager.func_179140_f();
/* 355 */       GlStateManager.func_179097_i();
/* 356 */       this.renderer.drawStringWithShadow(totems + "", (x + 19 - 2 - this.renderer.getStringWidth(totems + "")), (y + 9), 16777215);
/* 357 */       GlStateManager.func_179126_j();
/* 358 */       GlStateManager.func_179140_f();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void renderArmorHUD(boolean percent) {
/* 363 */     int width = this.renderer.scaledWidth;
/* 364 */     int height = this.renderer.scaledHeight;
/* 365 */     GlStateManager.func_179098_w();
/* 366 */     int i = width / 2;
/* 367 */     int iteration = 0;
/* 368 */     int y = height - 55 - ((mc.field_71439_g.func_70090_H() && mc.field_71442_b.func_78763_f()) ? 10 : 0);
/* 369 */     for (ItemStack is : mc.field_71439_g.field_71071_by.field_70460_b) {
/* 370 */       iteration++;
/* 371 */       if (is.func_190926_b())
/*     */         continue; 
/* 373 */       int x = i - 90 + (9 - iteration) * 20 + 2;
/* 374 */       GlStateManager.func_179126_j();
/* 375 */       RenderUtil.itemRender.field_77023_b = 200.0F;
/* 376 */       RenderUtil.itemRender.func_180450_b(is, x, y);
/* 377 */       RenderUtil.itemRender.func_180453_a(mc.field_71466_p, is, x, y, "");
/* 378 */       RenderUtil.itemRender.field_77023_b = 0.0F;
/* 379 */       GlStateManager.func_179098_w();
/* 380 */       GlStateManager.func_179140_f();
/* 381 */       GlStateManager.func_179097_i();
/* 382 */       String s = (is.func_190916_E() > 1) ? (is.func_190916_E() + "") : "";
/* 383 */       this.renderer.drawStringWithShadow(s, (x + 19 - 2 - this.renderer.getStringWidth(s)), (y + 9), 16777215);
/* 384 */       if (percent) {
/* 385 */         float green = ((is.func_77958_k() - is.func_77952_i()) / is.func_77958_k());
/* 386 */         float red = 1.0F - green;
/* 387 */         int dmg = 100 - (int)(red * 100.0F);
/* 388 */         this.renderer.drawStringWithShadow(dmg + "", (x + 8 - this.renderer.getStringWidth(dmg + "") / 2), (y - 11), ColorUtil.toRGBA((int)(red * 255.0F), (int)(green * 255.0F), 0));
/*     */       } 
/*     */     } 
/* 391 */     GlStateManager.func_179126_j();
/* 392 */     GlStateManager.func_179140_f();
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onUpdateWalkingPlayer(AttackEntityEvent event) {
/* 397 */     this.shouldIncrement = true;
/*     */   }
/*     */   
/*     */   public void onLoad() {
/* 401 */     Charon.commandManager.setClientMessage(getCommandMessage());
/*     */   }
/*     */   
/*     */   @SubscribeEvent
/*     */   public void onSettingChange(ClientEvent event) {
/* 406 */     if (event.getStage() == 2 && 
/* 407 */       equals(event.getSetting().getFeature()))
/* 408 */       Charon.commandManager.setClientMessage(getCommandMessage()); 
/*     */   }
/*     */   
/*     */   public String getCommandMessage() {
/* 412 */     return TextUtil.coloredString((String)this.commandBracket.getPlannedValue(), (TextUtil.Color)this.bracketColor.getPlannedValue()) + TextUtil.coloredString((String)this.command.getPlannedValue(), (TextUtil.Color)this.commandColor.getPlannedValue()) + TextUtil.coloredString((String)this.commandBracket2.getPlannedValue(), (TextUtil.Color)this.bracketColor.getPlannedValue());
/*     */   }
/*     */   
/*     */   public void drawTextRadar(int yOffset) {
/* 416 */     if (!this.players.isEmpty()) {
/* 417 */       int y = this.renderer.getFontHeight() + 7 + yOffset;
/* 418 */       for (Map.Entry<String, Integer> player : this.players.entrySet()) {
/* 419 */         String text = (String)player.getKey() + " ";
/* 420 */         int textheight = this.renderer.getFontHeight() + 1;
/* 421 */         this.renderer.drawString(text, 2.0F, y, this.color, true);
/* 422 */         y += textheight;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public enum RenderingMode {
/* 428 */     Length, ABC;
/*     */   }
/*     */   
/* 431 */   public enum WatermarkSelect { Big, Small, Csgo; }
/*     */   
/*     */   public enum ChatS {
/* 434 */     SILENT, SPAM;
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/modules/client/HUD.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */