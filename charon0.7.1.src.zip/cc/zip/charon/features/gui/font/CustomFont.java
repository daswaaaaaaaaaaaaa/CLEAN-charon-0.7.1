/*     */ package cc.zip.charon.features.gui.font;
/*     */ 
/*     */ import java.awt.Font;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.renderer.GlStateManager;
/*     */ import net.minecraft.client.renderer.texture.DynamicTexture;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public class CustomFont
/*     */   extends CFont
/*     */ {
/*  13 */   private final int[] colorCode = new int[32];
/*  14 */   private final String colorcodeIdentifiers = "0123456789abcdefklmnor";
/*  15 */   protected CFont.CharData[] boldChars = new CFont.CharData[256];
/*  16 */   protected CFont.CharData[] italicChars = new CFont.CharData[256];
/*  17 */   protected CFont.CharData[] boldItalicChars = new CFont.CharData[256];
/*     */   protected DynamicTexture texBold;
/*     */   protected DynamicTexture texItalic;
/*     */   protected DynamicTexture texItalicBold;
/*     */   
/*     */   public CustomFont(Font font, boolean antiAlias, boolean fractionalMetrics) {
/*  23 */     super(font, antiAlias, fractionalMetrics);
/*  24 */     setupMinecraftColorcodes();
/*  25 */     setupBoldItalicIDs();
/*     */   }
/*     */   
/*     */   public float drawStringWithShadow(String text, double x, double y, int color) {
/*  29 */     float shadowWidth = drawString(text, x + 1.0D, y + 1.0D, color, true);
/*  30 */     return Math.max(shadowWidth, drawString(text, x, y, color, false));
/*     */   }
/*     */   
/*     */   public float drawString(String text, float x, float y, int color) {
/*  34 */     return drawString(text, x, y, color, false);
/*     */   }
/*     */   
/*     */   public float drawCenteredStringWithShadow(String text, float x, float y, int color) {
/*  38 */     return drawStringWithShadow(text, (x - (getStringWidth(text) / 2)), y, color);
/*     */   }
/*     */   
/*     */   public float drawCenteredString(String text, float x, float y, int color) {
/*  42 */     return drawString(text, x - (getStringWidth(text) / 2), y, color);
/*     */   }
/*     */   
/*     */   public float drawString(String text, double x, double y, int color, boolean shadow) {
/*  46 */     x--;
/*  47 */     y -= 2.0D;
/*  48 */     if (text == null) {
/*  49 */       return 0.0F;
/*     */     }
/*  51 */     if (color == 553648127) {
/*  52 */       color = 16777215;
/*     */     }
/*  54 */     if ((color & 0xFC000000) == 0) {
/*  55 */       color |= 0xFF000000;
/*     */     }
/*     */     
/*  58 */     if (shadow) {
/*  59 */       color = (color & 0xFCFCFC) >> 2 | color & 0xFF000000;
/*     */     }
/*     */     
/*  62 */     CFont.CharData[] currentData = this.charData;
/*  63 */     float alpha = (color >> 24 & 0xFF) / 255.0F;
/*  64 */     boolean randomCase = false;
/*  65 */     boolean bold = false;
/*  66 */     boolean italic = false;
/*  67 */     boolean strikethrough = false;
/*  68 */     boolean underline = false;
/*  69 */     boolean render = true;
/*  70 */     x *= 2.0D;
/*  71 */     y *= 2.0D;
/*  72 */     if (render) {
/*  73 */       GL11.glPushMatrix();
/*  74 */       GlStateManager.func_179139_a(0.5D, 0.5D, 0.5D);
/*  75 */       GlStateManager.func_179147_l();
/*  76 */       GlStateManager.func_179112_b(770, 771);
/*  77 */       GlStateManager.func_179131_c((color >> 16 & 0xFF) / 255.0F, (color >> 8 & 0xFF) / 255.0F, (color & 0xFF) / 255.0F, alpha);
/*  78 */       int size = text.length();
/*  79 */       GlStateManager.func_179098_w();
/*  80 */       GlStateManager.func_179144_i(this.tex.func_110552_b());
/*  81 */       GL11.glBindTexture(3553, this.tex.func_110552_b());
/*  82 */       for (int i = 0; i < size; i++) {
/*  83 */         char character = text.charAt(i);
/*  84 */         if (character == '§' && i < size) {
/*  85 */           int colorIndex = 21;
/*     */           try {
/*  87 */             colorIndex = "0123456789abcdefklmnor".indexOf(text.charAt(i + 1));
/*  88 */           } catch (Exception exception) {}
/*     */           
/*  90 */           if (colorIndex < 16)
/*  91 */           { bold = false;
/*  92 */             italic = false;
/*  93 */             randomCase = false;
/*  94 */             underline = false;
/*  95 */             strikethrough = false;
/*  96 */             GlStateManager.func_179144_i(this.tex.func_110552_b());
/*     */ 
/*     */             
/*  99 */             currentData = this.charData;
/* 100 */             if (colorIndex < 0 || colorIndex > 15) colorIndex = 15; 
/* 101 */             if (shadow) colorIndex += 16; 
/* 102 */             int colorcode = this.colorCode[colorIndex];
/* 103 */             GlStateManager.func_179131_c((colorcode >> 16 & 0xFF) / 255.0F, (colorcode >> 8 & 0xFF) / 255.0F, (colorcode & 0xFF) / 255.0F, alpha); }
/* 104 */           else if (colorIndex == 16) { randomCase = true; }
/* 105 */           else if (colorIndex == 17)
/* 106 */           { bold = true;
/* 107 */             if (italic) {
/* 108 */               GlStateManager.func_179144_i(this.texItalicBold.func_110552_b());
/*     */ 
/*     */               
/* 111 */               currentData = this.boldItalicChars;
/*     */             } else {
/* 113 */               GlStateManager.func_179144_i(this.texBold.func_110552_b());
/*     */ 
/*     */               
/* 116 */               currentData = this.boldChars;
/*     */             }  }
/* 118 */           else if (colorIndex == 18) { strikethrough = true; }
/* 119 */           else if (colorIndex == 19) { underline = true; }
/* 120 */           else if (colorIndex == 20)
/* 121 */           { italic = true;
/* 122 */             if (bold) {
/* 123 */               GlStateManager.func_179144_i(this.texItalicBold.func_110552_b());
/*     */ 
/*     */               
/* 126 */               currentData = this.boldItalicChars;
/*     */             } else {
/* 128 */               GlStateManager.func_179144_i(this.texItalic.func_110552_b());
/*     */ 
/*     */               
/* 131 */               currentData = this.italicChars;
/*     */             }  }
/* 133 */           else if (colorIndex == 21)
/* 134 */           { bold = false;
/* 135 */             italic = false;
/* 136 */             randomCase = false;
/* 137 */             underline = false;
/* 138 */             strikethrough = false;
/* 139 */             GlStateManager.func_179131_c((color >> 16 & 0xFF) / 255.0F, (color >> 8 & 0xFF) / 255.0F, (color & 0xFF) / 255.0F, alpha);
/* 140 */             GlStateManager.func_179144_i(this.tex.func_110552_b());
/*     */ 
/*     */             
/* 143 */             currentData = this.charData; }
/*     */           
/* 145 */           i++;
/* 146 */         } else if (character < currentData.length && character >= '\000') {
/* 147 */           GL11.glBegin(4);
/* 148 */           drawChar(currentData, character, (float)x, (float)y);
/* 149 */           GL11.glEnd();
/* 150 */           if (strikethrough)
/* 151 */             drawLine(x, y + ((currentData[character]).height / 2), x + (currentData[character]).width - 8.0D, y + ((currentData[character]).height / 2), 1.0F); 
/* 152 */           if (underline)
/* 153 */             drawLine(x, y + (currentData[character]).height - 2.0D, x + (currentData[character]).width - 8.0D, y + (currentData[character]).height - 2.0D, 1.0F); 
/* 154 */           x += ((currentData[character]).width - 8 + this.charOffset);
/*     */         } 
/*     */       } 
/* 157 */       GL11.glHint(3155, 4352);
/* 158 */       GL11.glPopMatrix();
/*     */     } 
/* 160 */     return (float)x / 2.0F;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getStringWidth(String text) {
/* 165 */     if (text == null) {
/* 166 */       return 0;
/*     */     }
/* 168 */     int width = 0;
/* 169 */     CFont.CharData[] currentData = this.charData;
/* 170 */     boolean bold = false;
/* 171 */     boolean italic = false;
/* 172 */     int size = text.length();
/*     */     
/* 174 */     for (int i = 0; i < size; i++) {
/* 175 */       char character = text.charAt(i);
/* 176 */       if (character == '§' && i < size) {
/* 177 */         int colorIndex = "0123456789abcdefklmnor".indexOf(character);
/* 178 */         if (colorIndex < 16) {
/* 179 */           bold = false;
/* 180 */           italic = false;
/* 181 */         } else if (colorIndex == 17) {
/* 182 */           bold = true;
/* 183 */           if (italic) { currentData = this.boldItalicChars; }
/* 184 */           else { currentData = this.boldChars; } 
/* 185 */         } else if (colorIndex == 20) {
/* 186 */           italic = true;
/* 187 */           if (bold) { currentData = this.boldItalicChars; }
/* 188 */           else { currentData = this.italicChars; } 
/* 189 */         } else if (colorIndex == 21) {
/* 190 */           bold = false;
/* 191 */           italic = false;
/* 192 */           currentData = this.charData;
/*     */         } 
/* 194 */         i++;
/* 195 */       } else if (character < currentData.length && character >= '\000') {
/* 196 */         width += (currentData[character]).width - 8 + this.charOffset;
/*     */       } 
/*     */     } 
/*     */     
/* 200 */     return width / 2;
/*     */   }
/*     */   
/*     */   public void setFont(Font font) {
/* 204 */     super.setFont(font);
/* 205 */     setupBoldItalicIDs();
/*     */   }
/*     */   
/*     */   public void setAntiAlias(boolean antiAlias) {
/* 209 */     super.setAntiAlias(antiAlias);
/* 210 */     setupBoldItalicIDs();
/*     */   }
/*     */   
/*     */   public void setFractionalMetrics(boolean fractionalMetrics) {
/* 214 */     super.setFractionalMetrics(fractionalMetrics);
/* 215 */     setupBoldItalicIDs();
/*     */   }
/*     */   
/*     */   private void setupBoldItalicIDs() {
/* 219 */     this.texBold = setupTexture(this.font.deriveFont(1), this.antiAlias, this.fractionalMetrics, this.boldChars);
/* 220 */     this.texItalic = setupTexture(this.font.deriveFont(2), this.antiAlias, this.fractionalMetrics, this.italicChars);
/* 221 */     this.texItalicBold = setupTexture(this.font.deriveFont(3), this.antiAlias, this.fractionalMetrics, this.boldItalicChars);
/*     */   }
/*     */   
/*     */   private void drawLine(double x, double y, double x1, double y1, float width) {
/* 225 */     GL11.glDisable(3553);
/* 226 */     GL11.glLineWidth(width);
/* 227 */     GL11.glBegin(1);
/* 228 */     GL11.glVertex2d(x, y);
/* 229 */     GL11.glVertex2d(x1, y1);
/* 230 */     GL11.glEnd();
/* 231 */     GL11.glEnable(3553);
/*     */   }
/*     */   
/*     */   public List<String> wrapWords(String text, double width) {
/* 235 */     List<String> finalWords = new ArrayList();
/* 236 */     if (getStringWidth(text) > width) {
/* 237 */       String[] words = text.split(" ");
/* 238 */       String currentWord = "";
/* 239 */       char lastColorCode = Character.MAX_VALUE;
/*     */       
/* 241 */       for (String word : words) {
/* 242 */         for (int i = 0; i < (word.toCharArray()).length; i++) {
/* 243 */           char c = word.toCharArray()[i];
/*     */           
/* 245 */           if (c == '§' && i < (word.toCharArray()).length - 1) {
/* 246 */             lastColorCode = word.toCharArray()[i + 1];
/*     */           }
/*     */         } 
/* 249 */         if (getStringWidth(currentWord + word + " ") < width) {
/* 250 */           currentWord = currentWord + word + " ";
/*     */         } else {
/* 252 */           finalWords.add(currentWord);
/* 253 */           currentWord = "§" + lastColorCode + word + " ";
/*     */         } 
/*     */       } 
/* 256 */       if (currentWord.length() > 0) if (getStringWidth(currentWord) < width) {
/* 257 */           finalWords.add("§" + lastColorCode + currentWord + " ");
/* 258 */           currentWord = "";
/*     */         } else {
/* 260 */           for (String s : formatString(currentWord, width))
/* 261 */             finalWords.add(s); 
/*     */         }  
/*     */     } else {
/* 264 */       finalWords.add(text);
/*     */     } 
/* 266 */     return finalWords;
/*     */   }
/*     */   
/*     */   public List<String> formatString(String string, double width) {
/* 270 */     List<String> finalWords = new ArrayList();
/* 271 */     String currentWord = "";
/* 272 */     char lastColorCode = Character.MAX_VALUE;
/* 273 */     char[] chars = string.toCharArray();
/* 274 */     for (int i = 0; i < chars.length; i++) {
/* 275 */       char c = chars[i];
/*     */       
/* 277 */       if (c == '§' && i < chars.length - 1) {
/* 278 */         lastColorCode = chars[i + 1];
/*     */       }
/*     */       
/* 281 */       if (getStringWidth(currentWord + c) < width) {
/* 282 */         currentWord = currentWord + c;
/*     */       } else {
/* 284 */         finalWords.add(currentWord);
/* 285 */         currentWord = "§" + lastColorCode + c;
/*     */       } 
/*     */     } 
/*     */     
/* 289 */     if (currentWord.length() > 0) {
/* 290 */       finalWords.add(currentWord);
/*     */     }
/*     */     
/* 293 */     return finalWords;
/*     */   }
/*     */   
/*     */   private void setupMinecraftColorcodes() {
/* 297 */     for (int index = 0; index < 32; index++) {
/* 298 */       int noClue = (index >> 3 & 0x1) * 85;
/* 299 */       int red = (index >> 2 & 0x1) * 170 + noClue;
/* 300 */       int green = (index >> 1 & 0x1) * 170 + noClue;
/* 301 */       int blue = (index >> 0 & 0x1) * 170 + noClue;
/*     */       
/* 303 */       if (index == 6) {
/* 304 */         red += 85;
/*     */       }
/*     */       
/* 307 */       if (index >= 16) {
/* 308 */         red /= 4;
/* 309 */         green /= 4;
/* 310 */         blue /= 4;
/*     */       } 
/*     */       
/* 313 */       this.colorCode[index] = (red & 0xFF) << 16 | (green & 0xFF) << 8 | blue & 0xFF;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/gui/font/CustomFont.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */