/*     */ package cc.zip.charon.features.gui.components;
/*     */ 
/*     */ import cc.zip.charon.Charon;
/*     */ import cc.zip.charon.features.Feature;
/*     */ import cc.zip.charon.features.gui.Gui;
/*     */ import cc.zip.charon.features.gui.components.items.Item;
/*     */ import cc.zip.charon.features.gui.components.items.buttons.Button;
/*     */ import cc.zip.charon.features.modules.client.Componentik;
/*     */ import cc.zip.charon.util.ColorUtil;
/*     */ import cc.zip.charon.util.RenderUtil;
/*     */ import java.util.ArrayList;
/*     */ import net.minecraft.client.audio.ISound;
/*     */ import net.minecraft.client.audio.PositionedSoundRecord;
/*     */ import net.minecraft.init.SoundEvents;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ 
/*     */ public class Component
/*     */   extends Feature
/*     */ {
/*  20 */   public static int[] counter1 = new int[] { 1 };
/*  21 */   private final ArrayList<Item> items = new ArrayList<>();
/*     */   public boolean drag;
/*     */   private int x;
/*     */   private int y;
/*     */   private int x2;
/*     */   private int y2;
/*     */   private int width;
/*     */   private int height;
/*     */   private boolean open;
/*     */   private boolean hidden = false;
/*  31 */   private final ResourceLocation setiingscharon = new ResourceLocation("textures/stngg.png");
/*     */   
/*     */   public Component(String name, int x, int y, boolean open) {
/*  34 */     super(name);
/*  35 */     this.x = x;
/*  36 */     this.y = y;
/*  37 */     this.width = 88;
/*  38 */     this.height = 18;
/*  39 */     this.open = open;
/*  40 */     setupItems();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setupItems() {}
/*     */   
/*     */   private void drag(int mouseX, int mouseY) {
/*  47 */     if (!this.drag) {
/*     */       return;
/*     */     }
/*  50 */     this.x = this.x2 + mouseX;
/*  51 */     this.y = this.y2 + mouseY;
/*     */   }
/*     */   
/*     */   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
/*  55 */     drag(mouseX, mouseY);
/*  56 */     counter1 = new int[] { 1 };
/*  57 */     float totalItemHeight = this.open ? (getTotalItemHeight() - 2.0F) : 0.0F;
/*  58 */     int color = -7829368;
/*  59 */     int n = color = ColorUtil.toARGB(((Integer)(Componentik.getINSTANCE()).green1.getValue()).intValue(), ((Integer)(Componentik.getINSTANCE()).green1.getValue()).intValue(), ((Integer)(Componentik.getINSTANCE()).blue1.getValue()).intValue(), 255);
/*     */     
/*  61 */     RenderUtil.drawRect((this.x - 1), this.y - 2.5F, (this.x + this.width + 1), (this.y + this.height - 6), color);
/*  62 */     RenderUtil.drawTriangle(getX() - 0.5F, getY() + 5.0F, 7.75F, 180.0F, color);
/*  63 */     RenderUtil.drawTriangle((getX() + getWidth()) + 0.5F, getY() + 5.0F, 7.75F, 180.0F, color);
/*     */     
/*  65 */     if (this.open) {
/*  66 */       RenderUtil.drawRect((this.x - 1), this.y + 12.5F, (this.x + this.width + 1), (this.y + this.height) + totalItemHeight, ColorUtil.toARGB(((Integer)(Componentik.getINSTANCE()).r.getValue()).intValue(), ((Integer)(Componentik.getINSTANCE()).g.getValue()).intValue(), ((Integer)(Componentik.getINSTANCE()).b.getValue()).intValue(), ((Integer)(Componentik.getINSTANCE()).a.getValue()).intValue()));
/*     */     }
/*  68 */     Charon.textManager.drawStringWithShadow(getName(), (this.x + 5), this.y - 4.0F - Gui.getClickGui().getTextOffset(), -1);
/*  69 */     if (this.open) {
/*  70 */       float y = (getY() + getHeight()) - 3.0F;
/*  71 */       for (Item item : getItems()) {
/*  72 */         if (item.isHidden())
/*  73 */           continue;  item.setLocation(this.x + 2.0F, y);
/*  74 */         item.setWidth(getWidth() - 4);
/*  75 */         item.drawScreen(mouseX, mouseY, partialTicks);
/*  76 */         y += item.getHeight() + 1.5F;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
/*  81 */     if (mouseButton == 0 && isHovering(mouseX, mouseY)) {
/*  82 */       this.x2 = this.x - mouseX;
/*  83 */       this.y2 = this.y - mouseY;
/*  84 */       Gui.getClickGui().getComponents().forEach(component -> {
/*     */             if (component.drag) {
/*     */               component.drag = false;
/*     */             }
/*     */           });
/*  89 */       this.drag = true;
/*     */       return;
/*     */     } 
/*  92 */     if (mouseButton == 1 && isHovering(mouseX, mouseY)) {
/*  93 */       this.open = !this.open;
/*  94 */       mc.func_147118_V().func_147682_a((ISound)PositionedSoundRecord.func_184371_a(SoundEvents.field_187909_gi, 1.0F));
/*     */       return;
/*     */     } 
/*  97 */     if (!this.open) {
/*     */       return;
/*     */     }
/* 100 */     getItems().forEach(item -> item.mouseClicked(mouseX, mouseY, mouseButton));
/*     */   }
/*     */   
/*     */   public void mouseReleased(int mouseX, int mouseY, int releaseButton) {
/* 104 */     if (releaseButton == 0) {
/* 105 */       this.drag = false;
/*     */     }
/* 107 */     if (!this.open) {
/*     */       return;
/*     */     }
/* 110 */     getItems().forEach(item -> item.mouseReleased(mouseX, mouseY, releaseButton));
/*     */   }
/*     */   
/*     */   public void onKeyTyped(char typedChar, int keyCode) {
/* 114 */     if (!this.open) {
/*     */       return;
/*     */     }
/* 117 */     getItems().forEach(item -> item.onKeyTyped(typedChar, keyCode));
/*     */   }
/*     */   
/*     */   public void addButton(Button button) {
/* 121 */     this.items.add(button);
/*     */   }
/*     */   
/*     */   public int getX() {
/* 125 */     return this.x;
/*     */   }
/*     */   
/*     */   public void setX(int x) {
/* 129 */     this.x = x;
/*     */   }
/*     */   
/*     */   public int getY() {
/* 133 */     return this.y;
/*     */   }
/*     */   
/*     */   public void setY(int y) {
/* 137 */     this.y = y;
/*     */   }
/*     */   
/*     */   public int getWidth() {
/* 141 */     return this.width;
/*     */   }
/*     */   
/*     */   public void setWidth(int width) {
/* 145 */     this.width = width;
/*     */   }
/*     */   
/*     */   public int getHeight() {
/* 149 */     return this.height;
/*     */   }
/*     */   
/*     */   public void setHeight(int height) {
/* 153 */     this.height = height;
/*     */   }
/*     */   
/*     */   public boolean isHidden() {
/* 157 */     return this.hidden;
/*     */   }
/*     */   
/*     */   public void setHidden(boolean hidden) {
/* 161 */     this.hidden = hidden;
/*     */   }
/*     */   
/*     */   public boolean isOpen() {
/* 165 */     return this.open;
/*     */   }
/*     */   
/*     */   public final ArrayList<Item> getItems() {
/* 169 */     return this.items;
/*     */   }
/*     */   
/*     */   private boolean isHovering(int mouseX, int mouseY) {
/* 173 */     return (mouseX >= getX() && mouseX <= getX() + getWidth() && mouseY >= getY() && mouseY <= getY() + getHeight() - (this.open ? 2 : 0));
/*     */   }
/*     */   
/*     */   private float getTotalItemHeight() {
/* 177 */     float height = 0.0F;
/* 178 */     for (Item item : getItems()) {
/* 179 */       height += item.getHeight() + 1.5F;
/*     */     }
/* 181 */     return height;
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/gui/components/Component.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */