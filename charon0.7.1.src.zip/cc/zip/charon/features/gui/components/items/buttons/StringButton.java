/*     */ package cc.zip.charon.features.gui.components.items.buttons;
/*     */ 
/*     */ import cc.zip.charon.Charon;
/*     */ import cc.zip.charon.features.gui.Gui;
/*     */ import cc.zip.charon.features.modules.client.ClickGui;
/*     */ import cc.zip.charon.features.setting.Setting;
/*     */ import cc.zip.charon.util.RenderUtil;
/*     */ import com.mojang.realmsclient.gui.ChatFormatting;
/*     */ import net.minecraft.client.audio.ISound;
/*     */ import net.minecraft.client.audio.PositionedSoundRecord;
/*     */ import net.minecraft.init.SoundEvents;
/*     */ import net.minecraft.util.ChatAllowedCharacters;
/*     */ 
/*     */ public class StringButton extends Button {
/*     */   private final Setting setting;
/*     */   public boolean isListening;
/*  17 */   private CurrentString currentString = new CurrentString("");
/*     */   
/*     */   public StringButton(Setting setting) {
/*  20 */     super(setting.getName());
/*  21 */     this.setting = setting;
/*  22 */     this.width = 15;
/*     */   }
/*     */   
/*     */   public static String removeLastChar(String str) {
/*  26 */     String output = "";
/*  27 */     if (str != null && str.length() > 0) {
/*  28 */       output = str.substring(0, str.length() - 1);
/*     */     }
/*  30 */     return output;
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
/*  35 */     RenderUtil.drawRect(this.x, this.y, this.x + this.width + 7.4F, this.y + this.height - 0.5F, getState() ? (!isHovering(mouseX, mouseY) ? Charon.colorManager.getColorWithAlpha(((Integer)((ClickGui)Charon.moduleManager.getModuleByClass(ClickGui.class)).hoverAlpha.getValue()).intValue()) : Charon.colorManager.getColorWithAlpha(((Integer)((ClickGui)Charon.moduleManager.getModuleByClass(ClickGui.class)).alpha.getValue()).intValue())) : (!isHovering(mouseX, mouseY) ? 290805077 : -2007673515));
/*  36 */     if (this.isListening) {
/*  37 */       Charon.textManager.drawStringWithShadow(this.currentString.getString() + Charon.textManager.getIdleSign(), this.x + 2.3F, this.y - 1.7F - Gui.getClickGui().getTextOffset(), getState() ? -1 : -5592406);
/*     */     } else {
/*  39 */       Charon.textManager.drawStringWithShadow((this.setting.getName().equals("Buttons") ? "Buttons " : (this.setting.getName().equals("Prefix") ? ("Prefix  " + ChatFormatting.GRAY) : "")) + this.setting.getValue(), this.x + 2.3F, this.y - 1.7F - Gui.getClickGui().getTextOffset(), getState() ? -1 : -5592406);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
/*  45 */     super.mouseClicked(mouseX, mouseY, mouseButton);
/*  46 */     if (isHovering(mouseX, mouseY)) {
/*  47 */       mc.func_147118_V().func_147682_a((ISound)PositionedSoundRecord.func_184371_a(SoundEvents.field_187909_gi, 1.0F));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void onKeyTyped(char typedChar, int keyCode) {
/*  53 */     if (this.isListening) {
/*  54 */       switch (keyCode) {
/*     */         case 1:
/*     */           return;
/*     */         
/*     */         case 28:
/*  59 */           enterString();
/*     */         
/*     */         case 14:
/*  62 */           setString(removeLastChar(this.currentString.getString()));
/*     */           break;
/*     */       } 
/*  65 */       if (ChatAllowedCharacters.func_71566_a(typedChar)) {
/*  66 */         setString(this.currentString.getString() + typedChar);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void update() {
/*  73 */     setHidden(!this.setting.isVisible());
/*     */   }
/*     */   
/*     */   private void enterString() {
/*  77 */     if (this.currentString.getString().isEmpty()) {
/*  78 */       this.setting.setValue(this.setting.getDefaultValue());
/*     */     } else {
/*  80 */       this.setting.setValue(this.currentString.getString());
/*     */     } 
/*  82 */     setString("");
/*  83 */     onMouseClick();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getHeight() {
/*  88 */     return 14;
/*     */   }
/*     */ 
/*     */   
/*     */   public void toggle() {
/*  93 */     this.isListening = !this.isListening;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getState() {
/*  98 */     return !this.isListening;
/*     */   }
/*     */   
/*     */   public void setString(String newString) {
/* 102 */     this.currentString = new CurrentString(newString);
/*     */   }
/*     */   
/*     */   public static class CurrentString {
/*     */     private final String string;
/*     */     
/*     */     public CurrentString(String string) {
/* 109 */       this.string = string;
/*     */     }
/*     */     
/*     */     public String getString() {
/* 113 */       return this.string;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/gui/components/items/buttons/StringButton.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */