/*    */ package cc.zip.charon.features.gui.components.items.buttons;
/*    */ 
/*    */ import cc.zip.charon.Charon;
/*    */ import cc.zip.charon.features.gui.Gui;
/*    */ import cc.zip.charon.features.modules.client.ClickGui;
/*    */ import cc.zip.charon.features.setting.Bind;
/*    */ import cc.zip.charon.features.setting.Setting;
/*    */ import cc.zip.charon.util.ColorUtil;
/*    */ import cc.zip.charon.util.RenderUtil;
/*    */ import com.mojang.realmsclient.gui.ChatFormatting;
/*    */ import net.minecraft.client.audio.ISound;
/*    */ import net.minecraft.client.audio.PositionedSoundRecord;
/*    */ import net.minecraft.init.SoundEvents;
/*    */ 
/*    */ public class BindButton extends Button {
/*    */   private final Setting setting;
/*    */   public boolean isListening;
/*    */   
/*    */   public BindButton(Setting setting) {
/* 20 */     super(setting.getName());
/* 21 */     this.setting = setting;
/* 22 */     this.width = 15;
/*    */   }
/*    */ 
/*    */   
/*    */   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
/* 27 */     int color = ColorUtil.toARGB(((Integer)(ClickGui.getInstance()).red.getValue()).intValue(), ((Integer)(ClickGui.getInstance()).green.getValue()).intValue(), ((Integer)(ClickGui.getInstance()).blue.getValue()).intValue(), 255);
/* 28 */     RenderUtil.drawRect(this.x, this.y, this.x + this.width + 7.4F, this.y + this.height - 0.5F, getState() ? (!isHovering(mouseX, mouseY) ? 290805077 : -2007673515) : (!isHovering(mouseX, mouseY) ? Charon.colorManager.getColorWithAlpha(((Integer)((ClickGui)Charon.moduleManager.getModuleByClass(ClickGui.class)).hoverAlpha.getValue()).intValue()) : Charon.colorManager.getColorWithAlpha(((Integer)((ClickGui)Charon.moduleManager.getModuleByClass(ClickGui.class)).alpha.getValue()).intValue())));
/* 29 */     if (this.isListening) {
/* 30 */       Charon.textManager.drawStringWithShadow("Press a Key...", this.x + 2.3F, this.y - 1.7F - Gui.getClickGui().getTextOffset(), -1);
/*    */     } else {
/* 32 */       Charon.textManager.drawStringWithShadow(this.setting.getName() + " " + ChatFormatting.GRAY + this.setting.getValue().toString().toUpperCase(), this.x + 2.3F, this.y - 1.7F - Gui.getClickGui().getTextOffset(), getState() ? -1 : -5592406);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void update() {
/* 38 */     setHidden(!this.setting.isVisible());
/*    */   }
/*    */ 
/*    */   
/*    */   public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
/* 43 */     super.mouseClicked(mouseX, mouseY, mouseButton);
/* 44 */     if (isHovering(mouseX, mouseY)) {
/* 45 */       mc.func_147118_V().func_147682_a((ISound)PositionedSoundRecord.func_184371_a(SoundEvents.field_187909_gi, 1.0F));
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void onKeyTyped(char typedChar, int keyCode) {
/* 51 */     if (this.isListening) {
/* 52 */       Bind bind = new Bind(keyCode);
/* 53 */       if (bind.toString().equalsIgnoreCase("Escape")) {
/*    */         return;
/*    */       }
/* 56 */       if (bind.toString().equalsIgnoreCase("Delete")) {
/* 57 */         bind = new Bind(-1);
/*    */       }
/* 59 */       this.setting.setValue(bind);
/* 60 */       onMouseClick();
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public int getHeight() {
/* 66 */     return 14;
/*    */   }
/*    */ 
/*    */   
/*    */   public void toggle() {
/* 71 */     this.isListening = !this.isListening;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean getState() {
/* 76 */     return !this.isListening;
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/gui/components/items/buttons/BindButton.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */