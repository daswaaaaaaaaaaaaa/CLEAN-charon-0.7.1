/*    */ package cc.zip.charon.features.gui.components.items.buttons;
/*    */ 
/*    */ import cc.zip.charon.Charon;
/*    */ import cc.zip.charon.features.gui.Gui;
/*    */ import cc.zip.charon.features.gui.components.Component;
/*    */ import cc.zip.charon.features.gui.components.items.Item;
/*    */ import cc.zip.charon.features.modules.client.ClickGui;
/*    */ import cc.zip.charon.util.RenderUtil;
/*    */ import net.minecraft.client.audio.ISound;
/*    */ import net.minecraft.client.audio.PositionedSoundRecord;
/*    */ import net.minecraft.init.SoundEvents;
/*    */ 
/*    */ public class Button extends Item {
/*    */   private boolean state;
/*    */   
/*    */   public Button(String name) {
/* 17 */     super(name);
/* 18 */     this.height = 15;
/*    */   }
/*    */ 
/*    */   
/*    */   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
/* 23 */     RenderUtil.drawRect(this.x, this.y, this.x + this.width, this.y + this.height - 0.5F, getState() ? (!isHovering(mouseX, mouseY) ? Charon.colorManager.getColorWithAlpha(((Integer)((ClickGui)Charon.moduleManager.getModuleByClass(ClickGui.class)).hoverAlpha.getValue()).intValue()) : Charon.colorManager.getColorWithAlpha(((Integer)((ClickGui)Charon.moduleManager.getModuleByClass(ClickGui.class)).alpha.getValue()).intValue())) : (!isHovering(mouseX, mouseY) ? 290805077 : -2007673515));
/* 24 */     Charon.textManager.drawStringWithShadow(getName(), this.x + 2.3F, this.y - 2.0F - Gui.getClickGui().getTextOffset(), getState() ? -1 : -5592406);
/*    */   }
/*    */ 
/*    */   
/*    */   public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
/* 29 */     if (mouseButton == 0 && isHovering(mouseX, mouseY)) {
/* 30 */       onMouseClick();
/*    */     }
/*    */   }
/*    */   
/*    */   public void onMouseClick() {
/* 35 */     this.state = !this.state;
/* 36 */     toggle();
/* 37 */     mc.func_147118_V().func_147682_a((ISound)PositionedSoundRecord.func_184371_a(SoundEvents.field_187909_gi, 1.0F));
/*    */   }
/*    */ 
/*    */   
/*    */   public void toggle() {}
/*    */   
/*    */   public boolean getState() {
/* 44 */     return this.state;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getHeight() {
/* 49 */     return 14;
/*    */   }
/*    */   
/*    */   public boolean isHovering(int mouseX, int mouseY) {
/* 53 */     for (Component component : Gui.getClickGui().getComponents()) {
/* 54 */       if (!component.drag)
/* 55 */         continue;  return false;
/*    */     } 
/* 57 */     return (mouseX >= getX() && mouseX <= getX() + getWidth() && mouseY >= getY() && mouseY <= getY() + this.height);
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/gui/components/items/buttons/Button.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */