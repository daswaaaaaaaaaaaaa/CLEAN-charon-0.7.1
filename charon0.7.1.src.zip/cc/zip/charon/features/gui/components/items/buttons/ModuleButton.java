/*     */ package cc.zip.charon.features.gui.components.items.buttons;
/*     */ 
/*     */ import cc.zip.charon.features.gui.Gui;
/*     */ import cc.zip.charon.features.gui.components.Component;
/*     */ import cc.zip.charon.features.gui.components.items.Item;
/*     */ import cc.zip.charon.features.modules.Module;
/*     */ import cc.zip.charon.features.setting.Setting;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.client.audio.ISound;
/*     */ import net.minecraft.client.audio.PositionedSoundRecord;
/*     */ import net.minecraft.init.SoundEvents;
/*     */ import net.minecraft.util.ResourceLocation;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModuleButton
/*     */   extends Button
/*     */ {
/*     */   private final Module module;
/*  22 */   private final ResourceLocation logo = new ResourceLocation("textures/charon.png");
/*  23 */   private List<Item> items = new ArrayList<>();
/*     */   private boolean subOpen;
/*     */   
/*     */   public ModuleButton(Module module) {
/*  27 */     super(module.getName());
/*  28 */     this.module = module;
/*  29 */     initSettings();
/*     */   }
/*     */   
/*     */   public static void drawCompleteImage(float posX, float posY, int width, int height) {
/*  33 */     GL11.glPushMatrix();
/*  34 */     GL11.glTranslatef(posX, posY, 0.0F);
/*  35 */     GL11.glBegin(7);
/*  36 */     GL11.glTexCoord2f(0.0F, 0.0F);
/*  37 */     GL11.glVertex3f(0.0F, 0.0F, 0.0F);
/*  38 */     GL11.glTexCoord2f(0.0F, 1.0F);
/*  39 */     GL11.glVertex3f(0.0F, height, 0.0F);
/*  40 */     GL11.glTexCoord2f(1.0F, 1.0F);
/*  41 */     GL11.glVertex3f(width, height, 0.0F);
/*  42 */     GL11.glTexCoord2f(1.0F, 0.0F);
/*  43 */     GL11.glVertex3f(width, 0.0F, 0.0F);
/*  44 */     GL11.glEnd();
/*  45 */     GL11.glPopMatrix();
/*     */   }
/*     */   
/*     */   public void initSettings() {
/*  49 */     ArrayList<Item> newItems = new ArrayList<>();
/*  50 */     if (!this.module.getSettings().isEmpty()) {
/*  51 */       for (Setting setting : this.module.getSettings()) {
/*  52 */         if (setting.getValue() instanceof Boolean && !setting.getName().equals("Enabled")) {
/*  53 */           newItems.add(new BooleanButton(setting));
/*     */         }
/*  55 */         if (setting.getValue() instanceof cc.zip.charon.features.setting.Bind && !setting.getName().equalsIgnoreCase("Keybind") && !this.module.getName().equalsIgnoreCase("Hud")) {
/*  56 */           newItems.add(new BindButton(setting));
/*     */         }
/*  58 */         if ((setting.getValue() instanceof String || setting.getValue() instanceof Character) && !setting.getName().equalsIgnoreCase("displayName")) {
/*  59 */           newItems.add(new StringButton(setting));
/*     */         }
/*  61 */         if (setting.isNumberSetting() && setting.hasRestriction()) {
/*  62 */           newItems.add(new Slider(setting));
/*     */           continue;
/*     */         } 
/*  65 */         if (!setting.isEnumSetting())
/*  66 */           continue;  newItems.add(new EnumButton(setting));
/*     */       } 
/*     */     }
/*  69 */     newItems.add(new BindButton(this.module.getSettingByName("Keybind")));
/*  70 */     this.items = newItems;
/*     */   }
/*     */ 
/*     */   
/*     */   public void drawScreen(int mouseX, int mouseY, float partialTicks) {
/*  75 */     super.drawScreen(mouseX, mouseY, partialTicks);
/*  76 */     if (!this.items.isEmpty()) {
/*  77 */       mc.func_110434_K().func_110577_a(this.logo);
/*  78 */       drawCompleteImage(this.x - 1.5F + this.width - 7.4F, this.y - 2.2F - Gui.getClickGui().getTextOffset(), 8, 8);
/*     */     } 
/*     */     
/*  81 */     if (this.subOpen) {
/*  82 */       float height = 1.0F;
/*  83 */       for (Item item : this.items) {
/*  84 */         Component.counter1[0] = Component.counter1[0] + 1;
/*  85 */         if (!item.isHidden()) {
/*  86 */           item.setLocation(this.x + 2.0F, this.y + (height += 15.0F));
/*  87 */           item.setHeight(15);
/*  88 */           item.setWidth(this.width - 10);
/*  89 */           item.drawScreen(mouseX, mouseY, partialTicks);
/*     */         } 
/*  91 */         item.update();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
/*  98 */     super.mouseClicked(mouseX, mouseY, mouseButton);
/*  99 */     if (!this.items.isEmpty()) {
/* 100 */       if (mouseButton == 1 && isHovering(mouseX, mouseY)) {
/* 101 */         this.subOpen = !this.subOpen;
/* 102 */         mc.func_147118_V().func_147682_a((ISound)PositionedSoundRecord.func_184371_a(SoundEvents.field_187909_gi, 1.0F));
/*     */       } 
/* 104 */       if (this.subOpen) {
/* 105 */         for (Item item : this.items) {
/* 106 */           if (item.isHidden())
/* 107 */             continue;  item.mouseClicked(mouseX, mouseY, mouseButton);
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onKeyTyped(char typedChar, int keyCode) {
/* 115 */     super.onKeyTyped(typedChar, keyCode);
/* 116 */     if (!this.items.isEmpty() && this.subOpen) {
/* 117 */       for (Item item : this.items) {
/* 118 */         if (item.isHidden())
/* 119 */           continue;  item.onKeyTyped(typedChar, keyCode);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public int getHeight() {
/* 126 */     if (this.subOpen) {
/* 127 */       int height = 14;
/* 128 */       for (Item item : this.items) {
/* 129 */         if (item.isHidden())
/* 130 */           continue;  height += item.getHeight() + 1;
/*     */       } 
/* 132 */       return height + 2;
/*     */     } 
/* 134 */     return 14;
/*     */   }
/*     */   
/*     */   public Module getModule() {
/* 138 */     return this.module;
/*     */   }
/*     */ 
/*     */   
/*     */   public void toggle() {
/* 143 */     this.module.toggle();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getState() {
/* 148 */     return this.module.isEnabled();
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/gui/components/items/buttons/ModuleButton.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */