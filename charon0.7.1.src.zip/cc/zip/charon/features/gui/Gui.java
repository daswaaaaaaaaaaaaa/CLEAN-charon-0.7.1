/*     */ package cc.zip.charon.features.gui;
/*     */ 
/*     */ import cc.zip.charon.Charon;
/*     */ import cc.zip.charon.features.Feature;
/*     */ import cc.zip.charon.features.gui.components.Component;
/*     */ import cc.zip.charon.features.gui.components.items.Item;
/*     */ import cc.zip.charon.features.gui.components.items.buttons.Button;
/*     */ import cc.zip.charon.features.gui.components.items.buttons.ModuleButton;
/*     */ import cc.zip.charon.features.modules.Module;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import net.minecraft.client.gui.GuiScreen;
/*     */ import org.lwjgl.input.Mouse;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Gui
/*     */   extends GuiScreen
/*     */ {
/*     */   private static Gui charonGui;
/*  23 */   private static Gui INSTANCE = new Gui();
/*     */ 
/*     */   
/*  26 */   private final ArrayList<Component> components = new ArrayList<>();
/*     */   
/*     */   public Gui() {
/*  29 */     setInstance();
/*  30 */     load();
/*     */   }
/*     */   
/*     */   public static Gui getInstance() {
/*  34 */     if (INSTANCE == null) {
/*  35 */       INSTANCE = new Gui();
/*     */     }
/*  37 */     return INSTANCE;
/*     */   }
/*     */   
/*     */   public static Gui getClickGui() {
/*  41 */     return getInstance();
/*     */   }
/*     */   
/*     */   private void setInstance() {
/*  45 */     INSTANCE = this;
/*     */   }
/*     */   
/*     */   private void load() {
/*  49 */     int x = -84;
/*  50 */     for (Module.Category category : Charon.moduleManager.getCategories()) {
/*  51 */       x += 90; this.components.add(new Component(category.getName(), x, 4, true)
/*     */           {
/*     */             public void setupItems()
/*     */             {
/*  55 */               counter1 = new int[] { 1 };
/*  56 */               Charon.moduleManager.getModulesByCategory(category).forEach(module -> {
/*     */                     if (!module.hidden) {
/*     */                       addButton((Button)new ModuleButton(module));
/*     */                     }
/*     */                   });
/*     */             }
/*     */           });
/*     */     } 
/*  64 */     this.components.forEach(components -> components.getItems().sort(Comparator.comparing(Feature::getName)));
/*     */   }
/*     */   
/*     */   public void updateModule(Module module) {
/*  68 */     for (Component component : this.components) {
/*  69 */       for (Item item : component.getItems()) {
/*  70 */         if (!(item instanceof ModuleButton))
/*  71 */           continue;  ModuleButton button = (ModuleButton)item;
/*  72 */         Module mod = button.getModule();
/*  73 */         if (module == null || !module.equals(mod))
/*  74 */           continue;  button.initSettings();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
/*  80 */     checkMouseWheel();
/*     */     
/*  82 */     this.components.forEach(components -> components.drawScreen(mouseX, mouseY, partialTicks));
/*     */   }
/*     */   
/*     */   public void func_73864_a(int mouseX, int mouseY, int clickedButton) {
/*  86 */     this.components.forEach(components -> components.mouseClicked(mouseX, mouseY, clickedButton));
/*     */   }
/*     */   
/*     */   public void func_146286_b(int mouseX, int mouseY, int releaseButton) {
/*  90 */     this.components.forEach(components -> components.mouseReleased(mouseX, mouseY, releaseButton));
/*     */   }
/*     */   
/*     */   public boolean func_73868_f() {
/*  94 */     return false;
/*     */   }
/*     */   
/*     */   public final ArrayList<Component> getComponents() {
/*  98 */     return this.components;
/*     */   }
/*     */   
/*     */   public void checkMouseWheel() {
/* 102 */     int dWheel = Mouse.getDWheel();
/* 103 */     if (dWheel < 0) {
/* 104 */       this.components.forEach(component -> component.setY(component.getY() - 10));
/* 105 */     } else if (dWheel > 0) {
/* 106 */       this.components.forEach(component -> component.setY(component.getY() + 10));
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getTextOffset() {
/* 111 */     return -6;
/*     */   }
/*     */   
/*     */   public Component getComponentByName(String name) {
/* 115 */     for (Component component : this.components) {
/* 116 */       if (!component.getName().equalsIgnoreCase(name))
/* 117 */         continue;  return component;
/*     */     } 
/* 119 */     return null;
/*     */   }
/*     */   
/*     */   public void func_146281_b() {
/*     */     try {
/* 124 */       super.func_146281_b();
/* 125 */       Charon.moduleManager.getModuleByName("ClickGui").disable();
/*     */       
/* 127 */       this.field_146297_k.field_71460_t.func_147706_e().func_148021_a();
/* 128 */     } catch (Exception e) {
/* 129 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   public void func_73869_a(char typedChar, int keyCode) throws IOException {
/* 133 */     super.func_73869_a(typedChar, keyCode);
/* 134 */     this.components.forEach(component -> component.onKeyTyped(typedChar, keyCode));
/*     */   }
/*     */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/gui/Gui.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */