/*    */ package cc.zip.charon.features;
/*    */ 
/*    */ import cc.zip.charon.Charon;
/*    */ import cc.zip.charon.features.gui.Gui;
/*    */ import cc.zip.charon.features.modules.Module;
/*    */ import cc.zip.charon.features.setting.Setting;
/*    */ import cc.zip.charon.manager.TextManager;
/*    */ import cc.zip.charon.util.Util;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class Feature
/*    */   implements Util
/*    */ {
/* 15 */   public List<Setting> settings = new ArrayList<>();
/* 16 */   public TextManager renderer = Charon.textManager;
/*    */   
/*    */   private String name;
/*    */   
/*    */   public Feature() {}
/*    */   
/*    */   public Feature(String name) {
/* 23 */     this.name = name;
/*    */   }
/*    */   
/*    */   public static boolean nullCheck() {
/* 27 */     return (mc.field_71439_g == null);
/*    */   }
/*    */   
/*    */   public static boolean fullNullCheck() {
/* 31 */     return (mc.field_71439_g == null || mc.field_71441_e == null);
/*    */   }
/*    */   
/*    */   public String getName() {
/* 35 */     return this.name;
/*    */   }
/*    */   
/*    */   public List<Setting> getSettings() {
/* 39 */     return this.settings;
/*    */   }
/*    */   
/*    */   public boolean hasSettings() {
/* 43 */     return !this.settings.isEmpty();
/*    */   }
/*    */   
/*    */   public boolean isEnabled() {
/* 47 */     if (this instanceof Module) {
/* 48 */       return ((Module)this).isOn();
/*    */     }
/* 50 */     return false;
/*    */   }
/*    */   
/*    */   public boolean isDisabled() {
/* 54 */     return !isEnabled();
/*    */   }
/*    */   
/*    */   public Setting register(Setting setting) {
/* 58 */     setting.setFeature(this);
/* 59 */     this.settings.add(setting);
/* 60 */     if (this instanceof Module && mc.field_71462_r instanceof Gui) {
/* 61 */       Gui.getInstance().updateModule((Module)this);
/*    */     }
/* 63 */     return setting;
/*    */   }
/*    */   
/*    */   public void unregister(Setting settingIn) {
/* 67 */     ArrayList<Setting> removeList = new ArrayList<>();
/* 68 */     for (Setting setting : this.settings) {
/* 69 */       if (!setting.equals(settingIn))
/* 70 */         continue;  removeList.add(setting);
/*    */     } 
/* 72 */     if (!removeList.isEmpty()) {
/* 73 */       this.settings.removeAll(removeList);
/*    */     }
/* 75 */     if (this instanceof Module && mc.field_71462_r instanceof Gui) {
/* 76 */       Gui.getInstance().updateModule((Module)this);
/*    */     }
/*    */   }
/*    */   
/*    */   public Setting getSettingByName(String name) {
/* 81 */     for (Setting setting : this.settings) {
/* 82 */       if (!setting.getName().equalsIgnoreCase(name))
/* 83 */         continue;  return setting;
/*    */     } 
/* 85 */     return null;
/*    */   }
/*    */   
/*    */   public void reset() {
/* 89 */     for (Setting setting : this.settings) {
/* 90 */       setting.setValue(setting.getDefaultValue());
/*    */     }
/*    */   }
/*    */   
/*    */   public void clearSettings() {
/* 95 */     this.settings = new ArrayList<>();
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/Feature.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */