/*    */ package cc.zip.charon.features.command.commands;
/*    */ 
/*    */ import cc.zip.charon.Charon;
/*    */ import cc.zip.charon.features.command.Command;
/*    */ import com.mojang.realmsclient.gui.ChatFormatting;
/*    */ 
/*    */ public class HelpCommand
/*    */   extends Command {
/*    */   public HelpCommand() {
/* 10 */     super("help");
/*    */   }
/*    */ 
/*    */   
/*    */   public void execute(String[] commands) {
/* 15 */     sendMessage("Commands: ");
/* 16 */     for (Command command : Charon.commandManager.getCommands())
/* 17 */       sendMessage(ChatFormatting.GRAY + Charon.commandManager.getPrefix() + command.getName()); 
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/command/commands/HelpCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */