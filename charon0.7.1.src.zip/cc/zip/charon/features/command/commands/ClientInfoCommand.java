/*    */ package cc.zip.charon.features.command.commands;
/*    */ 
/*    */ import cc.zip.charon.Charon;
/*    */ import cc.zip.charon.features.command.Command;
/*    */ import com.mojang.realmsclient.gui.ChatFormatting;
/*    */ 
/*    */ public class ClientInfoCommand
/*    */   extends Command {
/*    */   public ClientInfoCommand() {
/* 10 */     super("info");
/*    */   }
/*    */ 
/*    */   
/*    */   public void execute(String[] commands) {
/* 15 */     HelpCommand.sendMessage("Commands: ");
/* 16 */     HelpCommand.sendMessage(ChatFormatting.GRAY + "Prefix: " + Charon.commandManager.getPrefix());
/* 17 */     HelpCommand.sendMessage(ChatFormatting.GRAY + "Client Name: " + "charon.eu");
/* 18 */     HelpCommand.sendMessage(ChatFormatting.GRAY + "Client Version: " + "0.6.1");
/* 19 */     HelpCommand.sendMessage(ChatFormatting.GRAY + "Client Modid: " + "charon");
/* 20 */     HelpCommand.sendMessage(ChatFormatting.GRAY + "Self Name: " + mc.field_71439_g.func_70005_c_());
/* 21 */     HelpCommand.sendMessage(ChatFormatting.GRAY + "Coords: " + mc.field_71439_g.field_70165_t + " " + mc.field_71439_g.field_70163_u + " " + mc.field_71439_g.field_70161_v);
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/command/commands/ClientInfoCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */