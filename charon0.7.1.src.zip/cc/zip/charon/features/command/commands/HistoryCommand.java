/*    */ package cc.zip.charon.features.command.commands;
/*    */ 
/*    */ import cc.zip.charon.features.command.Command;
/*    */ import cc.zip.charon.util.PlayerUtil;
/*    */ import com.mojang.realmsclient.gui.ChatFormatting;
/*    */ import java.util.List;
/*    */ import java.util.UUID;
/*    */ 
/*    */ public class HistoryCommand
/*    */   extends Command
/*    */ {
/*    */   public HistoryCommand() {
/* 13 */     super("history", new String[] { "<player>" });
/*    */   }
/*    */ 
/*    */   
/*    */   public void execute(String[] commands) {
/*    */     List<String> names;
/*    */     UUID uuid;
/* 20 */     if (commands.length == 1 || commands.length == 0) {
/* 21 */       sendMessage(ChatFormatting.RED + "Please specify a player.");
/*    */     }
/*    */     try {
/* 24 */       uuid = PlayerUtil.getUUIDFromName(commands[0]);
/* 25 */     } catch (Exception e) {
/* 26 */       sendMessage("An error occured.");
/*    */       return;
/*    */     } 
/*    */     try {
/* 30 */       names = PlayerUtil.getHistoryOfNames(uuid);
/* 31 */     } catch (Exception e) {
/* 32 */       sendMessage("An error occured.");
/*    */       return;
/*    */     } 
/* 35 */     if (names != null) {
/* 36 */       sendMessage(commands[0] + "Â´s name history:");
/* 37 */       for (String name : names) {
/* 38 */         sendMessage(name);
/*    */       }
/*    */     } else {
/* 41 */       sendMessage("No names found.");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/command/commands/HistoryCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */