/*    */ package cc.zip.charon.features.command.commands;
/*    */ 
/*    */ import cc.zip.charon.Charon;
/*    */ import cc.zip.charon.features.command.Command;
/*    */ import com.mojang.realmsclient.gui.ChatFormatting;
/*    */ import java.io.File;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.stream.Collectors;
/*    */ 
/*    */ public class ConfigCommand
/*    */   extends Command {
/*    */   public ConfigCommand() {
/* 14 */     super("config", new String[] { "<save/load>" });
/*    */   }
/*    */   
/*    */   public void execute(String[] commands) {
/* 18 */     if (commands.length == 1) {
/* 19 */       sendMessage("You`ll find the config files in your gameProfile directory under charon/config");
/*    */       return;
/*    */     } 
/* 22 */     if (commands.length == 2)
/* 23 */       if ("list".equals(commands[0])) {
/* 24 */         String configs = "Configs: ";
/* 25 */         File file = new File("charon/");
/* 26 */         List<File> directories = (List<File>)Arrays.<File>stream(file.listFiles()).filter(File::isDirectory).filter(f -> !f.getName().equals("util")).collect(Collectors.toList());
/* 27 */         StringBuilder builder = new StringBuilder(configs);
/* 28 */         for (File file1 : directories)
/* 29 */           builder.append(file1.getName() + ", "); 
/* 30 */         configs = builder.toString();
/* 31 */         sendMessage(configs);
/*    */       } else {
/* 33 */         sendMessage("Not a valid command... Possible usage: <list>");
/*    */       }  
/* 35 */     if (commands.length >= 3) {
/* 36 */       switch (commands[0]) {
/*    */         case "save":
/* 38 */           Charon.configManager.saveConfig(commands[1]);
/* 39 */           sendMessage(ChatFormatting.GREEN + "Config '" + commands[1] + "' has been saved.");
/*    */           return;
/*    */         case "load":
/* 42 */           if (Charon.configManager.configExists(commands[1])) {
/* 43 */             Charon.configManager.loadConfig(commands[1]);
/* 44 */             sendMessage(ChatFormatting.GREEN + "Config '" + commands[1] + "' has been loaded.");
/*    */           } else {
/* 46 */             sendMessage(ChatFormatting.RED + "Config '" + commands[1] + "' does not exist.");
/*    */           } 
/*    */           return;
/*    */       } 
/* 50 */       sendMessage("Not a valid command... Possible usage: <save/load>");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/command/commands/ConfigCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */