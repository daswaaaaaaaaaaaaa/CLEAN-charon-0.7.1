/*    */ package cc.zip.charon.features.command.commands;
/*    */ 
/*    */ import cc.zip.charon.Charon;
/*    */ import cc.zip.charon.features.command.Command;
/*    */ import cc.zip.charon.manager.FriendManager;
/*    */ import com.mojang.realmsclient.gui.ChatFormatting;
/*    */ 
/*    */ public class FriendCommand
/*    */   extends Command {
/*    */   public FriendCommand() {
/* 11 */     super("friend", new String[] { "<add/del/name/clear>", "<name>" });
/*    */   }
/*    */ 
/*    */   
/*    */   public void execute(String[] commands) {
/* 16 */     if (commands.length == 1) {
/* 17 */       if (Charon.friendManager.getFriends().isEmpty()) {
/* 18 */         sendMessage("Friend list empty D:.");
/*    */       } else {
/* 20 */         String f = "Friends: ";
/* 21 */         for (FriendManager.Friend friend : Charon.friendManager.getFriends()) {
/*    */           try {
/* 23 */             f = f + friend.getUsername() + ", ";
/* 24 */           } catch (Exception exception) {}
/*    */         } 
/*    */         
/* 27 */         sendMessage(f);
/*    */       } 
/*    */       return;
/*    */     } 
/* 31 */     if (commands.length == 2) {
/* 32 */       switch (commands[0]) {
/*    */         case "reset":
/* 34 */           Charon.friendManager.onLoad();
/* 35 */           sendMessage("Friends got reset.");
/*    */           return;
/*    */       } 
/*    */       
/* 39 */       sendMessage(commands[0] + (Charon.friendManager.isFriend(commands[0]) ? " is friended." : " isn't friended."));
/*    */       return;
/*    */     } 
/* 42 */     if (commands.length >= 2) {
/* 43 */       switch (commands[0]) {
/*    */         case "add":
/* 45 */           Charon.friendManager.addFriend(commands[1]);
/* 46 */           sendMessage(ChatFormatting.GREEN + commands[1] + " has been friended");
/*    */           return;
/*    */         
/*    */         case "del":
/* 50 */           Charon.friendManager.removeFriend(commands[1]);
/* 51 */           sendMessage(ChatFormatting.RED + commands[1] + " has been unfriended");
/*    */           return;
/*    */       } 
/*    */       
/* 55 */       sendMessage("Unknown Command, try friend add/del (name)");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/command/commands/FriendCommand.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */