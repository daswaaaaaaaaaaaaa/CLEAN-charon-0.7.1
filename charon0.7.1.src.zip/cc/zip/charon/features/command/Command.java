/*    */ package cc.zip.charon.features.command;
/*    */ 
/*    */ import cc.zip.charon.Charon;
/*    */ import cc.zip.charon.features.Feature;
/*    */ import com.mojang.realmsclient.gui.ChatFormatting;
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ import net.minecraft.util.text.ITextComponent;
/*    */ import net.minecraft.util.text.TextComponentBase;
/*    */ 
/*    */ public abstract class Command
/*    */   extends Feature
/*    */ {
/*    */   protected String name;
/*    */   protected String[] commands;
/*    */   
/*    */   public Command(String name) {
/* 18 */     super(name);
/* 19 */     this.name = name;
/* 20 */     this.commands = new String[] { "" };
/*    */   }
/*    */   
/*    */   public Command(String name, String[] commands) {
/* 24 */     super(name);
/* 25 */     this.name = name;
/* 26 */     this.commands = commands;
/*    */   }
/*    */   
/*    */   public static void sendMessage(String message) {
/* 30 */     sendSilentMessage(Charon.commandManager.getClientMessage() + " " + ChatFormatting.GRAY + message);
/*    */   }
/*    */   
/*    */   public static void sendSilentMessage(String message) {
/* 34 */     if (nullCheck()) {
/*    */       return;
/*    */     }
/* 37 */     mc.field_71439_g.func_145747_a((ITextComponent)new ChatMessage(message));
/*    */   }
/*    */   
/*    */   public static String getCommandPrefix() {
/* 41 */     return Charon.commandManager.getPrefix();
/*    */   }
/*    */ 
/*    */   
/*    */   public abstract void execute(String[] paramArrayOfString);
/*    */   
/*    */   public String getName() {
/* 48 */     return this.name;
/*    */   }
/*    */   
/*    */   public String[] getCommands() {
/* 52 */     return this.commands;
/*    */   }
/*    */   
/*    */   public static class ChatMessage
/*    */     extends TextComponentBase {
/*    */     private final String text;
/*    */     
/*    */     public ChatMessage(String text) {
/* 60 */       Pattern pattern = Pattern.compile("&[0123456789abcdefrlosmk]");
/* 61 */       Matcher matcher = pattern.matcher(text);
/* 62 */       StringBuffer stringBuffer = new StringBuffer();
/* 63 */       while (matcher.find()) {
/* 64 */         String replacement = matcher.group().substring(1);
/* 65 */         matcher.appendReplacement(stringBuffer, replacement);
/*    */       } 
/* 67 */       matcher.appendTail(stringBuffer);
/* 68 */       this.text = stringBuffer.toString();
/*    */     }
/*    */     
/*    */     public String func_150261_e() {
/* 72 */       return this.text;
/*    */     }
/*    */     
/*    */     public ITextComponent func_150259_f() {
/* 76 */       return null;
/*    */     }
/*    */     
/*    */     public ITextComponent shallowCopy() {
/* 80 */       return (ITextComponent)new ChatMessage(this.text);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/lcheater/Загрузки/charon0.7.1.jar!/cc/zip/charon/features/command/Command.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */